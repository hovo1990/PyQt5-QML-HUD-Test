/*
 * PeregrineItemRing.js
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */


var ring = new Array()

var currentIndex = -1

//////////////////////////////////////////////////////////////////////////////////////////////////////

function count()
{
    return ring.length;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function currentItem()
{
    if( currentIndex > 0 && currentIndex < ring.length )
        return ring[currentIndex]
    else
        return null
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function add( item )
{
    ring.push( item )
    currentIndex = ring.length - 1
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function at( index )
{
    if( ring.length > index )
        return ring[index]
    else
        return null
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function next()
{
    if( ring.length > 0 )
    {
        currentIndex++

        if( currentIndex >= ring.length )
            currentIndex = 0

        return ring[currentIndex]
    }
    else
        return null
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function previous()
{
    if( ring.length > 0 )
    {
        currentIndex--

        if( currentIndex < 0 )
            currentIndex = ring.length - 1

        return ring[currentIndex]
    }
    else
        return null
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function indexOf( prop, value )
{
    if( ring.length > 0 )
    {
        for( var i = 0; i < ring.length; i++ )
        {
            if( ring[i][prop] == value )
                return i
        }
    }

    return -1
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function find( prop, value )
{
    var index = indexOf( prop, value )
    if( index > -1 )
        return ring[index]
    else
        return null
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function removeAt( index )
{
    if( ring.length > index )
    {
        var item = at( index )
        ring.splice( index, 1 )
        item.destroy()

        if( ring.length > index - 1 )
            currentIndex = index - 1
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function remove( prop, value )
{
    var index = indexOf( prop, value )

    if( index > -1 )
        removeAt( index )
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function clear()
{
    if( ring.length > 0 )
    {
        var item
        while ( item = ring.pop() )
        {
            item.destroy();
        }
    }

    currentIndex = - 1
}

//////////////////////////////////////////////////////////////////////////////////////////////////////


