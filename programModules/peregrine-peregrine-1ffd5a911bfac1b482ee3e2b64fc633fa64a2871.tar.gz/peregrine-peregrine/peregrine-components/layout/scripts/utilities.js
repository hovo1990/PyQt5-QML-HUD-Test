.pragma library

function getStatusText( status ) {
    switch( status ) {
        case "available":
            return "Available";

        case "offline":
            return "Offline";

        case "away":
            return "Away";

        case "xa":
            return "Extended Away";

        case "hidden":
            return "Hidden";

        case "busy":
            return "Busy";

        default:
            return "Unknown";
    }
}


function getStatusImage( status ) {
    switch( status ) {
            case "available":
                return "image://peregrinelayoutimages/online";

            case "offline":
                return "image://peregrinelayoutimages/offline";

            case "away":
                return "image://peregrinelayoutimages/away";

            case "xa":
                return "image://peregrinelayoutimages/notavailable";

            case "hidden":
                return "image://peregrinelayoutimages/invisible";

            case "busy":
                return "image://peregrinelayoutimages/notavailable";

        default:
            return "image://peregrinelayoutimages/unknown";
    }
}



function getServiceImage( service ) {
    switch( service ) {
            case "skype":
                return "image://peregrinelayoutimages/skype";

            case "google-talk":
                return "image://peregrinelayoutimages/googletalk";

            case "msn":
                return "image://peregrinelayoutimages/msn";

            case "jabber":
                return "image://peregrinelayoutimages/jabber";

        default:
            return "image://peregrinelayoutimages/unknown";
    }
}


function trim( str ) {
    var str = str.replace(/^\s\s*/, ''),
        ws = /\s/,
        i = str.length;

    while (ws.test(str.charAt(--i)));

    return str.slice(0, i + 1);
}
