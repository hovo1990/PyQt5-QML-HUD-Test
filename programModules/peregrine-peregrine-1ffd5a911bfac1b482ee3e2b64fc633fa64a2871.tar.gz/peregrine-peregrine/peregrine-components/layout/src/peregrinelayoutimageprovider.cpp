/*
* layoutimageprovider.cpp
*
* Copyright (C) 2009-2011 basysKom GmbH
* Copyright (C) 2009-2011 Nokia Corporation
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <QColor>
#include <QDeclarativeEngine>
#include <QFile>
#include <QImageReader>
#include <QPixmap>
#include <QSize>
#include <QString>
#include <QStringList>
#include <QStringListIterator>
#include <QVariant>

#include "peregrinelayoutimageprovider.h"

PeregrineLayoutImageProvider::PeregrineLayoutImageProvider() : QDeclarativeImageProvider( QDeclarativeImageProvider::Pixmap )
{}

PeregrineLayoutImageProvider::~PeregrineLayoutImageProvider()
{}

QPixmap PeregrineLayoutImageProvider::requestPixmap( const QString &id, QSize *size, const QSize &requestedSize )
{
    QPixmap pixmap;

    if( !m_engine )
        return pixmap;

    // load the pixmap if the id is already in the hashtable
    if( m_paths.contains( id ) )
        pixmap = loadPixmap( m_paths.value( id ), requestedSize );

    // either the id wasn't in the hashtable or the pixmap couldn't be loaded from that path
    if( !pixmap )
    {
        QStringList importPaths = m_engine->importPathList();
        QStringListIterator pathIterator( importPaths );

        QString importPath;
        QString imagePath = "Peregrine/Components/Layout/images/";

        QVariant uxName = m_engine->property( "UX" );
        QStringList uxList;

        if( uxName.isValid() )
            uxList << uxName.toString();

        uxList << "default";
        QString ux;
        QStringListIterator uxIterator( uxList );

        QStringList extensionList;
        extensionList << ".png" << ".jpg" << ".svg";
        QString extension;
        QStringListIterator extensionIterator( extensionList );

        while( pathIterator.hasNext() && !pixmap )
        {
            importPath = pathIterator.next();

            if( !importPath.endsWith( "/" ) )
                importPath.append( "/" );

            importPath.append( imagePath );

            uxIterator.toFront();

            while( uxIterator.hasNext() && !pixmap )
            {
                ux = uxIterator.next();
                ux.append( "/" );

                // id may already have a file extension
                if( QFile::exists( importPath + ux + id ) )
                {
                    QString path = importPath + ux + id;

                    pixmap = loadPixmap( path, requestedSize );

                    // put the identified path in the hashtable so we dont have to look it up again
                    m_paths.insert( id, path );
                }
                else
                { // file not found: remove file extension from id  and attach an extension from our extension list, then check again

                    extensionIterator.toFront();
                    while( extensionIterator.hasNext() && !pixmap )
                    {
                        extension = extensionIterator.next();

                        if( QFile::exists( importPath + ux + id.section( '.', 0, 0 ) + extension ) )
                        {
                            QString path = importPath + ux + id.section( '.', 0, 0 ) + extension;

                            pixmap = loadPixmap( path, requestedSize );

                            // put the identified path in the hashtable so we dont have to look it up again
                            m_paths.insert( id, path );
                        }
                    }
                }
            }
        }
    }

     // No image found: return a red pixmap
    if( !pixmap )
    {       
        int width = requestedSize.width() > 0 ? requestedSize.width() : 50;
        int height = requestedSize.height() > 0 ? requestedSize.height() : 50;

        pixmap = QPixmap( width, height) ;

        pixmap.fill( QColor("red").rgba() );
    }

    if( size )
        *size = pixmap.size();

    return pixmap;
}

QPixmap PeregrineLayoutImageProvider::loadPixmap( const QString &path, const QSize &requestedSize )
{
    QImageReader imageReader( path );

    if( requestedSize.isValid() )
        imageReader.setScaledSize( requestedSize );

    return QPixmap::fromImageReader( &imageReader );
}

void PeregrineLayoutImageProvider::setEngine( QDeclarativeEngine *engine )
{
    m_engine = engine;
}

