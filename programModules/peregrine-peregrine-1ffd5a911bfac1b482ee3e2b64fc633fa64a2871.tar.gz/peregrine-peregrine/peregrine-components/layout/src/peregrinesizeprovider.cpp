/*
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#include <QtCore/qmath.h>
#include "peregrinesizeprovider.h"

PeregrineSizeProvider::PeregrineSizeProvider(QObject *parent) :
    QObject(parent)
{
    m_sdinfo = new QSystemDisplayInfo();

    if( !m_sdinfo )
        qFatal( "Couldn't get QSystemDisplayInfo (%s)", __FILE__ );
}

PeregrineSizeProvider::~PeregrineSizeProvider()
{
    if( m_sdinfo )
        delete m_sdinfo;
}

int PeregrineSizeProvider::minimumItemSize() const
{
    // an item should have a size of least 7mm to be easily touchable
    return qCeil( displayDPI() * 7 / 25.4 );
}

int PeregrineSizeProvider::minimumFontSize() const
{
    // a font should have a size of least 2mm to be easily readable
    return qCeil( displayDPI() * 2 / 25.4 );
}

int PeregrineSizeProvider::displayDPI() const
{
    int hdpi = m_sdinfo->getDPIHeight( 0 );
    int vdpi = m_sdinfo->getDPIWidth( 0 );

    if( hdpi < 0 && vdpi < 0 )
    {
        qCritical( "Couldn't get display DPI value (%s)", __FILE__ );
        return 200; // we assume that we have a display similar to a tablet or phone display
    }

    return (int)qMax( hdpi, vdpi );
}
