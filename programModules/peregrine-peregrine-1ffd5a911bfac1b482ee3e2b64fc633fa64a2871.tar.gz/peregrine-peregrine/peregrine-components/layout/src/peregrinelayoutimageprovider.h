/*
* layoutimageprovider.h
*
* Copyright (C) 2009-2011 basysKom GmbH
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef PEREGRINELAYOUTIMAGEPROVIDER_H
#define PEREGRINELAYOUTIMAGEPROVIDER_H

#include <QDeclarativeEngine>
#include <QDeclarativeImageProvider>

class PeregrineLayoutImageProvider : public QDeclarativeImageProvider
{
public:
    PeregrineLayoutImageProvider();
    ~PeregrineLayoutImageProvider();

    QPixmap requestPixmap( const QString &id, QSize *size, const QSize &requestedSize );
    void setEngine( QDeclarativeEngine *engine );

private:
    QPixmap loadPixmap( const QString &path, const QSize &requestedSize );

    QDeclarativeEngine *m_engine;
    QHash <QString,QString> m_paths;
};

#endif // PEREGRINELAYOUTIMAGEPROVIDER_H
