/*
 * commonbridgeimageprovider.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#include "commonbridgeimageprovider.h"

#include <QDir>
#include <QHash>

#ifndef DEFAULT_IMAGE_ASSET_PATH
#  define DEFAULT_IMAGE_ASSET_PATH "/usr/local/peregrine/bridges/common/images"
#endif

class CommonBridgeImageProviderPrivate
{
public:
    QHash<QString, QPixmap> directory;
};

CommonBridgeImageProvider::CommonBridgeImageProvider()
    : QDeclarativeImageProvider(QDeclarativeImageProvider::Pixmap),
      m_privatedata(new CommonBridgeImageProviderPrivate)
{
}

CommonBridgeImageProvider::~CommonBridgeImageProvider()
{
    delete this->m_privatedata;
}

QPixmap CommonBridgeImageProvider::requestPixmap(const QString &id, QSize *size, const QSize &requestedSize)
{
    Q_UNUSED(requestedSize)

    QPixmap asset;

    if(m_privatedata->directory.contains(id))
    {
        asset = m_privatedata->directory.value(id);
    }
    else
    {
        if(asset.load(QDir(DEFAULT_IMAGE_ASSET_PATH).absoluteFilePath(id)))
        {
            m_privatedata->directory.insert(id, asset);
        }
    }

    if(asset.isNull()) return asset;

    if(size) *size = QSize(asset.width(), asset.height());
    return asset;
}
