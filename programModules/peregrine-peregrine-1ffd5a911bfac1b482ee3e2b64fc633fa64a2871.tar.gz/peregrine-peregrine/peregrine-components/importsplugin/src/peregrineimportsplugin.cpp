/*
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <QDeclarativeExtensionPlugin>
#include <QDeclarativeEngine>
#include <QDir>
#include <QProcessEnvironment>
#include <QString>
#include <QStringListIterator>
#include <QDebug>
#include "peregrineimportsplugin.h"

void PeregrineImportsPlugin::registerTypes(const char *uri)
{
    Q_UNUSED( uri );
}

void PeregrineImportsPlugin::initializeEngine( QDeclarativeEngine *engine, const char *uri )
{
    Q_UNUSED( uri );

    // we need to add an import path to the engine so the desired bridge can be used with
    // import Peregrine.Components.Base x.y

    // first we need to remove all paths that already might contain bridged base components
    // as there is only one bridge per engine allowed

    QString baseComponentsPath = "Peregrine/Components/bridges/";
    QStringList bridgeList;

    //check if the property BRIDGESET has been set and put it first into the bridge list
    //to prioritize it if it exists
    QVariant bridgeSetName = engine->property( "BRIDGESET" );
    if( bridgeSetName.isValid() ) {
        bridgeList << bridgeSetName.toString();
    }

    bridgeList << "meegoux" << "qtcomponents" << "common";
    
    // get the import paths
    QStringList importPaths = engine->importPathList();
    QStringListIterator pathIterator( importPaths );
    QString importPath;

    // iterate over paths and remove base components paths
    while( pathIterator.hasNext() )
    {
        importPath = pathIterator.next();
        if( importPath.contains( baseComponentsPath ) )
            engine->importPathList().removeAll( importPath );
    }

    bool foundBridge = false;
    
    foreach (QString bridgeName, bridgeList)
    {	    
        QProcessEnvironment pe = QProcessEnvironment::systemEnvironment();
        QString ux = pe.value( QString::fromLatin1( "PEREGRINE_COMPONENTS_BASE" ), bridgeName );

        pathIterator.toFront();
	
	// look for the directory containing the bridge (should be a subdirectory somewhere in
        // the standard import path)
        while( pathIterator.hasNext() )
        {
            // get next path from list
            importPath = pathIterator.next();

            if( !importPath.endsWith( "/" ) )
                importPath.append( "/" );

            importPath.append(baseComponentsPath + ux);

            QDir dir(importPath);

            // does a subdir with the specifies ux-bridge exist?
            if( dir.exists() )
            {
                foundBridge = true;
   	        engine->addImportPath( importPath );
                break;
            }
        }
	
	if( foundBridge )
	{
	    break;
	}
    }

    if(!foundBridge)
    {
	qDebug() << "WARNING, NO PEREGRINE BRIDGES FOUND";
    }
}

Q_EXPORT_PLUGIN2(peregrineimportsplugin, PeregrineImportsPlugin);
