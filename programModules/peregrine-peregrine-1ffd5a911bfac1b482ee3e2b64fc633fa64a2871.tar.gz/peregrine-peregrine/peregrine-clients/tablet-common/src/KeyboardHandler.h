/*
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef KEYBOARDHANDLER_H
#define KEYBOARDHANDLER_H

#include <QObject>
#include <QRect>
#include <QVariant>

class KeyboardHandler : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QVariant visibleArea READ visibleArea WRITE setVisibleArea NOTIFY visibleAreaChanged)

public:
    explicit KeyboardHandler(QObject *parent = 0);

    QVariant visibleArea() const;
    void setVisibleArea( QVariant visibleArea );

public slots:
    void onVisibleAreaChanged( const QRect& rect );

signals:
    void visibleAreaChanged( QVariant visibleArea );

private:
    QVariant m_visibleArea;
};

#endif // KEYBOARDHANDLER_H

