/*
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#include "KeyboardHandler.h"

#include <QtCore/QDebug>
#include <QtGui/QWidget>
#include <QtGui/QApplication>
#include <MInputMethodState>

//QTM_USE_NAMESPACE

 KeyboardHandler::KeyboardHandler(QObject *parent) : QObject(parent)
{
    MInputMethodState* inputMethodState = MInputMethodState::instance();
    if( inputMethodState ) {
        connect( inputMethodState, SIGNAL( inputMethodAreaChanged( const QRect& ) ), this, SLOT( onVisibleAreaChanged( const QRect& ) ) );
    }
}


QVariant KeyboardHandler::visibleArea() const
{
    return m_visibleArea;
}

void KeyboardHandler::setVisibleArea( QVariant visibleArea )
{
    m_visibleArea = visibleArea;
    emit visibleAreaChanged( m_visibleArea );
}

void KeyboardHandler::onVisibleAreaChanged( const QRect& rect )
{
    qDebug() << "###################### KeyboardHandler::onVisibleAreaChanged ########################" << rect;
    setVisibleArea( QVariant( rect ) );
}


