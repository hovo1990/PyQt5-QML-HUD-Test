/*
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <QtGui/QApplication>
#include <QGLFormat>
#include <QDeclarativeContext>
#include <QDeclarativeEngine>
#include <QDeclarativeView>
#include <QProcessEnvironment>
#include <QDebug>
#include <QX11Info>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

#include "utilities.h"

#ifndef QMLPATH
#define QMLPATH "/usr/local/share/peregrine/"
#endif

#ifndef PEREGRINE_IMPORTS
#define PEREGRINE_IMPORTS "/usr/local/lib/peregrine/imports"
#endif

Q_DECL_EXPORT int main(int argc, char *argv[])
{
    // set default graphics system to raster for now
    //QApplication::setGraphicsSystem( "raster" );
    QApplication app(argc, argv);

    QDeclarativeView view;
    QDeclarativeEngine *engine = view.rootContext()->engine();

    engine->addImportPath( QString( PEREGRINE_IMPORTS ) );

    Utilities utilities;
    engine->rootContext()->setContextProperty("utilities", &utilities);

    engine->setProperty( "UX", "qtcomponents" ); // for layoutimageprovider
    engine->setProperty( "BRIDGESET", "qtcomponents" ); // for importsplugin

    // connect to quit() signal
    QObject::connect( engine, SIGNAL(quit()), &app, SLOT(quit()) );

    // but use a QGLWidget viewport
    QGLFormat format = QGLFormat::defaultFormat();
    format.setSampleBuffers( false );

    // create QGLWidget and set as viewport
    QGLWidget *glWidget = new QGLWidget( format );
    glWidget->setAutoFillBackground( true );
    view.setViewport( glWidget );

    // set base dir
    engine->setBaseUrl( QUrl::fromLocalFile( QMLPATH ) );

    // set QML file to load as content
    view.setSource( QUrl::fromLocalFile( QMLPATH + QString( "/main.qml" ) ) );
    view.setResizeMode( QDeclarativeView::SizeRootObjectToView );

    // show application on screen
    view.showFullScreen();

    unsigned char data = 1;
    XChangeProperty(QX11Info::display(), view.effectiveWinId(), XInternAtom(QX11Info::display(), "_MEEGOTOUCH_NOTIFICATION_PREVIEWS_DISABLED", False),XA_INTEGER, 8, PropModeReplace, &data, 1);

    // start event loop
    return app.exec();
}
