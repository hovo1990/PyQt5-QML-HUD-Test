#!/bin/bash
#
# NAME:    mic-chroot-helper.sh
# VERSION: 0.1
# DATE:    Apr 11 2011
# AUTHOR:  Maurice de la Ferté <maurice.ferte@basyskom.de>
#
# DESCRIPTION: This script starts the mic-chroot tool with a qemu runtime image
#     and mounts the project directory inside. It will take the latest installed
#     runtime image by default.
#
# Copyright (C) 2011 basysKom GmbH
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#

pushd "$(dirname $0)/../.." > /dev/null
PROJECT_DIR=$(pwd)
MADDE_RUNTIME_DIR=/usr/lib/madde/linux-i686/runtimes/
PATH=$PATH:/sbin:/usr/sbin
TOOLS="mad-admin mic-chroot xhost"

function usage(){
cat << EOF
usage: ${0} [options]
  This script starts the mic-chroot tool with a qemu runtime image and bind
  mounts the project directory inside. By default it will take the latest
  installed runtime image.

    --identifier=<madde runtime name>
      Will take the given runtime image <madde runtime name>

    --device-type=<device type> (e.g. handset, netbook ...)
      Will take the latest installed runtime image of <device type>

    --setup
      Automatically installation/update of needed packages and persistent
      environment settings inside runtime image
EOF
}

for tool in ${TOOLS}; do
	ret=$(which ${tool} || true)
	if [ -z "${ret}" ]; then
		echo "**  Error, needed tool not found: ${tool} **" >&2
		echo "**  Please install needed tool  **" >&2
		exit 1
	fi
done

unset RUNTIME_IDENTIFIER DEVICE_TYPE SETUP

for argument in ${@}; do
	case ${argument} in
		--identifier=*)
			RUNTIME_IDENTIFIER=${argument#--identifier=}
			if [ -z "${RUNTIME_IDENTIFIER}" ]; then
				echo "Error, empty '--identifier' argument" >&2
				usage >&2
				exit 1
			fi
			if [ -z "$(mad-admin list | grep ${RUNTIME_IDENTIFIER}*.*installed)" ]; then
				echo "Error, no runtime installation found for: ${RUNTIME_IDENTIFIER}" >&2
				exit 1
			fi
		;;
		--device-type=*)
			DEVICE_TYPE=${argument#--device-type=}
			if [ -z "${DEVICE_TYPE}" ]; then
				echo "Error, empty '--device-type' argument" >&2
				usage >&2
				exit 1
			fi
		;;
		--setup)
			SETUP=YES
		;;
		*)
			echo "Error, unknown argument: ${argument}" >&2
			usage >&2
			exit 1
		;;
	esac
done

if [ -z "${RUNTIME_IDENTIFIER}" ]; then
	# choose latest version of installed runtime images
	RUNTIME_IDENTIFIER=$(mad-admin list | \
		grep "meego*.*${DEVICE_TYPE}*.*runtime*.*installed" | \
		grep -v "\-w32-" | sort | tail -n 1 | awk -F ' ' '{print $1}')
fi

RUNTIME_IMAGE_PATH=$(find "${MADDE_RUNTIME_DIR}/${RUNTIME_IDENTIFIER}" \
	-name "*-sda.raw")

if [ ! -f "${RUNTIME_IMAGE_PATH}" ]; then
	echo "Error, cannot find relating qemu image"
	exit 1
fi

if [ "YES" == "${SETUP}" ]; then
	echo "** Start setup for runtime qemu image: ${RUNTIME_IDENTIFIER} **"
	sudo mic-chroot -b ${PROJECT_DIR} ${RUNTIME_IMAGE_PATH} -e \
		"bash ${PROJECT_DIR}/tools/development/meego-chroot-setup.sh"
fi

xhost +si:localuser:root

cat << EOF
###############################################################################

              Root permissions are needed by mic-chroot
               Please close this shell via "STRG + d"

###############################################################################
EOF

sudo mic-chroot -b ${PROJECT_DIR} ${RUNTIME_IMAGE_PATH}

