#!/bin/bash
#
# NAME:    meego-chroot-setup.sh
# VERSION: 0.1
# DATE:    Apr 11 2011
# AUTHOR:  Maurice de la Ferté <maurice.ferte@basyskom.de>
#
# DESCRIPTION: A setup and update script for MeeGo qemu runtime images.
# 	It works in collaboration with mic-chroot and should only called inside
#   chroot. This tool adds a remote rpm repository, installs for rapid
#   development several needed packages and extends the shell environment
#   with DISPLAY variable.
#
# Copyright (C) 2011 basysKom GmbH
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#

function usage(){
cat << EOF
usage: ${0}
    A setup and update script for MeeGo qemu runtime images.
    It works in collaboration with mic-chroot and should only called inside
    chroot. This tool adds a remote rpm repository, installs for rapid
    development several needed packages and extends the shell environment
    with DISPLAY variable.
EOF
}

if [ ! -f "/etc/meego-release" ]; then
	echo "$0:"
	echo "Error, this script is restricted to run on MeeGo systems"
	exit 1
fi

TOOLS="zypper"

for tool in ${TOOLS}; do
	ret=$(which ${tool} || true)
	if [ -z "${ret}" ]; then
		echo "**** ${0}: ****" >&2
		echo "****  Error, needed tool not found: ${tool} ****" >&2
		echo "****  Please install needed tool  ****" >&2
	fi
done

REPO_ALIAS=peregrine

PACKAGES="
	peregrine-unstable-plain-qml
	peregrine-unstable-libs
	peregrine-unstable-devel
	farsight2-devel
	gst-plugins-base-devel
	libqtdeclarative4-folderlistmodel
	libqt-devel
	libqtopengl-devel
	qt-mobility-devel
	qt-qmake
	telepathy-glib-devel
	telepathy-qt4-devel
	telepathy-qt4-farsight-devel
"

if [ -z "$(zypper lr | grep ${REPO_ALIAS})" ]; then
	echo "**** Add peregrine remote OBS repository ****"
	zypper ar -f http://repo.pub.meego.com/home:/mdfe:/peregrine/Trunk/ ${REPO_ALIAS}
	zypper ve
fi

echo "**** Verify repositories ****"
zypper ve

echo "**** Install/update needed packages ****"
for package in ${PACKAGES}; do
	zypper install -y ${package}
done

if [ -z "$(cat /root/.bashrc | grep DISPLAY )" ]; then
	echo "**** Add DISPLAY variable to environment via /root/.bashrc ****"
	echo "export DISPLAY=:0" >> /root/.bashrc
	echo
fi
