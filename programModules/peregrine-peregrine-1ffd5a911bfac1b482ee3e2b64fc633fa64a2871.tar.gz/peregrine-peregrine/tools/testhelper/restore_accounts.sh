#!/bin/bash
#
# restore_accounts.sh
#
# Copyright (C) 2011 basysKom GmbH
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#

# Script information:
# add account information between "begin data" and "end data" lines. You can have multiple data blocks.
# format of this blocks is as follows:
# each line consists of 4 or 5 columns. columns are separated by '#'
# each line that starts with '##' is not parsed (is a comment). this
#   makes it easy to exclude accounts that should not created in
#   MissionControl
# 1. column: place a 'x' in this column if you want to have this account
#            enabled automatically. leave it empty (min. one whitespace
#            or other char) to just create this account without enabling
#            it. (must be set)
# 2. column: Display name. The name that is displayed to the user (must
#            be set)
# 3. column: Account ID. Name of account or loggin name for this account
#            (must be set)
# 4. column: Password in plain text. (must be set)
# 5. column: server name. If you need to give a special server name write
#            it down in this column. (optional

# Example:
# The following configuration will create 2 accounts: "Full Name" and
# "Full Name 2". The account "Full Name" will be enabled, "Full Name 2"
# will not be enabled. All other lines start with '##' and will be handled
# as a comment line
# === begin data ===
## comment
#x# Full Name      # user@host.tld  # jabber password # jabber.server.tld
# # Full Name 2    # user2@host.tld # jabber password
# === end data ===

trim()
{
	echo -n $1
}

mode="script"
while read line
do
	if [ "$mode" == "script" ]
	then
		if [ "${line}" == "# === begin data ===" ]
		then
			mode="data"
			continue
		fi
	elif [ "$mode" == "data" ]
	then
		if [ "${line}" == "# === end data ===" ]
		then
			mode="script"
			continue
		fi
		if [ "${line:0:2}" == "##" ]
		then
			continue
		fi

		enabled=`echo -n $line | awk -F '#' '{ print $2; }'`
		displayname=`echo -n $line | awk -F '#' '{ print $3; }'`
		account=`echo -n $line | awk -F '#' '{ print $4; }'`
		password=`echo -n $line | awk -F '#' '{ print $5; }'`
		server=`echo -n $line | awk -F '#' '{ print $6; }'`

		displayname=`trim "$displayname"`
		account=`trim "$account"`
		password=`trim "$password"`
		server=`trim "$server"`

		accountpath=""
		if [ -n "$server" ]
		then
			accountpath=`mc-tool add 'gabble/jabber' "$displayname" "string:account=$account" "string:password=$password" "string:server=$server"`
		else
			accountpath=`mc-tool add 'gabble/jabber' "$displayname" "string:account=$account" "string:password=$password"`
		fi

		if [ -n "$accountpath" ]
		then
			echo "account '$displayname' created" >&2
		else
			echo "unable to create account '$displayname'" >&2
		fi

		if [ "$enabled" == "x" -o "$enabled" == "X" ]
		then
			mc-tool enable "$accountpath"
		fi
	fi
done < "$0"
