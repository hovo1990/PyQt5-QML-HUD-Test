#!/bin/bash
#
# setup_meego.sh
#
# Copyright (C) 2011 basysKom GmbH
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
# There should be no unset variables
set -u

extra_packages="dmidecode qt-qmlviewer synergy"
devel=0

# The destination ip can be passed as the first script parameter or set here
host=192.168.100.83

synhost=`hostname -f`

while getopts  "dh:p:?" flag
do
	case "$flag" in
		"d")
			echo "Activating devel mode. No peregrine will be installed, xhost added to extra packages."
			devel=1
			extra_packages="$extra_packages xorg-x11-utils-xhost"
		;;
		"?")
			echo "Usage: `basename $0` [-options]"
			echo "	-d			: Switch to dev mode, no peregrine is set up but xhost is installed."
			echo "	-h <host>		: Set the host to connect to."
			echo "	-p <package list>	: Install extra packages, e.g. vim."
			echo "	-?			: Print help messages."
			exit 0
		;;
		"h")
			host=$OPTARG
		;;
		"p")
			extra_packages="$extra_packages $OPTARG"
		;;
		*)
			echo "Unused option: $flag"
		;;
	esac
done

echo "I will try to set up the host at: $host"
if ! ping -c1 $host >/dev/null 2>&1; then
	echo "$host doesn't seem to be reachable. Trying anyway"
fi

# All files matching *.sh will be copied from $script_dir to the meego machine
# The Restore_accounts.sh and Remove_accounts.sh scripts should be in there
#script_dir=~/bin/meego_scripts/
script_dir=`dirname $0`

# Some ssh options to deal with changing ssh host keys
ssh_opts="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -q"

display="DISPLAY=:0.0"
dest=meego@$host
rdest=root@$host
ssh="ssh $ssh_opts"
zypper="zypper --no-gpg-checks --non-interactive"
# ssh-copy-id is not used because it produced errors. Something with umask. This works.
ssh_copy_id="mkdir .ssh; chmod 700 .ssh; cat >> .ssh/authorized_keys; chmod 600 .ssh/authorized_keys"

ssh_key_file=
if [ -f "$HOME/.ssh/id_rsa.pub" ]
then
	ssh_key_file="$HOME/.ssh/id_rsa.pub"
elif [ -f "$HOME/.ssh/id_dsa.pub" ]
then
	ssh_key_file="$HOME/.ssh/id_dsa.pub"
fi
echo "Using public key file: $ssh_key_file"

if [ -n "$ssh_key_file" ]
then
	echo "Setting up passwordless ssh authentication for user meego. Wait for the prompt and type 'meego'"
	cat "$ssh_key_file" | $ssh $dest "$ssh_copy_id" || {
		echo "No ssh reachable on host $host. Setup can't work without ssh access."
		exit 1
	}
	echo "Setting up passwordless ssh authentication for user root. Wait for the prompt and type 'meego'"
	cat "$ssh_key_file" | $ssh $rdest "$ssh_copy_id"
	
	$ssh $dest test -f .prgsetupdone && {
		echo "Setup has already been run"
		exit 2
	}
fi

$ssh $dest touch .prgsetupdone

$ssh $dest mkdir bin
scp $ssh_opts $script_dir/*.sh $dest:bin/

if [ $devel -eq 0 ]; then
	# Set up zypper and install peregrine...
	$ssh $rdest $zypper ar -f http://repo.pub.meego.com/home:/mdfe:/peregrine/Trunk/ peregrine-unstable
	$ssh $rdest $zypper install peregrine-unstable-libs peregrine-unstable-plain-qml
fi
if [ -n "$extra_packages" ]; then
	echo "Installing extra packages: $extra_packages"
	$ssh $rdest $zypper install $extra_packages
fi

# Fixed in git
#$ssh $rdest "echo 'Categories=Network;' >> /usr/share/applications/peregrine-plain-qml.desktop"

$ssh $dest synergyc -n meego $synhost

# Set us up the bo^waccounts
# Doesn't work without the DBUS environment which I don't yet know how to get from the logged in meego user
$ssh $dest "echo '. ~/bin/fixenv.sh' >> .bashrc"

# ...then drop us to a shell on the device
$ssh $dest
