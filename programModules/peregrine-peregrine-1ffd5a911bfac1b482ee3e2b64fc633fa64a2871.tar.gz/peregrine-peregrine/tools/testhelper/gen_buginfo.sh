#!/bin/bash
#
# gen_buginfo.sh
#
# Copyright (C) 2011 basysKom GmbH
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
PACKAGE_PREFIX=peregrine

PACKAGES_FOUND=$(zypper search ${PACKAGE_PREFIX} | grep '^i' | \
	awk '{print $3}')

if [ -z "${PACKAGES_FOUND}" ]; then
	echo "$0: Error, no ${PACKAGE_PREFIX} packages found" >&2
	exit 1
fi

echo "OS VERSION:"
cat /etc/meego-release
echo

if [ -n "$(which dmidecode 2>/dev/null)" ]; then
	echo "HARDWARE:"
	dmidecode -s system-version
	echo
fi

echo "$(echo ${PACKAGE_PREFIX} | tr [a-z] [A-Z]) PACKAGES:"
rpm -q ${PACKAGES_FOUND}
echo

for package in ${PACKAGES_FOUND}; do
	# The 'git' pattern in the first line of the changelog file indicates
	# a none stable package. Our unstable changelog files contains git
	# information like commit ID, branch and repository URL.
	CHANGELOG_HEAD=$(rpm -q --changelog ${package} | head -n 1 | \
		grep 'git')

	if [ -n "${CHANGELOG_HEAD}" ]; then
		echo "GIT INFO: (rpm -q --changelog ${package})"
		rpm -q --changelog ${package} | \
			egrep "Commit ID|Branch|Repository URL" | head -n3
		echo
	fi
done

unset DEPLIST
for package in ${PACKAGES_FOUND}; do
	# Do only track libs and packages. Remove files (^/), rpmlib and also
	# cut off version branding
	DEPENDENCIES=$(rpm -qR ${package} | egrep -v '^/|rpmlib' | \
		sed 's/[=<>].*//g')

	for dep in ${DEPENDENCIES}; do
		DEPLIST="$(rpm -q --whatprovides ${dep}) ${DEPLIST}"
	done
done

DEPLIST=$(echo ${DEPLIST} | sed 's/ /\n/g' | sort -u)

echo "$(echo ${PACKAGE_PREFIX} | tr [a-z] [A-Z]) RUNTIME DEPENDENCY PACKAGES:"
for package in ${DEPLIST}; do
	echo ${package}
done
