#include "shmvideo.h"

struct SharedVideoBuffer;

void shm_video_close_shared( char * name, int handle, struct SharedVideoBuffer * videoBuffer, int withUnlink ){
    G_PRINTF("####################################################################################################    shm_video_close_shared %d\n", withUnlink );
    if( withUnlink == 1 ){
        sem_destroy( &(videoBuffer->readSem) );
        sem_destroy( &(videoBuffer->writeSem) );
        sem_destroy( &(videoBuffer->format.changed) );
    }
    munmap(videoBuffer,videoBuffer->objectSize);
    if( withUnlink == 1 ){
        shm_unlink(name);
    }
    close(handle);
}

int shm_video_init_shared( char * name, int * handle, struct SharedVideoBuffer ** videoBuffer, int create ){
    G_PRINTF("shm_video_init_shared create %d\n",create);
    if( create == 1 ){
        *handle = shm_open( name, (O_RDWR|O_CREAT|O_EXCL), (S_IRUSR|S_IWUSR) );
    } else {
        *handle = -1;
        errno = EEXIST;
    }
    //G_PRINTERR( "Handle is %d.\n", *handle );
    if( *handle == -1 ){
        if( errno == EEXIST ){
            *handle = shm_open( name, (O_RDWR), (S_IRUSR|S_IWUSR) );
            if( *handle == -1 ){
                G_PRINTERR("Could not open shared memory %s. Check permission/presents. errno %d\n",name,errno);
                return -1;
            } else {
                if( shm_video_resize_shared( videoBuffer, *handle, 1, 0 ) > 0 ){
                    if( shm_video_resize_shared( videoBuffer, *handle, 1, 1 ) > 0 ){
                        return 0;
                    } else {
                        return -1;
                    }
                } else {
                    return -1;
                }
                //if (filter->silent == FALSE)
                G_PRINT("Shared memory was already created. Using it.\n");
                return 0;
            }
        } else {
            G_PRINTERR( "Shared memory not existed and create error %d\n", errno );
            return -1;
        }
    } else {
        if( shm_video_resize_shared( videoBuffer, *handle, 0, 0 ) < 0 ){
            return -1;
        }
        shm_video_init_sem_mutex( *videoBuffer );
        shm_video_init_data( *videoBuffer );

        //if (filter->silent == FALSE)
        G_PRINT("Shared memory created\n");
        return 0;
    }
}

int shm_video_resize_shared( struct SharedVideoBuffer ** videoBuffer, int handle, int mapOnly, int fromSharedVideoBuffer ){
    G_PRINT("shm_video_resize_shared\n");
    //static int firstrun = 1;
    int memsize;
    if( /*firstrun == 1*/ fromSharedVideoBuffer == 0 ){
        memsize = MAKE_ALIGNMENT_SIZE(sizeof(struct SharedVideoBuffer));
        //firstrun = 0;
    } else {
        memsize = (*videoBuffer)->objectSize;
    }
    G_PRINTF("shm_video_resize_shared handle is %d\n",handle);

    int ret = 0;
    if( mapOnly == 0 ){
        ret = ftruncate( handle, memsize );
    }

    if( handle != -1 &&  ret == 0  ){
        *videoBuffer = (struct SharedVideoBuffer*)mmap( NULL, memsize, ( PROT_READ | PROT_WRITE ), MAP_SHARED, handle, 0 );
        //(*videoBuffer)->objectSize = size;
        return memsize;
    } else {
        G_PRINTERR( "Shared memory could not be resized to size %d. errno %d\n", memsize, errno );
        return -1;
    }
    G_PRINT("shm_video_resize_shared done\n");

}

void shm_video_init_sem_mutex( struct SharedVideoBuffer * videoBuffer ){
    G_PRINT("shm_video_init_sem_mutex\n");
    sem_init( &(videoBuffer->readSem), 1, 0 );
    sem_init( &(videoBuffer->writeSem), 1, 2 );
    sem_init( &(videoBuffer->format.changed), 1, 1 );
    pthread_mutex_init( &(videoBuffer->writerMutex), NULL );
    pthread_mutex_init( &(videoBuffer->readerMutex), NULL );
    pthread_mutex_init( &(videoBuffer->structMutex), NULL );
    pthread_mutex_init( &(videoBuffer->format.structMutex), NULL );
}

void _shm_video_init_format( struct SharedVideoBuffer * videoBuffer ){
    G_PRINT("_shm_video_init_format\n");
    videoBuffer->format.videoFormat = FORMAT_UNKNOWN;
    videoBuffer->format.videoWidth = 0;
    videoBuffer->format.videoHeight = 0;
    videoBuffer->format.videoFramerateNumerator = 1;
    videoBuffer->format.videoFramerateDenominator = 1;
    videoBuffer->format.videoYuvFormat = 0;
    videoBuffer->format.videoRgbBpp = 0;
    videoBuffer->format.videoRgbDepth = 0;
    videoBuffer->format.videoRgbEndianness = 1234;
    videoBuffer->format.videoRgbRedMask = 0;
    videoBuffer->format.videoRgbGreenMask = 0;
    videoBuffer->format.videoRgbBlueMask = 0;
    videoBuffer->format.formatstring[0] = 0;
}

void shm_video_init_format( struct SharedVideoBuffer * videoBuffer ){
    G_PRINT("shm_video_init_format\n");
    pthread_mutex_lock( &(videoBuffer->format.structMutex) );
    _shm_video_init_format(videoBuffer);
    pthread_mutex_unlock( &(videoBuffer->format.structMutex) );
}

void shm_video_init_data( struct SharedVideoBuffer * videoBuffer ){
    G_PRINT("shm_video_init_data\n");
    pthread_mutex_lock( &(videoBuffer->structMutex) );
    videoBuffer->objectSize = sizeof(struct SharedVideoBuffer);
    videoBuffer->bufferSize = 0;
    videoBuffer->buffer[0] = NULL;
    videoBuffer->buffer[1] = NULL;
    videoBuffer->pushPosition = 0;
    videoBuffer->popPosition = 0;

    shm_video_init_format( videoBuffer );
    pthread_mutex_unlock( &(videoBuffer->structMutex) );
}

void shm_video_set_format_from_gst( struct SharedVideoBuffer * videoBuffer, GstCaps * caps ){
    G_PRINT("shm_video_set_format_from_gst\n");
    pthread_mutex_lock( &(videoBuffer->format.structMutex) );
    _shm_video_init_format( videoBuffer );
    GstStructure * structure = gst_caps_get_structure( caps, 0 );
    const gchar * mime;
    mime = gst_structure_get_name( structure );
    if (strcmp (mime, "video/x-raw-rgb") == 0) {
        videoBuffer->format.videoFormat = FORMAT_RGB;
        if( ! gst_structure_get_int (structure, "bpp", &(videoBuffer->format.videoRgbBpp) ) ){ videoBuffer->format.videoRgbBpp = 0; };
        if( ! gst_structure_get_int (structure, "depth", &(videoBuffer->format.videoRgbDepth) ) ){ videoBuffer->format.videoRgbDepth = videoBuffer->format.videoRgbBpp; };
        if( ! gst_structure_get_int (structure, "endianness", &(videoBuffer->format.videoRgbEndianness) ) ){ videoBuffer->format.videoRgbEndianness = 4321; };
        if( ! gst_structure_get_int (structure, "red_mask", &(videoBuffer->format.videoRgbRedMask) ) ){ videoBuffer->format.videoRgbRedMask = 0; };
        if( ! gst_structure_get_int (structure, "green_mask", &(videoBuffer->format.videoRgbGreenMask) ) ){ videoBuffer->format.videoRgbGreenMask = 0; };
        if( ! gst_structure_get_int (structure, "blue_mask", &(videoBuffer->format.videoRgbBlueMask) ) ){ videoBuffer->format.videoRgbBlueMask = 0; };
    }
    if (strcmp (mime, "video/x-raw-yuv") == 0) {
        videoBuffer->format.videoFormat = FORMAT_YUV;
        if( ! gst_structure_get_fourcc(structure, "format", &(videoBuffer->format.videoYuvFormat) ) ){ videoBuffer->format.videoYuvFormat = 0; };
    }
    if( videoBuffer->format.videoFormat != FORMAT_UNKNOWN ){
        if( ! gst_structure_get_int (structure, "width", &(videoBuffer->format.videoWidth) ) ){ videoBuffer->format.videoWidth = 0; };
        if( ! gst_structure_get_int (structure, "height", &(videoBuffer->format.videoHeight) ) ){ videoBuffer->format.videoHeight = 0; }
        if( ! gst_structure_get_fraction (structure, "framerate", &(videoBuffer->format.videoFramerateNumerator), &(videoBuffer->format.videoFramerateDenominator) ) ){ videoBuffer->format.videoFramerateNumerator = 0; videoBuffer->format.videoFramerateDenominator = 1; }
        if( ! gst_structure_get_fraction (structure, "pixel-aspect-ratio", &(videoBuffer->format.videoAspectratioNumerator), &(videoBuffer->format.videoAspectratioDenominator) ) ){ videoBuffer->format.videoAspectratioNumerator = 1; videoBuffer->format.videoAspectratioDenominator = 1; }
    }

    shm_video_format_changed( videoBuffer );
    pthread_mutex_unlock( &(videoBuffer->format.structMutex) );
}

void shm_video_format_changed( struct SharedVideoBuffer * videoBuffer ){
    G_PRINT("shm_video_format_changed\n");
    sem_post( &(videoBuffer->format.changed) );
}

int shm_video_format_has_changed( struct SharedVideoBuffer * videoBuffer ){
    G_PRINT("shm_video_format_has_changed\n");
    int ret;
    sem_getvalue( &(videoBuffer->format.changed), &ret );
    return ret;
}

void shm_video_format_confirm_has_changed( struct SharedVideoBuffer * videoBuffer ){
    sem_init( &(videoBuffer->format.changed), 1, 0 );
}

int shm_video_push( struct SharedVideoBuffer * videoBuffer, unsigned char * source ){
    G_PRINT("shm_video_push new frame ready\n");
    int ret = 0;

    if( shm_video_format_has_changed(videoBuffer) == 1 ){
        return -2;
    }

    if( sem_trywait( &(videoBuffer->writeSem) ) == 0 ){
    //if( ( ret = sem_wait( &(videoBuffer->writeSem) ) ) == 0 ){
      //static int pushPosition = 0;
      if( videoBuffer->pushPosition == 2 ){
          videoBuffer->pushPosition = 0;
      }

      // copy video memory in shared memory
      memcpy( (void*)( (int)(videoBuffer->buffer[(videoBuffer->pushPosition)++]) + (int)(videoBuffer) ), source, videoBuffer->bufferSize );
      // show start of buffer for debugging
      //strcpy((void*)( (int)(filter->videobuffer->buffer[position]) + (int)(filter->videobuffer) ),"buffer starts here");
      // show end of buffer for debugging
      //memcpy( (void*)( (int)(filter->videobuffer->buffer[position]) + (int)(filter->videobuffer) + buf->size - 1 ), 'E', 1 );

      //sem_getvalue( &(videoBuffer->readSem) ,&ret);
      //G_PRINTF("value before sem_post( &(videoBuffer->readSem) ) = %d\n",ret);
      sem_post( &(videoBuffer->readSem) );
      //sem_getvalue( &(videoBuffer->readSem) ,&ret);
      //G_PRINTF("value after sem_post( &(videoBuffer->readSem) ) = %d\n",ret);
      return 0;
    } else {
        G_PRINTF("shm_video_push error sem_wait( &(videoBuffer->writeSem) ) = %d errno = %d\n",ret,errno);
        sem_getvalue( &(videoBuffer->readSem) ,&ret);
        G_PRINTF("shm_video_push error sem_getvalue( &(videoBuffer->readSem) ,&ret) = %d\n",ret);
        sem_getvalue( &(videoBuffer->writeSem) ,&ret);
        G_PRINTF("shm_video_push error sem_getvalue( &(videoBuffer->writeSem) ,&ret) = %d\n",ret);

        return -1;
    }
}

void shm_video_wake_reader( struct SharedVideoBuffer * videoBuffer ){
    sem_post( &(videoBuffer->readSem) );
}

unsigned char * shm_video_pop( struct SharedVideoBuffer * videoBuffer ){
    // you can do what you want with this buffer
    //static int ret = 0;
    // take new one
    if( sem_wait( &(videoBuffer->readSem) ) == 0 ){
        //static int popPosition = 0;
        if( videoBuffer->popPosition == 2 ){
            videoBuffer->popPosition = 0;
        }
        //if( ( ret = sem_post( &(videoBuffer->writeSem) ) ) != 0 ){
        //    G_PRINTF("sem_post( &(videoBuffer->writeSem) ) failed with errno %d\n",ret);
        //}
        if( shm_video_format_has_changed( videoBuffer ) == 0 ){
            return (unsigned char *)(videoBuffer->buffer[(videoBuffer->popPosition)++]) + (unsigned int)(videoBuffer);
        } else {
            shm_video_format_confirm_has_changed( videoBuffer );
            return NULL;
        }
    } else {
        return NULL;
        //G_PRINTF("sem_wait( &(videoBuffer->readSem) ) failed with errno %d\n",ret);
    }
}

void shm_video_give_pop_buffer( struct SharedVideoBuffer * videoBuffer ){
    sem_post( &(videoBuffer->writeSem) );
}
