#ifndef __SHM_VIDEO__
#define __SHM_VIDEO__

#ifdef __cplusplus
extern "C" {
#endif

#include <semaphore.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <gst/gst.h>
#include <glib/gprintf.h>
#include <gst/video/video.h>

#define G_PRINT(x) //g_print(x)
#define G_PRINTF(x, ...) //g_printf(x,__VA_ARGS__)
#define G_PRINTERR(x, ...) //g_printerr(x,__VA_ARGS__)

// pointer can mostly only target on int borders
#define MAKE_ALIGNMENT_SIZE(size) ((( (size) + ( sizeof(int) -1 ) ) / sizeof(int))*sizeof(int))

// struct in shared memory
struct SharedVideoBuffer {
    int objectSize; // size of complete shared memory. resize it if format has changed
    int bufferSize; // size of 1 image in shared memory
    unsigned char * buffer[2]; // offset pointer to buffers in shared memory ( to get videobuffer you must do: &SharedVideoBuffer + buffer[0|1] )
    int pushPosition;
    int popPosition;
    sem_t readSem; // semaphore for reading thread
    sem_t writeSem; // semaphore for writing thread
    pthread_mutex_t structMutex; // if you read/write objectSize or bufferSize take this one
    pthread_mutex_t writerMutex; // only one writer should be using this object take it if you are the one
    pthread_mutex_t readerMutex; // only one reader should be using this object. take it if you are the one
    struct _format {
        pthread_mutex_t structMutex; // if you read/write in format take this one
        sem_t changed; // for format changed

        enum _videoFormat {
            FORMAT_UNKNOWN,
            FORMAT_RGB,
            FORMAT_YUV
        } videoFormat;
        int videoWidth;
        int videoHeight;
        int videoFramerateNumerator;
        int videoFramerateDenominator;
        int videoAspectratioNumerator;
        int videoAspectratioDenominator;
        guint32 videoYuvFormat;
        int videoRgbBpp;
        int videoRgbDepth;
        int videoRgbEndianness;
        int videoRgbRedMask;
        int videoRgbGreenMask;
        int videoRgbBlueMask;

        char formatstring[1]; // formatstring from gst_caps_to_string().Has to be last element in struct or you will segfault
    } format;
};

// close shared memory after usage
void shm_video_close_shared( char * name, int handle, struct SharedVideoBuffer * videoBuffer, int withUnlink );

// init shared memory and get back error code 0 on sucess, handle returns int filehandle, videoBuffer returns pointer to SharedVideoBuffer
int shm_video_init_shared( char * name, int * handle, struct SharedVideoBuffer ** videoBuffer, int create );

// init shared memory and get back error code 0 on sucess, handle returns int filehandle, videoBuffer returns pointer to SharedVideoBuffer
int shm_video_resize_shared( struct SharedVideoBuffer ** videoBuffer, int handle, int mapOnly, int fromSharedVideoBuffer );

// init all mutex and semaphore
void shm_video_init_sem_mutex( struct SharedVideoBuffer * videoBuffer );

// clean all data to NULL
void shm_video_init_data( struct SharedVideoBuffer * videoBuffer );

// clean format data to NULL
void shm_video_init_format( struct SharedVideoBuffer * videoBuffer );
void _shm_video_init_format( struct SharedVideoBuffer * videoBuffer ); // dont use this one, it is not protected by mutex

// set the format struct from caps
void shm_video_set_format_from_gst( struct SharedVideoBuffer * videoBuffer, GstCaps * caps );

// call this if you changed format. not needed after shm_video_set_format_from_gst
void shm_video_format_changed( struct SharedVideoBuffer * videoBuffer );

// return true if format changed
int shm_video_format_has_changed( struct SharedVideoBuffer * videoBuffer );

// copy new image in shared memory
int shm_video_push( struct SharedVideoBuffer * videoBuffer, unsigned char * source );

// consumer should call this if he has noticed format change
void shm_video_format_confirm_has_changed( struct SharedVideoBuffer * videoBuffer );

// wake up reader to give him notifications
void shm_video_wake_reader( struct SharedVideoBuffer * videoBuffer );

// get next ready buffer
unsigned char * shm_video_pop( struct SharedVideoBuffer * videoBuffer );

// give back pop buffer
void shm_video_give_pop_buffer( struct SharedVideoBuffer * videoBuffer );

#ifdef __cplusplus
}
#endif

#endif /* __SHM_VIDEO__ */
