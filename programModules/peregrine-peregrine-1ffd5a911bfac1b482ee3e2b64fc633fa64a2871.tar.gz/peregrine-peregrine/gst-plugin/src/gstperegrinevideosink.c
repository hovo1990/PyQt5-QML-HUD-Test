/*
 * GStreamer
 * Copyright (C) 2005 Thomas Vander Stichele <thomas@apestaart.org>
 * Copyright (C) 2005 Ronald S. Bultje <rbultje@ronald.bitfreak.net>
 * Copyright (C) 2011 Peter Rustler <<user@hostname.org>>
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Alternatively, the contents of this file may be used under the
 * GNU Lesser General Public License Version 2.1 (the "LGPL"), in
 * which case the following provisions apply instead of the ones
 * mentioned above:
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/**
 * SECTION:element-peregrinevideosink
 *
 * FIXME:Describe peregrinevideosink here.
 *
 * <refsect2>
 * <title>Example launch line</title>
 * |[
 * gst-launch -v -m fakesrc ! peregrinevideosink ! fakesink silent=TRUE
 * ]|
 * </refsect2>
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gst/gst.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#include "gstperegrinevideosink.h"
#include "shmvideo.h"

GST_DEBUG_CATEGORY_STATIC (gst_peregrinevideosink_debug);
#define GST_CAT_DEFAULT gst_peregrinevideosink_debug

/* Filter signals and args */
enum
{
  /* FILL ME */
  LAST_SIGNAL
};

enum
{
  PROP_0,
  PROP_SILENT,
  PROP_SHAREDNAME
};

/* the capabilities of the inputs and outputs.
 *
 * describe the real formats here.
 */
static GstStaticPadTemplate sink_factory = GST_STATIC_PAD_TEMPLATE ("sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS ("ANY")
    /*GST_STATIC_CAPS (
     GST_VIDEO_CAPS_RGB ";"
     GST_VIDEO_CAPS_RGBx ";"
     GST_VIDEO_CAPS_RGBA ";"
     GST_VIDEO_CAPS_YUV("{ I420, YV12, YUY2, UYVY, AYUV }")
     )*/
    );

static GstStaticPadTemplate src_factory = GST_STATIC_PAD_TEMPLATE ("src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS ("ANY")
    );

GST_BOILERPLATE (Gstperegrinevideosink, gst_peregrinevideosink, GstElement,
    GST_TYPE_ELEMENT);

static void gst_peregrinevideosink_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec);
static void gst_peregrinevideosink_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec);

static gboolean gst_peregrinevideosink_set_caps (GstPad * pad, GstCaps * caps);
static GstFlowReturn gst_peregrinevideosink_chain (GstPad * pad, GstBuffer * buf);
static gboolean gst_peregrinevideosink_sink_event (GstPad  *pad, GstEvent * event);

/* GObject vmethod implementations */

static void
gst_peregrinevideosink_base_init (gpointer gclass)
{
  GstElementClass *element_class = GST_ELEMENT_CLASS (gclass);

  gst_element_class_set_details_simple(element_class,
    "peregrinevideosink",
    "FIXME:Generic",
    "FIXME:Generic Template Element",
    "Peter Rustler <<user@hostname.org>>");

  gst_element_class_add_pad_template (element_class,
      gst_static_pad_template_get (&src_factory));
  gst_element_class_add_pad_template (element_class,
      gst_static_pad_template_get (&sink_factory));
}

// destructor of class
static void
gst_peregrinevideosink_finalize(Gstperegrinevideosink * filter) {
    if( filter->shm_mem_fd != -1 ){
        shm_video_init_format( filter->videobuffer );
        shm_video_format_changed( filter->videobuffer );
        shm_video_close_shared( filter->sharedFileName, filter->shm_mem_fd, filter->videobuffer, 0 );
    }
    /* Chain up to the parent class */
    G_OBJECT_CLASS (parent_class)->finalize ((GObject *)filter);
}

/* initialize the peregrinevideosink's class */
static void
gst_peregrinevideosink_class_init (GstperegrinevideosinkClass * klass)
{
  GObjectClass *gobject_class;
  GstElementClass *gstelement_class;

  gobject_class = (GObjectClass *) klass;
  gstelement_class = (GstElementClass *) klass;
  gobject_class->finalize = gst_peregrinevideosink_finalize;

  gobject_class->set_property = gst_peregrinevideosink_set_property;
  gobject_class->get_property = gst_peregrinevideosink_get_property;

  g_object_class_install_property (gobject_class, PROP_SILENT,
      g_param_spec_boolean ("silent", "Silent", "Produce verbose output ?",
          FALSE, G_PARAM_READWRITE));
  g_object_class_install_property (gobject_class, PROP_SHAREDNAME,
      g_param_spec_string("sharedname", "SharedName", "Name for shared memory object used. Use this in your client too",
          "ThisIsATest", G_PARAM_READWRITE));
}

/* initialize the new element
 * instantiate pads and add them to element
 * set pad calback functions
 * initialize instance structure
 */
static void
gst_peregrinevideosink_init (Gstperegrinevideosink * filter,
    GstperegrinevideosinkClass * gclass)
{
  // unused
  gclass = 0;
  filter->sinkpad = gst_pad_new_from_static_template (&sink_factory, "sink");
  gst_pad_set_setcaps_function (filter->sinkpad,
                                GST_DEBUG_FUNCPTR(gst_peregrinevideosink_set_caps));
  gst_pad_set_getcaps_function (filter->sinkpad,
                                GST_DEBUG_FUNCPTR(gst_pad_proxy_getcaps));
  gst_pad_set_chain_function (filter->sinkpad,
                                GST_DEBUG_FUNCPTR(gst_peregrinevideosink_chain));
  gst_pad_set_event_function(filter->sinkpad,
                                GST_DEBUG_FUNCPTR(gst_peregrinevideosink_sink_event));

  filter->srcpad = gst_pad_new_from_static_template (&src_factory, "src");
  gst_pad_set_getcaps_function (filter->srcpad,
                                GST_DEBUG_FUNCPTR(gst_pad_proxy_getcaps));

  filter->silent = TRUE;
  filter->shm_mem_fd = -1;
  filter->shm_mem_size = 0;
  filter->videobuffer = NULL;
  filter->sharedFileName[0] = 0;
  extern int errno;

  gst_element_add_pad (GST_ELEMENT (filter), filter->sinkpad);
  gst_element_add_pad (GST_ELEMENT (filter), filter->srcpad);
  if (filter->silent == FALSE) g_printf( "init done on %s\n", filter->sharedFileName );
}

static void
gst_peregrinevideosink_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  Gstperegrinevideosink *filter = GST_PEREGRINEVIDEOSINK (object);

  switch (prop_id) {
    case PROP_SILENT:
      filter->silent = g_value_get_boolean (value);
      break;
    case PROP_SHAREDNAME:
      if( filter->shm_mem_fd != -1 ){
          g_printerr("Cant set sharedname to \"%s\". It is already set to \"%s\".\n", g_value_get_string(value), filter->sharedFileName );
          return;
      }
      strcpy(filter->sharedFileName,g_value_get_string(value));
      // opening shared memory
      if( shm_video_init_shared( filter->sharedFileName, &(filter->shm_mem_fd), &(filter->videobuffer), 0 ) != 0 ){
          filter->shm_mem_fd = -1;
      }
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}

static gboolean
gst_peregrinevideosink_sink_event (GstPad  *pad, GstEvent * event)
{
  Gstperegrinevideosink * filter;
  gboolean ret;

  filter = GST_PEREGRINEVIDEOSINK (gst_pad_get_parent (pad));

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_NEWSEGMENT:
      if (filter->silent == FALSE) g_print( "gst_peregrinevideosink_sink_event got event: GST_EVENT_NEWSEGMENT in %s\n", filter->sharedFileName );
      ret = gst_pad_push_event (filter->srcpad, event);
      break;
    case GST_EVENT_EOS:
      if (filter->silent == FALSE) g_print( "gst_peregrinevideosink_sink_event got event: GST_EVENT_EOS in %s\n", filter->sharedFileName );
      ret = gst_pad_push_event (filter->srcpad, event);
      break;
    case GST_EVENT_FLUSH_STOP:
      if (filter->silent == FALSE) g_print( "gst_peregrinevideosink_sink_event got event: GST_EVENT_FLUSH_STOP in %s\n", filter->sharedFileName );
      ret = gst_pad_push_event (filter->srcpad, event);
      break;
    case GST_EVENT_FLUSH_START:
      if (filter->silent == FALSE) g_print( "gst_peregrinevideosink_sink_event got event: GST_EVENT_FLUSH_START in %s\n", filter->sharedFileName );
      ret = gst_pad_push_event (filter->srcpad, event);
      break;
    case GST_EVENT_TAG:
      if (filter->silent == FALSE) g_print( "gst_peregrinevideosink_sink_event got event: GST_EVENT_TAG in %s\n", filter->sharedFileName );
      ret = gst_pad_push_event (filter->srcpad, event);
      break;
    default:
      if (filter->silent == FALSE) g_print( "gst_peregrinevideosink_sink_event got event: UNKNOWN (%s) in %s\n", gst_event_type_get_name(GST_EVENT_TYPE (event)), filter->sharedFileName );
      ret = gst_pad_event_default (pad, event);
      break;
  }
  gst_object_unref (filter);
  return ret;
}

static void
gst_peregrinevideosink_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  Gstperegrinevideosink *filter = GST_PEREGRINEVIDEOSINK (object);

  switch (prop_id) {
    case PROP_SILENT:
      g_value_set_boolean (value, filter->silent);
      break;
    case PROP_SHAREDNAME:
      g_value_set_string(value, filter->sharedFileName);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}

/* GstElement vmethod implementations */

/* this function handles the link with other elements */
static gboolean
gst_peregrinevideosink_set_caps (GstPad * pad, GstCaps * caps)
{
  Gstperegrinevideosink *filter;
  GstPad *otherpad;

  filter = GST_PEREGRINEVIDEOSINK (gst_pad_get_parent (pad));
  otherpad = (pad == filter->srcpad) ? filter->sinkpad : filter->srcpad;
  otherpad = filter->sinkpad;
  gst_object_unref (filter);

  return gst_pad_set_caps (otherpad, caps);
}

/* chain function
 * this function does the actual processing
 */
static GstFlowReturn
gst_peregrinevideosink_chain (GstPad * pad, GstBuffer * buf)
{
  Gstperegrinevideosink *filter;

  filter = GST_PEREGRINEVIDEOSINK (GST_OBJECT_PARENT (pad));

  char * format = gst_caps_to_string(buf->caps);
  int shm_size = MAKE_ALIGNMENT_SIZE(sizeof(struct SharedVideoBuffer)) + MAKE_ALIGNMENT_SIZE(strlen(format)-1) + MAKE_ALIGNMENT_SIZE(buf->size) + MAKE_ALIGNMENT_SIZE(buf->size);
  extern int errno;
  // no shared memory available, so do not do anything
  if( filter->shm_mem_fd == -1 ){
      if (filter->silent == FALSE) g_print( "Shared memory not available. Can not copy video memory. Dropping Frame on %s.\n", filter->sharedFileName );
      return gst_pad_push (filter->srcpad, buf);
  }

  // gstreamer buffer would not fit in shared memory, so do a resize
  if( shm_size != filter->shm_mem_size ){
      //pthread_mutex_lock( &(filter->videobuffer->structMutex) );
      filter->shm_mem_size = shm_size;
      filter->videobuffer->objectSize = shm_size;
      if( ftruncate( filter->shm_mem_fd, shm_size ) == 0 ){ //shm_video_resize_shared( &(filter->videobuffer), filter->shm_mem_fd ) == 0 ){
        g_printerr( "Shared memory resize done %d %d\n", filter->shm_mem_size, errno );
        filter->videobuffer->objectSize = shm_size;
        filter->videobuffer->bufferSize = buf->size;
        filter->videobuffer = (struct SharedVideoBuffer*)mmap( NULL, filter->shm_mem_size, ( PROT_READ | PROT_WRITE ), MAP_SHARED, filter->shm_mem_fd, 0 );
        filter->videobuffer->buffer[0] = (unsigned char *)( MAKE_ALIGNMENT_SIZE( sizeof( struct SharedVideoBuffer ) ) + MAKE_ALIGNMENT_SIZE(strlen(format)-1) );
        filter->videobuffer->buffer[1] = filter->videobuffer->buffer[0] + MAKE_ALIGNMENT_SIZE(buf->size);
        if (filter->silent == FALSE) g_printf( "Shared memory resized to %d on %s\n", filter->shm_mem_size, filter->sharedFileName );
        shm_video_set_format_from_gst( filter->videobuffer, buf->caps );
        pthread_mutex_lock( &(filter->videobuffer->format.structMutex) );
        strcpy(filter->videobuffer->format.formatstring,format);
        pthread_mutex_unlock( &(filter->videobuffer->format.structMutex) );
      } else {
        // TODO: change this to something good
        filter->videobuffer->objectSize = sizeof( struct SharedVideoBuffer );
        filter->shm_mem_size = 0;
        filter->videobuffer->bufferSize = 0;
        g_printerr( "Shared memory %d resize to %d failed with errno %d\n", filter->shm_mem_fd, shm_size, errno );
      }
      pthread_mutex_unlock( &(filter->videobuffer->structMutex) );
  }

  //static int framecount = 0;
  //framecount++;

  // shared memory ok ? so copy memory in it
  if( shm_size == filter->shm_mem_size ){
      int ret = shm_video_push( filter->videobuffer, buf->data );
      if( ret == 0 ){
        if (filter->silent == FALSE) g_printf( "Copy %d byte video memory on %s.\n", buf->size, filter->sharedFileName );
      } else if(ret == -1){
        if (filter->silent == FALSE) g_print( "Semaphore locked. Can not copy video memory. Dropping Frame on %s.\n", filter->sharedFileName );
      } else {
          if (filter->silent == FALSE) g_print( "Video Format has changed. Dropping Frame on %s.\n", filter->sharedFileName );
      }
      // only needed if you debug with /dev/shm shared memory file in hexeditor
      //msync( filter->videobuffer, filter->shm_mem_size, MS_SYNC );
  }
  if( filter->silent == FALSE ){
    g_printf ("Got buffer size %d type \"%s\" on %s\n",buf->size,gst_caps_to_string(buf->caps), filter->sharedFileName);
  }
#ifdef ASCI_OUTPUT
  char * output = " .:;~+*M";
  // from here only printf debugging :-D
  if ( filter->silent == FALSE /*&& 0*/ ){
    unsigned char * charbuf = buf->data;
    int i,j;
    for( i = 0; i < 480; i += 7 ){
        for( j = 0; j < 480; j += 3 ){
            g_printf ("%c",output[charbuf[(i*480)+j]/32]); //(unsigned char)(val/devide));
        }
        g_print("\n");
    }
  }
#endif
  /* just push out the incoming buffer without touching it */
  return gst_pad_push (filter->srcpad, buf);
}


/* entry point to initialize the plug-in
 * initialize the plug-in itself
 * register the element factories and other features
 */
static gboolean
peregrinevideosink_init (GstPlugin * peregrinevideosink)
{
  /* debug category for fltering log messages
   *
   * exchange the string 'Template peregrinevideosink' with your description
   */
  GST_DEBUG_CATEGORY_INIT (gst_peregrinevideosink_debug, "peregrinevideosink",
      0, "Template peregrinevideosink");

  return gst_element_register (peregrinevideosink, "peregrinevideosink", GST_RANK_NONE,
      GST_TYPE_PEREGRINEVIDEOSINK);
}

/* PACKAGE: this is usually set by autotools depending on some _INIT macro
 * in configure.ac and then written into and defined in config.h, but we can
 * just set it ourselves here in case someone doesn't use autotools to
 * compile this code. GST_PLUGIN_DEFINE needs PACKAGE to be defined.
 */
#ifndef PACKAGE
#define PACKAGE "peregrinevideosink"
#endif

/* gstreamer looks for this structure to register peregrinevideosinks
 *
 * exchange the string 'Template peregrinevideosink' with your peregrinevideosink description
 */
GST_PLUGIN_DEFINE (
    GST_VERSION_MAJOR,
    GST_VERSION_MINOR,
    "peregrinevideosink",
    "Plugin that copy raw image in shared memory",
    peregrinevideosink_init,
    VERSION,
    "LGPL",
    "GStreamer",
    "http://gstreamer.net/"
)
