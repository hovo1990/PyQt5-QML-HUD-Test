/*
* plugin.cpp
*
* Copyright (C) 2009 basysKom GmbH
* Copyright (C) 2009 Nokia Corporation
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "plugin.h"

#include <qdeclarative.h>

#include "../peregrine-lib/channel/clienthandler.h"
#include "../peregrine-lib/account/accountdetailmodel.h"
#include "../peregrine-lib/account/accountlistmodel.h"
#include "../peregrine-lib/account/statusmodel.h"
#include "../peregrine-lib/channel/channelcreationwatcher.h"
#include "../peregrine-lib/channel/clientapprover.h"
#include "../peregrine-lib/contact/contactlistaggregatormodel.h"
#include "../peregrine-lib/contact/contactlistaggregatormodel.h"
#include "../peregrine-lib/contact/metacontact.h"
#include "../peregrine-lib/contact/metacontactlistmodel.h"
#include "../peregrine-lib/contact/metacontactwatcher.h"
#include "../peregrine-lib/channel/textchannelmodel.h"
#include "../peregrine-lib/channel/mediachannelmodel.h"
#include "../peregrine-lib/sortfilterproxymodel.h"
#include "../peregrine-lib/filelogger/notificationlogger.h"
#include "videooutput/qmlvideo.h"

//#include "accountadder.h"
//#include "ChatStorage.h"
//#include "tpinitializer.h"

void Plugin::registerTypes(const char *uri)
{
    qmlRegisterType<Peregrine::ClientHandler>(uri, 1, 0, "ClientHandler");
    qmlRegisterType<Peregrine::ClientApprover>(uri, 1, 0, "ClientApprover");

    qmlRegisterType<Peregrine::AccountDetailModel>(uri, 1, 0, "AccountDetailModel");
    qmlRegisterType<Peregrine::AccountListModel>(uri, 1, 0, "AccountListModel");
    qmlRegisterType<Peregrine::ChannelCreationWatcher>(uri, 1, 0, "ChannelCreationWatcher");
    qmlRegisterType<Peregrine::ContactListAggregatorModel>( uri, 1, 0, "ContactListAggregatorModel" );
    qmlRegisterType<Peregrine::MediaChannelModel>(uri, 1, 0, "MediaChannelModel" );
    qmlRegisterType<Peregrine::MetaContact>( uri, 1, 0, "MetaContact" );
    qmlRegisterType<Peregrine::MetaContactListModel>(uri, 1, 0, "MetaContactListModel");
    qmlRegisterType<Peregrine::MetaContactWatcher>( uri, 1, 0, "MetaContactWatcher" );
    qmlRegisterType<Peregrine::StatusModel>(uri, 1, 0, "StatusModel");
    qmlRegisterType<Peregrine::TextChannelModel>(uri, 1, 0, "TextChannelModel");
    qmlRegisterType<Peregrine::SortFilterProxyModel>(uri, 1, 0, "SortFilterProxyModel");
    qmlRegisterType<Peregrine::NotificationLogger>(uri, 1, 0, "NotificationLogger");
    qmlRegisterType<Peregrine::QMLVideo>(uri, 1, 0, "QMLVideo");
}

Q_EXPORT_PLUGIN2(peregrineqmlplugin, Plugin);
