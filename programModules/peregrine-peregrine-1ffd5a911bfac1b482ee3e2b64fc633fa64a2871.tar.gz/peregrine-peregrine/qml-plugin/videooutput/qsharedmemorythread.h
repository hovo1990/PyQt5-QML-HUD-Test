#ifndef QSHAREDMEMORYTHREAD_H
#define QSHAREDMEMORYTHREAD_H

#include <QThread>
#include <QImage>
#include <QLabel>
#include <QMutex>
#include <QString>

#include "../../gst-plugin/src/shmvideo.h"
#include "qgstvideoformat.h"

class QSharedMemoryThread : public QThread
{
    Q_OBJECT
public:
    explicit QSharedMemoryThread( QMutex * mutex, QImage ** buffer, QString sharedname, QObject *parent = 0 );
    ~QSharedMemoryThread();
    void run();
    void stop();
signals:
    void newDataAvailable();
    void formatCanged( const QGstVideoFormat * format );
public slots:

protected:
    int m_shm_fd;
    struct SharedVideoBuffer * m_videoBuffer;
    bool m_running;
    QMutex * m_mutex;
    QImage ** m_buffer;
    QImage * image[2];
    QString m_sharedName;
private:
    Q_DISABLE_COPY(QSharedMemoryThread)
};

#endif // QSHAREDMEMORYTHREAD_H
