#include "qgstvideoformat.h"

QGstVideoFormat::QGstVideoFormat( struct SharedVideoBuffer::_format * format, QObject *parent ) :
    QObject(parent), format(*format)
{
    formatstring = format->formatstring;
    qDebug("New Video Format %d x %d %s",this->format.videoWidth, this->format.videoHeight, formatstring.toAscii().data());
}

QString QGstVideoFormat::getFormatString(){
    return formatstring;
}

SharedVideoBuffer::_format * QGstVideoFormat::getFormat(){
    return &format;
}
