#include "qsharedmemorythread.h"

QSharedMemoryThread::QSharedMemoryThread( QMutex * mutex, QImage ** buffer, QString sharedname, QObject *parent )
    :  QThread(parent), m_running(false), m_mutex(mutex), m_buffer(buffer), m_sharedName(sharedname)
{
    image[0] = NULL;
    image[1] = NULL;
}

QSharedMemoryThread::~QSharedMemoryThread(){
    this->stop();
    if( image[0] != NULL ){
        delete image[0];
    }
    if( image[1] != NULL ){
        delete image[1];
    }
    *m_buffer = NULL;
}

void QSharedMemoryThread::run(){
    qDebug("start video thread");
    m_running = true;
    shm_video_init_shared( m_sharedName.toAscii().data(), &m_shm_fd, &m_videoBuffer, 1 );
    //unsigned char * buffer;
    //char * output = " .:;~+*M";
    //QImage image;
    //QLabel label;
    //label.show();
    while( m_running == true ){
        unsigned char * buffer;
        buffer = shm_video_pop( m_videoBuffer );
        if( buffer != NULL ){
            //for( int i = 0; i < 480; i += 1 ){ //7 ){
                //for( int j = 0; j < 480; j += 1 ){ //3 ){
                    //g_printf ("%c",output[buffer[(i*480)+j]/32]);

                //}
                //g_print("\n");
            //}
            if( ( m_videoBuffer->format.videoHeight * m_videoBuffer->format.videoWidth * 4 ) == m_videoBuffer->bufferSize ){
                m_mutex->lock();
                if( image[0] == NULL ){
                    image[0] = new QImage( buffer, m_videoBuffer->format.videoWidth, m_videoBuffer->format.videoHeight, QImage::Format_RGB32 );
                    *m_buffer = image[0];
                } else
                if( image[1] == NULL ){
                    image[1] = new QImage( buffer, m_videoBuffer->format.videoWidth, m_videoBuffer->format.videoHeight, QImage::Format_RGB32 );
                    *m_buffer = image[1];
                } else
                if( image[0]->bits() == buffer ){
                    *m_buffer = image[0];
                } else
                if( image[1]->bits() == buffer ){
                    *m_buffer = image[1];
                } else {
                    delete image[0];
                    delete image[1];
                    image[0] = new QImage( buffer, m_videoBuffer->format.videoWidth, m_videoBuffer->format.videoHeight, QImage::Format_RGB32 );
                    *m_buffer = image[0];
                    image[1] = NULL;
                }
                //qDebug("New frame ready on %s.",m_sharedName.toAscii().data());
                emit newDataAvailable();
            }
            //label.setPixmap(QPixmap().fromImage(image));
        } else {
            if( m_shm_fd != -1){
                shm_video_resize_shared( &m_videoBuffer, m_shm_fd, 1, 1 );
                shm_video_format_confirm_has_changed( m_videoBuffer );
                emit formatCanged( new QGstVideoFormat( &(m_videoBuffer->format) ) );
            } else {
                // thread finished
                return;
            }
        }
        //qDebug( "got new frame %d", (int)(m_buffer) );
        if( m_shm_fd != -1){
            shm_video_give_pop_buffer( m_videoBuffer );
        }
    }
}

void QSharedMemoryThread::stop(){
    m_running = false;
    m_shm_fd = -1;
    shm_video_wake_reader( m_videoBuffer );
    if( ! this->wait(1000) ){
        qDebug( "QSharedMemoryThread::stop() this->wait(1000) dont quit. Trying again." );
        shm_video_wake_reader( m_videoBuffer );
        if( ! this->wait(1000) ){
            qDebug( "QSharedMemoryThread::stop() this->wait(1000) dont quit. Terminate." );
            this->terminate();
            if( ! this->wait(1000) ){
                qDebug( "QSharedMemoryThread::stop() this->wait(1000) dont quit. Terminate failed. Quitting anyway." );
            }
        }
    }
    shm_video_close_shared( m_sharedName.toAscii().data(), m_shm_fd, m_videoBuffer, 1 );
    m_videoBuffer = NULL;
}
