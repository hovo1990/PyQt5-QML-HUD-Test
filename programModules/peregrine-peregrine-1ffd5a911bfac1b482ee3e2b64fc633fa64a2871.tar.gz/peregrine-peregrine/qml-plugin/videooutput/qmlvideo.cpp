#include "qmlvideo.h"

using namespace Peregrine;

QMLVideo::QMLVideo(QDeclarativeItem *parent):
    QDeclarativeItem(parent)
{
    // By default, QDeclarativeItem does not draw anything. If you subclass
    // QDeclarativeItem to create a visual item, you will need to uncomment the
    // following line:

    setFlag(ItemHasNoContents, false);
    m_videoThread = NULL;
    m_gstvideoformat = NULL;
    m_buffer = NULL;
    m_width = 100.0;
    m_height = 100.0;
    m_videoWidth = 0.0;
    m_videoHeight = 0.0;
    m_videoAspectratio = 1.0;
    QDeclarativeItem::setWidth(m_width);
    QDeclarativeItem::setHeight(m_height);
}

QMLVideo::~QMLVideo()
{
    delete( m_videoThread );
}

qreal QMLVideo::width() const{
    return m_width;
}

void QMLVideo::setWidth( const qreal & width ){
    m_width = width;
    emit widthChanged(m_width);
    QDeclarativeItem::setWidth(m_width);
}

qreal QMLVideo::height() const{
    return m_height;
}

void QMLVideo::setHeight( const qreal & height ){
    m_height = height;
    emit heightChanged(m_height);
    QDeclarativeItem::setHeight(m_height);
}

void QMLVideo::paint ( QPainter * painter, const QStyleOptionGraphicsItem * option, QWidget * widget ){
    Q_UNUSED(option);
    Q_UNUSED(widget);
#ifdef USE_OPENGL
    GLuint texture = 0;
#endif
    //painter->setPen( QColor("red"));
    //painter->fillRect( 0, 0, m_width, (m_height/2.0) ,QColor("red") );
    //painter->setPen( QColor("blue"));
    //painter->fillRect( 0, (m_height/2.0), m_width, (m_height/2.0), QColor("blue") );
    //qDebug("QMLVideo::paint");

    // if it is locked then we can paint
#ifndef USE_OPENGL
    //if( m_mutex.tryLock()){
        // buffer is in use
        // TODO: paint old image
#ifdef SCALED_VIDEO
            // TODO: keep aspect ratio
            //painter->drawImage(QRectF(0,0,m_width, m_height),*m_buffer,QRectF(0,0,m_gstvideoformat->getFormat()->videoWidth, m_gstvideoformat->getFormat()->videoHeight) );
            //painter->drawImage(QRectF(0,0,m_width, m_height),image,QRectF(0,0,m_gstvideoformat->getFormat()->videoWidth, m_gstvideoformat->getFormat()->videoHeight) );
            //painter->drawImage(0,0,image.scaled(m_width, m_height),0,0,m_width, m_height );
#else
            //painter->drawImage(0,0,*m_buffer,0,0,m_width, m_height );
            //painter->drawImage(0,0,image,0,0,m_width, m_height );
#endif // SCALED_VIDEO
    //} else {
#endif
        if ( m_gstvideoformat != NULL ){
#ifdef USE_OPENGL
            painter->beginNativePainting();

            QGLContext * context = const_cast<QGLContext *>(QGLContext::currentContext());
            if( context ){

                //glEnable(GL_DEPTH_TEST);

                glEnable(GL_TEXTURE_RECTANGLE_ARB);
                //glEnable(GL_TEXTURE_2D);

                GLfloat width = 0;
                GLfloat height = 0;

                int error;

                width = m_gstvideoformat->getFormat()->videoWidth;
                height = m_gstvideoformat->getFormat()->videoHeight;
                if( ! m_mutex.tryLock()){
                    if( texture != 0 ){
                        context->deleteTexture(texture);
                    }
                    texture = context->bindTexture( QImage( m_buffer, m_gstvideoformat->getFormat()->videoWidth, m_gstvideoformat->getFormat()->videoHeight, QImage::Format_RGB32 ), GL_TEXTURE_RECTANGLE_ARB );
                }
                glBindTexture(GL_TEXTURE_RECTANGLE_ARB, texture);
                if( ( error = glGetError() ) != GL_NO_ERROR )
                {
                    QString errorstring;
                    switch( error ){
                        case GL_INVALID_ENUM:
                            errorstring = "GL_INVALID_ENUM";
                            break;
                        case GL_INVALID_VALUE:
                            errorstring = "GL_INVALID_VALUE";
                            break;
                        case GL_INVALID_OPERATION:
                            errorstring = "GL_INVALID_OPERATION";
                            break;
                        case GL_STACK_OVERFLOW:
                            errorstring = "GL_STACK_OVERFLOW";
                            break;
                        case GL_STACK_UNDERFLOW:
                            errorstring = "GL_STACK_UNDERFLOW";
                            break;
                        case GL_OUT_OF_MEMORY:
                            errorstring = "GL_OUT_OF_MEMORY";
                            break;
                        default:
                            errorstring = "UNKNOWN";
                            break;
                    }
                    qDebug ("failed to bind texture %d %s",error,errorstring.toAscii().data());
                    return;
                }

                glEnable(GL_TEXTURE_RECTANGLE_ARB);
                //glEnable(GL_TEXTURE_2D);

                glTexParameteri( GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
                glTexParameteri( GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
                glTexParameteri( GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
                glTexParameteri( GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
                //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
                //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
                //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
                //glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
                glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE );

                glBegin(GL_QUADS);
                    glTexCoord2f( 0.0f, height );     glVertex2f( 0.0f, 0.0f );
                    glTexCoord2f( width, height );     glVertex2f( m_width, 0.0f );
                    glTexCoord2f( width, 0.0f );     glVertex2f( m_width, m_height );
                    glTexCoord2f( 0.0f, 0.0f );     glVertex2f( 0.0f, m_height );
                glEnd();

                //glBindTexture(GL_TEXTURE_2D, 0);
                glBindTexture(GL_TEXTURE_RECTANGLE_ARB, 0);
            }
            painter->endNativePainting();

#else
            //QImage image( m_buffer, m_gstvideoformat->getFormat()->videoWidth, m_gstvideoformat->getFormat()->videoHeight, QImage::Format_RGB32 );
#ifdef SCALED_VIDEO
            // TODO: keep aspect ratio
            if( m_buffer != NULL ){
                painter->drawImage(QRectF(0,0,m_width, m_height),*m_buffer,QRectF(0,0,m_gstvideoformat->getFormat()->videoWidth, m_gstvideoformat->getFormat()->videoHeight) );
            }
            //painter->drawImage(QRectF(0,0,m_width, m_height),image,QRectF(0,0,m_gstvideoformat->getFormat()->videoWidth, m_gstvideoformat->getFormat()->videoHeight) );
            //painter->drawImage(0,0,image.scaled(m_width, m_height),0,0,m_width, m_height );
#else
            if( m_buffer != NULL ){
                painter->drawImage(0,0,*m_buffer,0,0,m_width, m_height );
            }
            //painter->drawImage(0,0,image,0,0,m_width, m_height );
#endif // SCALED_VIDEO
#endif // USE_OPENGL
            // show from qimage
            /*for( int i = 0; i < 480; i += 1 ){ //7 ){
               for( int j = 0; j < 480; j += 1 ){ //3 ){
                   painter->setPen( image.pixel(j,i) );
                   painter->drawPoint(j,i);
               }
            }*/
            /*bool ret = pixmap->convertFromImage( image );
            if( ret == true ){
                static QLabel * label = new QLabel();
                label->setPixmap(*pixmap);
                label->show();
                //painter->drawPixmap(0,0,480,480,*pixmap);
            }*/


            // for rgb32
            /*for( int i = 0; i < 480; i += 1 ){ //7 ){
               for( int j = 0; j < 480; j += 1 ){ //3 ){
                   painter->setPen( QColor( m_buffer[(((i*480)+j)*4)+0], m_buffer[(((i*480)+j)*4)+1], m_buffer[(((i*480)+j)*4)+2] ) );
                   painter->drawPoint(j,i);
               }
            }*/

            // for yuv i420
            /*int uOffset = 480*480;
            int vOffset = uOffset+(uOffset/4);

            for( int i = 0; i < 480; i += 1 ){ //7 ){
               for( int j = 0; j < 480; j += 1 ){ //3 ){
                   painter->setPen( QColor( m_buffer[(i*480)+j], m_buffer[uOffset+((i/4*480)+j/2)], m_buffer[vOffset+((i/4*480)+j/2)] ) );
                   painter->drawPoint(j,i);
                    //g_printf ("%c",output[buffer[(i*480)+j]/32]);

                }
                g_print("\n");
            }*/

        }
#ifndef USE_OPENGL
    //}
#endif
    // we have done painting and give back buffer
    m_mutex.unlock();
}

void QMLVideo::update(){
    QGraphicsItem::update();
}

void QMLVideo::formatCanged( const QGstVideoFormat * format ){
    m_gstvideoformat = ( QGstVideoFormat * )format;
    m_videoWidth = m_gstvideoformat->getFormat()->videoWidth;
    m_videoHeight = m_gstvideoformat->getFormat()->videoHeight;
    m_videoAspectratio = (m_videoWidth / m_videoHeight) * ( (qreal)(m_gstvideoformat->getFormat()->videoAspectratioNumerator) / m_gstvideoformat->getFormat()->videoAspectratioDenominator );
    emit videoWidthChanged(m_videoWidth);
    emit videoHeightChanged(m_videoHeight);
    emit videoAspectratioChanged(m_videoAspectratio);
}

void QMLVideo::setSharedName( const QString & sharedName ){
    if( m_videoThread == NULL ){
        m_sharedName = sharedName;
        m_gstvideoformat = NULL;
        m_videoThread = new QSharedMemoryThread( &this->m_mutex, &this->m_buffer, m_sharedName );

        connect( m_videoThread, SIGNAL(newDataAvailable()), this, SLOT(update()) );
        connect( m_videoThread, SIGNAL(formatCanged(const QGstVideoFormat*)), this, SLOT(formatCanged(const QGstVideoFormat*)) );

        m_videoThread->start();
    }
}

QString QMLVideo::sharedName(){
    return m_sharedName;
}

qreal QMLVideo::videoWidth(){
    return m_videoWidth;
}

qreal QMLVideo::videoHeight(){
    return m_videoHeight;
}

qreal QMLVideo::videoAspectratio(){
    return m_videoAspectratio;
}
