#ifndef QQSTVIDEOFORMAT_H
#define QQSTVIDEOFORMAT_H

#include <QObject>
#include "../../gst-plugin/src/shmvideo.h"

class QGstVideoFormat : public QObject
{
    Q_OBJECT
public:
    explicit QGstVideoFormat( struct SharedVideoBuffer::_format * format, QObject *parent = 0);
    QString getFormatString();
    SharedVideoBuffer::_format * getFormat();
protected:
    SharedVideoBuffer::_format format;
    QString formatstring;
signals:

public slots:

};

#endif // QQSTVIDEOFORMAT_H
