#ifndef QMLVIDEO_H
#define QMLVIDEO_H

#define SCALED_VIDEO
//#define USE_OPENGL
//#define HAVE_GLES2

#include <QtDeclarative/QDeclarativeItem>
#include <QRectF>
#include <QPainter>
#include <QStyleOptionGraphicsItem>
#include <QWidget>
#include <QDebug>
#include <QtDeclarative/qdeclarative.h>
#include <QImage>
#include <QPixmap>
#include <QLabel>

#ifndef GL_TEXTURE_RECTANGLE_ARB
#define GL_TEXTURE_RECTANGLE_ARB 0x84F5
#endif

#ifdef USE_OPENGL
#include <QGLContext>
#if !defined(HAVE_GLES2)
#include <GL/gl.h>
#else
#include <GLES2/gl2.h>
#endif
#endif //USE_OPENGL

#include "../../gst-plugin/src/shmvideo.h"
#include "qsharedmemorythread.h"

namespace Peregrine
{

class QMLVideo : public QDeclarativeItem
{
    Q_OBJECT
    Q_DISABLE_COPY(QMLVideo)
    Q_PROPERTY(qreal width READ width WRITE setWidth NOTIFY widthChanged )
    Q_PROPERTY(qreal height READ height WRITE setHeight NOTIFY heightChanged )
    Q_PROPERTY(QString sharedname READ sharedName WRITE setSharedName)
    Q_PROPERTY(qreal videoWidth READ videoWidth NOTIFY videoWidthChanged )
    Q_PROPERTY(qreal videoHeight READ videoHeight NOTIFY videoHeightChanged )
    Q_PROPERTY(qreal videoAspectratio READ videoAspectratio NOTIFY videoAspectratioChanged )
public:
    QMLVideo(QDeclarativeItem *parent = 0);
    ~QMLVideo();

    qreal width() const;
    void setWidth( const qreal & width );

    qreal height() const;
    void setHeight( const qreal & height );
    QString sharedName();

    qreal videoWidth();
    qreal videoHeight();
    qreal videoAspectratio();

signals:
    void widthChanged( const qreal & width );
    void heightChanged( const qreal & height );
    void videoWidthChanged( const qreal & width );
    void videoHeightChanged( const qreal & height );
    void videoAspectratioChanged( const qreal & aspect );
public slots:
    void update();
    void formatCanged( const QGstVideoFormat * format );
    void setSharedName( const QString & sharedName );
protected:
    qreal m_width;
    qreal m_height;
    qreal m_videoWidth;
    qreal m_videoHeight;
    qreal m_videoAspectratio;
    void paint ( QPainter * painter, const QStyleOptionGraphicsItem * option, QWidget * widget );
    QMutex m_mutex;
    QImage * m_buffer;
    QSharedMemoryThread * m_videoThread;
    QGstVideoFormat * m_gstvideoformat;
    QString m_sharedName;
#ifdef USE_OPENGL
    GLuint texture;
#endif

};

}

#endif // QMLVIDEO_H

