/*
* presencestates.cpp
*
* Copyright (C) 2009-2011 basysKom GmbH
* Copyright (C) 2009-2011 Nokia Corporation
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "presencestates.h"
#include "peregrineDebugHelper.h"

#include <TelepathyQt4/Connection>

#include <QDebug>


using namespace Peregrine;

QStringList Peregrine::presencesStatesForAccount( Tp::AccountPtr account )
{
    FUNC_IN
    QStringList presenceStates;

    Tp::ConnectionPtr connection = account->connection();
    QList<int> availableIndex;

    if( connection.isNull() || !connection->isReady(Tp::Connection::FeatureSimplePresence) ||
        account.isNull() || !account->isReady(Tp::Features() << Tp::Account::FeatureProfile << Tp::Account::FeatureProtocolInfo) )
    {
        presenceStates = OFFLINE_PRESENCE_STATES;
    } else
    {
        Tp::PresenceSpecList speclist = account->allowedPresenceStatuses();
        QMap<QString, Tp::PresenceSpec> specmap = speclist.toMap();
        foreach( QString state, specmap.keys() )
        {
            if( specmap.value(state).maySetOnSelf() )
            {
                int type = specmap.value(state).presence().type();
                if( !availableIndex.contains(type) )
                {
                    availableIndex << type;
                }
            }
        }

        // do we realy want to remove eXtended Away?
        availableIndex.removeAll(PresenceStateXa);

        if( !availableIndex.contains(PresenceStateOffline) )
        {
            availableIndex.append(PresenceStateOffline);
        }

//        availableIndex = sortPresenceStates( availableIndex );
        foreach( int i, availableIndex )
        {
            presenceStates << PRESENCE_STATE_NAMES.at(i);
        }
    }

    // just a work around as long as we cannot get the list of available presence states
    //presenceStates = OFFLINE_PRESENCE_STATES;

//    qDebug() << __PRETTY_FUNCTION__ << "PRESENCE STATES" << presenceStates;
    FUNC_OUT
    return sortPresenceStates( presenceStates );
}

QStringList Peregrine::sortPresenceStates( const QStringList &presenceStateNames )
{
    FUNC_IN
    QStringList result;

    foreach( PresenceStates state, PRESENCE_STATES_ORDER )
    {
        QString presenceName = PRESENCE_STATE_NAMES.at( state );
        if( presenceStateNames.contains(presenceName) )
        {
            result.append( presenceName );
        }
    }

    FUNC_OUT
    return result;
}

QList<int> Peregrine::sortPresenceStates( const QList<int> &presenceStates )
{
    FUNC_IN
    QList<int> result;

    foreach( PresenceStates state, PRESENCE_STATES_ORDER )
    {
        if( presenceStates.contains(state) )
        {
            result.append( state );
        }
    }

    FUNC_OUT
    return result;
}
