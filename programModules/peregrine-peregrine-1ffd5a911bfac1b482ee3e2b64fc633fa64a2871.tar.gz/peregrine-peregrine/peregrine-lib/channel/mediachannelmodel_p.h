/*
 * mediachannelmodel_p.h
 *
 * Copyright (C) 2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef MEDIACHANNELMODEL_P_H
#define MEDIACHANNELMODEL_P_H

#include "farsight-channel.h"
#include "clienthandler_p.h"

#include <QObject>
#include <QTimerEvent>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/Connection>
#include <TelepathyQt4/Contact>
#include <TelepathyQt4/Features>
#include <TelepathyQt4/SharedPtr>
#include <TelepathyQt4/StreamedMediaChannel>
#include <TelepathyQt4/Types>

namespace Peregrine
{

class MediaChannelModel;

class MediaChannelModelPrivate
    : public QObject
{
    Q_OBJECT

    friend class MediaChannelModel;

    static const Tp::Features ACCOUNT_FEATURES;
    static const Tp::Features CONNECTION_FEATURES;
    static const Tp::Features CONTACT_FEATURES;
    static const QString DURATION_STRING_CONNECTED;
    static const QString DURATION_STRING_CONNECTING;
    static const QString DURATION_STRING_DISCONNECTED;
    static const Tp::Features STREAMED_MEDIA_CHANNEL_FEATURES;

    Tp::AccountPtr mAccount;
    QList<Tp::ChannelPtr> mChannels;
    Tp::ConnectionPtr mConnection;
    Tp::ContactPtr mContact;
    QPointer<ChannelContext> mContext;
    int mDuration;
    QString mDurationString;
    int mDurationTimerId;
    QPointer<FarsightChannel> mFarsightChannel;
    bool mIsConnected;
    QPointer<MediaChannelModel> mParent;
    QString mServiceName;
    Tp::StreamedMediaChannelPtr mStreamedMediaChannel;

    explicit MediaChannelModelPrivate( MediaChannelModel *parent = 0 );
    ~MediaChannelModelPrivate();

    bool connectAccount( Tp::AccountPtr account );
    bool connectConnection( Tp::ConnectionPtr connection );
    bool connectContact( Tp::ContactPtr contact );
    bool connectFarsightChannel( FarsightChannel *farsightChannel );
    bool connectStreamedMediaChannel( Tp::StreamedMediaChannelPtr channel );
    bool disconnectAccount( Tp::AccountPtr account );
    bool disconnectConnection( Tp::ConnectionPtr connection );
    bool disconnectContact( Tp::ContactPtr contact );
    bool disconnectFarsightChannel( FarsightChannel *farsightChannel );
    bool disconnectStreamedMediaChannel( Tp::StreamedMediaChannelPtr channel );

    QString updateDurationString();

private slots:
    // account
    void onAccountReady( Tp::PendingOperation *operation );
    // connection
    void onConnectionReady( Tp::PendingOperation *operation );
    // contact
    // TODO: check if we still need to upgrade contacts
//    void onContactManagerContactsUpgraded( Tp::PendingOperation *operation );
    // contact manager
    void onContactPresenceChanged( const Tp::Presence &presence );
    void onPendingContactsReady( Tp::PendingOperation *operation );
    // streams
    void onPendingMediaStreamStreamCreated( Tp::PendingOperation *operation );
    // general PendingOperation
    void onPendingOperationFinished( Tp::PendingOperation *operation );
    // channel
    void onStreamedMediaChannelAccepted( Tp::PendingOperation *operation );
    void onStreamedMediaChannelInvalidated( Tp::DBusProxy *proxy,
                                            const QString &errorName,
                                            const QString &errorMessage );
    void onStreamedMediaChannelLocalHoldStateChanged( Tp::LocalHoldState state,
                                                      Tp::LocalHoldStateReason reason );
    void onStreamedMediaChannelReady( Tp::PendingOperation *operation );
    void onStreamedMediaChannelStreamAdded( const Tp::StreamedMediaStreamPtr &stream );
    void onStreamedMediaChannelStreamDirectionChanged( const Tp::StreamedMediaStreamPtr &stream,
                                                       Tp::MediaStreamDirection direction,
                                                       Tp::MediaStreamPendingSend pendingSend );
    void onStreamedMediaChannelStreamError( const Tp::StreamedMediaStreamPtr &stream,
                                            Tp::MediaStreamError errorCode,
                                            const QString &errorMessage );
    void onStreamedMediaChannelStreamRemoved( const Tp::StreamedMediaStreamPtr &stream );
    void onStreamedMediaChannelStreamStateChanged( const Tp::StreamedMediaStreamPtr &stream,
                                                   Tp::MediaStreamState state );

    void updateChannelState();
    void timerEvent( QTimerEvent *event );

signals:

};

}
#endif // MEDIACHANNELMODEL_P_H
