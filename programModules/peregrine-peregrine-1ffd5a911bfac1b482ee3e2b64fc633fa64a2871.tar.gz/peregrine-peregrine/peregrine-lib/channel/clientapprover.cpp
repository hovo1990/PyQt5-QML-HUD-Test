/*
 * clientapprover.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "clientapprover.h"
#include "clientapprover_p.h"

#include "../peregrineDebugHelper.h"
#include "../peregrineinitializer.h"

#include <TelepathyQt4/Account>
#include <TelepathyQt4/Channel>
#include <TelepathyQt4/ChannelClassSpec>
#include <TelepathyQt4/FileTransferChannel>
#include <TelepathyQt4/PendingReady>
#include <TelepathyQt4/ReceivedMessage>
#include <TelepathyQt4/StreamedMediaChannel>
#include <TelepathyQt4/TextChannel>
#include <TelepathyQt4/Types>

using namespace Peregrine;

/* *****************************************************************************
 * DispatchOperationContext
 * ****************************************************************************/

const Tp::Features
DispatchOperationContext::CHANNEL_DISPATCH_OPERATION_FEATURES = ( Tp::Features()
                                                                  << Tp::ChannelDispatchOperation::FeatureCore );

void
DispatchOperationContext::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();
        emit removed();
        FUNC_OUT
        return;
    }

    if( mFinishedChannels == 0
        && mDispatchOperation->connection()->isReady() )
    {
        emit initialized();
    }
    FUNC_OUT
}

void
DispatchOperationContext::onChannelReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();
        emit removed();
        FUNC_OUT
        return;
    }

    Tp::ChannelPtr channel = Tp::ChannelPtr::staticCast( operation->object() );
    // activate specialized features for channels (also needed for core feature set!!!)
    if( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_TEXT )
    {
        // check if needed TextChannel features are activated
        Tp::TextChannelPtr textChannel = Tp::TextChannelPtr::staticCast( channel );
        if( !channel->isReady(Tp::Features() << Tp::TextChannel::FeatureCore
                                             << Tp::TextChannel::FeatureMessageQueue) )
        {
            connect( textChannel->becomeReady(Tp::Features() << Tp::TextChannel::FeatureCore << Tp::TextChannel::FeatureMessageQueue),
                     SIGNAL(finished(Tp::PendingOperation *)),
                     this,
                     SLOT(onChannelReady(Tp::PendingOperation *)) );
            FUNC_OUT
            return;
        }
    } else if( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_STREAMED_MEDIA )
    {
        Tp::StreamedMediaChannelPtr mediaChannel = Tp::StreamedMediaChannelPtr::staticCast( channel );
        if( !channel->isReady(Tp::Features() << Tp::StreamedMediaChannel::FeatureCore) )
        {
            connect( mediaChannel->becomeReady(),
                     SIGNAL(finished(Tp::PendingOperation *)),
                     this,
                     SLOT(onChannelReady(Tp::PendingOperation *)) );
            FUNC_OUT
            return;
        }
    } else if ( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_FILE_TRANSFER )
    {
        Tp::FileTransferChannelPtr fileChannel = Tp::FileTransferChannelPtr::staticCast( channel );
        if( !channel->isReady(Tp::Features() << Tp::FileTransferChannel::FeatureCore) )
        {
            connect( fileChannel->becomeReady(Tp::Features() << Tp::FileTransferChannel::FeatureCore),
                     SIGNAL(finished(Tp::PendingOperation *)),
                     this,
                     SLOT(onChannelReady(Tp::PendingOperation *)) );
            FUNC_OUT
            return;
        }
    }

    if( --mFinishedChannels <= 0
        && mDispatchOperation->account()->isReady()
        && mDispatchOperation->connection()->isReady() )
    {
        emit initialized();
    }
    FUNC_OUT
}

void
DispatchOperationContext::onConnectionReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();
        emit removed();
        FUNC_OUT
        return;
    }

    if( mFinishedChannels <= 0
        && mDispatchOperation->account()->isReady() )
    {
        emit initialized();
    }
    FUNC_OUT
}

void
DispatchOperationContext::onDispatchOperationInvalidated( Tp::DBusProxy *proxy,
                                                          const QString &errorName,
                                                          const QString &errorMessage )
{
    FUNC_IN
    Q_UNUSED( proxy );
    Q_UNUSED( errorName );
    Q_UNUSED( errorMessage );
    qDebug() << "noQML:" << __FUNCTION__ << POINTER_TO_QSTRING(this);

    disconnect( mDispatchOperation.data(), 0, this, 0 );
    mDispatchOperation.reset();
    emit removed();
    FUNC_OUT
}

void
DispatchOperationContext::onDispatchOperationReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    qDebug() << "noQML:" << __FUNCTION__ << POINTER_TO_QSTRING(this);
    if( operation->isError() )
    {
        disconnect( mDispatchOperation.data(), 0, this, 0 );
        mDispatchOperation.reset();
        emit removed();
        FUNC_OUT
        return;
    }

    mFinishedChannels = mDispatchOperation->channels().count();

    Tp::AccountPtr account = mDispatchOperation->account();
    Tp::ConnectionPtr connection = mDispatchOperation->connection();
    connect( account->becomeReady(),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onAccountReady(Tp::PendingOperation *)) );
    connect( connection->becomeReady(),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onConnectionReady(Tp::PendingOperation *)) );

    foreach( Tp::ChannelPtr channel, mDispatchOperation->channels() )
    {
        connect( channel->becomeReady(Tp::Features() << Tp::Channel::FeatureCore),
                 SIGNAL(finished(Tp::PendingOperation *)),
                 this,
                 SLOT(onChannelReady(Tp::PendingOperation *)) );
    }

    FUNC_OUT
}

DispatchOperationContext::DispatchOperationContext( const Tp::ChannelDispatchOperationPtr &dispatchOperation,
                                                    QObject *parent )
    : QObject( parent )
    , mFinishedChannels( 0 )
{
    FUNC_IN
    mDispatchOperation = dispatchOperation;
    qDebug() << "noQML:" << __FUNCTION__ << POINTER_TO_QSTRING(this);

    Q_ASSERT( !mDispatchOperation.isNull() );

    connect( mDispatchOperation->becomeReady(CHANNEL_DISPATCH_OPERATION_FEATURES),
             SIGNAL(finished(Tp::PendingOperation*)),
             this,
             SLOT(onDispatchOperationReady(Tp::PendingOperation *)) );
    connect( mDispatchOperation.data(),
             SIGNAL(invalidated(Tp::DBusProxy *, QString, QString)),
             this,
             SLOT(onDispatchOperationInvalidated(Tp::DBusProxy *, QString, QString)) );
    FUNC_OUT
}

QString
DispatchOperationContext::contactId() const
{
    FUNC_IN
    Q_ASSERT( mDispatchOperation->channels().count() > 0 );

    Tp::ChannelPtr channel = mDispatchOperation->channels().at(0);

    QString contactId = channel->immutableProperties().value( TP_QT4_IFACE_CHANNEL + ".TargetID" ).toString();
    if( channel->targetHandleType() == Tp::HandleTypeContact )
    {
        if( !contactId.isEmpty() )
        {
            contactId = mDispatchOperation->account()->objectPath() + "::" + contactId;
        }
    }

    if( contactId.isEmpty() )
    {
        contactId = QString( "unknown" );
    }
    FUNC_OUT
    return contactId;
}

Tp::ChannelDispatchOperationPtr
DispatchOperationContext::dispatchOperation() const
{
    FUNC_IN
    FUNC_OUT
    return mDispatchOperation;
}

QString
DispatchOperationContext::id() const
{
    FUNC_IN
    FUNC_OUT
    return mDispatchOperation->objectPath();
}

QString
DispatchOperationContext::type() const
{
    FUNC_IN
    Q_ASSERT( mDispatchOperation->channels().count() > 0 );

    QString type = mDispatchOperation->channels().at(0)->channelType();
    if( type == TP_QT4_IFACE_CHANNEL_TYPE_TEXT )
    {
        type = ClientApprover::CHANNEL_TYPE_TEXT;
    } else if( type == TP_QT4_IFACE_CHANNEL_TYPE_STREAMED_MEDIA )
    {
        type = ClientApprover::CHANNEL_TYPE_MEDIA;

        if( mDispatchOperation->account()->protocolName() == "tel" )
        {
            type = ClientApprover::CHANNEL_TYPE_CELL;
        }
    } else if( type == TP_QT4_IFACE_CHANNEL_TYPE_FILE_TRANSFER )
    {
        type = ClientApprover::CHANNEL_TYPE_FILE;
    }

    FUNC_OUT
    return type;
}

QString
DispatchOperationContext::variantData() const
{
    FUNC_IN
    Q_ASSERT( mDispatchOperation->channels().count() > 0 );

    Tp::ChannelPtr channel = mDispatchOperation->channels().at(0);
    QString type = channel->channelType();
    QString data;
    if( type == TP_QT4_IFACE_CHANNEL_TYPE_TEXT )
    {
        Tp::TextChannelPtr textChannel = Tp::TextChannelPtr::staticCast( channel );

        QList<Tp::ReceivedMessage> messages = textChannel->messageQueue();
        if( messages.count() > 0 )
        {
            data = messages.at(0).text();
        }
    } else if( type == TP_QT4_IFACE_CHANNEL_TYPE_STREAMED_MEDIA )
    {
    } else if( type == TP_QT4_IFACE_CHANNEL_TYPE_FILE_TRANSFER )
    {
        Tp::FileTransferChannelPtr fileChannel = Tp::FileTransferChannelPtr::staticCast( channel );
        data = fileChannel->fileName();
    }

    FUNC_OUT
    return data;
}

/* *****************************************************************************
 * ClientApproverPrivate
 * ****************************************************************************/

ClientApproverPrivate::ClientApproverPrivate( const QString clientName,
                                              const Tp::ChannelClassSpecList &filters,
                                              ClientApprover *parent )
    : QObject( parent )
    , Tp::AbstractClientApprover( filters )
    , mParent( parent )
{
    FUNC_IN
    if( mParent.isNull() )
    {
        deleteLater();
        FUNC_OUT
        return;
    }

    mParent->beginResetModel();

    mClientName = clientName;

    Tp::AbstractClientPtr ptr = Tp::AbstractClientPtr::dynamicCast(
                                Tp::SharedPtr<ClientApproverPrivate>(this) );
    // we need this hack because else when
    // ptr is deleted, the object itself gets deleted
    ptr->ref();

    mRegistrar = Tp::ClientRegistrar::create();
    mRegistrar->registerClient( ptr, clientName );

    mParent->endResetModel();
    emit mParent->initialized();

    FUNC_OUT
}

ClientApproverPrivate::~ClientApproverPrivate()
{
    FUNC_IN
    if( !mRegistrar.isNull() )
    {
        Tp::AbstractClientPtr ptr = Tp::AbstractClientPtr::dynamicCast(
                                    Tp::SharedPtr<ClientApproverPrivate>(this) );
        mRegistrar->unregisterClient( ptr );
    }
    FUNC_OUT
}

void
ClientApproverPrivate::addDispatchOperation( const Tp::MethodInvocationContextPtr<> &context,
                                             const Tp::ChannelDispatchOperationPtr &dispatchOperation )
{
    FUNC_IN
    DispatchOperationContext *doc = new DispatchOperationContext( dispatchOperation );
    connect( doc,
             SIGNAL(initialized()),
             this,
             SLOT(onDispatchOperationContextInitialized()) );
    connect( doc,
             SIGNAL(removed()),
             this,
             SLOT(onDispatchOperationContextRemoved()) );

    context->setFinished();
    FUNC_OUT
}

void
ClientApproverPrivate::onDispatchOperationContextInitialized()
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    // cast to DispatchOperationContext
    QPointer<DispatchOperationContext> doc(qobject_cast<DispatchOperationContext *>(sender()) );
    if( doc.isNull() )
    {
        FUNC_OUT
        return;
    }

    QString protocolName = doc->dispatchOperation()->account()->protocolName();
    if( protocolName != "jabber"
        && protocolName != "skype" )
    {
        doc->deleteLater();
        FUNC_OUT
        return;
    }

    // insert dispatch operation to list
    int row = mDispatchOperations.count();
    mParent->beginInsertRows( QModelIndex(), row, row );
    mDispatchOperations.append( doc );
    mParent->endInsertRows();

    // emit signal
    QString type = doc->type();
    QString id = doc->id();
    QString contactId = doc->contactId();
    emit mParent->incomingChannel( id, type, contactId );

    if( type == ClientApprover::CHANNEL_TYPE_TEXT )
    {
        // TODO: selective auto acceptance
        // automatically accept text channels
        mParent->accept( id );
//        emit mParent->incomingTextChat( id, contactId );
    } else if( type == ClientApprover::CHANNEL_TYPE_MEDIA
               || type == ClientApprover::CHANNEL_TYPE_CELL )
    {
        qDebug() << "noQML:" << __FUNCTION__ << "auto accepting media channel";
        mParent->accept( id );
//        emit mParent->incomingMediaCall( id, contactId );
    } else if( type == ClientApprover::CHANNEL_TYPE_FILE )
    {
        emit mParent->incomingFileTransfer( id, contactId );
    }

    FUNC_OUT
}

void
ClientApproverPrivate::onDispatchOperationContextRemoved()
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    // cast to DispatchOperationContext
    QPointer<DispatchOperationContext> doc( qobject_cast<DispatchOperationContext *>(sender()) );
    if( doc.isNull() )
    {
        FUNC_OUT
        return;
    }

    // insert dispatch operation to list
    int row = mDispatchOperations.indexOf( doc );
    if( row >= 0 )
    {
        mParent->beginRemoveRows( QModelIndex(), row, row );
        mDispatchOperations.removeAt( row );
        mParent->endInsertRows();
    }

    disconnect( doc.data(), 0, this, 0 );
    doc->deleteLater();
    FUNC_OUT
}

void
ClientApproverPrivate::onDispatchOperationFinished( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    Q_UNUSED( operation );

    // get DispatchOperation
    Tp::ChannelDispatchOperationPtr dispatchOperation =
            Tp::ChannelDispatchOperationPtr::staticCast( operation->object() );

    // find DispatchOperation
    for( int i = 0; i < mDispatchOperations.count(); ++i )
    {
        DispatchOperationContext *context = mDispatchOperations.at( i );
        if( context->dispatchOperation() == dispatchOperation )
        { // remove DispatchOperationContext
            mParent->beginRemoveRows( QModelIndex(), i, i );

            // remove from model
            disconnect( context, 0, this, 0 );
            context->deleteLater();
            mDispatchOperations.removeAt( i );

            mParent->endRemoveRows();
            break;
        }
    }
    FUNC_OUT
}

/* *****************************************************************************
 * ClientApprover
 * ****************************************************************************/

const QString ClientApprover::CAPABILITY_FILE_TRANSFER = QString( "file" );
const QString ClientApprover::CAPABILITY_TEXT_CHAT = QString( "text" );
const QString ClientApprover::CAPABILITY_VIDEO_CALL = QString( "video" );
const QString ClientApprover::CAPABILITY_VOIP_CALL = QString( "voip" );

const QString
ClientApprover::CHANNEL_TYPE_TEXT = QString("text");
const QString
ClientApprover::CHANNEL_TYPE_MEDIA = QString("media");
const QString
ClientApprover::CHANNEL_TYPE_CELL = QString("cell");
const QString
ClientApprover::CHANNEL_TYPE_FILE = QString("file");
const QString
ClientApprover::CHANNEL_TYPE_CONTACT_LIST = QString("contactlist");
const QString
ClientApprover::CHANNEL_TYPE_ROOM_LIST = QString("roomlist");
const QString
ClientApprover::CHANNEL_TYPE_STREAM_TUBE = QString("streamtube");
const QString
ClientApprover::CHANNEL_TYPE_TUBES = QString("tubes");
const QString
ClientApprover::CHANNEL_TYPE_UNKNOWN = QString("unknown");

void
ClientApprover::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames;
    rolenames.insert( IdRole,          "id" );
    rolenames.insert( TypeRole,        "type" );
    rolenames.insert( ContactIdRole,   "contactId" );
    rolenames.insert( AcceptanceRole,  "acceptance" );
    rolenames.insert( VariantDataRole, "variantData" );
    rolenames.insert( ServiceNameRole, "serviceName" );
    rolenames.insert( ServiceIconRole, "serviceIcon" );
    setRoleNames( rolenames );
    FUNC_OUT
}

ClientApprover::ClientApprover( QObject *parent )
    : QAbstractItemModel( parent )
    , d( 0 )
    , mClientName( "Peregrine" )
{
    FUNC_IN
    Peregrine::initialize();
    initRoleNames();
    mCapabilities << QString("text");

    connect( this,
             SIGNAL(columnsInserted(QModelIndex, int, int)),
             this,
             SIGNAL(columnCountChanged()) );
    connect( this,
             SIGNAL(columnsRemoved(QModelIndex, int, int)),
             this,
             SIGNAL(columnCountChanged()) );
    connect( this,
             SIGNAL(layoutChanged()),
             this,
             SIGNAL(columnCountChanged()) );
    connect( this,
             SIGNAL(layoutChanged()),
             this,
             SIGNAL(rowCountChanged()) );
    connect( this,
             SIGNAL(rowsInserted(QModelIndex, int, int)),
             this,
             SIGNAL(rowCountChanged()) );
    connect( this,
             SIGNAL(rowsRemoved(QModelIndex, int, int)),
             this,
             SIGNAL(rowCountChanged()) );

    FUNC_OUT
}

void
ClientApprover::addCapability( const QString &capability )
{
    FUNC_IN
    if( d )
    {
        FUNC_OUT
        return;
    }

    if( capability == CAPABILITY_FILE_TRANSFER
        && !mCapabilities.contains(CAPABILITY_FILE_TRANSFER) )
    {
        mCapabilities.append( CAPABILITY_FILE_TRANSFER );
        emit capabilitiesChanged( mCapabilities );
        FUNC_OUT
        return;
    }
    if( capability == CAPABILITY_TEXT_CHAT
        && !mCapabilities.contains(CAPABILITY_TEXT_CHAT) )
    {
        mCapabilities.append( CAPABILITY_TEXT_CHAT );
        emit capabilitiesChanged( mCapabilities );
        FUNC_OUT
        return;
    }
    if( capability == CAPABILITY_VIDEO_CALL
        && !mCapabilities.contains(CAPABILITY_VIDEO_CALL) )
    {
        mCapabilities.append( CAPABILITY_VIDEO_CALL );
        emit capabilitiesChanged( mCapabilities );
        FUNC_OUT
        return;
    }
    if( capability == CAPABILITY_VOIP_CALL
        && !mCapabilities.contains(CAPABILITY_VOIP_CALL) )
    {
        mCapabilities.append( CAPABILITY_VOIP_CALL );
        emit capabilitiesChanged( mCapabilities );
        FUNC_OUT
        return;
    }
    FUNC_OUT
}

QStringList
ClientApprover::capabilities() const
{
    FUNC_IN
    FUNC_OUT
    return mCapabilities;
}

QString
ClientApprover::clientName() const
{
    FUNC_IN
    if( !d.isNull() )
    {
        FUNC_OUT
        return mClientName;
    }
    FUNC_OUT
    return d->mClientName;
}

int
ClientApprover::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( d.isNull()
        || parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }
    FUNC_OUT
    return ColumnCount;
}

QVariant
ClientApprover::data( const QModelIndex &index, int role ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !index.isValid() )
    {
        FUNC_OUT
        return QVariant();
    }

    int row = index.row();
    switch( role )
    {
    case IdRole:
        FUNC_OUT
        return d->mDispatchOperations.at( row )->id();
    case TypeRole:
        FUNC_OUT
        return d->mDispatchOperations.at( row )->type();
    case ContactIdRole:
        FUNC_OUT
        return d->mDispatchOperations.at( row )->contactId();
    case AcceptanceRole:
        FUNC_OUT
        return AcceptanceStatePending;
    case VariantDataRole:
        FUNC_OUT
        return d->mDispatchOperations.at( row )->variantData();
    case ServiceNameRole:
        FUNC_OUT
        return d->mDispatchOperations.at( row )->dispatchOperation()->account()->serviceName();
    case ServiceIconRole:
        FUNC_OUT
        return d->mDispatchOperations.at( row )->dispatchOperation()->account()->iconName();
    }

    FUNC_OUT
    return QVariant();
}

Qt::ItemFlags
ClientApprover::flags( const QModelIndex &index ) const
{
    FUNC_IN
    if( !index.isValid() )
    {
        FUNC_OUT
        return QAbstractItemModel::flags( index );
    }

    FUNC_OUT
    return QAbstractItemModel::flags( index ) | Qt::ItemIsEditable;
}

QModelIndex
ClientApprover::index(int row, int column, const QModelIndex &parent) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( column < 0
        || column >= ColumnCount
        || row < 0
        || row >= d->mDispatchOperations.count()
        || parent.isValid() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    FUNC_OUT
    return createIndex( row, column, d->mDispatchOperations.at( row ).data() );
}

QModelIndex
ClientApprover::parent( const QModelIndex &child ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    Q_UNUSED( child );
    FUNC_OUT
    return QModelIndex();
}

QString
ClientApprover::preferredHandler() const
{
    FUNC_IN
    FUNC_OUT
    return mPreferredClientHandlerName;
}

void
ClientApprover::removeCapability( const QString &capability )
{
    FUNC_IN
    if( d )
    {
        FUNC_OUT
        return;
    }

    mCapabilities.removeAll( capability );
    emit capabilitiesChanged( mCapabilities );
    FUNC_OUT
}

int
ClientApprover::rowCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( d.isNull()
        || parent.isValid() )
    {
        return 0;
    }

    FUNC_OUT
    return d->mDispatchOperations.count();
}

void
ClientApprover::setCapabilities( const QStringList &capabilities )
{
    FUNC_IN
    if( d )
    {
        FUNC_OUT
        return;
    }

    mCapabilities = capabilities;
    for( int i = 0; i < mCapabilities.count(); ++i )
    {
        if( mCapabilities.at(i) == CAPABILITY_FILE_TRANSFER )
            continue;
        if( mCapabilities.at(i) == CAPABILITY_TEXT_CHAT )
            continue;
        if( mCapabilities.at(i) == CAPABILITY_VIDEO_CALL )
            continue;
        if( mCapabilities.at(i) == CAPABILITY_VOIP_CALL )
            continue;
        mCapabilities.removeAt(i--);
    }
    emit capabilitiesChanged( mCapabilities );
    FUNC_OUT
}

void
ClientApprover::setClientName( const QString &name )
{
    FUNC_IN
    if( !d.isNull()
        && !name.isEmpty() )
    {
        mClientName = name;
        emit clientNameChanged( mClientName );
    }
    FUNC_OUT
}

bool
ClientApprover::setData(const QModelIndex &index, const QVariant &value, int role)
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !index.isValid() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "index invalid";
        FUNC_OUT
        return false;
    }

    int row = index.row();
    if( role == AcceptanceRole )
    {
        AcceptanceStates acceptance = static_cast<AcceptanceStates>( value.toInt() );
        if( acceptance == AcceptanceStateAccept )
        { // accept
            DispatchOperationContext *context = d->mDispatchOperations.at( row );

            QString client = TP_QT4_IFACE_CLIENT + "." + mClientName;
            Tp::ChannelDispatchOperationPtr dispatchOperation = context->dispatchOperation();
            // accept channels
            if( dispatchOperation->possibleHandlers().contains(client))
            {
                connect( dispatchOperation->handleWith(client),
                         SIGNAL(finished(Tp::PendingOperation*)),
                         d.data(),
                         SLOT(onDispatchOperationFinished(Tp::PendingOperation*)) );
            } else
            {
                connect( dispatchOperation->handleWith(QString()),
                         SIGNAL(finished(Tp::PendingOperation*)),
                         d.data(),
                         SLOT(onDispatchOperationFinished(Tp::PendingOperation*)) );
            }
            FUNC_OUT
            return true;
        } else if( acceptance == AcceptanceStateReject )
        { // reject
            DispatchOperationContext *context = d->mDispatchOperations.at( row );

            beginRemoveRows( QModelIndex(), row, row );

            Tp::ChannelDispatchOperationPtr dispatchOperation = context->dispatchOperation();

            // close channels
            QList<Tp::ChannelPtr> channels = dispatchOperation->channels();
            foreach (Tp::ChannelPtr channel, channels) {
                if( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_TEXT )
                {
                    Tp::TextChannelPtr textChannel = Tp::TextChannelPtr::staticCast( channel );
                    QList<Tp::ReceivedMessage> messages = textChannel->messageQueue();
                    textChannel->acknowledge( messages );
                }
                channel->requestClose();
            }

            // remove from model
            disconnect( context, 0, d.data(), 0 );
            context->deleteLater();
            d->mDispatchOperations.removeAt( row );

            endRemoveRows();

            FUNC_OUT
            return true;
        }
    }

    FUNC_OUT
    return false;
}

bool
ClientApprover::setData( int row, const QVariant &value, int role )
{
    FUNC_IN
    QModelIndex idx = index( row, ColumnChannel );
    FUNC_OUT
    return setData( idx, value, role );
}

void
ClientApprover::setPreferredHandler( const QString &handlerName )
{
    if( handlerName.isEmpty()
        && d )
    {
        mPreferredClientHandlerName = mClientName;
        emit preferredHandlerChanged( mPreferredClientHandlerName );
        FUNC_OUT
        return;
    }

    mPreferredClientHandlerName = handlerName;
    emit preferredHandlerChanged( mPreferredClientHandlerName );
    FUNC_OUT
    return;
}

void
ClientApprover::accept( const QString &dispatchId )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    for( int i = 0; i < d->mDispatchOperations.count(); ++i )
    {
        DispatchOperationContext *context = d->mDispatchOperations.at( i );
        if( context->id() == dispatchId )
        {
            beginRemoveRows( QModelIndex(), i, i );

//            QString client = TP_QT4_IFACE_CLIENT + "." + mClientName;
            QString client = TP_QT4_IFACE_CLIENT + "." + mPreferredClientHandlerName;
            Tp::ChannelDispatchOperationPtr dispatchOperation = context->dispatchOperation();
            // accept channels
            if( dispatchOperation->possibleHandlers().contains(client))
            {
                dispatchOperation->handleWith( client );
            } else
            {
                dispatchOperation->handleWith( QString() );
            }

            // remove from model
            disconnect( context, 0, d.data(), 0 );
            context->deleteLater();
            d->mDispatchOperations.removeAt( i );

            endRemoveRows();
            break;
        }
    }
    FUNC_OUT
}

bool
ClientApprover::initialize( const QString &clientName )
{
    FUNC_IN
    if( d )
    { // already initialized
        qWarning() << __PRETTY_FUNCTION__
                   << "ClientApprover already initialized";
        FUNC_OUT
        return false;
    }
    QString name = clientName;
    if( name.isEmpty() )
    { // use local stored name
        name = mClientName;
    } else if( clientName != mClientName )
    {
        mClientName = clientName;
        emit clientNameChanged( clientName );
    }

    if( mPreferredClientHandlerName.isEmpty() )
    {
        mPreferredClientHandlerName = mClientName;
        emit preferredHandlerChanged( mPreferredClientHandlerName );
    }

    Tp::ChannelClassSpecList filters;

    if( mCapabilities.contains(CAPABILITY_TEXT_CHAT) )
    {
        filters << Tp::ChannelClassSpec::textChat();
        filters << Tp::ChannelClassSpec::textChatroom();
    }

    if( mCapabilities.contains(QString("media")) )
    {
        filters << Tp::ChannelClassSpec::streamedMediaCall();
        filters << Tp::ChannelClassSpec::streamedMediaAudioCall();
        filters << Tp::ChannelClassSpec::streamedMediaVideoCall();
        filters << Tp::ChannelClassSpec::streamedMediaVideoCallWithAudio();
    } else
    {
        if( mCapabilities.contains(CAPABILITY_VOIP_CALL) )
        {
            filters << Tp::ChannelClassSpec::streamedMediaCall();
            filters << Tp::ChannelClassSpec::streamedMediaAudioCall();
        }
        if( mCapabilities.contains(CAPABILITY_VIDEO_CALL) )
        {
            filters << Tp::ChannelClassSpec::streamedMediaVideoCall();
            if( mCapabilities.contains(CAPABILITY_VOIP_CALL) )
            {
                filters << Tp::ChannelClassSpec::streamedMediaVideoCallWithAudio();

            } else
            {
                filters << Tp::ChannelClassSpec::streamedMediaCall();
            }
        }
    }

    if( mCapabilities.contains(CAPABILITY_FILE_TRANSFER) )
    {
        filters << Tp::ChannelClassSpec::incomingFileTransfer();
        filters << Tp::ChannelClassSpec::outgoingFileTransfer();
    }


    // this call will create an instance of ClientHandlerPrivate singleton
    d = new ClientApproverPrivate( name, filters, this );
    if( !d )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "unable to initialize ClientApprover";
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return true;
}

void
ClientApprover::reject( const QString &dispatchId )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    for( int i = 0; i < d->mDispatchOperations.count(); ++i )
    {
        DispatchOperationContext *context = d->mDispatchOperations.at( i );
        if( context->id() == dispatchId )
        {
            beginRemoveRows( QModelIndex(), i, i );

            Tp::ChannelDispatchOperationPtr dispatchOperation = context->dispatchOperation();

            // close channels
            QList<Tp::ChannelPtr> channels = dispatchOperation->channels();
            foreach (Tp::ChannelPtr channel, channels) {
                if( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_TEXT )
                {
                    Tp::TextChannelPtr textChannel = Tp::TextChannelPtr::staticCast( channel );
                    QList<Tp::ReceivedMessage> messages = textChannel->messageQueue();
                    textChannel->acknowledge( messages );
                }
                channel->requestClose();
            }

            // remove from model
            disconnect( context, 0, d.data(), 0 );
            context->deleteLater();
            d->mDispatchOperations.removeAt( i );

            endRemoveRows();
            break;
        }
    }

    FUNC_OUT
    return;
}
