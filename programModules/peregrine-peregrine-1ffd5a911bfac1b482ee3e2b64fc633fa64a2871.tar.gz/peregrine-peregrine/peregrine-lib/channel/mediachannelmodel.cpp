/*
 * mediachannelmodel.cpp
 *
 * Copyright (C) 2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mediachannelmodel.h"
#include "mediachannelmodel_p.h"
#include "../peregrineDebugHelper.h"
#include "../peregrineinitializer.h"
#include "../peregrineservicenames.h"
#include "../presencestates.h"
#include "../contact/contactlistmodelinterface.h"

#include <TelepathyQt4/ContactManager>
#include <TelepathyQt4/PendingContacts>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/PendingReady>

using namespace Peregrine;

/* *****************************************************************************
 * MediaChannelModelPrivate
 * ****************************************************************************/

/* ***
 * private
 */

const Tp::Features
MediaChannelModelPrivate::ACCOUNT_FEATURES = ( Tp::Features()
                                               << Tp::Account::FeatureCore
                                               << Tp::Account::FeatureAvatar
                                               << Tp::Account::FeatureProtocolInfo );

const Tp::Features
MediaChannelModelPrivate::CONNECTION_FEATURES = ( Tp::Features()
                                                  << Tp::Connection::FeatureCore
                                                  << Tp::Connection::FeatureRoster
                                                  << Tp::Connection::FeatureSelfContact
                                                  << Tp::Connection::FeatureSimplePresence );

const Tp::Features
MediaChannelModelPrivate::CONTACT_FEATURES = ( Tp::Features()
                                               << Tp::Contact::FeatureAlias
                                               << Tp::Contact::FeatureAvatarToken
                                               << Tp::Contact::FeatureCapabilities
                                               << Tp::Contact::FeatureSimplePresence );

const QString
MediaChannelModelPrivate::DURATION_STRING_CONNECTED = QString( "Connected" );

const QString
MediaChannelModelPrivate::DURATION_STRING_CONNECTING = QString( "Connecting" );

const QString
MediaChannelModelPrivate::DURATION_STRING_DISCONNECTED = QString( "Disconnected" );

const Tp::Features
MediaChannelModelPrivate::STREAMED_MEDIA_CHANNEL_FEATURES( Tp::Features()
                                                           << Tp::StreamedMediaChannel::FeatureCore
                                                           << Tp::StreamedMediaChannel::FeatureLocalHoldState
                                                           << Tp::StreamedMediaChannel::FeatureStreams );


MediaChannelModelPrivate::MediaChannelModelPrivate( MediaChannelModel *parent )
    : QObject( parent ),
    mParent( parent )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    mDuration = 0;
    mDurationTimerId = 0;
    mIsConnected = false;
    FUNC_OUT
}

MediaChannelModelPrivate::~MediaChannelModelPrivate()
{
    FUNC_IN
    if( !mFarsightChannel.isNull() )
    {
        delete mFarsightChannel.data();
    }
    FUNC_OUT
}

bool
MediaChannelModelPrivate::connectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    FUNC_OUT
    return result;
}

bool
MediaChannelModelPrivate::connectConnection( Tp::ConnectionPtr connection )
{
    FUNC_IN
    if( connection.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    FUNC_OUT
    return result;
}

bool
MediaChannelModelPrivate::connectContact( Tp::ContactPtr contact )
{
    FUNC_IN
    if( contact.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( contact.data(),
                       SIGNAL( presenceChanged( Tp::Presence ) ),
                       this,
                       SLOT( onContactPresenceChanged( Tp::Presence ) ) );

    FUNC_OUT
    return result;
}

bool MediaChannelModelPrivate::connectFarsightChannel( FarsightChannel *farsightChannel )
{
    FUNC_IN
    if( farsightChannel == 0 )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( farsightChannel,
                       SIGNAL(notification(QString, QString, NotificationTypes)),
                       mParent.data(),
                       SIGNAL(notification(QString, QString, NotificationTypes)));

    FUNC_OUT
    return result;
}

bool
MediaChannelModelPrivate::connectStreamedMediaChannel( Tp::StreamedMediaChannelPtr channel )
{
    FUNC_IN
    if( channel.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( channel.data(),
                       SIGNAL(invalidated(Tp::DBusProxy*,
                                          QString,
                                          QString)),
                       this,
                       SLOT(onStreamedMediaChannelInvalidated(Tp::DBusProxy*,QString,QString)) );
    result &= connect( channel.data(),
                       SIGNAL(localHoldStateChanged(Tp::LocalHoldState,Tp::LocalHoldStateReason)),
                       this,
                       SLOT(onStreamedMediaChannelLocalHoldStateChanged(Tp::LocalHoldState,
                                                                        Tp::LocalHoldStateReason)) );
    result &= connect( channel.data(),
                       SIGNAL(streamAdded(Tp::StreamedMediaStreamPtr)),
                       this,
                       SLOT(onStreamedMediaChannelStreamAdded(Tp::StreamedMediaStreamPtr)) );
    result &= connect( channel.data(),
                       SIGNAL(streamDirectionChanged(Tp::StreamedMediaStreamPtr,
                                                     Tp::MediaStreamDirection,
                                                     Tp::MediaStreamPendingSend)),
                       this,
                       SLOT(onStreamedMediaChannelStreamDirectionChanged(Tp::StreamedMediaStreamPtr,
                                                                         Tp::MediaStreamDirection,
                                                                         Tp::MediaStreamPendingSend)) );
    result &= connect( channel.data(),
                       SIGNAL(streamError(Tp::StreamedMediaStreamPtr,
                                          Tp::MediaStreamError,
                                          QString)),
                       this,
                       SLOT(onStreamedMediaChannelStreamError(Tp::StreamedMediaStreamPtr,
                                                              Tp::MediaStreamError,
                                                              QString)) );
    result &= connect( channel.data(),
                       SIGNAL(streamRemoved(Tp::StreamedMediaStreamPtr)),
                       this,
                       SLOT(onStreamedMediaChannelStreamRemoved(Tp::StreamedMediaStreamPtr)) );
    result &= connect( channel.data(),
                       SIGNAL(streamStateChanged(Tp::StreamedMediaStreamPtr,
                                                 Tp::MediaStreamState)),
                       this,
                       SLOT(onStreamedMediaChannelStreamStateChanged(Tp::StreamedMediaStreamPtr,
                                                                     Tp::MediaStreamState)) );

    FUNC_OUT
    return result;
}

bool
MediaChannelModelPrivate::disconnectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( account.data(), 0, this, 0 );
}

bool
MediaChannelModelPrivate::disconnectConnection( Tp::ConnectionPtr connection )
{
    FUNC_IN
    if( connection.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( connection.data(), 0, this, 0 );
}

bool
MediaChannelModelPrivate::disconnectContact( Tp::ContactPtr contact )
{
    FUNC_IN
    if( contact.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( contact.data(), 0, this, 0 );
}

bool
MediaChannelModelPrivate::disconnectFarsightChannel( FarsightChannel *farsightChannel )
{
    if( farsightChannel == 0 )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( farsightChannel, 0, this, 0 );
}

bool
MediaChannelModelPrivate::disconnectStreamedMediaChannel( Tp::StreamedMediaChannelPtr channel )
{
    FUNC_IN
    if( channel.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( channel.data(), 0, this, 0 );
}

QString
MediaChannelModelPrivate::updateDurationString()
{
    if( mStreamedMediaChannel.isNull()
        || mStreamedMediaChannel->streams().count() <= 0 )
    {
        mDurationString = DURATION_STRING_DISCONNECTED;
        FUNC_OUT
        return mDurationString;
    }

    for( int i = 0, j = 0; i <= mStreamedMediaChannel->streams().count(); ++i )
    {
        if( i == mStreamedMediaChannel->streams().count() )
        {
            if( i == j )
            {
                mDurationString = DURATION_STRING_DISCONNECTED;
            } else
            {
                mDurationString = DURATION_STRING_CONNECTING;
            }

            FUNC_OUT
            return mDurationString;
        }

        Tp::StreamedMediaStreamPtr stream = mStreamedMediaChannel->streams().at(i);
        if( stream->state() == Tp::MediaStreamStateConnected )
        {
            break;
        }
        if( stream->state() == Tp::MediaStreamStateDisconnected )
        {
            ++j;
        }
    }

    int hour = mDuration / 3600;
    int min = mDuration / 60;
    int sec = mDuration - min * 60;
    min -= hour * 60;

    QString duration = QString( "%1:%2" ).arg( min, 2, 10, QLatin1Char('0') )
                                         .arg( sec, 2, 10, QLatin1Char('0') );
    if( hour > 0 )
    {
        duration = QString::number( hour ) + ":" + duration;
    }

    FUNC_OUT
    return mDurationString = duration;
}

/* ***
 * private slots
 */

void
MediaChannelModelPrivate::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName(), operation->errorMessage(), NotificationTypeError );
        FUNC_OUT
        return;
    }

    mServiceName = serviceNameForAccount( mAccount );
    emit mParent->serviceNameChanged( mServiceName );
    FUNC_OUT
}

void
MediaChannelModelPrivate::onConnectionReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName(), operation->errorMessage(), NotificationTypeError );
        FUNC_OUT
        return;
    }

    if( mStreamedMediaChannel->isReady( STREAMED_MEDIA_CHANNEL_FEATURES ) )
    {
        if( mContact.isNull()
            && (mStreamedMediaChannel->targetHandleType() == Tp::HandleTypeContact) )
        {
            Tp::ContactManagerPtr contactManager = mConnection->contactManager();
            Q_ASSERT( !contactManager.isNull() );

            uint handle = mStreamedMediaChannel->targetHandle();
            connect( contactManager->contactsForHandles(Tp::UIntList() << handle,
                                                        CONTACT_FEATURES),
                     SIGNAL(finished(Tp::PendingOperation *)),
                     this,
                     SLOT(onPendingContactsReady(Tp::PendingOperation *)) );
        }
    }
    FUNC_OUT
}

//void MediaChannelModelPrivate::onContactManagerContactsUpgraded( Tp::PendingOperation *operation );
void
MediaChannelModelPrivate::onContactPresenceChanged( const Tp::Presence &presence )
{
    FUNC_IN
    Q_UNUSED( presence );
    if( mStreamedMediaChannel->targetHandleType() == Tp::HandleTypeContact
        && mContact.data() == sender() )
    {
        emit mParent->targetPresenceChanged( mParent->targetPresence() );
    }
    FUNC_OUT
}

void
MediaChannelModelPrivate::onPendingContactsReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), NotificationTypeWarning );
        FUNC_OUT
        return;
    }

    Tp::PendingContacts *pc = qobject_cast<Tp::PendingContacts *>( operation );

    if( !pc )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "cannot cast to pending contacts pointer";
        emit mParent->notification( "Unknown data!", "Unable to retrieve contact information!", NotificationTypeWarning );
        FUNC_OUT
        return;
    }

    Q_ASSERT( !mConnection.isNull() );
    Tp::ContactManagerPtr contactManger = mConnection->contactManager();

    QList<Tp::ContactPtr> contactList = pc->contacts();
    foreach( Tp::ContactPtr contact, contactList )
    {
        if( contact.isNull() )
        {
            continue;
        }

        if( contact->handle().first() == mStreamedMediaChannel->targetHandle()
            && mStreamedMediaChannel->targetHandleType() == Tp::HandleTypeContact )
        {
            mContact = contact;
            emit mParent->targetIdChanged( mParent->targetId() );
            emit mParent->targetNameChanged( mParent->targetName() );
            emit mParent->targetPresenceChanged( mParent->targetPresence() );
        }

        connectContact( contact );

        if( !contactManger.isNull()
            && !contact->isAvatarTokenKnown() )
        {
            contactManger->requestContactAvatar( contact.data() );
        }
    }
    FUNC_OUT
}

void
MediaChannelModelPrivate::onPendingMediaStreamStreamCreated( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        emit mParent->notification( operation->errorName(), operation->errorMessage(), NotificationTypeError );
    }
    FUNC_OUT
}

void
MediaChannelModelPrivate::onPendingOperationFinished( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        emit mParent->notification( operation->errorName(), operation->errorMessage(), NotificationTypeWarning );
    }
    FUNC_OUT
}

void
MediaChannelModelPrivate::onStreamedMediaChannelAccepted( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();

        emit mParent->notification( operation->errorName(), operation->errorMessage(), NotificationTypeError );
    }
    FUNC_OUT
}

void
MediaChannelModelPrivate::onStreamedMediaChannelInvalidated( Tp::DBusProxy *proxy,
                                                             const QString &errorName,
                                                             const QString &errorMessage )
{
    FUNC_IN
    Q_UNUSED( proxy );
    emit mParent->notification( errorName, errorMessage, NotificationTypeNotice );
    emit mParent->channelClosed();
    FUNC_OUT
}

void
MediaChannelModelPrivate::onStreamedMediaChannelLocalHoldStateChanged( Tp::LocalHoldState state,
                                                                       Tp::LocalHoldStateReason reason )
{
    FUNC_IN
    Q_UNUSED( reason );
    if( reason == Tp::LocalHoldStateReasonResourceNotAvailable )
    {
        emit mParent->notification( "Cannot switch hold state", "Resource not available!", NotificationTypeWarning );
    }
    switch( state )
    {
    case Tp::LocalHoldStateHeld:
        emit mParent->holdStateChanged( true );
        break;
    case Tp::LocalHoldStateUnheld:
        emit mParent->holdStateChanged( false );
        break;
    case Tp::LocalHoldStatePendingHold:
    case Tp::LocalHoldStatePendingUnhold:
    // just to prevent warning
    case Tp::_LocalHoldStatePadding:
        break;
    }
    updateChannelState();
    FUNC_OUT
}

void
MediaChannelModelPrivate::onStreamedMediaChannelReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Tp::PendingReady *pr = qobject_cast<Tp::PendingReady *>( operation );
    Tp::StreamedMediaChannelPtr channel =
                        Tp::StreamedMediaChannelPtr::staticCast( pr->object() );

    Q_ASSERT( channel == mStreamedMediaChannel );

    if ( operation->isError() ) {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();

        emit mParent->notification( operation->errorName(), operation->errorMessage(), NotificationTypeError );

        mStreamedMediaChannel->requestClose();
        mStreamedMediaChannel.reset();
        FUNC_OUT
        return;
    }

    if( mStreamedMediaChannel->awaitingLocalAnswer() )
    {
        connect( mStreamedMediaChannel->acceptCall(),
                 SIGNAL(finished( Tp::PendingOperation *)),
                 this,
                 SLOT(onStreamedMediaChannelAccepted(Tp::PendingOperation*)) );
    }

    if( mConnection->isReady( CONNECTION_FEATURES ) )
    {
        if( mContact.isNull()
            && (mStreamedMediaChannel->targetHandleType() == Tp::HandleTypeContact) )
        {
            Tp::ContactManagerPtr contactManager = mConnection->contactManager();
            Q_ASSERT( !contactManager.isNull() );

            uint handle = mStreamedMediaChannel->targetHandle();
            connect( contactManager->contactsForHandles(Tp::UIntList() << handle,
                                                        CONTACT_FEATURES),
                     SIGNAL(finished(Tp::PendingOperation *)),
                     this,
                     SLOT(onPendingContactsReady(Tp::PendingOperation *)) );
        }
    }

    if( mStreamedMediaChannel->handlerStreamingRequired() )
    {
        mFarsightChannel = new FarsightChannel( mStreamedMediaChannel, this );

        connectFarsightChannel( mFarsightChannel.data() );

    }

    // TODO: check if we still need this code for initial audio streams
    // this is needed to create a stream ( to initiate a call )
    //switchAudio( true );

    FUNC_OUT
}

void
MediaChannelModelPrivate::onStreamedMediaChannelStreamAdded( const Tp::StreamedMediaStreamPtr &stream )
{
    FUNC_IN
    // set stream direction to sending and receiving
    stream->requestDirection( true, true );
    updateChannelState();
    FUNC_OUT
}

void
MediaChannelModelPrivate::onStreamedMediaChannelStreamDirectionChanged( const Tp::StreamedMediaStreamPtr &stream,
                                                                        Tp::MediaStreamDirection direction,
                                                                        Tp::MediaStreamPendingSend pendingSend )
{
    FUNC_IN
    Q_UNUSED( stream );
    Q_UNUSED( direction );
    Q_UNUSED( pendingSend );
    emit mParent->muteStateChanged( !(direction == Tp::MediaStreamDirectionBidirectional
                                      || direction == Tp::MediaStreamDirectionSend) );
    updateChannelState();
    FUNC_OUT
}

void
MediaChannelModelPrivate::onStreamedMediaChannelStreamError( const Tp::StreamedMediaStreamPtr &stream,
                                                             Tp::MediaStreamError errorCode,
                                                             const QString &errorMessage )
{
    FUNC_IN
    Q_UNUSED( stream );
    emit mParent->notification( QString("Error [%1]").arg((int)errorCode), errorMessage, NotificationTypeError );
    FUNC_OUT
}

void
MediaChannelModelPrivate::onStreamedMediaChannelStreamRemoved( const Tp::StreamedMediaStreamPtr &stream )
{
    FUNC_IN
    Q_UNUSED( stream );
    if( mStreamedMediaChannel->streams().count() <= 0 )
    {
        if( mDurationTimerId != 0 )
        {
            killTimer( mDurationTimerId );
            mDurationTimerId = 0;
        }
        mDurationString = DURATION_STRING_DISCONNECTED;
        if( !mContext.isNull() )
        {
            mContext->setDuration( mDurationString );
        }
        if( mIsConnected )
        {
            mIsConnected = false;
            emit mParent->isConnectedChanged( mIsConnected );
        }
        emit mParent->durationChanged( mDurationString );
        qWarning() << __PRETTY_FUNCTION__
                   << "last stream was removed from channel";
        emit mParent->notification( "No Stream left", "Last stream removed from channel", NotificationTypeWarning );
    }
    updateChannelState();
    FUNC_OUT
}

void MediaChannelModelPrivate::onStreamedMediaChannelStreamStateChanged( const Tp::StreamedMediaStreamPtr &stream,
                                                                         Tp::MediaStreamState state )
{
    FUNC_IN
    Q_UNUSED( stream );
    int streamCount = mStreamedMediaChannel->streams().count();
    switch( state )
    {
    case Tp::MediaStreamStateDisconnected:
        if( streamCount <= 1 )
        {
            if( mDurationTimerId != 0 )
            {
                killTimer( mDurationTimerId );
                mDurationTimerId = 0;
            }
            mDurationString = DURATION_STRING_DISCONNECTED;
            if( !mContext.isNull() )
            {
                mContext->setDuration( mDurationString );
            }
            if( mIsConnected )
            {
                mIsConnected = false;
                emit mParent->isConnectedChanged( mIsConnected );
            }
            emit mParent->durationChanged( mDurationString );
        }
        break;
    case Tp::MediaStreamStateConnecting:
        if( streamCount <= 1 )
        {
            mDurationString = DURATION_STRING_CONNECTING;
            if( !mContext.isNull() )
            {
                mContext->setDuration( mDurationString );
            }
            if( mIsConnected )
            {
                mIsConnected = false;
                emit mParent->isConnectedChanged( mIsConnected );
            }
            emit mParent->durationChanged( mDurationString );
        }
        break;
    case Tp::MediaStreamStateConnected:
        if( streamCount <= 1 )
        {
            if( mDurationTimerId == 0 )
            {
                mDurationTimerId = startTimer( 1000 );
            }
            updateDurationString();
            if( !mContext.isNull() )
            {
                mContext->setDuration( mDurationString );
            }
            if( !mIsConnected )
            {
                mIsConnected = true;
                emit mParent->isConnectedChanged( mIsConnected );
            }
            emit mParent->durationChanged( mDurationString );
        }
        break;
    // just to prevent warning
    case Tp::_MediaStreamStatePadding:
        break;
    }
    updateChannelState();
    FUNC_OUT
}

void
MediaChannelModelPrivate::updateChannelState()
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    if( !mContext.isNull() )
    {
        bool held = mParent->holdState();
        bool muted = mParent->muteState();
        if( held )
        {
            mContext->setChannelState( "hold" );
        } else if( muted )
        {
            mContext->setChannelState( "mute" );
        } else
        {
            mContext->setChannelState( QString() );
        }
    } else
    {
        mContext->setChannelState( QString() );
    }
    FUNC_OUT
}

void
MediaChannelModelPrivate::timerEvent( QTimerEvent *event )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    if( event->timerId() == mDurationTimerId )
    {
        ++mDuration;
        updateDurationString();
        emit mParent->durationChanged( mDurationString );

        if( !mContext.isNull() )
        {
            // update duration in context
            mContext->setDuration( mDurationString );
            if( !mParent->holdState() )
            {
                // update latestActionTime if not on hold
                mContext->setLatestActionTime( QDateTime::currentDateTime() );
            }
        }
    }
    FUNC_OUT
}

/* *****************************************************************************
 * MediaChannelModel
 * ****************************************************************************/

/* ***
 * public
 */
MediaChannelModel::MediaChannelModel(QObject *parent) :
    QObject( parent )
{
    FUNC_IN
    Peregrine::initialize();
    d = new MediaChannelModelPrivate( this );
    FUNC_OUT
}

MediaChannelModel::~MediaChannelModel()
{
    FUNC_IN
    FUNC_OUT
}

QString
MediaChannelModel::channelId() const
{
    FUNC_IN
    FUNC_OUT
    return mChannelId;
}

QString
MediaChannelModel::duration() const
{
    FUNC_IN
    if( d.isNull() )
    {
        FUNC_OUT
        return MediaChannelModelPrivate::DURATION_STRING_DISCONNECTED;
    }
    FUNC_OUT
    return d->mDurationString;
}

bool
MediaChannelModel::holdState() const
{
    FUNC_IN
    if( d.isNull()
        || d->mStreamedMediaChannel.isNull() )
    {
        FUNC_OUT
        return false;
    }

    Tp::LocalHoldState state = d->mStreamedMediaChannel->localHoldState();
    switch( state )
    {
    case Tp::LocalHoldStateHeld:
    case Tp::LocalHoldStatePendingUnhold:
        FUNC_OUT
        return true;
    case Tp::LocalHoldStateUnheld:
    case Tp::LocalHoldStatePendingHold:
        FUNC_OUT
        return false;
    case Tp::_LocalHoldStatePadding:
        break;
    }
    FUNC_OUT
    return false;
}

bool
MediaChannelModel::isConnected() const
{
    FUNC_IN
    if( d.isNull()
        || d->mStreamedMediaChannel.isNull() )
    {
        return false;
    }
    return d->mIsConnected;
    FUNC_OUT
}

bool
MediaChannelModel::muteState() const
{
    FUNC_IN
    if( d.isNull()
        || d->mStreamedMediaChannel.isNull() )
    {
        return false;
    }

    Tp::StreamedMediaStreams streams = d->mStreamedMediaChannel->streamsForType(Tp::MediaStreamTypeAudio);
    for( int i = 0; i < streams.count(); ++i )
    {
        Tp::StreamedMediaStreamPtr stream = streams.at(i);
        if( stream->sending() )
        {
            FUNC_OUT
            return false;
        }
    }

    FUNC_OUT
    return true;
}

QString MediaChannelModel::serviceName() const
{
    FUNC_IN
    if( d.isNull() )
    {
        FUNC_OUT
        return QString();
    }
    FUNC_OUT
    return d->mServiceName;
}

QString
MediaChannelModel::targetId() const
{
    FUNC_IN
    if( d.isNull()
        || d->mContact.isNull()
        || d->mAccount.isNull() )
    {
        FUNC_OUT
        return QString();
    }

    QString contactId = d->mAccount->objectPath() + ContactListModelInterface::SEPARATOR + d->mContact->id();

    FUNC_OUT
    return contactId;
}

QString
MediaChannelModel::targetName() const
{
    FUNC_IN
    if( d.isNull()
        || d->mContact.isNull() )
    {
        FUNC_OUT
        return QString();
    }

    FUNC_OUT
    return d->mContact->alias();
}

QString
MediaChannelModel::targetPresence() const
{
    FUNC_IN
    if( d.isNull()
        || d->mContact.isNull() )
    {
        FUNC_OUT
        return PRESENCE_STATE_NAMES.at( PresenceStateUnknown );
    }

    FUNC_OUT
    return PRESENCE_STATE_NAMES.at( d->mContact->presence().type() );
}

/* ***
 * public slots
 */
void MediaChannelModel::closeChannel()
{
    FUNC_IN
    if( d.isNull() )
    {
        emit notification( "Disconnected", "Cannot close channel. Currently not connected!", NotificationTypeWarning );
        return;
    }

    for( int i = 0; i < d->mChannels.count(); ++i )
    {
        if( !d->mChannels.at(i).isNull() )
        {
            d->mChannels.at(i)->requestClose();
        }
    }
    FUNC_OUT
}

void
MediaChannelModel::setChannelId( const QString &channelId )
{
    FUNC_IN
    if( d.isNull() )
    {
        d = new MediaChannelModelPrivate( this );
    }

    Q_ASSERT( !d.isNull() );

    if( channelId == mChannelId )
    {
        FUNC_OUT
        return;
    }

    // clean up stuff
    if( !d->mStreamedMediaChannel.isNull() )
    {
        d->mStreamedMediaChannel->hangupCall();
    }
    if( !d->mContext.isNull() )
    {
        d->mContext->close();
    }

    d->mAccount.reset();
    foreach( Tp::ChannelPtr channel, d->mChannels )
    {
        channel.reset();
    }
    d->mConnection.reset();
    d->mContact.reset();
    d->mContext = 0;
    if( d->mDurationTimerId )
    {
        d->killTimer( d->mDurationTimerId );
    }
    d->mDuration = 0;
    d->mDurationTimerId = 0;
    d->mServiceName.clear();
    d->mStreamedMediaChannel.reset();
    if( d->mFarsightChannel )
    {
        delete d->mFarsightChannel.data();
        d->mFarsightChannel = 0;
    }
    mChannelId.clear();


    if( channelId.isEmpty() )
    {
        FUNC_OUT
        return;
    }

    ClientHandlerPrivate *clientHandler = ClientHandlerPrivate::instance();
    Q_ASSERT( clientHandler != 0 );
    d->mContext = clientHandler->channelContext( channelId );

    d->mAccount = d->mContext->account();
    d->mChannels = d->mContext->channels();
    d->mConnection = d->mContext->connection();

    for( int i = 0; i < d->mChannels.count(); ++i )
    {
        QVariantMap properties = d->mChannels.at(i)->immutableProperties();
        QString type = properties.value(
                    QLatin1String( TELEPATHY_INTERFACE_CHANNEL ".ChannelType" ) )
                    .toString();
        if( type == TP_QT4_IFACE_CHANNEL_TYPE_STREAMED_MEDIA )
        {
            d->mStreamedMediaChannel = Tp::StreamedMediaChannelPtr::dynamicCast( d->mChannels.at(i) );
            break;
        }
    }

    if( d->mStreamedMediaChannel.isNull() )
    {
        emit notification( "Open Channel", "Unable to open channel! No streamed media channel found!", NotificationTypeError );
        for( int i = 0; d->mChannels.count(); ++i )
        {
            d->mChannels.at(i)->requestClose();
        }
        return;
    }

    d->connectAccount( d->mAccount );
    connect( d->mAccount->becomeReady(MediaChannelModelPrivate::ACCOUNT_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             d.data(),
             SLOT(onAccountReady(Tp::PendingOperation *)) );

    d->connectConnection( d->mConnection );
    connect( d->mConnection->becomeReady(MediaChannelModelPrivate::CONNECTION_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             d.data(),
             SLOT(onConnectionReady(Tp::PendingOperation *)) );

    d->connectStreamedMediaChannel( d->mStreamedMediaChannel );
    connect( d->mStreamedMediaChannel->becomeReady(MediaChannelModelPrivate::STREAMED_MEDIA_CHANNEL_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             d.data(),
             SLOT(onStreamedMediaChannelReady(Tp::PendingOperation *)) );
    FUNC_OUT
}

void
MediaChannelModel::setHoldState( bool state )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( d->mStreamedMediaChannel.isNull() )
    {
        FUNC_OUT
        return;
    }

    bool currentState = holdState();
    if( currentState == state )
    {
        FUNC_OUT
        return;
    }


    connect( d->mStreamedMediaChannel->requestHold(state),
             SIGNAL(finished(Tp::PendingOperation *)),
             d.data(),
             SLOT(onPendingOperationFinished(Tp::PendingOperation *)) );
    FUNC_OUT
}

void
MediaChannelModel::setMuteState( bool mute )
{
    Q_ASSERT( !d.isNull() );

    if( d->mStreamedMediaChannel.isNull() )
    {
        FUNC_OUT
        return;
    }

    Tp::StreamedMediaStreams streams = d->mStreamedMediaChannel->streamsForType( Tp::MediaStreamTypeAudio );
    for( int i = 0; i < streams.count(); ++i )
    {
        Tp::StreamedMediaStreamPtr stream = streams.at(i);
        if( stream->sending() == mute )
        {
            connect( stream->requestSending(!mute),
                     SIGNAL(finished(Tp::PendingOperation*)),
                     d.data(),
                     SLOT(onPendingOperationFinished(Tp::PendingOperation*)) );
        }
    }
    FUNC_OUT
}

void
MediaChannelModel::toggleHold()
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( d->mStreamedMediaChannel.isNull() )
    {
        FUNC_OUT
        return;
    }

    bool state = holdState();

    connect( d->mStreamedMediaChannel->requestHold(!state),
             SIGNAL(finished(Tp::PendingOperation *)),
             d.data(),
             SLOT(onPendingOperationFinished(Tp::PendingOperation *)) );
    FUNC_OUT
}
