/*
 * clienthandler_p.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CLIENTHANDLER_P_H
#define CLIENTHANDLER_P_H

#include "../peregrinetypes.h"

#include <TelepathyQt4/AbstractClientHandler>
#include <TelepathyQt4/AccountSet>
#include <TelepathyQt4/ChannelClassSpecList>
#include <TelepathyQt4/ClientRegistrar>
#include <TelepathyQt4/Feature>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/Types>

namespace Peregrine
{

class ClientHandler;

/*!
 * class for easy exchange of channels including complete context
 */
class ChannelContext : public QObject
{
    Q_OBJECT

    bool accountFinished;
    bool connectionFinished;
    bool channelFinished;
    bool contactsFinished;
    int mFinishedChannels;

    bool getContacts();

private slots:
    void onAccountReady( Tp::PendingOperation *operation );
    void onChannelInvalidated( Tp::DBusProxy *proxy,
                               const QString &errorName,
                               const QString &errorMessage );
    void onChannelLocalHoldStateChanged( Tp::LocalHoldState state, Tp::LocalHoldStateReason reason );
    void onChannelReady( Tp::PendingOperation *operation );
    void onConnectionReady( Tp::PendingOperation *operation );
    void onContactChanged();
    void onContactsUpgraded( Tp::PendingOperation *operation );
    void validateReadyState();
    void onTextChannelMessageReceived();
    void onAcountRemoved();

protected:
    friend class ClientHandler;
    friend class ClientHandlerPrivate;

    Tp::AccountPtr mAccount;
    QList<Tp::ChannelPtr> mChannels;
    Tp::ConnectionPtr mConnection;
    Tp::ContactPtr mContact;
    QDateTime mUserActionTime;

    QString mDuration;
    QDateTime mFirstUntouchedActivityTime;
    QDateTime mLatestActionTime;
    QString mServiceName;
    bool mUntouched;
    int mUntouchedActivityCount;
    QVariant mVariantData;

    QString mChannelId;
    bool mChannelRequested;
    QString mChannelState;
    QString mChannelType;

public:
    Q_ENUMS( NotificationTypes );

    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };

    Tp::AccountPtr account() const;
    QString channelId() const;
    bool channelRequested() const;
    QList<Tp::ChannelPtr> channels() const;
    QString channelState() const;
    QString channelType() const;
    Tp::ConnectionPtr connection() const;
    Tp::ContactPtr contact() const;
    QString duration() const;
    QDateTime firstUntouchedActivityTime() const;
    /**
     * initialize the channel context. that will try to make
     * all objects ready with standard feature set and emit
     * @see initialized() signal when ready
     * @param channelId give this context a channel Id or none to use DBUS object path of first channel object as default
     */
    bool initialize( const QString &channelId = QString() );
    QDateTime latestActionTime() const;
    void setChannelState( const QString &state );
    void setDuration( const QString &timestring );
    void setFirstUntouchedActivityTime( const QDateTime &timestamp );
    void setLatestActionTime( const QDateTime &timestamp );
    void setUntouchedActivityCount( int count );
    void setVariantData( const QVariant &data );
    bool untouched() const;
    int untouchedActivityCount() const;
    QDateTime userActionTime() const;
    QVariant variantData() const;


public slots:
    void close();
signals:
    void changed( const QString &channelId );
    void closed( const QString &channelId );    
    void untouchedActivitiesCountChanged();
    void initialized( const QString &channelId, bool error = false );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );
};

class ClientHandlerPrivate : public QObject, public Tp::AbstractClientHandler
{
    Q_OBJECT
    friend class ClientHandler;
    friend class ChannelContext;

    static QPointer<ClientHandlerPrivate> mInstance;

    /**
     * The account manager that we use to get all account relevant information
     */
    Tp::AccountManagerPtr mAccountManager;
    /**
     * this variable will hold a set of online accounts
     * the set is automatically updated by Tp::AccountManager
     */
    Tp::AccountSetPtr mAccounts;
    /**
     * client name is set when calling the constructor
     * and used to register client in onAccountManagerReady()
     */
    QString mClientName;
    /**
     * This container hold all open channels with all related data (context)
     */
    QHash<QString, ChannelContext *> mContexts;
    /**
     * will be true if instance is ready to go
     */
    bool mInitialized;
    QPointer<ClientHandler> mParent;
    Tp::ClientRegistrarPtr mRegistrar;

    QList<Tp::ChannelRequestPtr> mRequests;

    static const Tp::Features ACCOUNT_MANAGER_FEATURES;
    static const Tp::Features ACCOUNT_FEATURES;
    static const Tp::Features CHANNEL_FEATURES;
    static const Tp::Features CONNECTION_FEATURES;
    static const Tp::Features CONTACT_FEATURES;
    static const Tp::Features FILE_CHANNEL_FEATURES;
    static const Tp::Features MEDIA_CHANNEL_FEATURES;
    static const Tp::Features TEXT_CHANNEL_FEATURES;

    static const QString CHANNEL_TYPE_TEXT;
    static const QString CHANNEL_TYPE_VOIP;
    static const QString CHANNEL_TYPE_VIDEO;
    static const QString CHANNEL_TYPE_CELL;
    static const QString CHANNEL_TYPE_FILE;
    static const QString CHANNEL_TYPE_CONTACT_LIST;
    static const QString CHANNEL_TYPE_ROOM_LIST;
    static const QString CHANNEL_TYPE_STREAM_TUBE;
    static const QString CHANNEL_TYPE_TUBES;
    static const QString CHANNEL_TYPE_UNKNOWN;

    /**
     * private constructor will be called by ClientHandler
     * ClientHandler is acting as factory for ClientHandlerPrivate
     */
    explicit ClientHandlerPrivate( const QString &clientName,
                                   const Tp::ChannelClassSpecList &filters,
                                   const Tp::AbstractClientHandler::Capabilities capabilities = Tp::AbstractClientHandler::Capabilities(),
                                   ClientHandler *parent = 0 );

private slots:
    void onAccountManagerReady( Tp::PendingOperation *operation );
    void onChannelRequestFailed( const QString &errorName, const QString &errorMessage );
    void onChannelRequestSucceeded();
    void onContextClosed( const QString &channelId );
    void onContextInitialized( const QString &channelId, bool error );
    void onPendingChannelRequestChannelRequestCreated( const Tp::ChannelRequestPtr &channelRequest );
    void onUntouchedActivitiesCountChanged();

public:
    ~ClientHandlerPrivate();

    /**
     * @see Tp::AbstractClientHandler::bypassApproval()
     */
    virtual bool bypassApproval() const;

    /**
     * get the channel context identified by channelId
     * @param channelId the Id that will be published by ClientHandler
     * @return pointer to requested ChannelContext or 0 if channelId is not known
     */
    ChannelContext *channelContext( const QString &channelId ) const;

    /**
     * @see Tp::AbstractClientHandler::handleChannels()
     */
    virtual void handleChannels(
            const Tp::MethodInvocationContextPtr<> &context,
            const Tp::AccountPtr &account,
            const Tp::ConnectionPtr &connection,
            const QList<Tp::ChannelPtr> &channels,
            const QList<Tp::ChannelRequestPtr> &requestsSatisfied,
            const QDateTime &userActionTime,
            const HandlerInfo &handlerInfo );

    /**
     * return the instance of ClientHandlerPrivate if already created
     * @return pointer to instance. else return `0'
     */
    static ClientHandlerPrivate *instance();

    /**
     * return the clients name if an instance already exists. if client
     * is not initialized a call to this function returns an empty QString
     */
    static QString clientName();

signals:
    void initialized();
    void channelChanged( const QString &channelId );
    void channelClosed( const QString &channelId );
    void channelOpened( const QString &channelId );
    void channelToBeRemoved( const QString &channelId );
    void channelRequestsFocus( const QString &channelId );
    void untouchedActivitiesChanged( int count );
    void unreadChannelsChanged( int count );
};

}

#endif // CLIENTHANDLER_P_H
