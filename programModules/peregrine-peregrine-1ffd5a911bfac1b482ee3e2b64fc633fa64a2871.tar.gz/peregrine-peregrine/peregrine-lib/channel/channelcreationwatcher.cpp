/*
 * channelcreationwatcher.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "channelcreationwatcher.h"
#include "clienthandler.h"
#include "clienthandler_p.h"
#include "../peregrineDebugHelper.h"

#include <QTimer>

using namespace Peregrine;

const int ChannelCreationWatcher::DEFAULT_TIME_OUT = 2000;

void
ChannelCreationWatcher::removeWatch( const QString &contactId, const QString &type )
{
    FUNC_IN
    for( int i = 0; i < mChannelRequestInfo.count(); ++i )
    {
        if( mChannelRequestInfo.at(i).contactId == contactId
            && mChannelRequestInfo.at(i).type == type )
        {
            mChannelRequestInfo.removeAt(i);
        }
    }
    FUNC_OUT
}

void
ChannelCreationWatcher::onClientHandlerFocusOn( const QString &channelId, const QString &type, const QString &contactId )
{
    FUNC_IN
    Q_UNUSED( channelId );
    removeWatch( contactId, type );
    FUNC_OUT
}

void
ChannelCreationWatcher::onClientHandlerNewChannel( const QString &channelId, const QString &type, const QString &contactId )
{
    FUNC_IN
    Q_UNUSED( channelId );
    removeWatch( contactId, type );
    FUNC_OUT
}

void
ChannelCreationWatcher::removeWatch()
{
    FUNC_IN
    QDateTime now = QDateTime::currentDateTime();
    for( int i = 0; i < mChannelRequestInfo.count(); ++i )
    {
        if( mChannelRequestInfo.at(i).timestamp <= now )
        {
            emit channelRequestTimedOut( mChannelRequestInfo.at(i).contactId, mChannelRequestInfo.at(i).type );
            mChannelRequestInfo.removeAt( i-- );
        }
    }
    FUNC_OUT
}

ChannelCreationWatcher::ChannelCreationWatcher( QObject *parent )
    : QObject( parent )
{
    FUNC_IN
    ClientHandlerPrivate *chp = ClientHandlerPrivate::instance();
    if( chp == 0 )
    {
        qWarning() << __PRETTY_FUNCTION__ << "No ClientHandler initialized!";
    } else
    {
        mClientHandler = qobject_cast<ClientHandler *>( chp->parent() );
        connect( mClientHandler,
                 SIGNAL(focusOn(QString,QString,QString)),
                 this,
                 SLOT(onClientHandlerFocusOn(QString,QString,QString)) );
        connect( mClientHandler,
                 SIGNAL(newChannel(QString,QString,QString)),
                 this,
                 SLOT(onClientHandlerNewChannel(QString,QString,QString)) );
    }
    mTimeOut = DEFAULT_TIME_OUT;
    FUNC_OUT
}

bool
ChannelCreationWatcher::addWatch( const QString &contactId, const QString &type )
{
    FUNC_IN
    if( mClientHandler.isNull() )
    {
        ClientHandlerPrivate *chp = ClientHandlerPrivate::instance();
        if( chp == 0 )
        {
            qWarning() << __PRETTY_FUNCTION__ << "No ClientHandler initialized!";
            FUNC_OUT
            return false;
        }
        mClientHandler = qobject_cast<ClientHandler *>( chp->parent() );
        connect( mClientHandler,
                 SIGNAL(focusOn(QString,QString,QString)),
                 this,
                 SLOT(onClientHandlerFocusOn(QString,QString,QString)) );
        connect( mClientHandler,
                 SIGNAL(newChannel(QString,QString,QString)),
                 this,
                 SLOT(onClientHandlerNewChannel(QString,QString,QString)) );
    }

    QDateTime now = QDateTime::currentDateTime();
    Triplet triplet;
    triplet.contactId = contactId;
    triplet.timestamp = now;
    triplet.type = type;
    mChannelRequestInfo.append( triplet );
    QTimer::singleShot( mTimeOut, this, SLOT(removeWatch()) );
    return true;
    FUNC_OUT
}

void
ChannelCreationWatcher::setTimeOut( int timeOut )
{
    FUNC_IN
    mTimeOut = timeOut;
    emit timeOutChanged( mTimeOut );
    FUNC_OUT
}

int
ChannelCreationWatcher::timeOut() const
{
    FUNC_IN
    FUNC_OUT
    return mTimeOut;
}
