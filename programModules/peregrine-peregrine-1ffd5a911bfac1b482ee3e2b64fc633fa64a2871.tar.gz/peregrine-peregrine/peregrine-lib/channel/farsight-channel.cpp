/*
 * Very basic Tp-Qt <-> Tp-Farsight integration.
 *
 * Copyright © 2008-2009 Collabora Ltd. <http://www.collabora.co.uk/>
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "farsight-channel.h"

#include <QDebug>

#include <TelepathyQt4/Connection>
#include <TelepathyQt4/Farsight/Channel>
#include <TelepathyQt4/StreamedMediaChannel>

using namespace Peregrine;

struct FarsightChannel::Private
{
    Private(FarsightChannel *parent, const Tp::StreamedMediaChannelPtr &channel);
    ~Private();

#if VIDEO_STREAMS >0
            void startVideoSrc();
            static GstElement * createVideoInputPipe( const char * name, FarsightChannel::Private *self  );
            static GstElement * createVideoOutputPipe( const char * name, const char * SharedName, FarsightChannel::Private *self  );
#ifdef WITH_PREVIEW
            static GstElement * createVideoPreviewPipe( const char * name, const char * SharedName, FarsightChannel::Private *self  );
#endif
#endif
    static gboolean busWatch(GstBus *bus,
            GstMessage *message, FarsightChannel::Private *self);
    static void onClosed(TfChannel *tfChannel,
            FarsightChannel::Private *self);
    static void onSessionCreated(TfChannel *tfChannel,
            FsConference *conference, FsParticipant *participant,
            FarsightChannel::Private *self);
    static void onStreamCreated(TfChannel *tfChannel,
            TfStream *stream, FarsightChannel::Private *self);
    static void onStreamClosed( TfStream *stream,
            FarsightChannel::Private *self );
    static void onSrcPadAdded(TfStream *stream,
            GstPad *pad, FsCodec *codec, FarsightChannel::Private *self);
    static gboolean onRequestResource(TfStream *stream,
            guint direction, gpointer data);
    static void onStreamError(TfStream *stream,
            FarsightChannel::Private *self);

    FarsightChannel *parent;
    Tp::StreamedMediaChannelPtr channel;
    Status status;
    TfChannel *tfChannel;
    GstBus *bus;
    GstElement *pipeline;
    GstElement *audioInput;
    GstElement *audioOutput;

#if VIDEO_STREAMS>0
    GstElement * videoSource;
    GstElement * videoInRate;
    GstCaps * videoInCaps;
    GstElement * videoInCapsFilter;
    GstElement * videoInTee;
    GstElement * videoInQueue;
#ifdef WITH_PREVIEW
    GstElement * videoPreviewQueue;
    GstElement * VideoPreviewOutColor;
    GstElement * videoPreviewOutCapsFilter;
    GstElement * videoPreviewperegrinevideosink;
    GstElement * videoPreviewOutFakeSink;
    GstCaps * videoPreviewOutCaps;
    GstElement * videoPreviewPipe;
#endif
    GstElement * videoInputPipe;
    GstElement * videoOutputQueue;
    GstElement * videoOutputPipe;
    GstElement * videoperegrinevideosink;
    GstElement * VideoOutColor;
    GstCaps * videoOutCaps;
    GstElement * videoOutCapsFilter;
    GstElement * videoOutFakeSink;
#endif
};

#if VIDEO_STREAMS>0


int setElementPlaying( GstElement * element ){
    char * name = gst_object_get_name(GST_OBJECT_CAST(element));
    qDebug("setElementPlaying %s",name);
    if( gst_element_set_state(element, GST_STATE_PLAYING) == GST_STATE_CHANGE_FAILURE )
    {
        qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not set state `GST_STATE_PLAYING' for element" << name;
        g_free(name);
        return -1;
    }
    g_free(name);
    return 0;
}

int setElementNull( GstElement * element ){
    char * name = gst_object_get_name(GST_OBJECT_CAST(element));
    qDebug("setElementNull %s",name);
    if( gst_element_set_state(element, GST_STATE_NULL) == GST_STATE_CHANGE_FAILURE )
    {
        qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not set state `GST_STATE_NULL' for element" << name;
        g_free(name);
        return -1;
    }
    g_free(name);
    return 0;
}

#ifdef WITH_PREVIEW
GstElement * FarsightChannel::Private::createVideoPreviewPipe( const char * name, const char * SharedName, FarsightChannel::Private *self )
{
    GstElement * ret = gst_bin_new( name );

    self->VideoPreviewOutColor = gst_element_factory_make( "ffmpegcolorspace", "my_previewffmpegcolorspace" );
    gst_object_ref(self->VideoPreviewOutColor);
    gst_object_sink(self->VideoPreviewOutColor);

    self->videoPreviewOutCaps = gst_caps_new_simple("video/x-raw-rgb",
                                        "bpp", G_TYPE_INT, 32,
                                        "blue_mask", G_TYPE_INT, -16777216,
                                        "green_mask", G_TYPE_INT, 16711680,
                                        "red_mask", G_TYPE_INT, 65280,
                                        NULL);

    self->videoPreviewOutCapsFilter = gst_element_factory_make( "capsfilter", "my_previewcapsfilter" );
    g_object_set( G_OBJECT(self->videoPreviewOutCapsFilter), "caps", self->videoPreviewOutCaps, NULL );
    gst_object_ref(self->videoPreviewOutCapsFilter);
    gst_object_sink(self->videoPreviewOutCapsFilter);

    self->videoPreviewperegrinevideosink = gst_element_factory_make ("peregrinevideosink", "my_previewperegrinevideosink");
#ifndef PREVIEW_peregrinevideosink_SILENT
    g_object_set (G_OBJECT (self->videoPreviewperegrinevideosink), "silent", false, NULL);
#endif
    g_object_set (G_OBJECT (self->videoPreviewperegrinevideosink), "sharedname", SharedName, NULL);
    gst_object_ref(self->videoPreviewperegrinevideosink);
    gst_object_sink(self->videoPreviewperegrinevideosink);


    self->videoPreviewOutFakeSink = gst_element_factory_make ("fakesink", "my_previewfakesink");
#ifdef PREVIEW_FAKESINK_DUMP
    g_object_set( G_OBJECT(self->videoPreviewOutFakeSink), "dump", true, NULL );
#endif
    gst_object_ref(self->videoPreviewOutFakeSink);
    gst_object_sink(self->videoPreviewOutFakeSink);
    gst_bin_add_many( GST_BIN(ret), self->VideoPreviewOutColor, self->videoPreviewOutCapsFilter, self->videoPreviewperegrinevideosink, self->videoPreviewOutFakeSink, NULL );
    gst_element_link_many( self->VideoPreviewOutColor, self->videoPreviewOutCapsFilter, self->videoPreviewperegrinevideosink, self->videoPreviewOutFakeSink, NULL );
    GstPad *pad = gst_element_get_static_pad ( self->VideoPreviewOutColor, "sink" );
    gst_element_add_pad (ret, gst_ghost_pad_new ("sink", pad));
    gst_object_unref (GST_OBJECT (pad));

    return ret;
}
#endif

GstElement * FarsightChannel::Private::createVideoOutputPipe( const char * name, const char * SharedName, FarsightChannel::Private *self )
{
    GstElement * ret = gst_bin_new( name );

    self->videoperegrinevideosink = gst_element_factory_make ("peregrinevideosink", "my_outperegrinevideosink");
#ifndef OUTPUT_peregrinevideosink_SILENT
    g_object_set (G_OBJECT (self->videoperegrinevideosink), "silent", false, NULL);
#endif
    g_object_set (G_OBJECT (self->videoperegrinevideosink), "sharedname", SharedName, NULL);
    gst_object_ref(self->videoperegrinevideosink);
    gst_object_sink(self->videoperegrinevideosink);

    self->VideoOutColor = gst_element_factory_make( "ffmpegcolorspace", "my_outffmpegcolorspace" );
    gst_object_ref(self->VideoOutColor);
    gst_object_sink(self->VideoOutColor);

    self->videoOutCaps = gst_caps_new_simple("video/x-raw-rgb",
                                        "bpp", G_TYPE_INT, 32,
                                        "blue_mask", G_TYPE_INT, -16777216,
                                        "green_mask", G_TYPE_INT, 16711680,
                                        "red_mask", G_TYPE_INT, 65280,
                                        NULL);

    self->videoOutCapsFilter = gst_element_factory_make( "capsfilter", "my_outcapsfilter" );
    g_object_set( G_OBJECT(self->videoOutCapsFilter), "caps", self->videoOutCaps, NULL );
    gst_object_ref(self->videoOutCapsFilter);
    gst_object_sink(self->videoOutCapsFilter);

    self->videoOutFakeSink = gst_element_factory_make ("fakesink", "my_outfakesink");
#ifdef FAKESINK_DUMP
    g_object_set( G_OBJECT(self->videoOutFakeSink), "dump", true, NULL );
#endif
    gst_object_ref(self->videoOutFakeSink);
    gst_object_sink(self->videoOutFakeSink);

    self->videoOutputQueue = gst_element_factory_make( "queue", "my_outputqueue" );
    g_object_set( G_OBJECT(self->videoOutputQueue), "leaky", 2, NULL );
    gst_object_ref(self->videoOutputQueue);
    gst_object_sink(self->videoOutputQueue);

    gst_bin_add_many( GST_BIN(ret), self->videoOutputQueue, self->VideoOutColor, self->videoOutCapsFilter, self->videoperegrinevideosink, self->videoOutFakeSink, NULL);
    gst_element_link_many( self->videoOutputQueue, self->VideoOutColor, self->videoOutCapsFilter, self->videoperegrinevideosink, self->videoOutFakeSink, NULL);
    GstPad *pad = gst_element_get_static_pad ( self->videoOutputQueue, "sink" );
    gst_element_add_pad (ret, gst_ghost_pad_new ("sink", pad));
    gst_object_unref (GST_OBJECT (pad));

    return ret;
}

GstElement * FarsightChannel::Private::createVideoInputPipe( const char * name, FarsightChannel::Private *self )
{
    GstElement * ret = gst_bin_new( name );
#ifdef WITH_TESTSOURCE
    self->videoSource = gst_element_factory_make( "videotestsrc", "my_autovideosrc" );
#else
    self->videoSource = gst_element_factory_make( "autovideosrc", "my_autovideosrc" );
#endif
    gst_object_ref(self->videoSource);
    gst_object_sink(self->videoSource);

    self->videoInRate = gst_element_factory_make( "videorate", "my_videorate" );
    gst_object_ref(self->videoInRate);
    gst_object_sink(self->videoInRate);

    self->videoInCaps = gst_caps_new_simple("video/x-raw-yuv",
                                          "width", G_TYPE_INT, 160,
                                          "height", G_TYPE_INT, 120,
                                          "framerate", GST_TYPE_FRACTION, 15, 1,
                                          NULL);

    self->videoInCapsFilter = gst_element_factory_make( "capsfilter", "my_incapsfilter" );
    g_object_set( G_OBJECT(self->videoInCapsFilter), "caps", self->videoInCaps, NULL );
    gst_object_ref(self->videoInCapsFilter);
    gst_object_sink(self->videoInCapsFilter);

    self->videoInTee = gst_element_factory_make( "tee", "my_tee" );
    gst_object_ref(self->videoInTee);
    gst_object_sink(self->videoInTee);

    self->videoInQueue = gst_element_factory_make( "queue", "my_inqueue" );
    g_object_set( G_OBJECT(self->videoInQueue), "leaky", 2, NULL );
    gst_object_ref(self->videoInQueue);
    gst_object_sink(self->videoInQueue);

#ifdef WITH_PREVIEW
    self->videoPreviewQueue = gst_element_factory_make( "queue", "my_previewqueue" );
    g_object_set( G_OBJECT(self->videoPreviewQueue), "leaky", 2, NULL );
    gst_object_ref(self->videoPreviewQueue);
    gst_object_sink(self->videoPreviewQueue);
#endif

    gst_bin_add_many( GST_BIN(ret),
#ifdef WITH_PREVIEW
                     self->videoPreviewQueue,
#endif
                     self->videoSource, self->videoInRate, self->videoInCapsFilter, self->videoInTee, self->videoInQueue, NULL );
    gst_element_link_many( self->videoSource, self->videoInRate, self->videoInCapsFilter, self->videoInTee, self->videoInQueue, NULL );
#ifdef WITH_PREVIEW
    gst_element_link_many( self->videoInTee, self->videoPreviewQueue, NULL );
#endif
    GstPad * pad = gst_element_get_static_pad ( self->videoInQueue, "src" );
    gst_element_add_pad (ret, gst_ghost_pad_new ("src_1", pad));
    gst_object_unref (GST_OBJECT (pad));
#ifdef WITH_PREVIEW
    pad = gst_element_get_static_pad ( self->videoPreviewQueue, "src" );
    gst_element_add_pad (ret, gst_ghost_pad_new ("src_2", pad));
    gst_object_unref (GST_OBJECT (pad));
#endif
    return ret;
}

#endif

FarsightChannel::Private::Private(FarsightChannel *parent,
        const Tp::StreamedMediaChannelPtr &chan)
    : parent(parent),
      channel(chan),
      status(StatusDisconnected),
      tfChannel(0),
      bus(0),
      pipeline(0),
      audioInput(0),
      audioOutput(0)
#if VIDEO_STREAMS>0
      ,
    videoSource(0),
    videoInRate(0),
    videoInCaps(0),
    videoInCapsFilter(0),
    videoInTee(0),
    videoInQueue(0),
#ifdef WITH_PREVIEW
    videoPreviewQueue(0),
    VideoPreviewOutColor(0),
    videoPreviewOutCapsFilter(0),
    videoPreviewperegrinevideosink(0),
    videoPreviewOutFakeSink(0),
    videoPreviewOutCaps(0),
    videoPreviewPipe(0),
#endif
    videoInputPipe(0),
    videoOutputQueue(0),
    videoOutputPipe(0),
    videoperegrinevideosink(0),
    VideoOutColor(0),
    videoOutCaps(0),
    videoOutCapsFilter(0),
    videoOutFakeSink(0)
#endif
{
    qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "creating Telepathy-Farsight channel";

    tfChannel = Tp::createFarsightChannel(channel);
    if (!tfChannel) {
        qWarning() << "Unable to construct TfChannel";
        return;
    }

    qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "setting up gstreamer stuff";

    /* Set up the telepathy farsight channel */
    g_signal_connect(tfChannel, "closed",
        G_CALLBACK(&FarsightChannel::Private::onClosed), this);
    g_signal_connect(tfChannel, "session-created",
        G_CALLBACK(&FarsightChannel::Private::onSessionCreated), this);
    g_signal_connect(tfChannel, "stream-created",
        G_CALLBACK(&FarsightChannel::Private::onStreamCreated), this);
    pipeline = gst_pipeline_new(NULL);
    bus = gst_pipeline_get_bus(GST_PIPELINE(pipeline));


    audioInput = gst_element_factory_make( "autoaudiosrc", "mic" );
    gst_object_ref(audioInput);
    gst_object_sink(audioInput);

    audioOutput = gst_bin_new( "audioOutput" );
    {
        GstElement *speaker = gst_element_factory_make( "autoaudiosink", "autoaudiosink" );
        GstElement *converter = gst_element_factory_make( "audioconvert", "audioconvert" );
        gst_bin_add( GST_BIN(audioOutput), speaker );
        gst_bin_add( GST_BIN(audioOutput), converter );
        gst_element_link( converter, speaker );

        GstPad *pad = gst_element_get_static_pad( converter, "sink" );
        gst_element_add_pad( audioOutput, gst_ghost_pad_new("sink", pad) );
        gst_object_unref( GST_OBJECT(pad) );
    }
    gst_object_ref( audioOutput );
    gst_object_sink( audioOutput );

    this->videoInputPipe = createVideoInputPipe( "videoInputPipe", this );
    gst_object_ref( this->videoInputPipe );
    gst_object_sink( this->videoInputPipe );
#ifdef WITH_PREVIEW
    this->videoPreviewPipe = createVideoPreviewPipe( "videoPreviewPipe", "voipcallpreview", this );
    gst_object_ref( this->videoPreviewPipe );
    gst_object_sink( this->videoPreviewPipe );
#endif
    this->videoOutputPipe = createVideoOutputPipe( "videoOutputPipe", "voipcallexample", this );
    gst_object_ref( this->videoOutputPipe );
    gst_object_sink( this->videoOutputPipe );

    if( gst_element_set_state(pipeline, GST_STATE_PLAYING) == GST_STATE_CHANGE_FAILURE )
    {
        qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not set state `GST_STATE_PLAYING' for element `pipeline'";
        emit parent->notification( "GStreamer Pipeline", "Could not set pipeline to playing!", NotificationTypeWarning );
    }

    status = StatusConnecting;
    emit parent->statusChanged(status);

    GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "constructor_finished" );
}

FarsightChannel::Private::~Private()
{
    qDebug() << __PRETTY_FUNCTION__ << __LINE__;

    GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "beforeFarsightChannelDestroyed" );

    if( tfChannel ) {
        g_object_unref( tfChannel );
        tfChannel = 0;
    }

    if( bus )
    {
        g_object_unref( bus );
        bus = 0;
    }

    setElementNull( pipeline );
    setElementNull( videoPreviewPipe );
    setElementNull( videoOutputPipe );
    setElementNull( videoInputPipe );

    if( audioInput )
    {
        g_object_unref( audioInput );
        audioInput = 0;
    }

    if( audioOutput )
    {
        g_object_unref( audioOutput );
        audioOutput = 0;
    }

#if VIDEO_STREAMS > 0
    qDebug( "unrefing videoOutput ##########################################################" );
    if( videoOutputQueue )
    {
        g_object_unref( videoOutputQueue );
        videoOutputQueue = 0;
    }

    if( videoSource )
    {
        g_object_unref( videoSource );
        videoSource = 0;
    }

    if( videoInRate )
    {
        g_object_unref( videoInRate );
        videoInRate = 0;
    }

    if( videoInCapsFilter )
    {
        g_object_unref( videoInCapsFilter );
        videoInCapsFilter = 0;
    }

    if( videoInTee )
    {
        g_object_unref( videoInTee );
        videoInTee = 0;
    }

    if( videoInQueue )
    {
        g_object_unref( videoInQueue );
        videoInQueue = 0;
    }

    if( videoInputPipe )
    {
        g_object_unref( videoInputPipe );
        videoInputPipe = 0;
    }

    if( videoOutputPipe )
    {
        g_object_unref( videoOutputPipe );
        videoOutputPipe = 0;
    }

#ifdef WITH_PREVIEW
    if( videoPreviewPipe )
    {
        g_object_unref( videoPreviewPipe );
        videoPreviewPipe = 0;
    }

    if( videoPreviewQueue )
    {
        g_object_unref( videoPreviewQueue );
        videoPreviewQueue = 0;
    }

    if( VideoPreviewOutColor )
    {
        g_object_unref( VideoPreviewOutColor );
        VideoPreviewOutColor = 0;
    }

    if( videoPreviewOutCapsFilter )
    {
        g_object_unref( videoPreviewOutCapsFilter );
        videoPreviewOutCapsFilter = 0;
    }

    if( videoPreviewperegrinevideosink )
    {
        g_object_unref( videoPreviewperegrinevideosink );
        videoPreviewperegrinevideosink = 0;
    }

    if( videoPreviewOutFakeSink )
    {
        g_object_unref( videoPreviewOutFakeSink );
        videoPreviewOutFakeSink = 0;
    }

#endif

    if( videoperegrinevideosink )
    {
        g_object_unref( videoperegrinevideosink );
        videoperegrinevideosink = 0;
    }

    if( VideoOutColor )
    {
        g_object_unref( VideoOutColor );
        VideoOutColor = 0;
    }

    if( videoOutCapsFilter )
    {
        g_object_unref( videoOutCapsFilter );
        videoOutCapsFilter = 0;
    }

    if( videoOutFakeSink )
    {
        g_object_unref( videoOutFakeSink );
        videoOutFakeSink = 0;
    }

    GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "onFarsightChannelDestroyed" );

    if( pipeline )
    {
        g_object_unref(pipeline);
        pipeline = 0;
    }

#endif
}

void FarsightChannel::Private::onStreamError(TfStream *stream,
        FarsightChannel::Private *self)
{
    // unused
    stream = 0;
    self = 0;
    qDebug("############################################################################################################################################");
    qDebug("############################################################################################################################################");
    qDebug("###############################################################################################################################onStreamError");
    qDebug("############################################################################################################################################");
    qDebug("############################################################################################################################################");
}

gboolean FarsightChannel::Private::busWatch( GstBus *bus,
                                             GstMessage *message,
                                             FarsightChannel::Private *self )
{
    Q_UNUSED( bus );
    tf_channel_bus_message( self->tfChannel, message );

    return true;
}

void FarsightChannel::Private::onClosed( TfChannel *tfChannel,
                                         FarsightChannel::Private *self )
{
    Q_UNUSED( tfChannel );
    self->status = StatusDisconnected;
    emit self->parent->statusChanged( self->status );
}

void FarsightChannel::Private::onSessionCreated( TfChannel *tfChannel,
                                                 FsConference *conference,
                                                 FsParticipant *participant,
                                                 FarsightChannel::Private *self )
{
    Q_UNUSED( tfChannel );
    Q_UNUSED( participant );
    gst_bus_add_watch( self->bus,(GstBusFunc) &FarsightChannel::Private::busWatch,self );
    if( !gst_bin_add(GST_BIN(self->pipeline), GST_ELEMENT(conference)) )
    {
        qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not add element `conference' to bin `pipeline'";
        emit self->parent->notification( "GStreamer Pipeline", "Could not add conference element to pipeline", NotificationTypeError );
    }

    if( gst_element_set_state(GST_ELEMENT(conference), GST_STATE_PLAYING) == GST_STATE_CHANGE_FAILURE )
    {
        qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not set state to `GST_STATE_PLAYING' for element `conference'";
        emit self->parent->notification( "GStreamer Pipeline", "Could not set pipeline to playing!", NotificationTypeWarning );
    }
    GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(self->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "on_session_created" );
}

void FarsightChannel::Private::onStreamCreated( TfChannel *tfChannel,
                                                TfStream *stream,
                                                FarsightChannel::Private *self )
{
    Q_UNUSED( tfChannel );
    guint media_type;
    GstPad *sink;
    g_signal_connect( stream, "src-pad-added",
                      G_CALLBACK(&FarsightChannel::Private::onSrcPadAdded), self );
    g_signal_connect( stream, "request-resource",
                      G_CALLBACK(&FarsightChannel::Private::onRequestResource), NULL );
    g_signal_connect( stream, "closed",
                      G_CALLBACK(&FarsightChannel::Private::onStreamClosed), self );
    g_signal_connect( stream, "error",
                      G_CALLBACK(&FarsightChannel::Private::onStreamError), self );

    g_object_get( stream, "media-type", &media_type,
                  "sink-pad", &sink, NULL );

    {
        qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << QString( "************************************");
        qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << QString( "Stream added. Inspecting sink pads caps:" );

        GstCaps *sinkcaps = gst_pad_get_caps( sink );

        GST_DEBUG_CAPS( "stream created", sinkcaps );

        //gst_object_unref( sinkcaps );

        qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << QString( "************************************");
    }

    GstPad *pad;
    GstCaps * caps;
    GstStructure * structure;
    switch( media_type ) {
    case TP_MEDIA_STREAM_TYPE_AUDIO:
        if( !gst_bin_add( GST_BIN(self->pipeline), self->audioInput ) )
        {
            qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not add element `audioInput' to bin `pipeline'";
            emit self->parent->notification( "GStreamer Pipeline", "Could not add audioInput element to pipeline", NotificationTypeError );
        }
        if( gst_element_set_state( self->audioInput, GST_STATE_PLAYING ) == GST_STATE_CHANGE_FAILURE )
        {
            qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not set state to `GST_STATE_PLAYING' for element `audioInput'";
            emit self->parent->notification( "GStreamer Pipeline", "Could not set audioInput to playing!", NotificationTypeWarning );
        }

        pad = gst_element_get_static_pad( self->audioInput, "src" );
        caps = gst_pad_get_caps( pad );
        structure = gst_caps_get_structure( caps, 0 );
        qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "got mic pad with '" << gst_pad_get_name(pad) << "' '" << gst_structure_get_name( structure ) << "'";
        // connect audioInput (mic) to sink pad
        gst_pad_link(pad, sink);
        break;
    case TP_MEDIA_STREAM_TYPE_VIDEO:
#if VIDEO_STREAMS>0
    {
        gst_bin_add( GST_BIN(self->pipeline), self->videoInputPipe );
        GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(self->videoInputPipe), GST_DEBUG_GRAPH_SHOW_ALL, "onCreateVideoInputPipe" );
#ifdef WITH_PREVIEW
        gst_bin_add( GST_BIN(self->pipeline), self->videoPreviewPipe );
        GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(self->videoPreviewPipe), GST_DEBUG_GRAPH_SHOW_ALL, "onCreateVideoPreviewPipe" );
        GstPad * pad1, * pad2;
        pad1 = gst_element_get_static_pad( self->videoInputPipe, "src_2" );
        pad2 = gst_element_get_static_pad( self->videoPreviewPipe, "sink" );
        gst_pad_link(pad1, pad2);
        gst_object_unref( GST_OBJECT(pad1) );
        gst_object_unref( GST_OBJECT(pad2) );
#endif
        pad = gst_element_get_static_pad( self->videoInputPipe, "src_1" );
        gst_pad_link(pad, sink);
        gst_object_unref( GST_OBJECT(pad) );
        emit self->parent->startVideoNow();
        return;
    }
    qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "should now be playing";
#endif

        GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(self->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "on_video_stream_added" );
        break;
    default:
        Q_ASSERT( false );
    }

}

void FarsightChannel::Private::onStreamClosed( TfStream *stream,
                                               FarsightChannel::Private *self )
{
    Q_UNUSED( self );
    guint media_type;

    g_object_get( stream, "media-type", &media_type, NULL );

    switch( media_type )
    {
    case TP_MEDIA_STREAM_TYPE_AUDIO:
        break;
    case TP_MEDIA_STREAM_TYPE_VIDEO:
#if VIDEO_STREAMS > 0

        GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(self->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "on_stream_closed_added" );

#endif
        break;
    default:
        Q_ASSERT( false );
    }
}

void FarsightChannel::Private::onSrcPadAdded( TfStream *stream,
                                              GstPad *src,
                                              FsCodec *codec,
                                              FarsightChannel::Private *self )
{
    Q_UNUSED( codec );
    qDebug() << __FILE__ << __FUNCTION__ << __LINE__;
    guint media_type;
    g_object_get( stream, "media-type", &media_type, NULL );

    {
        qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << QString( "**********************************************" );
        qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << QString( "Source pad added. Inspecting source pads caps:" );

        GstCaps *srccaps = gst_pad_get_caps( src );

        GST_DEBUG_CAPS( "source pad added", srccaps );

        qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << QString( "**********************************************" );
    }

    GstCaps * caps;
    GstStructure * structure;
    switch( media_type ) {
    case TP_MEDIA_STREAM_TYPE_AUDIO:
        {
            qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "set state for element `pipeline'";
            if( gst_element_set_state( self->pipeline, GST_STATE_PAUSED ) == GST_STATE_CHANGE_FAILURE )
            {
                qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not set state to playing for output pipeline!";
                emit self->parent->notification( "GStreamer Pipeline", "Could not set pipeline to playing!", NotificationTypeError );
            }

            qDebug() << "added sink" << gst_bin_add(GST_BIN(self->pipeline), self->audioOutput);
            GstPad *sink = gst_element_get_static_pad( self->audioOutput, "sink" );

            caps = gst_pad_get_caps( src );
            structure = gst_caps_get_structure( caps, 0 );
            qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "got farsight pad with '" << gst_pad_get_name(src) << "' '" << gst_structure_get_name( structure ) << "'";
            caps = gst_pad_get_caps( sink );
            structure = gst_caps_get_structure( caps, 0 );
            qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "got alsa pad with '" << gst_pad_get_name(sink) << "' '" << gst_structure_get_name( structure ) << "'";
            qDebug() << "linking source pad, sink pad" << gst_pad_link( src, sink );

            //gst_object_unref( GST_OBJECT(src) );
            gst_object_unref( GST_OBJECT(sink) );

            qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "set state for element `pipeline'";
            if( gst_element_set_state( self->pipeline, GST_STATE_PLAYING ) == GST_STATE_CHANGE_FAILURE )
            {
                qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not set state to playing for output pipeline!";
                emit self->parent->notification( "GStreamer Pipeline", "Could not set pipeline to playing!", NotificationTypeError );
            }
            self->status = StatusConnected;
            emit self->parent->statusChanged(self->status);
            return;
        }
        break;
    case TP_MEDIA_STREAM_TYPE_VIDEO:
#if VIDEO_STREAMS>0
        {

            qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "set state for element `pipeline'";
            if( gst_element_set_state( self->pipeline, GST_STATE_PAUSED ) == GST_STATE_CHANGE_FAILURE )
            {
                qWarning() << __PRETTY_FUNCTION__ << __LINE__ << "Could not set state to paused for output pipeline!";
                emit self->parent->notification( "GStreamer Pipeline", "Could not set pipeline to paused!", NotificationTypeError );
            }

                gst_bin_add( GST_BIN(self->pipeline), self->videoOutputPipe );

               GstPad * peregrinevideosinkpad = gst_element_get_static_pad( self->videoOutputPipe, "sink" );

            qDebug() << "linking source src, sink mypad" << gst_pad_link( src, peregrinevideosinkpad );
            gst_object_unref( GST_OBJECT(peregrinevideosinkpad) );
            qDebug() << __FILE__ << __FUNCTION__ << __LINE__ << "set state for element `pipeline'";
            setElementPlaying( self->videoOutputPipe );
            setElementPlaying( self->pipeline );
            self->status = StatusConnected;
            emit self->parent->statusChanged(self->status);
            GST_DEBUG_BIN_TO_DOT_FILE( GST_BIN(self->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "on_video_source_added" );
            return;
        }

#else
        return;
#endif
        break;
    default:
        Q_ASSERT( false );
    }
}

gboolean FarsightChannel::Private::onRequestResource( TfStream *stream,
                                                      guint direction,
                                                      gpointer data )
{
    Q_UNUSED( stream );
    Q_UNUSED( direction );
    Q_UNUSED( data );
    return TRUE;
}

FarsightChannel::FarsightChannel( const Tp::StreamedMediaChannelPtr &channel,
                                  QObject *parent )
                                      : QObject( parent ),
                                      mPriv( new Private(this, channel) )
{
#if VIDEO_STREAMS>0
    connect( this, SIGNAL(startVideoNow()), SLOT(startVideoSrc()) );
#endif
}

FarsightChannel::~FarsightChannel()
{
    qDebug() << __FILE__ << __FUNCTION__ << __LINE__;
    delete mPriv;
}

#if VIDEO_STREAMS>0

void FarsightChannel::startVideoSrc()
{
    qDebug() << __FILE__ << __FUNCTION__ << __LINE__;
    //if( mPriv->videoOutput )
    {
#ifdef WITH_PREVIEW
        setElementPlaying(mPriv->videoPreviewPipe);
#endif
        setElementPlaying(mPriv->videoOutputPipe);
        setElementPlaying(mPriv->videoInputPipe);
        setElementPlaying(mPriv->pipeline);
    }
}
#endif


void FarsightChannel::dumpPipeline()
{
    GST_DEBUG_BIN_TO_DOT_FILE_WITH_TS( GST_BIN(mPriv->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline_dump" );
}

