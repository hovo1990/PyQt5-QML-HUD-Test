/*
 * clienthandler.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "clienthandler.h"
#include "clienthandler_p.h"
#include "../peregrineinitializer.h"
#include "../peregrineservicenames.h"
#include "../presencestates.h"
#include "../peregrineDebugHelper.h"
#include "../contact/contactlistmodelinterface.h"

#include <QDateTime>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/AccountManager>
#include <TelepathyQt4/ChannelRequest>
#include <TelepathyQt4/Contact>
#include <TelepathyQt4/ContactManager>
#include <TelepathyQt4/FileTransferChannel>
#include <TelepathyQt4/PendingChannelRequest>
#include <TelepathyQt4/PendingContacts>
#include <TelepathyQt4/PendingReady>
#include <TelepathyQt4/ReceivedMessage>
#include <TelepathyQt4/SharedPtr>
#include <TelepathyQt4/StreamedMediaChannel>
#include <TelepathyQt4/TextChannel>

using namespace Peregrine;

/* *****************************************************************************
 * ChannelContext
 * ****************************************************************************/

bool
ChannelContext::getContacts()
{
    FUNC_IN
    Tp::ContactManagerPtr contactManager = mConnection->contactManager();

    if( contactManager.isNull() )
    {
        FUNC_OUT
        return false;
    }

    if( mChannels.size() <= 0 )
    {
        FUNC_OUT
        return false;
    }

    QList<Tp::ContactPtr> contacts;
    foreach( Tp::ChannelPtr channel, mChannels )
    {
        if( channel->targetHandleType() == Tp::HandleTypeContact )
        {
            Tp::ContactPtr contact = contactManager->lookupContactByHandle( channel->targetHandle() );
            if( contact.isNull() )
            {
                continue;
            }

            contacts.append( contact );
        }
    }

    if( contacts.isEmpty() )
    {
        FUNC_OUT
        return false;
    }

    connect( contactManager->upgradeContacts(contacts, ClientHandlerPrivate::CONTACT_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onContactsUpgraded(Tp::PendingOperation *)) );
    FUNC_OUT
    return true;
}

void
ChannelContext::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    accountFinished = true;
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();

        emit notification( operation->errorName().split(".").last(), operation->errorMessage(), NotificationTypeWarning );

    }
    mServiceName = serviceNameForAccount( mAccount );
    validateReadyState();
    FUNC_OUT
}

void
ChannelContext::onChannelInvalidated( Tp::DBusProxy *proxy,
                                                            const QString &errorName,
                                                            const QString &errorMessage )
{
    FUNC_IN
    Q_UNUSED( proxy );

    qWarning() << __PRETTY_FUNCTION__
               << errorName + ": " + errorMessage;

    emit notification( errorName, errorMessage, NotificationTypeWarning );


    for( int i = 0; i < mChannels.count(); ++i )
    {
        if( mChannels.at(i)->isValid() )
        {
            continue;
        } else
        {
            mChannels.removeAt( i-- );
        }
    }
    if( mChannels.count() <= 0 )
    {
        emit untouchedActivitiesCountChanged();
        emit closed( mChannelId );
    }
    FUNC_OUT
}

void
ChannelContext::onChannelLocalHoldStateChanged( Tp::LocalHoldState state, Tp::LocalHoldStateReason reason )
{
    FUNC_IN
    Q_UNUSED( reason );

    if( state <= 1 )
    {
        mChannelState = QString();
    } else
    {
        mChannelState = QString( "hold" );
    }

    emit changed( mChannelId );
    FUNC_OUT
}

void
ChannelContext::onChannelReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();

        emit notification( operation->errorName().split(".").last(), operation->errorMessage(), NotificationTypeWarning );
    } else
    {
        // we need a specialized call to becomeReady for each type of channel

        Tp::ChannelPtr channel = Tp::ChannelPtr::staticCast( operation->object() );
        if( channel == mChannels.at(0) )
        {
            mChannelRequested = channel->isRequested();
        }

        // activate specialized features for channels (also needed for core feature set!!!)
        if( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_TEXT )
        {
            // check if needed TextChannel features are activated
            Tp::TextChannelPtr textChannel = Tp::TextChannelPtr::staticCast( channel );
            if( !channel->isReady(ClientHandlerPrivate::TEXT_CHANNEL_FEATURES) )
            {
                connect( textChannel->becomeReady(ClientHandlerPrivate::TEXT_CHANNEL_FEATURES),
                         SIGNAL(finished(Tp::PendingOperation *)),
                         this,
                         SLOT(onChannelReady(Tp::PendingOperation *)) );
                FUNC_OUT
                return;
            }

            connect( textChannel.data(),
                     SIGNAL( messageReceived( Tp::ReceivedMessage ) ),
                     this,
                     SLOT( onTextChannelMessageReceived() ) );

            // set meta-data
            QList<Tp::ReceivedMessage> messages = textChannel->messageQueue();
            mUntouchedActivityCount = messages.count();
            if( mUntouchedActivityCount > 0 )
            {
                Tp::ReceivedMessage message = messages.at(0);
                mVariantData = message.text();
                setFirstUntouchedActivityTime( message.received() );
            }

        } else if( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_STREAMED_MEDIA )
        {
            Tp::StreamedMediaChannelPtr mediaChannel = Tp::StreamedMediaChannelPtr::staticCast( channel );
            if( !channel->isReady(ClientHandlerPrivate::MEDIA_CHANNEL_FEATURES) )
            {
                connect( mediaChannel->becomeReady(ClientHandlerPrivate::MEDIA_CHANNEL_FEATURES),
                         SIGNAL(finished(Tp::PendingOperation *)),
                         this,
                         SLOT(onChannelReady(Tp::PendingOperation *)) );
                connect( mediaChannel.data(),
                         SIGNAL(localHoldStateChanged(Tp::LocalHoldState,Tp::LocalHoldStateReason)),
                         this,
                         SLOT(onChannelLocalHoldStateChanged(Tp::LocalHoldState,Tp::LocalHoldStateReason)) );
                onChannelLocalHoldStateChanged( mediaChannel->localHoldState(), mediaChannel->localHoldStateReason() );
                FUNC_OUT
                return;
            }

            // set meta-data
            mDuration = "00:00";
        } else if ( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_FILE_TRANSFER )
        {
            Tp::FileTransferChannelPtr fileChannel = Tp::FileTransferChannelPtr::staticCast( channel );
            if( !channel->isReady(ClientHandlerPrivate::FILE_CHANNEL_FEATURES) )
            {
                connect( fileChannel->becomeReady(ClientHandlerPrivate::FILE_CHANNEL_FEATURES),
                         SIGNAL(finished(Tp::PendingOperation *)),
                         this,
                         SLOT(onChannelReady(Tp::PendingOperation *)) );
                FUNC_OUT
                return;
            }

            // set meta-data
            mVariantData = fileChannel->fileName();
            mUntouchedActivityCount = 1;
        }

        if( connectionFinished )
        {
            if( !getContacts() )
            {
                contactsFinished = true;
            }
        }
    }

    if( --mFinishedChannels <= 0 )
    {
        channelFinished = true;
    }

    validateReadyState();
    FUNC_OUT
}

void
ChannelContext::onTextChannelMessageReceived()
{
    Tp::TextChannel* textChannel = qobject_cast<Tp::TextChannel *>( sender() );
    if( mUntouched )
    {        
        QList<Tp::ReceivedMessage> messages = textChannel->messageQueue();
        mUntouchedActivityCount = messages.count();
        if( mUntouchedActivityCount > 0 )
        {
            Tp::ReceivedMessage message = messages.last();
            setLatestActionTime( message.received() );
        }
        emit untouchedActivitiesCountChanged();
    }
    else
        disconnect( textChannel, SIGNAL( messageReceived( Tp::ReceivedMessage ) ), this, SLOT( onTextChannelMessageReceived() ) );
}

void
ChannelContext::onAcountRemoved()
{
    emit closed( mChannelId );
}

void
ChannelContext::onConnectionReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    connectionFinished = true;
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();

        emit notification( operation->errorName().split(".").last(), operation->errorMessage(), NotificationTypeWarning );

    } else
    {
        if( channelFinished )
        {
            if( !getContacts() )
            {
                contactsFinished = true;
            }
        }
    }
    validateReadyState();
    FUNC_OUT
}

void ChannelContext::onContactChanged()
{
    FUNC_IN
    emit changed( mChannelId );
    FUNC_OUT
}

void
ChannelContext::onContactsUpgraded( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();

        emit notification( operation->errorName().split(".").last(), operation->errorMessage(), NotificationTypeNotice );

    }

    Tp::PendingContacts *pc = qobject_cast<Tp::PendingContacts *>(operation);
    QList<Tp::ContactPtr> contacts = pc->contacts();
    foreach( Tp::ContactPtr contact, contacts )
    {
        if( mChannels.at(0)->targetHandleType() == Tp::HandleTypeContact
            && contact->handle().first() == mChannels.at(0)->targetHandle() )
        {
            mContact = contact;
            connect( mContact.data(),
                     SIGNAL(aliasChanged(QString)),
                     this,
                     SLOT(onContactChanged()) );
            connect( mContact.data(),
                     SIGNAL(avatarDataChanged(Tp::AvatarData)),
                     this,
                     SLOT(onContactChanged()) );
            connect( mContact.data(),
                     SIGNAL(presenceChanged(Tp::Presence)),
                     this,
                     SLOT(onContactChanged()) );
        }
    }

    // TODO:
    // this deprecated code is fallback if contact was not found in foreach loop
    if( mContact.isNull()
        && contacts.count() > 0 )
    {
        mContact = contacts.at(0);
        connect( mContact.data(),
                 SIGNAL(aliasChanged(QString)),
                 this,
                 SLOT(onContactChanged()) );
        connect( mContact.data(),
                 SIGNAL(avatarDataChanged(Tp::AvatarData)),
                 this,
                 SLOT(onContactChanged()) );
        connect( mContact.data(),
                 SIGNAL(presenceChanged(Tp::Presence)),
                 this,
                 SLOT(onContactChanged()) );
    }

    contactsFinished = true;
    validateReadyState();
    FUNC_OUT
}

void
ChannelContext::validateReadyState()
{
    FUNC_IN
    if( accountFinished
        && connectionFinished
        && channelFinished
        && contactsFinished )
    {
        bool error = false;
        error |= !mAccount->isReady(ClientHandlerPrivate::ACCOUNT_FEATURES);
        error |= !mConnection->isReady(ClientHandlerPrivate::CONNECTION_FEATURES);
        foreach( Tp::ChannelPtr channel, mChannels )
        {
            error |= !channel->isReady(ClientHandlerPrivate::CHANNEL_FEATURES);
        }
        emit initialized( mChannelId, error );
    }
    FUNC_OUT
}

void
ChannelContext::close()
{
    FUNC_IN
    foreach( Tp::ChannelPtr channel, mChannels )
    {
        // activate specialized features for channels (also needed for core feature set!!!)
        if( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_TEXT )
        {
            // check if needed TextChannel features are activated
            Tp::TextChannelPtr textChannel = Tp::TextChannelPtr::staticCast( channel );
            // set meta-data
            QList<Tp::ReceivedMessage> messages = textChannel->messageQueue();
            mUntouchedActivityCount = 0;
            if( messages.count() > 0 )
            {
                textChannel->acknowledge( messages );
            }
            emit untouchedActivitiesCountChanged();
        } else if( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_STREAMED_MEDIA )
        {
            // set meta-data
            mDuration = "Disconnected";
        } else if ( channel->channelType() == TP_QT4_IFACE_CHANNEL_TYPE_FILE_TRANSFER )
        {
            emit untouchedActivitiesCountChanged();
        }

        channel->requestClose();
    }
    FUNC_OUT
}

Tp::AccountPtr
ChannelContext::account() const
{
    FUNC_IN
    FUNC_OUT
    return mAccount;
}

QString
ChannelContext::channelId() const
{
    FUNC_IN
    FUNC_OUT
    return mChannelId;
}

bool
ChannelContext::channelRequested() const
{
    FUNC_IN
    FUNC_OUT
    return mChannelRequested;
}

QList<Tp::ChannelPtr>
ChannelContext::channels() const
{
    FUNC_IN
    FUNC_OUT
    return mChannels;
}

QString
ChannelContext::channelState() const
{
    FUNC_IN
    FUNC_OUT
    return mChannelState;
}

QString
ChannelContext::channelType() const
{
    FUNC_IN
    FUNC_OUT
    return mChannelType;
}

Tp::ConnectionPtr
ChannelContext::connection() const
{
    FUNC_IN
    FUNC_OUT
    return mConnection;
}

Tp::ContactPtr
ChannelContext::contact() const
{
    FUNC_IN
    FUNC_OUT
    return mContact;
}

QString
ChannelContext::duration() const
{
    FUNC_IN
    FUNC_OUT
    return mDuration;
}

QDateTime
ChannelContext::firstUntouchedActivityTime() const
{
    FUNC_IN
    FUNC_OUT
    return mFirstUntouchedActivityTime;
}

bool
ChannelContext::initialize( const QString &channelId )
{
    FUNC_IN
    bool error = false;
    if( mAccount.isNull() )
    {
        error = true;
    } else
    {
        error |= !connect( mAccount.data(), SIGNAL(removed()), this, SLOT(onAccountRemoved()) );
        error |= !connect( mAccount->becomeReady(ClientHandlerPrivate::ACCOUNT_FEATURES),
                           SIGNAL(finished(Tp::PendingOperation *)),
                           this,
                           SLOT(onAccountReady(Tp::PendingOperation *)) );
    }
    if( mConnection.isNull() )
    {
        error = true;
    } else
    {
        error |= !connect( mConnection->becomeReady(ClientHandlerPrivate::CONNECTION_FEATURES),
                           SIGNAL(finished(Tp::PendingOperation*)),
                           this,
                           SLOT(onConnectionReady(Tp::PendingOperation *)) );
    }
    if( mChannels.count() <= 0 )
    {
        error = true;
    } else
    {
        if( channelId.isEmpty() )
        {
            mChannelId = mChannels.at(0)->objectPath();
        } else
        {
            mChannelId = channelId;
        }

        mFinishedChannels = mChannels.count();
        foreach( Tp::ChannelPtr channel, mChannels )
        {
            error |= !connect( channel.data(),
                               SIGNAL(invalidated(Tp::DBusProxy *, QString, QString)),
                               this,
                               SLOT(onChannelInvalidated(Tp::DBusProxy *, QString, QString)) );
            error |= !connect( channel->becomeReady(ClientHandlerPrivate::CHANNEL_FEATURES),
                               SIGNAL(finished(Tp::PendingOperation *)),
                               this,
                               SLOT(onChannelReady(Tp::PendingOperation *)) );
        }
    }

    FUNC_OUT
    return !error;
}

QDateTime
ChannelContext::latestActionTime() const
{
    FUNC_IN
    FUNC_OUT
    return mLatestActionTime;
}

void
ChannelContext::setChannelState( const QString &state )
{
    FUNC_IN
    if( state != mChannelState )
    {
        mChannelState = state;
        emit changed( mChannelId );
    }
    FUNC_OUT
}

void
ChannelContext::setDuration( const QString &timestring )
{
    FUNC_IN
    if( timestring != mDuration )
    {
        mDuration = timestring;
        emit changed( mChannelId );
    }
    FUNC_OUT
}

void
ChannelContext::setFirstUntouchedActivityTime( const QDateTime &timestamp )
{
    FUNC_IN
    if( mFirstUntouchedActivityTime != timestamp
        || mFirstUntouchedActivityTime.isValid() )
    {
        if( timestamp.isValid() )
        {
            mFirstUntouchedActivityTime = timestamp;
        } else
        {
            mFirstUntouchedActivityTime = QDateTime::currentDateTime();
        }
        emit changed( mChannelId );
    }
    FUNC_OUT
}

void
ChannelContext::setLatestActionTime( const QDateTime &timestamp )
{
    FUNC_IN
    if( mLatestActionTime != timestamp
        || !mLatestActionTime.isValid() )
    {
        if( timestamp.isValid() )
        {
            mLatestActionTime = timestamp;
        } else
        {
            mLatestActionTime = QDateTime::currentDateTime();
        }
        emit changed( mChannelId );
    }
    FUNC_OUT
}

void
ChannelContext::setUntouchedActivityCount( int count )
{
    FUNC_IN
    if( mUntouchedActivityCount != count )
    {
        mUntouchedActivityCount = count;
        emit changed( mChannelId );
        emit untouchedActivitiesCountChanged();
    }
    FUNC_OUT
}

void
ChannelContext::setVariantData( const QVariant &data )
{
    FUNC_IN
    if( data != mVariantData )
    {
        mVariantData = data;
        emit changed( mChannelId );
    }
    FUNC_OUT
}

bool
ChannelContext::untouched() const
{
    FUNC_IN
    FUNC_OUT
    return mUntouched;
}

int
ChannelContext::untouchedActivityCount() const
{
    FUNC_IN
    FUNC_OUT
    return mUntouchedActivityCount;
}

QDateTime ChannelContext::userActionTime() const
{
    FUNC_IN
    FUNC_OUT
    return mUserActionTime;
}

QVariant
ChannelContext::variantData() const
{
    FUNC_IN
    FUNC_OUT
    return mVariantData;
}

/* *****************************************************************************
 * ClientHandlerPrivate
 * ****************************************************************************/

QPointer<ClientHandlerPrivate> ClientHandlerPrivate::mInstance( 0 );

const Tp::Features
ClientHandlerPrivate::ACCOUNT_FEATURES = ( Tp::Features()
                                         << Tp::Account::FeatureCore
                                         << Tp::Account::FeatureProtocolInfo );

const Tp::Features
ClientHandlerPrivate::ACCOUNT_MANAGER_FEATURES = ( Tp::Features()
                                           << Tp::AccountManager::FeatureCore );

const Tp::Features
ClientHandlerPrivate::CHANNEL_FEATURES = ( Tp::Features()
                                         << Tp::Channel::FeatureCore );

const Tp::Features
ClientHandlerPrivate::CONNECTION_FEATURES = ( Tp::Features()
                                     << Tp::Connection::FeatureCore
                                     << Tp::Connection::FeatureRoster
                                     << Tp::Connection::FeatureSimplePresence );

const Tp::Features
ClientHandlerPrivate::CONTACT_FEATURES = ( Tp::Features()
                                           << Tp::Contact::FeatureAlias
                                           << Tp::Contact::FeatureSimplePresence );

const Tp::Features
ClientHandlerPrivate::FILE_CHANNEL_FEATURES = ( Tp::Features()
                                                << Tp::FileTransferChannel::FeatureCore );

const Tp::Features
ClientHandlerPrivate::MEDIA_CHANNEL_FEATURES = ( Tp::Features()
                                                 << Tp::StreamedMediaChannel::FeatureCore
                                                 << Tp::StreamedMediaChannel::FeatureLocalHoldState
                                                 << Tp::StreamedMediaChannel::FeatureStreams );

const Tp::Features
ClientHandlerPrivate::TEXT_CHANNEL_FEATURES = ( Tp::Features()
                                                << Tp::TextChannel::FeatureCore
                                                << Tp::TextChannel::FeatureMessageQueue );

const QString
ClientHandlerPrivate::CHANNEL_TYPE_TEXT = QString("text");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_VOIP = QString("voip");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_VIDEO = QString("video");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_CELL = QString("cell");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_FILE = QString("file");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_CONTACT_LIST = QString("contactlist");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_ROOM_LIST = QString("roomlist");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_STREAM_TUBE = QString("streamtube");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_TUBES = QString("tubes");
const QString
ClientHandlerPrivate::CHANNEL_TYPE_UNKNOWN = QString("unknown");


ClientHandlerPrivate::ClientHandlerPrivate( const QString &clientName,
                                            const Tp::ChannelClassSpecList &filters,
                                            const Tp::AbstractClientHandler::Capabilities capabilities,
                                            ClientHandler *parent ) :
    QObject( parent ),
    Tp::AbstractClientHandler( filters, capabilities, false ),
    mClientName( clientName ),
    mInitialized( false ),
    mParent( parent )
{
    FUNC_IN
    // set instance pointer
    mInstance = this;
    mAccountManager = Tp::AccountManager::create();
    connect( mAccountManager->becomeReady(ACCOUNT_MANAGER_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onAccountManagerReady(Tp::PendingOperation *)) );
    FUNC_OUT
}

ClientHandlerPrivate::~ClientHandlerPrivate()
{
    FUNC_IN
    if( !mRegistrar.isNull() )
    {
        Tp::AbstractClientPtr ptr = Tp::AbstractClientPtr::dynamicCast(
                                    Tp::SharedPtr<ClientHandlerPrivate>(this) );
        // we need this hack because else when
        // ptr is deleted, the object itself gets deleted
        ptr->ref();

        mRegistrar->unregisterClient( ptr );
    }
    FUNC_OUT
}

void
ClientHandlerPrivate::onAccountManagerReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();

        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), ClientHandler::NotificationTypeError );

        FUNC_OUT
        return;
    }

    mAccounts = mAccountManager->onlineAccounts();

    mRegistrar = Tp::ClientRegistrar::create( mAccountManager );
    Tp::AbstractClientPtr ptr = Tp::AbstractClientPtr::dynamicCast(
                                Tp::SharedPtr<ClientHandlerPrivate>(this) );
    // we need this hack because else when
    // ptr is deleted, the object itself gets deleted
    ptr->ref();

    mRegistrar->registerClient( ptr, mClientName );
    mInitialized = true;
    emit initialized();
    FUNC_OUT
}

void
ClientHandlerPrivate::onChannelRequestFailed( const QString &errorName, const QString &errorMessage )
{
    FUNC_IN
    qWarning() << __PRETTY_FUNCTION__ << errorName + ": " + errorMessage;
    FUNC_OUT
}

void
ClientHandlerPrivate::onChannelRequestSucceeded()
{
    FUNC_IN
    FUNC_OUT
}

void
ClientHandlerPrivate::onContextClosed( const QString &channelId )
{
    FUNC_IN
    // model needs to direct connect to this signal to implement
    // the rowsAboutToBeRemoved thing
    emit channelClosed( channelId );
    emit channelToBeRemoved( channelId );
    FUNC_OUT
}

void
ClientHandlerPrivate::onContextInitialized( const QString &channelId, bool error )
{
    FUNC_IN
    ChannelContext *context = mContexts.value( channelId, 0 );
    if( context == 0 )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "cannot find context for channel id `" + channelId + "'";

        emit mParent->notification( "Invalid channel ID", "Cannot find context for channel ID `" + channelId + "'!", ClientHandler::NotificationTypeNotice );

        FUNC_OUT
        return;
    }

    if( error )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "context finished with errors";

        emit mParent->notification( "Channel error", "Context finished with errors!", ClientHandler::NotificationTypeWarning );

        mContexts.remove( channelId );
        context->close();
        delete context;
        FUNC_OUT
        return;
    }

    // get type of communication from first channel
    // and store it in context object
    Tp::ChannelPtr channel = context->mChannels.at(0);
    QVariantMap properties = channel->immutableProperties();
    QString type = properties.value(
            QLatin1String( TELEPATHY_INTERFACE_CHANNEL ".ChannelType" ) )
            .toString();
    if( type == QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_TEXT) )
    {
        type = ClientHandlerPrivate::CHANNEL_TYPE_TEXT;
    }
    else if( type == QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_STREAMED_MEDIA) )
    {
        type = ClientHandlerPrivate::CHANNEL_TYPE_VOIP;
        if( context->mAccount->cmName() == "ring"
            || context->mAccount->protocolName() == "tel" )
        {
            type = ClientHandlerPrivate::CHANNEL_TYPE_CELL;
        }
    }
    else if( type == QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_FILE_TRANSFER) )
    {
        type = ClientHandlerPrivate::CHANNEL_TYPE_FILE;
    }
    else if( type == QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_CONTACT_LIST) )
    {
        type = ClientHandlerPrivate::CHANNEL_TYPE_CONTACT_LIST;
    }
    else if( type == QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_ROOM_LIST) )
    {
        type = ClientHandlerPrivate::CHANNEL_TYPE_ROOM_LIST;
    }
    else if( type == QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_STREAM_TUBE) )
    {
        type = ClientHandlerPrivate::CHANNEL_TYPE_STREAM_TUBE;
    }
    else if( type == QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_TUBES) )
    {
        type = ClientHandlerPrivate::CHANNEL_TYPE_TUBES;
    }
    else
    {
        type = ClientHandlerPrivate::CHANNEL_TYPE_UNKNOWN;
    }

    context->mChannelType = type;

    connect( context, SIGNAL(changed(QString)), this, SIGNAL(channelChanged(QString)) );    
    connect( context, SIGNAL( untouchedActivitiesCountChanged() ), this, SLOT( onUntouchedActivitiesCountChanged() ) );

    emit channelOpened( channelId );

    onUntouchedActivitiesCountChanged();

    FUNC_OUT
}

void
ClientHandlerPrivate::onPendingChannelRequestChannelRequestCreated( const Tp::ChannelRequestPtr &channelRequest )
{
    FUNC_IN
    if( channelRequest.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "Channel request could not be created!";
        FUNC_OUT
        return;
    }
    connect( channelRequest.data(),
             SIGNAL(failed(QString, QString)),
             this,
             SLOT(onChannelRequestFailed(QString, QString)),
             Qt::DirectConnection );
    connect( channelRequest.data(),
             SIGNAL(succeeded()),
             this,
             SLOT(onChannelRequestSucceeded()),
             Qt::DirectConnection );
    mRequests.append( channelRequest );
    FUNC_OUT
}

void
ClientHandlerPrivate::onUntouchedActivitiesCountChanged()
{
    FUNC_IN

    QHashIterator<QString, ChannelContext *> i( mContexts );

    int untouchedActivities = 0;
    int unreadChannels = 0;
    ChannelContext* context;

    while( i.hasNext() )
    {
        i.next();
        context = i.value();
        untouchedActivities += context->untouchedActivityCount();        
        if( context->untouchedActivityCount() > 0 )
            unreadChannels += 1;
    }
    emit untouchedActivitiesChanged( untouchedActivities );    
    emit unreadChannelsChanged( unreadChannels );

    FUNC_OUT
}

bool
ClientHandlerPrivate::bypassApproval() const
{
    FUNC_IN
    FUNC_OUT
    return false;
}

ChannelContext *
ClientHandlerPrivate::channelContext( const QString &channelId ) const
{
    FUNC_IN
    if( channelId.isEmpty() )
    {
        qWarning() << __PRETTY_FUNCTION__
                 << "no channel id given";
        FUNC_OUT
        return 0;
    }
    if( !mContexts.contains( channelId ) )
    {
        qWarning() << __PRETTY_FUNCTION__
                 << "channel id `"
                 << channelId
                 << "' not found in list";

        FUNC_OUT
        return 0;
    }

    ChannelContext *context = mContexts.value( channelId );
    if( context->mUntouched )
    {
        context->mUntouched = false;
        emit (const_cast<ClientHandlerPrivate *>(this))->channelChanged( channelId );
    }

    FUNC_OUT
    return context;
}

void
ClientHandlerPrivate::handleChannels( const Tp::MethodInvocationContextPtr<> &context,
                                      const Tp::AccountPtr &account,
                                      const Tp::ConnectionPtr &connection,
                                      const QList<Tp::ChannelPtr> &channels,
                                      const QList<Tp::ChannelRequestPtr> &requestsSatisfied,
                                      const QDateTime &userActionTime,
                                      const HandlerInfo &handlerInfo )
{
    FUNC_IN
    Q_UNUSED( requestsSatisfied );
    Q_UNUSED( handlerInfo );

    if( account.isNull() )
    {
        context->setFinishedWithError( "missing account",
                                 "arguments do not contain a related account" );

        qWarning() << __PRETTY_FUNCTION__
                   << "arguments do not contain a related account";

        emit mParent->notification( "Account missing!", "arguments do not contain a related account", ClientHandler::NotificationTypeDebug );

        FUNC_OUT
        return;
    }

    if( connection.isNull() )
    {
        context->setFinishedWithError( "missing connection",
                              "arguments do not contain a related connection" );

        qWarning() << __PRETTY_FUNCTION__
                   << "arguments do not contain a related connection";

        emit mParent->notification( "Connection missing", "arguments do not contain a related connection", ClientHandler::NotificationTypeDebug );

        FUNC_OUT
        return;
    }

    if( channels.count() <= 0 )
    {
        context->setFinishedWithError( "missing channels",
                           "arguments do not contain any channels to handle" );

        qWarning() << __PRETTY_FUNCTION__
                   << "argumenhts do not contain any channels to handle";

        emit mParent->notification( "Channel missing", "arguments do not contain any channels to handle", ClientHandler::NotificationTypeDebug );

        FUNC_OUT
        return;
    }

    if( mContexts.contains(channels.first()->objectPath()) )
    {
        ChannelContext *channelContext = mContexts.value( channels.first()->objectPath() );
        // channel is already handled
        // we have to bring it to the front
        emit mParent->focusOn( channelContext->mChannelId,
                               channelContext->mChannelType,
                               channelContext->mAccount->objectPath() + ContactListModelInterface::SEPARATOR + channelContext->mContact->id() );
        context->setFinished();
        FUNC_OUT
        return;
    }

    ChannelContext *channelContext = new ChannelContext();
    connect( channelContext,
             SIGNAL(initialized(QString,bool)),
             this,
             SLOT(onContextInitialized(QString,bool)) );
    connect( channelContext,
             SIGNAL(closed(QString)),
             this,
             SLOT(onContextClosed(QString)) );
    connect( channelContext,
             SIGNAL(notification(QString, QString, NotificationTypes)),
             mParent.data(),
             SIGNAL(notification(QString, QString, NotificationTypes)) );

    channelContext->mAccount = account;
    channelContext->mConnection = connection;
    channelContext->mChannels = channels;
    channelContext->mUserActionTime = userActionTime;
    // set some additional meta-data
    channelContext->setFirstUntouchedActivityTime( userActionTime );
    channelContext->setLatestActionTime( userActionTime );
    channelContext->mUntouchedActivityCount = 0;
    channelContext->mUntouched = true;

    channelContext->initialize( channels.first()->objectPath() );

    mContexts.insert( channelContext->mChannelId, channelContext );

    context->setFinished();
    FUNC_OUT
}

ClientHandlerPrivate *
ClientHandlerPrivate::instance()
{
    FUNC_IN
    FUNC_OUT
    return mInstance;
}

QString
ClientHandlerPrivate::clientName()
{
    FUNC_IN
    if( mInstance.isNull() )
    {
        FUNC_OUT
        return QString();
    }
    FUNC_OUT
    return mInstance->mClientName;
}


/* *****************************************************************************
 * ClientHandler
 * ****************************************************************************/

const QString ClientHandler::CAPABILITY_FILE_TRANSFER = QString( "file" );
const QString ClientHandler::CAPABILITY_TEXT_CHAT = QString( "text" );
const QString ClientHandler::CAPABILITY_VIDEO_CALL = QString( "video" );
const QString ClientHandler::CAPABILITY_VOIP_CALL = QString( "voip" );

void
ClientHandler::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames;

    rolenames.insert( ChannelIdRole, "channelId" );
    rolenames.insert( TypeRole, "type" );
    rolenames.insert( StateRole, "state" );
    rolenames.insert( RequestedRole, "requested" );
    rolenames.insert( DurationRole, "duration" );
    rolenames.insert( ServiceNameRole, "serviceName" );

    rolenames.insert( ContactIdRole, "contactId" );
    rolenames.insert( DisplayNameRole, "displayName" );
    rolenames.insert( AvatarUriRole, "avatarUri" );
    rolenames.insert( PresenceStateRole, "presenceState" );

    rolenames.insert( UntouchedRole, "untouched" );
    rolenames.insert( FirstUntouchedActivityTimeRole, "firstUntouchedActivityTime" );
    rolenames.insert( UntouchedActivityCountRole, "untouchedActivityCount" );
    rolenames.insert( LatestActionTimeRole, "latestActionTime" );

    rolenames.insert( VariantDataRole, "variantData" );
    setRoleNames( rolenames );
    FUNC_OUT
}

ClientHandler::ClientHandler( QObject *parent ) :
    QAbstractItemModel( parent ),
    d( 0 ),
    mClientName( "Peregrine" ),
    mUntouchedActivitiesCount( 0 ),
    mUnreadChannelsCount( 0 )
{
    Peregrine::initialize();
    initRoleNames();
    mCapabilities << QString("text");

    d = ClientHandlerPrivate::instance();
    if( d )
    {
        connect( d,
                 SIGNAL(channelClosed(QString)),
                 this,
                 SLOT(onChannelClosed(QString)),
                 Qt::DirectConnection );
        connect( d,
                 SIGNAL(channelOpened(QString)),
                 this,
                 SLOT(onChannelOpened(QString)) );
        connect( d,
                 SIGNAL(channelToBeRemoved(QString)),
                 this,
                 SLOT(onChannelToBeRemoved(QString)),
                 Qt::DirectConnection );
        connect( d,
                 SIGNAL(channelRequestsFocus(QString)),
                 this,
                 SLOT(onChannelRequestsFocus(QString)) );
        connect( d,
                 SIGNAL(initialized()),
                 this,
                 SIGNAL(initialized()) );

        if( d->mParent != this )
        {
            connect( d->mParent.data(),
                     SIGNAL(notification(QString,NotificationTypes)),
                     this,
                     SIGNAL(notification(QString,NotificationTypes)) );
            mCapabilities = d->mParent->mCapabilities;
            mChannelList = d->mParent->mChannelList;
            mClientName = d->mParent->mClientName;

            // TODO: we need a mechanism to find a new parent whenever d->mParent gets deleted
        }
    }
}

void
ClientHandler::addCapability( const QString &capability )
{
    FUNC_IN
    if( d )
    {
        FUNC_OUT
        return;
    }

    if( capability == CAPABILITY_FILE_TRANSFER
        && !mCapabilities.contains(CAPABILITY_FILE_TRANSFER) )
    {
        mCapabilities.append( CAPABILITY_FILE_TRANSFER );
        emit capabilitiesChanged( mCapabilities );
        FUNC_OUT
        return;
    }
    if( capability == CAPABILITY_TEXT_CHAT
        && !mCapabilities.contains(CAPABILITY_TEXT_CHAT) )
    {
        mCapabilities.append( CAPABILITY_TEXT_CHAT );
        emit capabilitiesChanged( mCapabilities );
        FUNC_OUT
        return;
    }
    if( capability == CAPABILITY_VIDEO_CALL
        && !mCapabilities.contains(CAPABILITY_VIDEO_CALL) )
    {
        mCapabilities.append( CAPABILITY_VIDEO_CALL );
        emit capabilitiesChanged( mCapabilities );
        FUNC_OUT
        return;
    }
    if( capability == CAPABILITY_VOIP_CALL
        && !mCapabilities.contains(CAPABILITY_VOIP_CALL) )
    {
        mCapabilities.append( CAPABILITY_VOIP_CALL );
        emit capabilitiesChanged( mCapabilities );
        FUNC_OUT
        return;
    }
    FUNC_OUT
}

QStringList
ClientHandler::capabilities() const
{
    FUNC_IN
    FUNC_OUT
    return mCapabilities;
}

QString
ClientHandler::clientName() const
{
    FUNC_IN
    if( !d )
    {
        FUNC_OUT
        return mClientName;
    }
    FUNC_OUT
    return d->mClientName;
}

int
ClientHandler::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    Q_UNUSED( parent );
    FUNC_OUT
    return ColumnCount;
}

QVariant
ClientHandler::data( const QModelIndex &index, int role ) const
{
    FUNC_IN
    if( !index.isValid() )
    {
        FUNC_OUT
        return QVariant();
    }

    int row = index.row();
    QString channelId = mChannelList.at( row );
    ChannelContext *context = d->mContexts.value( channelId );

    switch( role )
    {
    case ChannelIdRole:
        FUNC_OUT
        return channelId;
    case TypeRole:
        FUNC_OUT
        return context->mChannelType;
    case StateRole:
        FUNC_OUT
        return context->mChannelState;
    case RequestedRole:
        FUNC_OUT
        return context->mChannelRequested;
    case DurationRole:
        FUNC_OUT
        return context->mDuration;
    case ServiceNameRole:
        FUNC_OUT
        return context->mServiceName;

    case ContactIdRole:
        if( context->mAccount.isNull()
            || context->mContact.isNull() )
        {
            FUNC_OUT
            return QString();
        }
        FUNC_OUT
        return context->mAccount->objectPath() + ContactListModelInterface::SEPARATOR + context->mContact->id();
    case DisplayNameRole:
        if( context->mContact.isNull() )
        {
            FUNC_OUT
            return QString();
        }
        FUNC_OUT
        return context->mContact->alias();
    case AvatarUriRole:
        if( context->mContact.isNull() )
        {
            FUNC_OUT
            return PRESENCE_STATE_NAMES.at( PresenceStateUnknown );
        }
        FUNC_OUT
        return context->mContact->avatarData().fileName;
    case PresenceStateRole:
        if( context->mContact.isNull() )
        {
            FUNC_OUT
            return QString();
        } else
        {
            int type = context->mContact->presence().type();
            if( type >= PresenceStateCount || type < 0 )
            {
                type = PresenceStateUnknown;
            }

            FUNC_OUT
            return PRESENCE_STATE_NAMES.at( type );
        }

    case UntouchedRole:
        FUNC_OUT
        return context->mUntouched;
    case FirstUntouchedActivityTimeRole:
        FUNC_OUT
        return context->mFirstUntouchedActivityTime;
    case UntouchedActivityCountRole:
        FUNC_OUT
        return context->mUntouchedActivityCount;
    case LatestActionTimeRole:
        FUNC_OUT
        return context->mLatestActionTime;

    case VariantDataRole:
        FUNC_OUT
        return context->mVariantData;
    case RowRole:
        FUNC_OUT
        return row;
    }

    FUNC_OUT
    return QVariant();
}

QModelIndex
ClientHandler::index( int row, int column, const QModelIndex &parent ) const
{
    FUNC_IN
    if( parent.isValid()
        || column < 0
        || column >= ColumnCount
        || row < 0
        || row >= mChannelList.count() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    QString channelId = mChannelList.at( row );
    QModelIndex idx = createIndex( row, column, d->mContexts.value(channelId) );
    FUNC_OUT
    return idx;
}

QModelIndex
ClientHandler::parent( const QModelIndex &child ) const
{
    FUNC_IN
    Q_UNUSED( child );
    FUNC_OUT
    return QModelIndex();
}

void
ClientHandler::removeCapability( const QString &capability )
{
    FUNC_IN
    if( d )
    {
        FUNC_OUT
        return;
    }

    mCapabilities.removeAll( capability );
    emit capabilitiesChanged( mCapabilities );
    FUNC_OUT
}

int
ClientHandler::rowCount( const QModelIndex &parent ) const
{
    FUNC_IN
    Q_UNUSED( parent );
    FUNC_OUT
    return mChannelList.count();
}

void
ClientHandler::setCapabilities( const QStringList &capabilities )
{
    FUNC_IN
    if( d )
    {
        FUNC_OUT
        return;
    }

    mCapabilities = capabilities;
    for( int i = 0; i < mCapabilities.count(); ++i )
    {
        if( mCapabilities.at(i) == CAPABILITY_FILE_TRANSFER )
            continue;
        if( mCapabilities.at(i) == CAPABILITY_TEXT_CHAT )
            continue;
        if( mCapabilities.at(i) == CAPABILITY_VIDEO_CALL )
            continue;
        if( mCapabilities.at(i) == CAPABILITY_VOIP_CALL )
            continue;
        mCapabilities.removeAt(i--);
    }
    emit capabilitiesChanged( mCapabilities );
    FUNC_OUT
}

void
ClientHandler::setClientName( const QString &name )
{
    FUNC_IN
    if( !d && !name.isEmpty() )
    {
        mClientName = name;
        emit clientNameChanged( mClientName );
    }
    FUNC_OUT
}

void
ClientHandler::onChannelChanged( const QString &channelId )
{
    FUNC_IN
    int row = mChannelList.indexOf( channelId );
    if( row >= 0
        && row < mChannelList.count() )
    {
        QModelIndex topLeft = index( row, 0 );
        QModelIndex bottomRight = index( row, ColumnCount - 1 );
        emit dataChanged( topLeft, bottomRight );
    }
    FUNC_OUT
}

void
ClientHandler::onChannelClosed( const QString &channelId )
{
    FUNC_IN
    Q_UNUSED( channelId );
    emit channelClosed( channelId );
    FUNC_OUT
}

void
ClientHandler::onChannelOpened( const QString &channelId )
{
    FUNC_IN
    if( !d || !d->mInitialized )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "client not ready initialized";
        FUNC_OUT
        return;
    }

    beginInsertRows( QModelIndex(), mChannelList.count(), mChannelList.count() );

    // insert channelId
    mChannelList.append( channelId );

    ChannelContext *context = d->mContexts.value( channelId );
    QString contactId;
    if( !context->mContact.isNull() )
    {
        contactId = context->mAccount->objectPath() + ContactListModelInterface::SEPARATOR + context->mContact->id();
    }
    QString type = context->mChannelType;

    endInsertRows();

    emit newChannel( channelId, type, contactId );

    FUNC_OUT
}

void
ClientHandler::onChannelToBeRemoved( const QString &channelId )
{
    FUNC_IN
    int row = mChannelList.indexOf( channelId );
    if( row >= 0
        && row < mChannelList.count() )
    {
        beginRemoveRows(QModelIndex(), row, row);
        mChannelList.removeAt( row );
        endRemoveRows();
    }
    d->mContexts.remove( channelId );
    FUNC_OUT
}

void
ClientHandler::onChannelRequestsFocus( const QString &channelId )
{
    FUNC_IN
    Q_UNUSED( channelId );
    ChannelContext *context = d->mContexts.value(channelId );
    if( context )
    {
        QString contactId;
        if( !context->mContact.isNull() )
        {
            contactId = context->mAccount->objectPath() + ContactListModelInterface::SEPARATOR + context->mContact->id();
        }
        QString type = context->mChannelType;
        emit focusOn( channelId, type, contactId );
    }
    FUNC_OUT
}

void
ClientHandler::closeChannel( const QString &channelId )
{
    FUNC_IN
    if( d )
    {
        ChannelContext *context = d->mContexts.value( channelId );
        if( context )
        {
            context->close();
        }
    }
    FUNC_OUT
}

void
ClientHandler::onUntouchedActivitiesCountChanged( int count )
{
    FUNC_IN
    mUntouchedActivitiesCount = count;
    emit untouchedActivitiesChanged( mUntouchedActivitiesCount );
    FUNC_OUT
}

int
ClientHandler::untouchedActivities()
{
    FUNC_IN
    FUNC_OUT
    return mUntouchedActivitiesCount;
}

void
ClientHandler::onUnreadChannelsCountChanged( int count )
{
    FUNC_IN
    mUnreadChannelsCount = count;
    emit unreadChannelsChanged( mUnreadChannelsCount );
    FUNC_OUT
}

int
ClientHandler::unreadChannels()
{
    FUNC_IN
    FUNC_OUT
    return mUnreadChannelsCount;
}

void
ClientHandler::openTextChat( const QString &contactId )
{
    FUNC_IN
    if( !d || !d->mInitialized )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "client not initialized";

        emit notification( "Client not initialized!", "The client needs to be named and initialized to open and handle channels!", NotificationTypeError );

        FUNC_OUT
        return;
    }

    if( contactId.isEmpty() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "`contactId' must not be empty";

        emit notification( "Contact ID not set", "Contact ID must not be empty!", NotificationTypeError );

        FUNC_OUT
        return;
    }

    QStringList parts = contactId.split( ContactListModelInterface::SEPARATOR, QString::SkipEmptyParts );
    if( parts.size() != 2 )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "invalid contactId";

        emit notification( "Invalid contact ID", "Invalid contact ID `" + contactId + "'!", NotificationTypeError );

        FUNC_OUT
        return;
    }

    QString accountPath = parts.at( 0 );
    QString contactIdentifier = parts.at( 1 );

    // check for existing channel
    foreach( ChannelContext *context, d->mContexts.values() )
    {
        if( context->mAccount->objectPath() != accountPath )
        {
            continue;
        }

        if( contactIdentifier != context->mContact->id() )
        {
            continue;
        }
        if( ClientHandlerPrivate::CHANNEL_TYPE_TEXT == context->mChannels.at(0)->immutableProperties().value
                ( QLatin1String( TELEPATHY_INTERFACE_CHANNEL ".ChannelType" ) )
                .toString() )
        {
            emit focusOn( context->mChannelId,
                          ClientHandlerPrivate::CHANNEL_TYPE_TEXT,
                          contactIdentifier );
            FUNC_OUT
            return;
        }
    }

    // request to create channel
    QList<Tp::AccountPtr> accounts = d->mAccounts->accounts();
    foreach( Tp::AccountPtr account, accounts )
    {
        if( account->objectPath() == accountPath )
        {
            account->ensureTextChat( contactIdentifier,
                                     QDateTime::currentDateTime(),
                                     TP_QT4_IFACE_CLIENT + "." + d->mClientName );
            FUNC_OUT
            return;
        }
    }
    qWarning() << __PRETTY_FUNCTION__
               << "no online account for path `" + accountPath + "'";

    emit notification( "Not online", "No or not online account for path `" + accountPath + "'!", NotificationTypeWarning );

    FUNC_OUT
}

void
ClientHandler::openVoipCall( const QString &contactId )
{
    FUNC_IN
    if( !d || !d->mInitialized )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "client not initialized";

        emit notification( "Client not initialized!", "The client needs to be named and initialized to open and handle channels!", NotificationTypeError );

        FUNC_OUT
        return;
    }

    if( contactId.isEmpty() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "`contactId' must not be empty";

        emit notification( "Contact ID not set", "Contact ID must not be empty!", NotificationTypeError );

        FUNC_OUT
        return;
    }

    QStringList parts = contactId.split( ContactListModelInterface::SEPARATOR, QString::SkipEmptyParts );
    if( parts.size() != 2 )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "invalid contactId";

        emit notification( "Invalid contact ID", "Invalid contact ID `" + contactId + "'!", NotificationTypeError );

        FUNC_OUT
        return;
    }

    QString accountPath = parts.at( 0 );
    QString contactIdentifier = parts.at( 1 );

    // check for existing channel
    foreach( ChannelContext *context, d->mContexts.values() )
    {
        if( context->mAccount->objectPath() != accountPath )
        {
            continue;
        }

        if( contactIdentifier != context->mContact->id() )
        {
            continue;
        }
        if( ClientHandlerPrivate::CHANNEL_TYPE_TEXT == context->mChannels.at(0)->immutableProperties().value
                ( QLatin1String( TELEPATHY_INTERFACE_CHANNEL ".ChannelType" ) )
                .toString() )
        {
            emit focusOn( context->mChannelId,
                          ClientHandlerPrivate::CHANNEL_TYPE_TEXT,
                          contactIdentifier );
            FUNC_OUT
            return;
        }
    }

    // request to create channel
    QList<Tp::AccountPtr> accounts = d->mAccounts->accounts();
    foreach( Tp::AccountPtr account, accounts )
    {
        if( account->objectPath() == accountPath )
        {
            Tp::PendingChannelRequest *request = account->ensureStreamedMediaCall( contactIdentifier,
                                                                                        QDateTime::currentDateTime(),
                                                                                        TP_QT4_IFACE_CLIENT + "." + d->mClientName );
            connect( request,
                     SIGNAL(channelRequestCreated(Tp::ChannelRequestPtr)),
                     d,
                     SLOT(onPendingChannelRequestChannelRequestCreated(Tp::ChannelRequestPtr)) );
            FUNC_OUT
            return;
        }
    }
    qWarning() << __PRETTY_FUNCTION__
               << "no online account for path `" + accountPath + "'";

    emit notification( "Not online", "No or not online account for path `" + accountPath + "'!", NotificationTypeWarning );

    FUNC_OUT
}

bool
ClientHandler::initialize( const QString &clientName )
{
    FUNC_IN
    if( d )
    { // already initialized
        qWarning() << __PRETTY_FUNCTION__
                   << "ClientHandler already initialized";

        emit notification( "Already initialized", "Client already initialized. Name and capabilities cannot be changed after first initialization!", NotificationTypeNotice );

        FUNC_OUT
        return false;
    }
    QString name = clientName;
    if( name.isEmpty() )
    { // use local stored name
        name = mClientName;
    }

    QStringList capabilities;
    Tp::ChannelClassList filters;

    if( mCapabilities.contains(QString("text")) )
    {
        // append filter for text channels
        QMap<QString, QDBusVariant> filter;
        filter.insert( QLatin1String( TELEPATHY_INTERFACE_CHANNEL ".ChannelType" ),
                       QDBusVariant( QLatin1String( TELEPATHY_INTERFACE_CHANNEL_TYPE_TEXT ) ) );
        filter.insert( QLatin1String( TELEPATHY_INTERFACE_CHANNEL ".TargetHandleType" ),
                       QDBusVariant( (uint) Tp::HandleTypeContact ) );
        filters.append( filter );
    }

    if( mCapabilities.contains(QString("voip"))
        || mCapabilities.contains(QString("video"))
        || mCapabilities.contains(QString("media")) )
    {
        // append filter for audio
        {
            QMap<QString, QDBusVariant> filter;
            filter.insert( QLatin1String( TELEPATHY_INTERFACE_CHANNEL ".ChannelType" ),
                           QDBusVariant( QLatin1String( TELEPATHY_INTERFACE_CHANNEL_TYPE_STREAMED_MEDIA ) ) );
            filter.insert( QLatin1String( TELEPATHY_INTERFACE_CHANNEL ".TargetHandleType" ),
                           QDBusVariant( (uint) Tp::HandleTypeContact ) );
            filters.append( filter );
        }

        {
            QMap<QString, QDBusVariant> filter;
            filter.insert(
                    QLatin1String(TELEPATHY_INTERFACE_CHANNEL ".ChannelType"),
                    QDBusVariant(TELEPATHY_INTERFACE_CHANNEL_TYPE_STREAMED_MEDIA) );
            filter.insert(
                    QLatin1String(TELEPATHY_INTERFACE_CHANNEL ".TargetHandleType"),
                    QDBusVariant((uint) Tp::HandleTypeContact) );
            filter.insert(
                    QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_STREAMED_MEDIA ".InitialAudio"),
                    QDBusVariant(true) );
            filters.append( filter );
        }

        if( mCapabilities.contains(QString("video"))
            || mCapabilities.contains(QString("media")) )
        {
            // append filter for video
            {
                QMap<QString, QDBusVariant> filter;
                filter.insert(
                        QLatin1String(TELEPATHY_INTERFACE_CHANNEL ".ChannelType"),
                        QDBusVariant(TELEPATHY_INTERFACE_CHANNEL_TYPE_STREAMED_MEDIA) );
                filter.insert(
                        QLatin1String(TELEPATHY_INTERFACE_CHANNEL ".TargetHandleType"),
                        QDBusVariant((uint) Tp::HandleTypeContact) );
                filter.insert(
                        QLatin1String(TELEPATHY_INTERFACE_CHANNEL_TYPE_STREAMED_MEDIA ".InitialVideo"),
                        QDBusVariant(true) );
                filters.append( filter );
            }
        }

        // append capabilities for audio / video
        capabilities << QLatin1String(TELEPATHY_INTERFACE_CHANNEL_INTERFACE_MEDIA_SIGNALLING "/ice-udp")
                << QLatin1String(TELEPATHY_INTERFACE_CHANNEL_INTERFACE_MEDIA_SIGNALLING "/gtalk-p2p")
                << QLatin1String(TELEPATHY_INTERFACE_CHANNEL_INTERFACE_MEDIA_SIGNALLING "/audio/speex")
                << QLatin1String(TELEPATHY_INTERFACE_CHANNEL_INTERFACE_MEDIA_SIGNALLING "/audio/vorbis")
                << QLatin1String(TELEPATHY_INTERFACE_CHANNEL_INTERFACE_MEDIA_SIGNALLING "/audio/PCMA")
                << QLatin1String(TELEPATHY_INTERFACE_CHANNEL_INTERFACE_MEDIA_SIGNALLING "/wlm-8.5");
    }

    // this call will create an instance of ClientHandlerPrivate singleton
    d = new ClientHandlerPrivate( name, filters, capabilities, this );
    if( !d )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "unable to initialize ClientHandler";

        emit notification( "Client initialization failed!", "Unable to initialize Client! Unknown error occurred", NotificationTypeError );

        FUNC_OUT
        return false;
    }

    connect( d,
             SIGNAL(channelClosed(QString)),
             this,
             SLOT(onChannelClosed(QString)),
             Qt::DirectConnection );
    connect( d,
             SIGNAL(channelOpened(QString)),
             this,
             SLOT(onChannelOpened(QString)) );
    connect( d,
             SIGNAL(channelChanged(QString)),
             this,
             SLOT(onChannelChanged(QString)) );
    connect( d,
             SIGNAL(channelToBeRemoved(QString)),
             this,
             SLOT(onChannelToBeRemoved(QString)),
             Qt::DirectConnection );
    connect( d,
             SIGNAL(channelRequestsFocus(QString)),
             this,
             SLOT(onChannelRequestsFocus(QString)) );
    connect( d,
             SIGNAL(initialized()),
             this,
             SIGNAL(initialized()) );    
    connect( d,
             SIGNAL( untouchedActivitiesChanged( int ) ),
             this,
             SLOT( onUntouchedActivitiesCountChanged( int ) ) );
    connect( d,
             SIGNAL( unreadChannelsChanged( int ) ),
             this,
             SLOT( onUnreadChannelsCountChanged(int) ) );

    FUNC_OUT
    return true;
}
