/*
 * Very basic Tp-Qt <-> Tp-Farsight integration.
 *
 * Copyright © 2008-2009 Collabora Ltd. <http://www.collabora.co.uk/>
 * Copyright © 2009-2011 Nokia Corporation
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef _TelepathyQt4_examples_call_farsight_channel_h_HEADER_GUARD_
#define _TelepathyQt4_examples_call_farsight_channel_h_HEADER_GUARD_

#include "../peregrinetypes.h"

#include <QObject>
#include <QMetaType>

#undef signals
#include <telepathy-farsight/channel.h>
#define signals protected
#include <TelepathyQt4/Types>

#ifndef VIDEO_STREAMS
#define VIDEO_STREAMS 1
#endif
#define WITH_PREVIEW
#define PREVIEW_MYSINK_SILENT
#define OUTPUT_MYSINK_SILENT
//#define OUTPUT_FAKESINK_DUMP
//#define PREVIEW_FAKESINK_DUMP
#define WITH_TESTSOURCE

namespace Peregrine 
{
    class Connection;

    /*!
     * This class handles farsight channels and manages the required GStreamer pipelines.
     */
    class FarsightChannel : public QObject
    {
        Q_OBJECT
        Q_ENUMS(Status)

        public:
            /**
             * enum to describe state of channel
             */
            enum Status {
                StatusDisconnected = 0,
                StatusConnecting = 1,
                StatusConnected = 2
            };

            /**
             * constructor of FarsightChannel.
             * @param channel a Tp::StreamedMediaChannel to create a Farsight channel for
             */
            FarsightChannel(const Tp::StreamedMediaChannelPtr &channel, QObject *parent = 0);
            virtual ~FarsightChannel();

            /**
             * get the current channel state
             */
            Status status() const;

//          TODO add a way to change input and output devices

        public slots:
            /**
             * not implemented
             */
#if VIDEO_STREAMS >0
            void startVideoSrc();
#endif

            /**
             * dump current GStreamer pipeline into a dot file
             * dumping the pipeline does only work if GStreamer is compiled using the debuggin flags.
             */
            void dumpPipeline();

        Q_SIGNALS:
            void notification( const QString &title, const QString &message, NotificationTypes type );
            /**
             * signal is emitted whenever the channel state changes. values are of type Status
             */
            void statusChanged(int status);
#if VIDEO_STREAMS >0
            /**
             *
             */
            void startVideoNow();
#endif

        private:
            struct Private;
            friend struct Private;
            Private *mPriv;
    };
} // Tp
Q_DECLARE_METATYPE(Peregrine::FarsightChannel::Status)
#endif
