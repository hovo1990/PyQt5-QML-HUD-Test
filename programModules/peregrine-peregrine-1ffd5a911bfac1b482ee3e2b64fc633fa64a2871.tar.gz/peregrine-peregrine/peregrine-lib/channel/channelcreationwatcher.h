/*
 * channelcreationwatcher.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CHANNELCREATIONWATCHER_H
#define CHANNELCREATIONWATCHER_H

#include <QDateTime>
#include <QList>
#include <QObject>
#include <QPointer>
#include <QString>

namespace Peregrine
{

class ClientHandler;

class ChannelCreationWatcher
        : public QObject
{
    Q_OBJECT

    typedef struct Triplet_
    {
        QString contactId;
        QDateTime timestamp;
        QString type;
    } Triplet;

    QList< Triplet > mChannelRequestInfo;
    QPointer<ClientHandler> mClientHandler;
    int mTimeOut;

    static const int DEFAULT_TIME_OUT;

    void removeWatch( const QString &contactId, const QString &type );

private slots:
    void onClientHandlerFocusOn( const QString &channelId, const QString &type, const QString &contactId );
    void onClientHandlerNewChannel( const QString &channelId, const QString &type, const QString &contactId );
    void removeWatch();

public:
    Q_PROPERTY( int timeOut READ timeOut WRITE setTimeOut NOTIFY timeOutChanged );

    explicit ChannelCreationWatcher( QObject *parent = 0 );

    Q_INVOKABLE bool addWatch( const QString &contactId, const QString &type );
    void setTimeOut( int timeOut );
    int timeOut() const;
signals:
    void channelRequestTimedOut( const QString &contactId, const QString &type );
    void timeOutChanged( int timeOut );

};

}

#endif // CHANNELCREATIONWATCHER_H
