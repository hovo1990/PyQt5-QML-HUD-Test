/*
 * clientapprover.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CLIENTAPPROVER_H
#define CLIENTAPPROVER_H

#include "../peregrinetypes.h"

#include <QAbstractItemModel>
#include <QModelIndex>
#include <QPointer>
#include <QString>
#include <QStringList>
#include <QVariant>

namespace Peregrine
{

class ClientApproverPrivate;

class ClientApprover
    : public QAbstractItemModel
{
    Q_OBJECT

    friend class ClientApproverPrivate;

    QPointer<ClientApproverPrivate> d;
    QStringList mCapabilities;
    QString mClientName;
    QString mPreferredClientHandlerName;

    void initRoleNames();

public:
    Q_ENUMS( AcceptanceStates );
    Q_ENUMS( Columns );
    Q_ENUMS( ChannelTypes );
    Q_ENUMS( Roles );
    Q_PROPERTY( QStringList capabilities READ capabilities WRITE setCapabilities NOTIFY capabilitiesChanged );
    Q_PROPERTY( int columnCount READ columnCount NOTIFY columnCountChanged );
    Q_PROPERTY( QString name READ clientName WRITE setClientName NOTIFY clientNameChanged );
    Q_PROPERTY( QString preferredHandler READ preferredHandler WRITE setPreferredHandler NOTIFY preferredHandlerChanged );
    Q_PROPERTY( int rowCount READ rowCount NOTIFY rowCountChanged );

    static const QString CHANNEL_TYPE_TEXT;
    static const QString CHANNEL_TYPE_MEDIA;
    static const QString CHANNEL_TYPE_CELL;
    static const QString CHANNEL_TYPE_FILE;
    static const QString CHANNEL_TYPE_CONTACT_LIST;
    static const QString CHANNEL_TYPE_ROOM_LIST;
    static const QString CHANNEL_TYPE_STREAM_TUBE;
    static const QString CHANNEL_TYPE_TUBES;
    static const QString CHANNEL_TYPE_UNKNOWN;

    /**
     * enumeration used to accept or reject a pending channel
     */
    enum AcceptanceStates
    {
        AcceptanceStateReject,
        AcceptanceStateAccept,
        AcceptanceStatePending
    };
    /**
     * enumeration of defined column types
     */
    enum Columns
    {
        ColumnChannel,
        ColumnCount
    };
    /**
     * enum to indicate type of channel
     */
    enum ChannelTypes {
        ChannelTypeText,
        ChannelTypeMedia,
        ChannelTypeFile,
        ChannelTypeContactList,
        ChannelTypeRoomList,
        ChannelTypeStreamTube,
        ChannelTypeTubes,
        ChannelTypeUnknown
    };
    /**
     * enumeration of all defined custom roles
     */
    enum Roles
    {
        IdRole = Qt::UserRole + 1,
        TypeRole,
        ContactIdRole,
        AcceptanceRole,
        VariantDataRole,
        ServiceNameRole,
        ServiceIconRole,
        RoleCount
    };

    static const QString CAPABILITY_FILE_TRANSFER;
    static const QString CAPABILITY_TEXT_CHAT;
    static const QString CAPABILITY_VIDEO_CALL;
    static const QString CAPABILITY_VOIP_CALL;

    explicit ClientApprover( QObject *parent = 0 );

    void addCapability( const QString &capability );
    QStringList capabilities() const;
    QString clientName() const;
    int columnCount( const QModelIndex &parent = QModelIndex() ) const;
    Q_INVOKABLE QVariant data( const QModelIndex &index, int role = Qt::DisplayRole ) const;
    Q_INVOKABLE Qt::ItemFlags flags( const QModelIndex &index ) const;
    Q_INVOKABLE QModelIndex index( int row, int column, const QModelIndex &parent = QModelIndex() ) const;
    Q_INVOKABLE QModelIndex parent( const QModelIndex &child ) const;
    QString preferredHandler() const;
    void removeCapability( const QString &capability );
    int rowCount( const QModelIndex &parent = QModelIndex() ) const;
    void setCapabilities( const QStringList &capabilities );
    void setClientName( const QString &name );
    Q_INVOKABLE bool setData( const QModelIndex &index, const QVariant &value, int role = AcceptanceRole );
    Q_INVOKABLE bool setData( int row, const QVariant &value, int role = AcceptanceRole );
    void setPreferredHandler( const QString &handlerName );

signals:
    void capabilitiesChanged( const QStringList &capabilities );
    void clientNameChanged( const QString &name );
    void columnCountChanged();
    void initialized();
    void incomingChannel( const QString &dispatchId,
                          const QString &type,
                          const QString &contactId );
    void incomingMediaCall( const QString &dispatchId,
                            const QString &contactId );
    void incomingTextChat( const QString &dispatchId,
                           const QString &contactId );
    void incomingFileTransfer( const QString &dispatchId,
                               const QString &contactId );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( QString message, NotificationTypes type );
    void preferredHandlerChanged( const QString &handlerName );
    void rowCountChanged();

public slots:
    /**
     * accept channel so that a client handles the named channel
     * @param channelId channel id of channel that was accepted by user
     */
    void accept( const QString &dispatchId );
    /**
     * initialize client with given name
     * this slot has to be called before using this class
     * capabilities can be set using @see setCapability
     */
    bool initialize( const QString &clientName = QString() );
    /**
     * reject and close channel
     * @param channelId channel id of channel that was rejected by user
     */
    void reject( const QString &dispatchId );

};

}

#endif // CLIENTAPPROVER_H
