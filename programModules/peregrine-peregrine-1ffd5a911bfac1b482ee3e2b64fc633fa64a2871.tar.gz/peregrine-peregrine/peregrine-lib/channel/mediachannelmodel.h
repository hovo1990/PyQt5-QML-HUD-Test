/*
 * mediachannelmodel.h
 *
 * Copyright (C) 2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef MEDIACHANNELMODEL_H
#define MEDIACHANNELMODEL_H

#include "../peregrinetypes.h"

#include <QObject>
#include <QPointer>
#include <QString>

namespace Peregrine
{

class MediaChannelModelPrivate;

class MediaChannelModel
    : public QObject
{
    Q_OBJECT

    friend class MediaChannelModelPrivate;

    QPointer<MediaChannelModelPrivate> d;
    QString mChannelId;

public:
    Q_PROPERTY( QString channelId READ channelId WRITE setChannelId );
    Q_PROPERTY( QString duration READ duration NOTIFY durationChanged );
    Q_PROPERTY( bool holdState READ holdState WRITE setHoldState NOTIFY holdStateChanged );
    Q_PROPERTY( bool isConnected READ isConnected NOTIFY isConnectedChanged );
    Q_PROPERTY( bool muteState READ muteState WRITE setMuteState NOTIFY muteStateChanged );
    Q_PROPERTY( QString serviceName READ serviceName NOTIFY serviceNameChanged );
    Q_PROPERTY( QString targetId READ targetId NOTIFY targetIdChanged );
    Q_PROPERTY( QString targetName READ targetName NOTIFY targetNameChanged );
    Q_PROPERTY( QString targetPresence READ targetPresence NOTIFY targetPresenceChanged );

    explicit MediaChannelModel( QObject *parent = 0 );
    ~MediaChannelModel();

    /**
     * return the channel id. this function will return an empty string
     * if channel id wasn't set yet
     */
    QString channelId() const;
    /**
     * duration of the call since connection was established
     * the duration is formated as: mm:ss
     * \sa durationChanged()
     */
    QString duration() const;
    /**
     * returns current state of channel
     * @return true if call is on hold
     */
    bool holdState() const;
    /**
     * returns true if channel is connected (call is ongoing)
     */
    bool isConnected() const;
    /**
     * @return true if all audio streams are muted
     */
    bool muteState() const;
    /**
     * get name of service
     */
    QString serviceName() const;
    /**
     * get id of target contact
     */
    QString targetId() const;
    /**
     * get name of target contact
     */
    QString targetName() const;
    /**
     * get presence state of target contact
     */
    QString targetPresence() const;

signals:
    void channelClosed();
    void durationChanged( const QString &duration );
    void holdStateChanged( bool state );
    void isConnectedChanged( bool connected );
    void muteStateChanged( bool mute );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );
    void serviceNameChanged( const QString &serviceName );
    void targetIdChanged( const QString &id );
    void targetNameChanged( const QString &name );
    void targetPresenceChanged( const QString &presence );

public slots:
    /**
     * terminate / hang up the call
     */
    void closeChannel();
    /**
     * set the channel id
     * use this function to set the channel id that you received from
     * the ActiveChannelModel. This will initialize the MediaChannel
     * object and will handle the StreamedMediaChannel
     * @param channelId channel id you received from ActiveChannelModel
     */
    void setChannelId( const QString &channelId );
    /**
     * set channel to hold state
     * if state is true no data will be sent or played until it is
     * toggled to false
     * @param state true if you want to hold the call false if you
     * want to resume a call
     */
    void setHoldState( bool state );
    void setMuteState( bool mute );
    /**
     * toggle the hold state between true (hold) and false (play)
     */
    void toggleHold();

};

}

#endif // MEDIACHANNELMODEL_H
