/*
 * textchannelmodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef TEXTCHANNELMODEL_P_H
#define TEXTCHANNELMODEL_P_H

#include <QDateTime>
#include <QList>
#include <QMap>
#include <QObject>
#include <QSet>
#include <QString>
#include <QStringList>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/Connection>
#include <TelepathyQt4/Contact>
#include <TelepathyQt4/Feature>
#include <TelepathyQt4/Features>
#include <TelepathyQt4/Message>
#include <TelepathyQt4/ReceivedMessage>
#include <TelepathyQt4/SharedPtr>
#include <TelepathyQt4/TextChannel>

namespace Peregrine
{

class ChannelContext;
class TextChannelModel;

class TextChannelModelPrivate
    : public QObject
{
    Q_OBJECT

    friend class TextChannelModel;

    static const Tp::Features ACCOUNT_FEATURES;
    static const Tp::Features CONNECTION_FEATURES;
    static const Tp::Features CONTACT_FEATURES;
    static const Tp::Features TEXT_CHANNEL_FEATURES;

    /**
     * list of all messages
     */
    QList<Tp::Message *> mMessageList;
    /**
     * set of pointers pointing to unread messages
     */
    QSet<Tp::Message *> mUnread;
    /**
     * list of contact pointer defining who sent corresponding message
     */
    QList<Tp::ContactPtr> mSenderList;
    /**
     * list of timestamps defining when a corresponding message was sent
     */
    QList<QDateTime> mDateTimeList;
    /**
     * list of boolean, indicating if this is a message from the subsystem
     */
    QList<bool> mSystemMessageList;

    /**
     *
     */
    QString mChannelId;
    QList<Tp::ChannelPtr> mChannels;
    Tp::TextChannelPtr mTextChannel;
    Tp::AccountPtr mAccount;
    Tp::ConnectionPtr mConnection;
    Tp::ContactPtr mTargetContact;
    QList<Tp::ContactPtr> mContacts;
    QPointer<ChannelContext> mContext;

    QPointer<TextChannelModel> mParent;
    QString mServiceName;

    TextChannelModelPrivate( TextChannelModel *parent );

    bool connectAccount( Tp::AccountPtr account );
    bool connectConnection( Tp::ConnectionPtr connection );
    bool connectContact( Tp::ContactPtr contact );
    bool connectTextChannel( Tp::TextChannelPtr channel );
    bool disconnectAccount( Tp::AccountPtr account );
    bool disconnectConnection( Tp::ConnectionPtr connection );
    bool disconnectContact( Tp::ContactPtr contact );
    bool disconnectTextChannel( Tp::TextChannelPtr channel );
    /**
     * insert message to the internal storage
     * this function should be used to insert a message to the internal storage.
     * it is called whenever a message is sent or received or
     * the chatstate changed
     */
    int insertMessage( const Tp::Message &message,
                       const QDateTime &timestamp = QDateTime(),
                       Tp::ContactPtr sender = Tp::ContactPtr(0),
                       bool systemMessage = false );
    void setFirstUnreadMessage() const;
    void upgradeContact( Tp::ContactPtr contact );

private slots:
    void onAccountReady( Tp::PendingOperation *operation );
    void onConnectionReady( Tp::PendingOperation *operation );
    void onContactPresenceChanged( const Tp::Presence &presence );
    void onContactsUpgraded( Tp::PendingOperation *operation );
    void onPendingContactsReady( Tp::PendingOperation *operation );
    void onPendingSendMessageFinished( Tp::PendingOperation *operation );
    void onTextChannelInvalidated( Tp::DBusProxy *proxy,
                                   const QString &errorName,
                                   const QString &errorMessage );
    void onTextChannelMessageSent( const Tp::Message &message,
                                   Tp::MessageSendingFlags flags,
                                   const QString &sentMessageToken );
    void onTextChannelMessageReceived( const Tp::ReceivedMessage &message );
    void onTextChannelPendingMessageRemoved( const Tp::ReceivedMessage &message );
    void onTextChannelReady( Tp::PendingOperation *operation );
};

}

#endif // TEXTCHANNELMODEL_P_H
