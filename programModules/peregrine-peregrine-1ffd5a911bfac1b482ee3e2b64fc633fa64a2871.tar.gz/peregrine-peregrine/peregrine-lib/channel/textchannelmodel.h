/*
 * textchannelmodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef TEXTCHANNELMODEL_H
#define TEXTCHANNELMODEL_H

#include <QAbstractItemModel>
#include <QList>
#include <QModelIndex>
#include <QPixmap>
#include <QPointer>
#include <QString>
#include <QStringList>
#include <QVariant>

#include <TelepathyQt4/Feature>
#include <TelepathyQt4/Types>
#include <TelepathyQt4/Message>
#include <TelepathyQt4/ConnectionInterfaceAvatarsInterface>

namespace Peregrine
{

// we need this typedef because of an issue in
// Tp::TextChannel::onChatStateChanged signal declaration
// typedef Tp::ChannelChatState ChannelChatState;

class TextChannelModelPrivate;

/*!
 * This class handles and presents a text channel in form of a model.
 */
class TextChannelModel
    : public QAbstractItemModel
{
    Q_OBJECT

    friend class TextChannelModelPrivate;

    QPointer<TextChannelModelPrivate> d;

    void initRoleNames();

public:
    Q_ENUMS( Columns );
    Q_ENUMS( MessageDirections );
    Q_ENUMS( MessageTypes );
    Q_ENUMS( NotificationTypes );
    Q_ENUMS( Roles );
    /**
     * property to set telepathy channel to work on
     */
    Q_PROPERTY( QString channelId READ channelId WRITE setChannelId );
    /**
     * r/o property to get name of used service
     */
    Q_PROPERTY( QString serviceName READ serviceName NOTIFY serviceNameChanged );
    /**
     * r/o property to get the id of target contact
     */
    Q_PROPERTY( QString targetId READ targetId NOTIFY targetIdChanged );
    /**
     * r/o property to get the name of target contact
     */
    Q_PROPERTY( QString targetName READ targetName NOTIFY targetNameChanged );
    /**
     * r/o property to get the presence state of target contact
     */
    Q_PROPERTY( QString targetPresence READ targetPresence NOTIFY targetPresenceChanged );
    /**
     * property shows if there are some unread messages
     * setting this property results in marking all messages as read or unread
     */
    Q_PROPERTY( bool unreadMessages READ unreadMessages NOTIFY unreadMessagesChanged );
    /**
     * enum for convenient access to the columns
     */
    enum Columns
    {
        ColumnMessage,
        ColumnCount
    };
    /**
     * enum to indicate direction of message
     */
    enum MessageDirections
    {
        MessageDirectionIncoming,
        MessageDirectionOutgoing
    };
    /**
     * enum to indicate type of message
     */
    enum MessageTypes
    {
        MessageTypeNormal,
        MessageTypeAction,
        MessageTypeNotice,
        MessageTypeAutoReply,
        MessageTypeDeliveryReport
    };
    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };
    /**
     * enum for convenient access to the roles
     */
    enum Roles
    {
        //Qt::DisplayRole has the message
        TimestampRole = Qt::UserRole + 1,
        MessageTypeRole,
        DirectionRole,
        NameRole,
        SystemMessageRole,
        UnreadRole,
        RoleCount
    };


    static const QStringList MESSAGE_TYPE_NAMES;


    explicit TextChannelModel( QObject *parent = 0 );
    ~TextChannelModel();

    QString channelId() const;
    /**
     * @see Qt::QAbstractItemModel::columnCount()
     */
    int columnCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractItemModel::data()
     */
    QVariant data( const QModelIndex &index, int role = Qt::DisplayRole ) const;
    /**
     * @see Qt::QAbstractItemModel::flags()
     */
    Qt::ItemFlags flags( const QModelIndex &index ) const;
    /**
     * @see Qt::QAbstractItemModel::index()
     */
    QModelIndex index( int row, int column, const QModelIndex &parent = QModelIndex() ) const;
    /**
     * mark all messages as read or unread
     * the default is to mark the messages as read
     * @param unread if unread is false, all messages become marked as read
     */
    Q_INVOKABLE void markMessagesAs( bool unread = false );
    /**
     * @see Qt::QAbstractItemModel::parent()
     */
    QModelIndex parent( const QModelIndex &child ) const;
    /**
     * @see Qt::QAbstractItemModel::rowCount()
     */
    int rowCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * returns name of used service
     */
    QString serviceName() const;
    /**
     * @see Qt::QAbstractItemModel::setData()
     */
    void setChannelId( const QString &channelId );
    bool setData( const QModelIndex &index,
                  const QVariant &value,
                  int role = Qt::EditRole );

    QString targetId() const;
    QString targetName() const;
    QString targetPresence() const;

    /**
     * indikates if there are unread messages
     * @return true if there is at least one unread message
     */
    bool unreadMessages() const;

signals:
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );
    /**
     * signal is emitted whenever there are new unread messages
     */
    void unreadMessagesChanged( bool unread );
    /**
     * emitted when account becomes ready and we can get the service name
     */
    void serviceNameChanged( const QString &serviceName );
    /**
     *
     */
    void targetIdChanged( const QString &id );
    /**
     * signal is emitted whenever target contacts name changed
     * it takes a while to get the alias of the target contact. at first there
     * is only the contact id available but TextChannelModel will emit this
     * signal when alias is available
     */
    void targetNameChanged( const QString &name );
    /**
     * signal is emitted whenever target contacts presence state changed
     */
    void targetPresenceChanged( const QString &presence );

public slots:
    /**
     * close the text channel. the TextChannelModel is not usable after a call
     * to this slot
     */
    void closeChannel();
    /**
     * slot to send a message through the channel to target contact
     * @param message text message that should be send to target
     */
    void send( const QString &message );

};

} // namespace Peregrine
#endif // TEXTCHANNELMODEL_H
