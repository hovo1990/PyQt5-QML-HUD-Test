/*
 * clienthandler.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CLIENTHANDLER_H
#define CLIENTHANDLER_H

#include <QAbstractItemModel>
#include <QObject>
#include <QString>
#include <QStringList>

namespace Peregrine
{

class ClientHandlerPrivate;

class ClientHandler
    : public QAbstractItemModel
{
    Q_OBJECT

    friend class ClientHandlerPrivate;

    ClientHandlerPrivate *d;
    QStringList mCapabilities;
    /**
     * This list holds a list of channelIds that will be exposed to the UI
     */
    QStringList mChannelList;

    QString mClientName;

    int mUntouchedActivitiesCount;
    int mUnreadChannelsCount;

    void initRoleNames();

private slots:
    void onChannelChanged( const QString &channelId );
    void onChannelClosed( const QString &channelId );
    void onChannelOpened( const QString &channelId );
    void onChannelRequestsFocus( const QString &channelId );
    void onChannelToBeRemoved( const QString &channelId );
    void onUntouchedActivitiesCountChanged( int count );
    void onUnreadChannelsCountChanged( int count );

public:
    Q_ENUMS( Columns );
    Q_ENUMS( ChannelTypes );
    Q_ENUMS( NotificationTypes );
    Q_ENUMS( Roles );
    Q_PROPERTY( QStringList capabilities READ capabilities WRITE setCapabilities NOTIFY capabilitiesChanged );
    Q_PROPERTY( QString name READ clientName WRITE setClientName NOTIFY clientNameChanged );
    Q_PROPERTY( int untouchedActivities READ untouchedActivities NOTIFY untouchedActivitiesChanged ); // read-only
    Q_PROPERTY( int unreadChannels READ unreadChannels NOTIFY unreadChannelsChanged ); // read-only

    /**
     * enumeration of defined column types
     */
    enum Columns
    {
        ColumnChannel,
        ColumnCount
    };
    /**
     * enum to indicate type of channel
     */
    enum ChannelTypes {
        ChannelTypeText,
        ChannelTypeMedia,
        ChannelTypeFile,
        ChannelTypeContactList,
        ChannelTypeRoomList,
        ChannelTypeStreamTube,
        ChannelTypeTubes,
        ChannelTypeUnknown
    };
    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };
    /**
     * enumeration of all defined custom roles
     */
    enum Roles
    {
        ChannelIdRole = Qt::UserRole + 1,
        TypeRole,
        StateRole,
        RequestedRole,
        DurationRole,
        ServiceNameRole,

        ContactIdRole,
        DisplayNameRole,
        AvatarUriRole,
        PresenceStateRole,

        UntouchedRole,
        FirstUntouchedActivityTimeRole,
        UntouchedActivityCountRole,
        LatestActionTimeRole,

        VariantDataRole,
        RowRole,
        RoleCount
    };

    static const QString CAPABILITY_FILE_TRANSFER;
    static const QString CAPABILITY_TEXT_CHAT;
    static const QString CAPABILITY_VIDEO_CALL;
    static const QString CAPABILITY_VOIP_CALL;

    explicit ClientHandler( QObject *parent = 0 );

    void addCapability( const QString &capability );
    QStringList capabilities() const;
    QString clientName() const;
    int columnCount( const QModelIndex &parent = QModelIndex() ) const;
    Q_INVOKABLE QVariant data( const QModelIndex &index, int role = Qt::DisplayRole ) const;
    Q_INVOKABLE QModelIndex index( int row, int column, const QModelIndex &parent = QModelIndex() ) const;
    Q_INVOKABLE QModelIndex parent( const QModelIndex &child ) const;
    void removeCapability( const QString &capability );
    int rowCount( const QModelIndex &parent = QModelIndex() ) const;
    void setCapabilities( const QStringList &capabilities );
    void setClientName( const QString &name );
    int untouchedActivities();
    int unreadChannels();

signals:
    void capabilitiesChanged( const QStringList &capabilities );
    void channelClosed( const QString &channelId );
    void clientNameChanged( const QString &name );
    void untouchedActivitiesChanged( int count );
    void unreadChannelsChanged( int count );
    void initialized();
    void focusOn( const QString &channelId,
                  const QString &type,
                  const QString &contactId );
    void newChannel( const QString &channelId,
                     const QString &type,
                     const QString &contactId );
    void newTextChat( const QString &channelId,
                      const QString &contactId );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );

public slots:
    /**
     * close the named channel
     */
    void closeChannel( const QString &channelId );
    /**
     * open a new text channel
     * @param contactId a contact ID as returned by ContactListAggregatorModel or MetaContactListModel
     */
    void openTextChat( const QString &contactId );
    /**
     * open a new streamed media channel with initial audio stream
     * @param contactId a contact ID as returned by ContactListAggregatorModel or MetaContactListModel
     */
    void openVoipCall( const QString &contactId );
    /**
     * initialize client with given name
     * this slot has to be called before using this class
     * capabilities can be set using @see setCapability
     */
    bool initialize( const QString &clientName = QString() );

};

}

#endif // CLIENTHANDLER_H
