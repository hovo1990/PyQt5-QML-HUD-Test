/*
 * clientapprover_p.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CLIENTAPPROVER_P_H
#define CLIENTAPPROVER_P_H

#include <QList>
#include <QObject>
#include <QPointer>
#include <QString>

#include <TelepathyQt4/AbstractClientApprover>
#include <TelepathyQt4/ChannelDispatchOperation>
#include <TelepathyQt4/ClientRegistrar>
#include <TelepathyQt4/MethodInvocationContext>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/SharedPtr>

namespace Peregrine
{

class ClientApprover;

class DispatchOperationContext
    : public QObject
{
    Q_OBJECT

    static const Tp::Features CHANNEL_DISPATCH_OPERATION_FEATURES;

    Tp::ChannelDispatchOperationPtr mDispatchOperation;
    int mFinishedChannels;

private slots:
    void onAccountReady( Tp::PendingOperation *operation );
    void onChannelReady( Tp::PendingOperation *operation );
    void onConnectionReady( Tp::PendingOperation *operation );
    void onDispatchOperationInvalidated( Tp::DBusProxy *proxy, const QString &errorName, const QString &errorMessage );
    void onDispatchOperationReady( Tp::PendingOperation *operation );

public:
    explicit DispatchOperationContext( const Tp::ChannelDispatchOperationPtr &dispatchOperation,
                                       QObject *parent = 0 );

    QString contactId() const;
    Tp::ChannelDispatchOperationPtr dispatchOperation() const;
    QString id() const;
    QString type() const;
    QString variantData() const;

signals:
    void removed();
    void initialized();
};

class ClientApproverPrivate
    : public QObject
    , public Tp::AbstractClientApprover
{
    Q_OBJECT

    friend class ClientApprover;

    QString mClientName;
    QList< QPointer<DispatchOperationContext> > mDispatchOperations;
    QPointer<ClientApprover> mParent;
    Tp::ClientRegistrarPtr mRegistrar;

    explicit ClientApproverPrivate( const QString clientName, const Tp::ChannelClassSpecList &filters, ClientApprover *parent );

private slots:
    /**
     * The DispatchOperation and all assoziated objects
     * are ready to use. We insert this context into our
     * model so the user can accept / reject it
     */
    void onDispatchOperationContextInitialized();
    /**
     * something happened to the DispatchOperation
     * so that we can delete the context
     */
    void onDispatchOperationContextRemoved();
    /**
     * This slot is used to delete an entry
     * in case the user uses the setData method
     * to accept / reject a channel
     * We don't want to delete the model entry directly!
     */
    void onDispatchOperationFinished( Tp::PendingOperation *operation );

public:
    ~ClientApproverPrivate();
    /**
     * See documentation of AbstractClientApprover
     * @see Tp::AbstractClientApprover::addDispatchOperation()
     */
    void addDispatchOperation( const Tp::MethodInvocationContextPtr<> &context,
                               const Tp::ChannelDispatchOperationPtr &dispatchOperation );

};

}

#endif // CLIENTAPPROVER_P_H
