/*
* textchannelmodel.cpp
*
* Copyright (C) 2009-2011 basysKom GmbH
* Copyright (C) 2009-2011 Nokia Corporation
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "textchannelmodel.h"
#include "textchannelmodel_p.h"
#include "clienthandler_p.h"
#include "../presencestates.h"
#include "../peregrineDebugHelper.h"
#include "../peregrineinitializer.h"
#include "../peregrineservicenames.h"
#include "../contact/contactlistmodelinterface.h"

#include <TelepathyQt4/PendingContacts>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/PendingReady>
#include <TelepathyQt4/TextChannel>
#include <TelepathyQt4/ContactManager>

using namespace Peregrine;

/* *****************************************************************************
 * TextChannelModelPrivate
 * ****************************************************************************/

const Tp::Features
TextChannelModelPrivate::ACCOUNT_FEATURES = ( Tp::Features()
                                      << Tp::Account::FeatureCore
                                      << Tp::Account::FeatureAvatar );

const Tp::Features
TextChannelModelPrivate::CONNECTION_FEATURES = ( Tp::Features()
                                                 << Tp::Connection::FeatureCore
                                                 << Tp::Connection::FeatureSelfContact
                                                 << Tp::Connection::FeatureSimplePresence );

const Tp::Features
TextChannelModelPrivate::TEXT_CHANNEL_FEATURES = ( Tp::Features()
                                                   << Tp::TextChannel::FeatureCore
                                                   << Tp::TextChannel::FeatureChatState
                                                   << Tp::TextChannel::FeatureMessageCapabilities
                                                   << Tp::TextChannel::FeatureMessageQueue
                                                   << Tp::TextChannel::FeatureMessageSentSignal );
const Tp::Features
TextChannelModelPrivate::CONTACT_FEATURES = ( Tp::Features()
                                              << Tp::Contact::FeatureAlias
                                              << Tp::Contact::FeatureAvatarToken
                                              << Tp::Contact::FeatureSimplePresence );

TextChannelModelPrivate::TextChannelModelPrivate( TextChannelModel *parent )
    : QObject( parent ),
    mParent( parent )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    FUNC_OUT
}

bool
TextChannelModelPrivate::connectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    FUNC_OUT
    return result;
}

bool
TextChannelModelPrivate::connectConnection( Tp::ConnectionPtr connection )
{
    FUNC_IN
    if( connection.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    FUNC_OUT
    return result;
}

bool
TextChannelModelPrivate::connectContact( Tp::ContactPtr contact )
{
    FUNC_IN
    if( contact.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( contact.data(),
                       SIGNAL(presenceChanged(Tp::Presence)),
                       this,
                       SLOT(onContactPresenceChanged(Tp::Presence)) );

    FUNC_OUT
    return result;
}

bool
TextChannelModelPrivate::connectTextChannel( Tp::TextChannelPtr channel )
{
    FUNC_IN
    if( channel.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( channel.data(),
                       SIGNAL(invalidated(Tp::DBusProxy *, QString, QString)),
                       this,
                       SLOT(onTextChannelInvalidated(Tp::DBusProxy *, QString, QString)) );
    result &= connect( channel.data(),
                       SIGNAL(messageSent(Tp::Message, Tp::MessageSendingFlags, QString)),
                       this,
                       SLOT(onTextChannelMessageSent(Tp::Message, Tp::MessageSendingFlags, QString)) );
    result &= connect( channel.data(),
                       SIGNAL(messageReceived(Tp::ReceivedMessage)),
                       this,
                       SLOT(onTextChannelMessageReceived(Tp::ReceivedMessage)) );
    result &= connect( channel.data(),
                       SIGNAL(pendingMessageRemoved(Tp::ReceivedMessage)),
                       this,
                       SLOT(onTextChannelPendingMessageRemoved(Tp::ReceivedMessage)) );

    FUNC_OUT
    return result;
}

bool
TextChannelModelPrivate::disconnectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( account.data(), 0, this, 0 );
}

bool
TextChannelModelPrivate::disconnectConnection( Tp::ConnectionPtr connection )
{
    FUNC_IN
    if( connection.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( connection.data(), 0, this, 0 );
}

bool
TextChannelModelPrivate::disconnectContact( Tp::ContactPtr contact )
{
    FUNC_IN
    if( contact.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( contact.data(), 0, this, 0 );
}

bool
TextChannelModelPrivate::disconnectTextChannel( Tp::TextChannelPtr channel )
{
    FUNC_IN
    if( channel.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( channel.data(), 0, this, 0 );
}

int
TextChannelModelPrivate::insertMessage( const Tp::Message &message,
                                        const QDateTime &timestamp,
                                        Tp::ContactPtr sender,
                                        bool systemMessage )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    // insert message
    int row = mMessageList.count();

    mParent->beginInsertRows( QModelIndex(), row, row );

    // do we realy need to create a copy?
    Tp::Message *localMessage = new Tp::Message( message );

    mMessageList.append( localMessage );
    mSenderList.append( sender );
    mDateTimeList.append( timestamp );
    mSystemMessageList.append( systemMessage );

    // mark message as unread
    if( !sender.isNull() )
        mUnread.insert( localMessage );

    if( !mContext.isNull() )
    {
        mContext->setLatestActionTime( timestamp );
        setFirstUnreadMessage();
        mContext->setUntouchedActivityCount( mUnread.count() );
    }

    emit mParent->unreadMessagesChanged( true );

    mParent->endInsertRows();

    FUNC_OUT
    return row;
}

void
TextChannelModelPrivate::setFirstUnreadMessage() const
{
    FUNC_IN
    int first = mMessageList.count() - 1;
    foreach( Tp::Message *msg, mUnread )
    {
        int i = mMessageList.indexOf( msg );
        if( i < first && i >= 0 )
        {
            first = i;
        }
    }
    if( first > 0 )
    {
        mContext->setFirstUntouchedActivityTime( mDateTimeList.at(first) );
        mContext->setVariantData( mMessageList.at(first)->text() );
    } else if( mMessageList.count() > 0 )
    {
        mContext->setFirstUntouchedActivityTime( mDateTimeList.at(mDateTimeList.count() - 1) );
        mContext->setVariantData( mMessageList.at(mMessageList.count() - 1)->text() );
    }
    FUNC_OUT
}

void
TextChannelModelPrivate::upgradeContact( Tp::ContactPtr contact )
{
    FUNC_IN
    Q_ASSERT( !mConnection.isNull() );

    Tp::ContactManagerPtr contactManager = mConnection->contactManager();

    if( contactManager.isNull() )
    {
        FUNC_OUT
        return;
    }

    // setting features
    Tp::Features contactFeatures = CONTACT_FEATURES;

    Tp::Features requested = contact->requestedFeatures();
    foreach( Tp::Feature feature, requested )
    {
        contactFeatures.remove( feature );
    }

    if( contactFeatures.size() <= 0 )
    {
        FUNC_OUT
        return;
    }

    connect( contactManager->upgradeContacts(
                     QList<Tp::ContactPtr>() << contact, contactFeatures ),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onContactsUpgraded(Tp::PendingOperation *)) );
    FUNC_OUT
}

/* ***
 * private slots
 */

void
TextChannelModelPrivate::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), TextChannelModel::NotificationTypeError );
        FUNC_OUT
        return;
    }
    mServiceName = serviceNameForAccount( mAccount );
    emit mParent->serviceNameChanged( mServiceName );
    FUNC_OUT
}

void
TextChannelModelPrivate::onConnectionReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), TextChannelModel::NotificationTypeError );
        FUNC_OUT
        return;
    }

    FUNC_OUT
}

void
TextChannelModelPrivate::onContactPresenceChanged( const Tp::Presence &presence )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    Q_UNUSED( presence );
    if( sender() == mTargetContact.data() )
    {
        emit mParent->targetPresenceChanged( mParent->targetPresence() );
    }
    FUNC_OUT
}

void
TextChannelModelPrivate::onContactsUpgraded( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), TextChannelModel::NotificationTypeWarning );
        FUNC_OUT
        return;
    }

    Tp::PendingContacts *pc = qobject_cast<Tp::PendingContacts *>( operation );

    Q_ASSERT( !mConnection.isNull() );
    Tp::ContactManagerPtr contactManger = mConnection->contactManager();

    foreach( Tp::ContactPtr contact, pc->contacts() )
    {
        if( contact.isNull() )
        {
            continue;
        }

        if( contact->handle().first() == mTextChannel->targetHandle()
            && mTextChannel->targetHandleType() == Tp::HandleTypeContact )
        {
            emit mParent->targetIdChanged( mParent->targetId() );
            emit mParent->targetNameChanged( mParent->targetName() );
            emit mParent->targetPresenceChanged( mParent->targetPresence() );
        }

        connectContact( contact );
        mContacts.append( contact );

        if( !contactManger.isNull()
            && !contact->isAvatarTokenKnown() )
        {
            contactManger->requestContactAvatar( contact.data() );
        }
    }
    FUNC_OUT
}

void
TextChannelModelPrivate::onPendingContactsReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), TextChannelModel::NotificationTypeWarning );
        FUNC_OUT
        return;
    }

    Tp::PendingContacts *pc = qobject_cast<Tp::PendingContacts *>( operation );

    if( !pc )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "cannot cast to pending contacts pointer";
        FUNC_OUT
        return;
    }

    Q_ASSERT( !mConnection.isNull() );
    Tp::ContactManagerPtr contactManger = mConnection->contactManager();

    QList<Tp::ContactPtr> contactList = pc->contacts();
    foreach( Tp::ContactPtr contact, contactList )
    {
        if( contact.isNull() )
        {
            continue;
        }

        if( contact->handle().first() == mTextChannel->targetHandle()
            && mTextChannel->targetHandleType() == Tp::HandleTypeContact )
        {
            mTargetContact = contact;
            emit mParent->targetIdChanged( mParent->targetId() );
            emit mParent->targetNameChanged( mParent->targetName() );
            emit mParent->targetPresenceChanged( mParent->targetPresence() );
        }

        connectContact( contact );
        mContacts.append( contact );

        if( !contactManger.isNull()
            && !contact->isAvatarTokenKnown() )
        {
            contactManger->requestContactAvatar( contact.data() );
        }
    }
    FUNC_OUT
}

void
TextChannelModelPrivate::onPendingSendMessageFinished( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), TextChannelModel::NotificationTypeWarning );
        FUNC_OUT
        return;
    }
    FUNC_OUT
}

void
TextChannelModelPrivate::onTextChannelInvalidated( Tp::DBusProxy *proxy,
                                                   const QString &errorName,
                                                   const QString &errorMessage )
{
    FUNC_IN
    qWarning() << __PRETTY_FUNCTION__
               << errorName
               << ": "
               << errorMessage;
    emit mParent->notification( errorName.split(".").last(), errorMessage, TextChannelModel::NotificationTypeDebug );
    mParent->setChannelId( QString() );
    qWarning() << __PRETTY_FUNCTION__
               << QString("Channel: 0x%1  Proxy: 0x%2")
                  .arg((int)mTextChannel.data(), 0, 16)
                  .arg((int)proxy, 0, 16);

    FUNC_OUT
}

void
TextChannelModelPrivate::onTextChannelMessageSent( const Tp::Message &message,
                                                   Tp::MessageSendingFlags flags,
                                                   const QString &sentMessageToken )
{
    FUNC_IN
    Q_UNUSED( flags );
    Q_UNUSED( sentMessageToken );
    insertMessage( message, message.sent() );
    FUNC_OUT
}

void
TextChannelModelPrivate::onTextChannelMessageReceived( const Tp::ReceivedMessage &message )
{
    FUNC_IN
    QDateTime timestamp = message.sent();
    if( message.sent() == QDateTime() )
    { // if sent time is not set use the time we received the message
        timestamp = message.received();
    }

    Tp::ContactPtr contact = message.sender();

    insertMessage( message, timestamp, contact );

    if( !contact.isNull()
        && !mContacts.contains(contact) )
    {
        upgradeContact( contact );
    }

    mTextChannel->acknowledge( (QList<Tp::ReceivedMessage>() << message) );
    FUNC_OUT
}

void
TextChannelModelPrivate::onTextChannelPendingMessageRemoved( const Tp::ReceivedMessage &message )
{
    FUNC_IN
    Q_UNUSED( message );
    FUNC_OUT
}

void
TextChannelModelPrivate::onTextChannelReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), TextChannelModel::NotificationTypeError );
        FUNC_OUT
        return;
    }

    Tp::TextChannelPtr chan = Tp::TextChannelPtr::staticCast(operation->object());

    Q_ASSERT( chan == mTextChannel );

    if( mTextChannel->targetHandleType() == Tp::HandleTypeContact )
    {
        Q_ASSERT( !mConnection.isNull() );

        Tp::ContactManagerPtr contactManager = mConnection->contactManager();

        Q_ASSERT( !contactManager.isNull() );

        uint handle = mTextChannel->targetHandle();
        connect( contactManager->contactsForHandles(Tp::UIntList() << handle,
                                                    CONTACT_FEATURES),
                 SIGNAL(finished(Tp::PendingOperation *)),
                 this,
                 SLOT(onPendingContactsReady(Tp::PendingOperation *)) );
    }

    // get all pending messages
    QList<Tp::ReceivedMessage> messageList = mTextChannel->messageQueue();
    for( int i = 0; i < messageList.size(); ++i )
    {
        onTextChannelMessageReceived( messageList.at(i) );
    }
    FUNC_OUT
}


/* *****************************************************************************
 * TextChannelModel
 * ****************************************************************************/

const QStringList
TextChannelModel::MESSAGE_TYPE_NAMES = ( QStringList()
                                                << "normal"
                                                << "action"
                                                << "notice"
                                                << "autoreply"
                                                << "deliveryreport" );

void
TextChannelModel::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames;
    rolenames.insert( Qt::DisplayRole, "message" );
    rolenames.insert( TimestampRole, "timestamp" );
    rolenames.insert( MessageTypeRole, "messageType" );
    rolenames.insert( DirectionRole, "direction" );
    rolenames.insert( NameRole, "name" );
    rolenames.insert( SystemMessageRole, "systemMessage" );
    setRoleNames( rolenames );
    FUNC_OUT
}

TextChannelModel::TextChannelModel( QObject *parent )
    : QAbstractItemModel( parent )
{
    FUNC_IN
    Peregrine::initialize();
    initRoleNames();
    d = new TextChannelModelPrivate( this );
    FUNC_OUT
}

TextChannelModel::~TextChannelModel()
{
    FUNC_IN
    if( !d.isNull() )
    {
        if( !d->mTextChannel.isNull() )
        {
            d->mTextChannel->requestClose();
        }

        for( int i = 0; i < d->mMessageList.count(); ++i )
        {
            delete d->mMessageList.at( i );
        }
    }
    // delete members
    FUNC_OUT
}

QString
TextChannelModel::channelId() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    FUNC_OUT
    return d->mChannelId;
}

int
TextChannelModel::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( d.isNull()
        || parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return ColumnCount;
}

QVariant
TextChannelModel::data( const QModelIndex &index, int role ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !index.isValid() )
    {
        FUNC_OUT
        return QVariant();
    }

    int row = index.row();
    switch( role )
    {
    case Qt::DisplayRole:
        FUNC_OUT
        return QVariant( d->mMessageList.at(row)->text() );

    case TimestampRole:
        FUNC_OUT
        return QVariant( d->mDateTimeList.at(row) );

    case MessageTypeRole:
        FUNC_OUT
        return MESSAGE_TYPE_NAMES.at( d->mMessageList.at(row)->messageType() );

    case DirectionRole:
        if( d->mSenderList.at(row).data() )
        {
            FUNC_OUT
            return QVariant( TextChannelModel::MessageDirectionIncoming );
        }
        else
        {
            FUNC_OUT
            return QVariant( TextChannelModel::MessageDirectionOutgoing );
        }

    case NameRole:
        if( d->mSenderList.at(row).data() )
        {
            FUNC_OUT
            return QVariant( d->mSenderList.at(row)->alias() );
        }
        else
        {
            // this is needed because there is no contact in list if
            // the message is sent by the local user
            if( d->mAccount.isNull() )
            {
                FUNC_OUT
                return QString( "me" );
            } else
            {
                QString name = d->mAccount->displayName();
                if( !name.isEmpty() )
                {
                    FUNC_OUT
                    return name;
                }
                name = d->mAccount->nickname();
                if( !name.isEmpty() )
                {
                    FUNC_OUT
                    return name;
                }
                FUNC_OUT
                return d->mAccount->normalizedName();
            }
        }

    case SystemMessageRole:
        FUNC_OUT
        return d->mSystemMessageList.at(row);
    }

    FUNC_OUT
    return QVariant();
}

Qt::ItemFlags
TextChannelModel::flags( const QModelIndex &index ) const
{
    FUNC_IN
    FUNC_OUT
    return QAbstractItemModel::flags( index ) | Qt::ItemIsUserCheckable;
}

QModelIndex
TextChannelModel::index( int row, int column, const QModelIndex &parent ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    if( column < 0
        || column >= ColumnCount
        || row < 0
        || row >= d->mMessageList.count()
        || parent.isValid() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    FUNC_OUT
    return createIndex( row, column, d->mMessageList.at(row) );
}

void
TextChannelModel::markMessagesAs( bool unread )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    bool current = unreadMessages();

    if( unread )
    {
        d->mUnread = d->mMessageList.toSet();
        if( current )
        {
            emit unreadMessagesChanged( unread );
        }
    } else
    {
        d->mUnread.clear();
        if( !current )
        {
            emit unreadMessagesChanged( unread );
        }
    }

    d->setFirstUnreadMessage();

    if( !d->mContext.isNull() )
    {
        d->mContext->setUntouchedActivityCount( d->mUnread.count() );
    }
    FUNC_OUT
}

QModelIndex
TextChannelModel::parent( const QModelIndex &child ) const
{
    FUNC_IN
    Q_UNUSED( child );
    FUNC_OUT
    return QModelIndex();
}

int
TextChannelModel::rowCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( d.isNull()
        || parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return d->mMessageList.count();
}

QString
TextChannelModel::serviceName() const
{
    FUNC_IN
    if( d.isNull() )
    {
        FUNC_OUT
        return QString();
    }
    FUNC_OUT
    return d->mServiceName;
}

void
TextChannelModel::setChannelId( const QString &channelId )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( d->mChannelId == channelId )
    {
        // channel id already set
        FUNC_OUT
        return;
    }

    ClientHandlerPrivate *instance = ClientHandlerPrivate::instance();
    if( !instance )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "client not initialized";
        emit notification( "No client", "Client component not initialized", NotificationTypeError );
        FUNC_OUT
        return;
    }

    beginResetModel();

    {
        // clean up
        d->disconnectAccount( d->mAccount );
        d->disconnectConnection( d->mConnection );
        d->disconnectTextChannel( d->mTextChannel );

        if( d->mTextChannel )
        {
            d->mTextChannel->requestClose();
            d->mTextChannel.reset();
        }
        for( int i = 0; 1 < d->mMessageList.count(); ++i )
        {
            delete d->mMessageList.at( i );
        }

        d->mChannelId.clear();
        d->mMessageList.clear();
        d->mSenderList.clear();
        d->mDateTimeList.clear();
        d->mSystemMessageList.clear();
        d->mChannels.clear();
        d->mTextChannel.reset();
        d->mAccount.reset();
        d->mConnection.reset();
        d->mContacts.clear();
        d->mServiceName.clear();
    }

    if( channelId.isEmpty() )
    {
        endResetModel();
        FUNC_OUT
        return;
    }
    ChannelContext *context = instance->channelContext( channelId );
    if( context == 0 )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "channel not available";
        emit notification( "Invalid channel ID", "No channel for channel ID ", NotificationTypeError );
        endResetModel();
        FUNC_OUT
        return;
    }
    if( context->channels().count() <= 0 )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "channel not available";
        emit notification( "Invalid channel ID", "No channel for channel ID ", NotificationTypeError );
        endResetModel();
        FUNC_OUT
        return;
    }

    d->mChannelId = channelId;
    d->mAccount = context->account();
    d->mConnection = context->connection();
    d->mChannels = context->channels();
    d->mTextChannel = Tp::TextChannelPtr::staticCast( d->mChannels.at(0) );
    d->mContext = context;

    d->connectAccount( d->mAccount );
    connect( d->mAccount->becomeReady(TextChannelModelPrivate::ACCOUNT_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             d,
             SLOT(onAccountReady(Tp::PendingOperation *)) );
    d->connectConnection( d->mConnection );
    connect( d->mConnection->becomeReady(TextChannelModelPrivate::CONNECTION_FEATURES) ,
             SIGNAL(finished(Tp::PendingOperation *)),
             d,
             SLOT(onConnectionReady(Tp::PendingOperation *)) );
    d->connectTextChannel( d->mTextChannel );
    connect( d->mTextChannel->becomeReady(TextChannelModelPrivate::TEXT_CHANNEL_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             d,
             SLOT(onTextChannelReady(Tp::PendingOperation *)) );

    endResetModel();

    FUNC_OUT
}

bool
TextChannelModel::setData( const QModelIndex &index,
                           const QVariant &value,
                           int role )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !index.isValid() )
    {
        FUNC_OUT
        return false;
    }
    if( role != UnreadRole )
    {
        FUNC_OUT
        return false;
    }

    Tp::Message *message = d->mMessageList.at( index.row() );
    bool unread = unreadMessages();
    if( value.toBool() )
    {
        d->mUnread.insert( message );
    } else
    {
        d->mUnread.remove( message );
    }
    if( (!unread && (d->mUnread.count() > 0))
        || (unread && (d->mUnread.count() <= 0)) )
    {
        emit unreadMessagesChanged( unreadMessages() );
    }
    d->setFirstUnreadMessage();

    if( !d->mContext.isNull() )
    {
        d->mContext->setUntouchedActivityCount( d->mUnread.count() );
    }

    FUNC_OUT
    return true;
}

QString
TextChannelModel::targetId() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !d->mTargetContact.isNull() )
    {
        FUNC_OUT
        return d->mAccount->objectPath() + ContactListModelInterface::SEPARATOR + d->mTargetContact->id();
    }
    FUNC_OUT
    return QString();
}

QString
TextChannelModel::targetName() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !d->mTargetContact.isNull() )
    {
        FUNC_OUT
        return d->mTargetContact->alias();
    }
    FUNC_OUT
    return QString();
}

QString
TextChannelModel::targetPresence() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !d->mTargetContact.isNull() )
    {
        int state = d->mTargetContact->presence().type();
        if( state >= 0 && state <= PresenceStateError )
        {
            FUNC_OUT
            return PRESENCE_STATE_NAMES.at( state );
        }
    }
    FUNC_OUT
    return PRESENCE_STATE_NAMES.at( PresenceStateUnknown );
}

bool
TextChannelModel::unreadMessages() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    FUNC_OUT
    return d->mUnread.count() > 0;
}

/* ***
 * public slots
 */
void
TextChannelModel::closeChannel()
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    connect( d->mTextChannel->requestClose(),
             SIGNAL(finished(Tp::PendingOperation *)),
             d,
             SLOT(channelClosed(Tp::PendingOperation *)) );
    FUNC_OUT
}

void
TextChannelModel::send( const QString &message )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    connect( d->mTextChannel->send( message ),
             SIGNAL(finished(Tp::PendingOperation *)),
             d,
             SLOT(onPendingSendMessageFinished(Tp::PendingOperation *)) );
            ;
    FUNC_OUT
}

