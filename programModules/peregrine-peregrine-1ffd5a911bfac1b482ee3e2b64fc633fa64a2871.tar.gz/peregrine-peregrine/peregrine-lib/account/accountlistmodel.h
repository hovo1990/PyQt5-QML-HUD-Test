/*
 * accountlistmodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef ACCOUNTLISTMODEL_H
#define ACCOUNTLISTMODEL_H

#include "../peregrinetypes.h"

#include <QAbstractItemModel>
#include <QModelIndex>
#include <QObject>
#include <QPointer>
#include <QString>
#include <QStringList>
#include <QVariant>

namespace Peregrine
{

class AccountListModelPrivate;


class AccountListModel
    : public QAbstractItemModel
{
    Q_OBJECT

    friend class AccountListModelPrivate;

    QPointer<AccountListModelPrivate> d;

    void initRoleNames();

public:
    Q_ENUMS( Columns );
    Q_ENUMS( NotificationTypes );
    Q_ENUMS( Roles );

    Q_PROPERTY( bool autoConnect READ autoConnect WRITE setAutoConnect NOTIFY autoConnectChanged );
    Q_PROPERTY( bool oneAccountOnline READ oneAccountOnline NOTIFY oneAccountOnlineChanged );
    /**
     * Enum for convenient access to the columns.
     */
    enum Columns
    {
        ColumnAccount,
        ColumnPresence,
        ColumnService,
        ColumnCount
    };
    /**
     * Enum for convenient access to the roles.
     */
    enum Roles
    {
        NicknameRole = Qt::UserRole + 1,
        AccountIdRole,
        AccountUidRole,
        PresenceStateRole,
        PresenceStateMessageRole,
        AvailablePresenceStatesRole,
        ServiceNameRole,
        ProtocolNameRole,
        AccountObjectPathRole,
        RoleCount
    };

    /**
     *  Constructs an AccountListModel with the given parent.
     */
    explicit AccountListModel( QObject *parent = 0 );
    ~AccountListModel();

    /**
     * returns the number of (not offline) accounts for a service name
     * @return 0 if no account online or serviceName unknown
     */
    Q_INVOKABLE int accountCountForService( const QString &serviceName ) const;
    /**
     * convenience function to get the accounts path at row
     * @param index row to get the account path from
     */
    Q_INVOKABLE QString accountPathAtRow(int index);
    /**
     * returns a list of accountIds (accountPaths) for given service name
     */
    Q_INVOKABLE QStringList accountsForService( const QString &serviceName ) const;
    bool autoConnect() const;
    /**
     * @see Qt::QAbstractItemModel::columnCount()
     */
    Q_INVOKABLE int columnCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractItemModel::data()
     */
    Q_INVOKABLE QVariant data( const QModelIndex &index,
                               int role = Qt::DisplayRole ) const;
    Q_INVOKABLE QVariant data( int row,
                               int role = Qt::DisplayRole ) const;
    /**
     * @see Qt::QAbstractItemModel::flags()
     */
    Q_INVOKABLE Qt::ItemFlags flags( const QModelIndex &index ) const;
    /**
     * @see Qt::QAbstractItemModel::headerData()
     */
    Q_INVOKABLE QVariant headerData( int section,
                                     Qt::Orientation orientation,
                                     int role ) const;
    /**
     * @see Qt::QAbstractItemModel::index()
     */
    Q_INVOKABLE QModelIndex index( int row, int column, const QModelIndex &parent = QModelIndex() ) const;
    /**
     * returns true if there is one (or more) account online
     */
    bool oneAccountOnline() const;
    /**
     * @see Qt::QAbstractItemModel::parent()
     */
    Q_INVOKABLE QModelIndex parent( const QModelIndex &child ) const;
    /**
     * @see Qt::QAbstractItemModel::removeRows()
     */
    Q_INVOKABLE bool removeRows(int row,
                                int count,
                                const QModelIndex &parent = QModelIndex() );
    /**
     * @see Qt::QAbstractItemModel::rowCount()
     */
    Q_INVOKABLE int rowCount( const QModelIndex &parent = QModelIndex() ) const;
    Q_INVOKABLE int rowForAccountId( const QString &accountId ) const;
    /**
     * returns a list of service names the user has an account for
     */
    Q_INVOKABLE QStringList serviceList() const;
    /**
     * set property to connect accounts automatically when
     * they appear in list
     * accounts are also connected immediately when this function is called
     * with parameter \em true
     */
    void setAutoConnect( bool autoconnect );
    /**
     * @see Qt::QAbstractItemModel::setData()
     */
    Q_INVOKABLE bool setData( const QModelIndex &index,
                              const QVariant &value,
                              int role = Qt::EditRole );
    /**
     * Convenience function which can be used in QML to set data.
     * @param row row in which the data should be changed
     * @param rolename specify which rolename to change the data for
     * @param value new value to be set
     */
    Q_INVOKABLE virtual bool setData( int row,
                                      const QString &rolename,
                                      const QVariant &value );

signals:
    /**
     * emitted when autoConnect value changes
     */
    void autoConnectChanged( bool autoconnect );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( QString message, NotificationTypes type );
    /**
     * This signal is emitted when there was no account online and one (or more)
     * account goes online
     */
    void oneAccountOnlineChanged( bool oneAccountOnline );
    /**
     * This signal is emitted whenever an account changes its presence state.
     * @param index row of account that changed its presence state
     * @param presenceState new presence state the account switched to
     */
    void presenceStateChanged( int index, const QString &presenceState );


public slots:

};

}

#endif // ACCOUNTLISTMODEL_H
