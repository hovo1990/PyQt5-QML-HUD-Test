/*
 * statusmodel.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "statusmodel.h"
#include "statusmodel_p.h"

#include "../peregrineDebugHelper.h"
#include "../peregrineinitializer.h"
#include "../presencestates.h"

#include <TelepathyQt4/PendingReady>
#include <TelepathyQt4/Types>

using namespace Peregrine;

/* *****************************************************************************
 * StatusModelPrivate
 * ****************************************************************************/

const Tp::Features
StatusModelPrivate::ACCOUNT_FEATURES = ( Tp::Features()
                                         << Tp::Account::FeatureCore
                                         << Tp::Account::FeatureProtocolInfo
                                         << Tp::Account::FeatureProfile );

const Tp::Features
StatusModelPrivate::ACCOUNT_MANAGER_FEATURES = ( Tp::Features()
                                                 << Tp::AccountManager::FeatureCore );

const Tp::Features
StatusModelPrivate::CONNECTION_FEATURES = ( Tp::Features()
                                            << Tp::Connection::FeatureCore
                                            << Tp::Connection::FeatureSimplePresence );

const Tp::Features
StatusModelPrivate::CONNECTION_MANAGER_FEATURES = ( Tp::Features()
                                                    << Tp::ConnectionManager::FeatureCore );

StatusModelPrivate::StatusModelPrivate( StatusModel *parent )
    : QObject( parent ),
    mParent( parent )
{
    FUNC_IN

    if( mParent.isNull() )
    {
        deleteLater();
        FUNC_OUT
        return;
    }

    mPresenceStates = aggregateStatusList();
    mGlobalPresence = PRESENCE_STATE_NAMES.at( PresenceStateOffline );

    mAccountManager = Tp::AccountManager::create();
    connectAccountManager( mAccountManager );
    connect( mAccountManager->becomeReady(),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onAccountManagerReady(Tp::PendingOperation *)) );
    FUNC_OUT
}

bool
StatusModelPrivate::addAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    mAccountList.append( account );

    connectAccount( account );

    Tp::ConnectionPtr connection = account->connection();
    if( !connection.isNull() )
    {
        connection->becomeReady( CONNECTION_FEATURES );
    }

    FUNC_OUT
    return true;
}

QStringList
StatusModelPrivate::aggregateStatusList() const
{
    FUNC_IN

    if( mAccountList.count() <= 0 )
    {
        // if we don't know about an account we cannot go online
        FUNC_OUT
        return ( QStringList() << "offline" );
    }

    QStringList result;
    foreach( Tp::AccountPtr account, mAccountList )
    {
        result.append( presencesStatesForAccount( account ) );
    }

    result.removeDuplicates();
    FUNC_OUT
    return sortPresenceStates( result );
}

QString
StatusModelPrivate::calculateGlobalPresence() const
{
    FUNC_IN
    if( mAccountList.count() <= 0
        || !mParent->oneAccountOnline() )
    {
        FUNC_OUT
        return PRESENCE_STATE_NAMES.at( PresenceStateOffline );
    }

    int index = PRESENCE_STATES_ORDER.count();

    foreach( Tp::AccountPtr account, mAccountList )
    {
        if( !account.isNull()
            && account->isReady(ACCOUNT_FEATURES) )
        {
            int curindex = PRESENCE_STATES_ORDER.indexOf( static_cast<Peregrine::PresenceStates>(account->currentPresence().type()) );
            if( curindex >= 0
                && curindex < index )
            {
                index = curindex;
            }
        }
    }

    if( index >= 0 &&
        index < PRESENCE_STATES_ORDER.count() )
    {
        FUNC_OUT
        return PRESENCE_STATE_NAMES.at( PRESENCE_STATES_ORDER.at(index) );
    }
    FUNC_OUT
    return PRESENCE_STATE_NAMES.at( PresenceStateOffline );
}

bool
StatusModelPrivate::connectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( account.data(),
                       SIGNAL(removed()),
                       this,
                       SLOT(onAccountRemoved()),
                       Qt::DirectConnection );

    result &= connect( account.data(),
                       SIGNAL(currentPresenceChanged(Tp::Presence)),
                       this,
                       SLOT(onAccountCurrentPresenceChanged(Tp::Presence)) );

    result &= connect( account.data(),
                       SIGNAL(connectionChanged(Tp::ConnectionPtr)),
                       this,
                       SLOT(onAccountConnectionChanged(Tp::ConnectionPtr)) );

    FUNC_OUT
    return result;
}

bool
StatusModelPrivate::connectAccountManager( Tp::AccountManagerPtr accountManager )
{
    FUNC_IN

    if( accountManager.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( accountManager.data(),
                       SIGNAL( newAccount( Tp::AccountPtr ) ),
                       this,
                       SLOT( onAccountManagerNewAccount( Tp::AccountPtr ) ) );

    FUNC_OUT
    return result;
}


bool
StatusModelPrivate::disconnectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( account.data(), 0, this, 0 );
}

bool
StatusModelPrivate::disconnectAccountManager( Tp::AccountManagerPtr accountManager )
{
    FUNC_IN
    if( accountManager.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( accountManager.data(), 0, this, 0 );
}

QString
StatusModelPrivate::mapToValidPresenceForAccount( Tp::AccountPtr account,
                                                  const QString &presence )
{
    FUNC_IN
    Q_ASSERT ( !account.isNull() );

    if( !account->isOnline() )
    {
        FUNC_OUT
        return "offline";
    }

    Tp::ConnectionPtr connection = account->connection();

    if( connection->status() != Tp::ConnectionStatusConnected )
    {
        FUNC_OUT
        return "offline";
    }

    QStringList availablePresenceStates = presencesStatesForAccount( account );

    int type = availablePresenceStates.indexOf( presence );
    if( type > 0 && type <= availablePresenceStates.size() )
    {
        FUNC_OUT
        return presence;
    }

    type = PRESENCE_STATE_NAMES.indexOf( presence );
    if( type < 0
        || type >= PresenceStateCount )
    {
        FUNC_OUT
        return PRESENCE_STATE_NAMES.at( PresenceStateOffline );
    }

    // try a mapping
    if( type == PresenceStateAvailable )
    {
        FUNC_OUT
        return PRESENCE_STATE_NAMES.at( PresenceStateAvailable );
    } else if( type > PresenceStateAvailable )
    {
        if( availablePresenceStates.contains(PRESENCE_STATE_NAMES
                                             .at(PresenceStateAway)) )
        {
            FUNC_OUT
            return PRESENCE_STATE_NAMES.at( PresenceStateAway );
        }
        if( availablePresenceStates.contains(PRESENCE_STATE_NAMES
                                             .at(PresenceStateAvailable)) )
        {
            FUNC_OUT
            return PRESENCE_STATE_NAMES.at( PresenceStateAvailable );
        }
    }

    // fall back to offline
    FUNC_OUT
    return PRESENCE_STATE_NAMES.at( PresenceStateOffline );
}

bool
StatusModelPrivate::removeAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        return true;
    }
    int index = mAccountList.indexOf( account );
    if( index > 0 )
    {
        //disconnect objects
        disconnectAccount( mAccountList.at(index) );

        // remove objects
        mAccountList.removeAt( index );
        FUNC_OUT
        return true;
    }
    FUNC_OUT
    return false;
}

bool
StatusModelPrivate::setCurrentPresence( Tp::AccountPtr account,
                                        const Tp::Presence presence )
{
    FUNC_IN
    Q_ASSERT( !account.isNull() );

    if ( !account->isValidAccount() )
    {
        FUNC_OUT
        return false;
    }

    if( account->currentPresence().type() == presence.type() )
    {
        FUNC_OUT
        return true;
    }

    // in case account has status
    // Tp::ConnectionStatus == StatusDisconnected the AccountManager will
    // connect the account for us
    account->setRequestedPresence( presence );

    FUNC_OUT
    return true;
}

void
StatusModelPrivate::updateModel()
{
    FUNC_IN
    QStringList newPresenceStates = aggregateStatusList();
    QString newPresence = calculateGlobalPresence();

    if( mPresenceStates.count() <= 0
        || newPresenceStates.count() <= 0 )
    {
        mParent->beginResetModel();
        mPresenceStates = newPresenceStates;
        mGlobalPresence = newPresence;
        mParent->endResetModel();

        FUNC_OUT
        return;
    }

    for( int i = 0, j = 0, k = 0; i < PRESENCE_STATES_ORDER.count(); ++i )
    {
        QString state = PRESENCE_STATE_NAMES.at( PRESENCE_STATES_ORDER.at(i) );

        if( j < mPresenceStates.count()
            && mPresenceStates.at(j) == state )
        {
            if( k >= newPresenceStates.count()
                || newPresenceStates.at(k) != state )
            {
                mParent->beginRemoveRows( QModelIndex(), j, j );
                mPresenceStates.removeAt( j );
                mParent->endRemoveRows();
            } else
            {
                ++j; ++k;
            }
        } else
        {
            if( k < newPresenceStates.count()
                && newPresenceStates.at(k) == state )
            {
                mParent->beginInsertRows( QModelIndex(), j, j );
                mPresenceStates.insert( j++, newPresenceStates.at(k++) );
                mParent->endInsertRows();
            }
        }
    }

    if( mGlobalPresence != newPresence )
    {
        int row = mPresenceStates.indexOf(mGlobalPresence);
        QModelIndex index = mParent->index( row, StatusModel::ColumnPresenceStates );
        // change status variable before emitting signal
        mGlobalPresence = newPresence;
        emit mParent->dataChanged( index, index );


        row = mPresenceStates.indexOf(mGlobalPresence);
        index = mParent->index( row, StatusModel::ColumnPresenceStates );
        emit mParent->dataChanged( index, index );

        emit mParent->globalPresenceChanged( mGlobalPresence );
    }
    FUNC_OUT
}

void
StatusModelPrivate::onAccountManagerNewAccount( const Tp::AccountPtr &account )
{
    FUNC_IN
    addAccount( account );

    // update list of presence states
    updateModel();
    FUNC_OUT
}

void
StatusModelPrivate::onAccountManagerReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(),
                                    NotificationTypeError );
        FUNC_OUT
        return;
    }

    // clear list of accounts
    while( mAccountList.size() > 0 )
    {
        disconnectAccount( mAccountList.at(0) );
        mAccountList.removeAt( 0 );
    }
    // get all accounts
    mAccountList = mAccountManager->allAccounts();

    for( int i = 0; i < mAccountList.size(); ++i )
    {
        // connect accounts
        connectAccount( mAccountList.at(i) );

        // make accounts ready
        connect( mAccountList.at(i)->becomeReady(ACCOUNT_FEATURES),
                 SIGNAL(finished(Tp::PendingOperation *)),
                 this,
                 SLOT(onAccountReady(Tp::PendingOperation *)) );
    }

    updateModel();
    FUNC_OUT
}

void
StatusModelPrivate::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "could not make account ready";
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(),
                                    NotificationTypeWarning );
        FUNC_OUT
        return;
    }

    Tp::PendingReady *pr = qobject_cast<Tp::PendingReady *>( operation );
    Tp::AccountPtr account = Tp::AccountPtr::staticCast( pr->object() );

    int row = mAccountList.indexOf( account );
    if( row >= 0 )
    {
        Tp::ConnectionPtr connection = account->connection();
        if( !connection.isNull() )
        {
            connection->becomeReady( CONNECTION_FEATURES );
        }
    }

    // we don't have to update the model because we could not retrieve
    // any presence state information
    updateModel();
    FUNC_OUT
}

void
StatusModelPrivate::onAccountRemoved()
{
    FUNC_IN
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(sender()) );

    int i = mAccountList.indexOf( account );
    if( i >= 0 )
    {
        disconnectAccount( mAccountList.at(i) );
        mAccountList.removeAt(i);
    }

    // update list of presence states
    updateModel();
    FUNC_OUT
}

void
StatusModelPrivate::onAccountConnectionChanged( const Tp::ConnectionPtr &connection )
{
    FUNC_IN
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(this->sender()) );
    if( account.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "unresolved sender";
        FUNC_OUT
        return;
    }

    // check if account is in list
    int index = mAccountList.indexOf( account );
    if( index < 0 )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "signal from unknown account. disconnecting account...";
        disconnectAccount( account );
        FUNC_OUT
        return;
    }

    if( !connection.isNull() )
    {
        connection->becomeReady( CONNECTION_FEATURES );
    }

    // update list of presence states
    updateModel();
    // TODO
    // update global presence state
    FUNC_OUT
}

void
StatusModelPrivate::onAccountCurrentPresenceChanged( const Tp::Presence&
                                                               currentPresence )
{
    FUNC_IN
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(this->sender()) );
    if( account.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "(unresolved sender)"
                   << currentPresence.status();
        FUNC_OUT
        return;
    }

    // update list of presence states
    updateModel();
    FUNC_OUT
}

/* *****************************************************************************
 * StatusModel
 * ****************************************************************************/

void
StatusModel::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames = roleNames();
    rolenames.insert( Qt::CheckStateRole, "checkState" );
    setRoleNames( rolenames );
    FUNC_OUT
}

StatusModel::StatusModel( QObject *parent )
    : QAbstractItemModel( parent )
{
    FUNC_IN
    Peregrine::initialize();
    d = new StatusModelPrivate( this );
    initRoleNames();
    FUNC_OUT
}

StatusModel::~StatusModel()
{
    FUNC_IN
    FUNC_OUT
}

int
StatusModel::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return ColumnCount;
}

QVariant
StatusModel::data( const QModelIndex &index, int role ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !index.isValid()
        || index.row() < 0
        || index.row() >= d->mPresenceStates.count() )
    {
        FUNC_OUT
        return QVariant();
    }

    if( index.column() == ColumnPresenceStates )
    {
        switch( role )
        {
        case Qt::DisplayRole:
            FUNC_OUT
            return d->mPresenceStates.at( index.row() );
        case Qt::CheckStateRole:
            qDebug() << __PRETTY_FUNCTION__
                     << "row: " + QString::number( index.row() )
                     + "status: " + d->mPresenceStates.at(index.row())
                     + "global: " + d->mGlobalPresence;
            FUNC_OUT
            return ( d->mPresenceStates.at(index.row()) == d->mGlobalPresence )
                        ? Qt::Checked
                        : Qt::Unchecked;
        }
    }

    // fall back
    FUNC_OUT
    return QVariant();
}

QString
StatusModel::globalPresence() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    FUNC_OUT
    return d->mGlobalPresence;
}

QModelIndex
StatusModel::index( int row, int column, const QModelIndex &parent ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( parent.isValid()
        || column < 0
        || column >= ColumnCount
        || row < 0
        || row >= d->mPresenceStates.count() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    FUNC_OUT
    return createIndex( row, column );
}

bool
StatusModel::oneAccountOnline() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    for( int i = 0; i < d->mAccountList.count(); ++i )
    {
        Tp::AccountPtr account = d->mAccountList.at(i);

        Q_ASSERT( !account.isNull() );

        if( account->connectionStatus() == Tp::ConnectionStatusConnected )
        {
            FUNC_OUT
            return true;
        }
    }

    // no connected account found
    FUNC_OUT
    return false;
}

QModelIndex
StatusModel::parent( const QModelIndex &child ) const
{
    FUNC_IN
    Q_UNUSED( child );
    FUNC_OUT
    return QModelIndex();
}

int
StatusModel::rowCount( const QModelIndex &parent ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return d->mPresenceStates.count();
}

bool
StatusModel::setCurrentPresence( const QString& accountPath,
                                 const QString& presenceName,
                                 const QString& message )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( accountPath.isEmpty() )
    {
        FUNC_OUT
        return false;
    }

    Tp::AccountPtr account( 0 );
    for( int i = 0; i < d->mAccountList.count(); ++i )
    {
        if( !d->mAccountList.at(i).isNull() )
        {
            if( d->mAccountList.at(i)->objectPath() == accountPath )
            {
                account = d->mAccountList.at(i);
                break;
                FUNC_OUT
            }
        }
    }

    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    int type = PRESENCE_STATE_NAMES.indexOf( presenceName );
    if( type < 0 )
    {
        emit notification( "unknown presence name `" + presenceName + "'",
                           NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    Tp::Presence presence = PRESENCE_STATES.at( type );
    if( !message.isEmpty() )
    {
        presence = Tp::Presence( presence.type(),
                    presence.status(),
                    message );
    }

    FUNC_OUT
    return d->setCurrentPresence( account, presence );
}

void
StatusModel::setCurrentPresenceGlobal( const QString& presenceName,
                                       const QString& message )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    int type = PRESENCE_STATE_NAMES.indexOf( presenceName );
    if( type < 0 )
    {
        emit notification( "unknown presence name `" + presenceName + "'",
                           NotificationTypeWarning );
        FUNC_OUT
        return;
    }

    Tp::Presence presence = PRESENCE_STATES.at( type );
    if( !message.isEmpty() )
    {
        presence = Tp::Presence( presence.type(),
                                 presence.status(),
                                 message );
    }

    for( int i = 0; i < d->mAccountList.count(); ++i )
    {
        !d->setCurrentPresence( d->mAccountList.at(i), presence );
    }
    FUNC_OUT
}

void
StatusModel::setGlobalPresence( const QString &presence )
{
    setCurrentPresenceGlobal( presence );
}
