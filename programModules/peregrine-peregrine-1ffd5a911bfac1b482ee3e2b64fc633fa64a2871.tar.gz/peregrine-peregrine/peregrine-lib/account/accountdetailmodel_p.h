/*
 * accountdetailmodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef ACCOUNTDETAILMODEL_P_H
#define ACCOUNTDETAILMODEL_P_H

#include <QObject>
#include <QPointer>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/AccountManager>
#include <TelepathyQt4/Connection>
#include <TelepathyQt4/ConnectionManager>
#include <TelepathyQt4/Feature>
#include <TelepathyQt4/Features>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/SharedPtr>
#include <TelepathyQt4/Types>

namespace Peregrine
{

class AccountDetailModel;

class AccountDetailModelPrivate
    : public QObject
{
    Q_OBJECT

    friend class AccountDetailModel;

    static const Tp::Features ACCOUNT_FEATURES;
    static const Tp::Features ACCOUNT_MANAGER_FEATURES;
    static const Tp::Features CONNECTION_MANAGER_FEATURES;

    QPointer<AccountDetailModel> mParent;

    // these maps are needed to hold changed values before submitting
    // them to the subsystem
    QMap<int, QVariant> m_newProperties;
    QVariantMap m_newParameters;
    QStringList m_unsetParameters;

    /** account object the model gets it's data from */
    Tp::AccountPtr mAccount;
    /** connection manager */
    Tp::ConnectionManagerPtr mConnectionManager;
    /** account manager */
    Tp::AccountManagerPtr mAccountManager;

    // needed to call retrieveParamSpec when mCM finished
    QString mConnectionManagerName;
    QString mProtocolName;
    QString mAccountObjectPath;
    bool mAccountCreationMode;

    Tp::ProtocolParameterList mParamList;

    explicit AccountDetailModelPrivate( AccountDetailModel *parent );

    /**
     * connect model to signals of account object
     * \sa disconnectAccount
     */
    bool connectAccount( Tp::AccountPtr account );
    /**
     * disconnect model from signals of account object
     * \sa connectAccount
     */
    bool disconnectAccount( Tp::AccountPtr account );
    /**
     * Load information about the protocol including a list of parameters
     * from connection manager
     */
    void loadProtocolInfo( const QString& protocol );

private slots:
    /**
     *  Convenience slot to select the region of the model that has been
     *  updated.
     */
    void onAccountChanged();
    /**
     * onAccountManagerReady is called after finished was emitted by AccountManager
     */
    void onAccountManagerReady( Tp::PendingOperation *operation );
    /**
     * onAccountReady is called after finished was emitted by account
     */
    void onAccountReady( Tp::PendingOperation *operation = 0 );
    /**
     * onAccountRemoved is called when account gets deleted
     */
    void onAccountRemoved();
    /**
     * onConnectionManagerReady is called after finished was emitted by ConnectionManager
     */
    void onConnectionManagerReady( Tp::PendingOperation *operation = 0 );
    /**
     * onPendingAccountReady is called after finished was emitted by a
     * PendingAccount object.
     * That happens when AccountDetailModel is used to create a new account
     * and is not destroyed before the operation has finished
     */
    void onPendingAccountReady( Tp::PendingOperation *operation );

    /**
     * onConnectionChanged is called when connectionChanged is emitted by
     * mAccount
     */
    void onConnectionChanged( const Tp::ConnectionPtr &connection );
    void onConnectionReady( Tp::PendingOperation *operation );


public:
signals:
public slots:

};

}
#endif // ACCOUNTDETAILMODEL_P_H
