/*
 * statusmodel_p.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef STATUSMODEL_P_H
#define STATUSMODEL_P_H

#include <QObject>
#include <QPointer>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/AccountManager>
#include <TelepathyQt4/Connection>
#include <TelepathyQt4/ConnectionManager>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/Presence>
#include <TelepathyQt4/SharedPtr>


namespace Peregrine
{

class StatusModel;

class StatusModelPrivate
    : public QObject
{
    Q_OBJECT

    friend class StatusModel;

    static const Tp::Features ACCOUNT_FEATURES;
    static const Tp::Features ACCOUNT_MANAGER_FEATURES;
    static const Tp::Features CONNECTION_FEATURES;
    static const Tp::Features CONNECTION_MANAGER_FEATURES;

    QPointer<StatusModel> mParent;

    QStringList mPresenceStates;
    QString mGlobalPresence;

    Tp::AccountManagerPtr mAccountManager;

    QList<Tp::AccountPtr> mAccountList;

//    const Tp::Features mConnectionFeatures;


    explicit StatusModelPrivate( StatusModel *parent );

    /**
     * Add account to list of accounts
     */
    bool addAccount( Tp::AccountPtr account );

    /**
     * Return an aggregated list of statuses, containing all available
     * statuses of connections in mConnectionList
     */
    Q_INVOKABLE QStringList aggregateStatusList() const;

    /**
     * Remove account from list of accounts.
     */
    bool removeAccount( Tp::AccountPtr account );

    /**
     *
     */
    QString calculateGlobalPresence() const;

    /**
     * connect to signals of an account
     */
    bool connectAccount( Tp::AccountPtr account );
    /**
     * connect to signals of an account manager
     */
    bool connectAccountManager( Tp::AccountManagerPtr accountManager );

    /**
     * disconnect from signals of an account
     */
    bool disconnectAccount( Tp::AccountPtr account );
    /**
     * disconnect from signals of an account manager
     */
    bool disconnectAccountManager( Tp::AccountManagerPtr accountManager );

    /**
     * Maps to a presence status, which is valid for the given connection
     */
    QString mapToValidPresenceForAccount( Tp::AccountPtr account,
                                          const QString &presence );

    /**
     * Set the current presence.
     * @param account The account to set the presence for
     * @param presence The new presence to change to.
     * @param message The message that should be displayed to the contacts
     */
   bool setCurrentPresence( Tp::AccountPtr account,
                            const Tp::Presence presence );

   /**
    * update internal list of presence states
    */
   void updateModel();


private slots:
   /**
    * slot is called when a new account is created
    */
   void onAccountManagerNewAccount( const Tp::AccountPtr &account );
   /**
    * slot is called when account manager has become ready
    */
   void onAccountManagerReady( Tp::PendingOperation *operation );

   /**
    *
    */
   void onAccountReady( Tp::PendingOperation *operation );
   /**
    * slot is called when a registered account gets removed
    */
   void onAccountRemoved();
   /**
    * This slot is called when the value of Tp::Account::connection()
    * changes.
    * @param connection new Tp::Connection object or null if account
    * is not connected
    */
   void onAccountConnectionChanged( const Tp::ConnectionPtr &connection );
   /**
    * slot is called when the presence of a account changes
    */
   void onAccountCurrentPresenceChanged(
                                     const Tp::Presence &currentPresence );

public:

signals:

public slots:

};

}

#endif // STATUSMODEL_P_H
