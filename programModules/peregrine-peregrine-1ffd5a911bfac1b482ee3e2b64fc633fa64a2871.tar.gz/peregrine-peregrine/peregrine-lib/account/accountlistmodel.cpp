/*
 * accountlistmodel.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "accountlistmodel.h"
#include "accountlistmodel_p.h"

#include "../peregrineDebugHelper.h"
#include "../peregrineinitializer.h"
#include "../peregrineservicenames.h"
#include "../presencestates.h"

#include <QPixmap>

#include <TelepathyQt4/PendingReady>

using namespace Peregrine;

#define HIDE_MMSCM_ACCOUNT 0
#define HIDE_RING_ACCOUNT 0

/* *****************************************************************************
 * AccountListModelPrivate
 * ****************************************************************************/

const Tp::Features
AccountListModelPrivate::ACCOUNT_FEATURES = ( Tp::Features()
                                              << Tp::Account::FeatureCore
                                              << Tp::Account::FeatureAvatar
                                              << Tp::Account::FeatureProfile
                                              << Tp::Account::FeatureProtocolInfo );
const Tp::Features
AccountListModelPrivate::CONNECTION_FEATURES = ( Tp::Features()
                                                 << Tp::Connection::FeatureCore
                                                 << Tp::Connection::FeatureSimplePresence );

AccountListModelPrivate::AccountListModelPrivate( AccountListModel *parent )
    : QObject( parent )
    , mParent( parent )
    , mAutoConnect( false )
    , mInitializeCounter( 0 )
{
    FUNC_IN
    if( mParent.isNull() )
    {
        deleteLater();
        FUNC_OUT
        return;
    }

    // create an account manager and connect to it
    mAccountManager = Tp::AccountManager::create();
    connect( mAccountManager->becomeReady(),
             SIGNAL( finished( Tp::PendingOperation * ) ),
             this,
             SLOT( onAccountManagerReady( Tp::PendingOperation * ) ) );
    connectAccountManager( mAccountManager );
    FUNC_OUT
}

bool
AccountListModelPrivate::connectAccount( const Tp::AccountPtr &account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( account.data(),
                       SIGNAL(removed()),
                       this,
                       SLOT(onAccountRemoved()),
                       Qt::DirectConnection );

    result &= connect( account.data(),
                       SIGNAL(serviceNameChanged(QString)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(profileChanged(Tp::ProfilePtr)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(displayNameChanged(QString)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(iconNameChanged(QString)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(nicknameChanged(QString)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(normalizedNameChanged(QString)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(validityChanged(bool)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(stateChanged(bool)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(capabilitiesChanged(Tp::ConnectionCapabilities)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(connectsAutomaticallyPropertyChanged(bool)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(firstOnline()),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(parametersChanged(QVariantMap)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(changingPresence(bool)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(automaticPresenceChanged(Tp::Presence)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(currentPresenceChanged(Tp::Presence)),
                       this,
                       SLOT(onAccountCurrentPresenceChanged(Tp::Presence)));
    result &= connect( account.data(),
                       SIGNAL(requestedPresenceChanged(Tp::Presence)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(onlinenessChanged(bool)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(onlinenessChanged(bool)),
                       this,
                       SLOT(onAccountOnlinenessChanged(bool)) );
    result &= connect( account.data(),
                       SIGNAL(avatarChanged(Tp::Avatar)),
                       this,
                       SLOT(onAccountChanged()) );
    result &= connect( account.data(),
                       SIGNAL(connectionStatusChanged(Tp::ConnectionStatus)),
                       this,
                       SLOT(onAccountChanged()) );

    result &= connect( account.data(),
                       SIGNAL(connectionChanged(Tp::ConnectionPtr)),
                       this,
                       SLOT(onAccountConnectionChanged(Tp::ConnectionPtr)) );

    result &= connect( account.data(),
                       SIGNAL(serviceNameChanged(QString)),
                       this,
                       SLOT(onAccountServiceChanged()) );
    result &= connect( account.data(),
                       SIGNAL(profileChanged(Tp::ProfilePtr)),
                       this,
                       SLOT(onAccountServiceChanged()) );
    result &= connect( account.data(),
                       SIGNAL(iconNameChanged(QString)),
                       this,
                       SLOT(onAccountServiceChanged()) );

    FUNC_OUT
    return result;
}

bool
AccountListModelPrivate::connectAccountManager( const Tp::AccountManagerPtr& accountManager )
{
    FUNC_IN
    if( accountManager.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( accountManager.data(),
                       SIGNAL(newAccount(Tp::AccountPtr)),
                       this,
                       SLOT(onAccountManagerNewAccount(Tp::AccountPtr)) );

    FUNC_OUT
    return result;
}

bool
AccountListModelPrivate::disconnectAccount( const Tp::AccountPtr &account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return disconnect( account.data(), 0, this, 0 );
}

bool
AccountListModelPrivate::disconnectAccountManager( const Tp::AccountManagerPtr& accountManager )
{
    FUNC_IN
    if( accountManager.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( accountManager.data(), 0, this, 0 );
}

bool
AccountListModelPrivate::initialized() const
{
    FUNC_IN
    if( mAccountManager.isNull()
        || !mAccountManager->isReady() )
    {
        FUNC_OUT
        return false;
    }
    FUNC_OUT
    return true;
}

int
AccountListModelPrivate::rowForPath( const QString &path )
{
    FUNC_IN
    int row = -1;
    for( int i = 0; i < mAccounts.count(); ++i )
    {
        if( mAccounts.at(i)->objectPath() == path )
        {
            row = i;
            break;
        }
    }
    if( row < 0 )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "fallback";

        // try to get account object from account manager
        Tp::AccountPtr account = mAccountManager->accountForPath( path );
        if( account.data() )
        {
            // get index
            row = mAccounts.indexOf( account );
            if( row < 0 )
            { // account not found
                // add account to list
                onAccountManagerNewAccount( account );
                // get index
                row = mAccounts.indexOf( account );
            }
        }
    }

    FUNC_OUT
    return row;
}

/* ***
 * private slots
 */

void
AccountListModelPrivate::onAccountManagerNewAccount( const Tp::AccountPtr &account )
{
    FUNC_IN
    int rows = mAccounts.count();

    if( !account.isNull() )
    {
#if HIDE_RING_ACCOUNT > 0
        if( account->cmName() == "ring" )
        {
            FUNC_OUT
            return;
        }
#endif
#if HIDE_MMSCM_ACCOUNT > 0
        if( account->cmName() == "mmscm" )
        {
            FUNC_OUT
            return;
        }
#endif
        QString protocolName = account->protocolName();
        if( protocolName != "jabber"
            && protocolName != "skype" )
        {
            FUNC_OUT
            return;
        }
        mParent->beginInsertRows( QModelIndex(), rows, rows );
        mAccounts.append( account );
        connect( account->becomeReady(ACCOUNT_FEATURES),
                 SIGNAL(finished(Tp::PendingOperation *)),
                 this,
                 SLOT(onAccountReady(Tp::PendingOperation *)) );
        connectAccount( account );
        mParent->endInsertRows();
    }
    FUNC_OUT
}

void
AccountListModelPrivate::onAccountManagerReady( Tp::PendingOperation *operation )
{
    FUNC_IN

    mParent->beginResetModel();

    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                  << operation->errorName()
                  << ": "
                  << operation->errorMessage();

        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(),
                                    NotificationTypeError );
        mAccounts.clear();
    } else
    {
        // read list of accounts
        QList<Tp::AccountPtr> accountList = mAccountManager->allAccounts();
        mInitializeCounter = accountList.count();

        foreach( Tp::AccountPtr account, accountList )
        {
            if( !account.isNull() )
            {
#if HIDE_RING_ACCOUNT > 0
                if( account->cmName() == "ring" )
                {
                    --mInitializeCounter;
                    continue;
                }
#endif
#if HIDE_MMSCM_ACCOUNT > 0
                if( account->cmName() == "mmscm" )
                {
                    --mInitializeCounter;
                    continue;
                }
#endif
                // whitelist all jabber, skype accounts
                QString protocolName = account->protocolName();
                if( protocolName != "jabber"
                    && protocolName != "skype" )
                {
                    --mInitializeCounter;
                    continue;
                }

                mAccounts.append( account );
                connect( account->becomeReady(ACCOUNT_FEATURES),
                         SIGNAL(finished(Tp::PendingOperation *)),
                         this,
                         SLOT(onAccountReady(Tp::PendingOperation *)) );
                connectAccount( account );
            }
        }
    }

    // reset model state
    mParent->endResetModel();
    FUNC_OUT
}

void
AccountListModelPrivate::onAccountConnectionChanged( const Tp::ConnectionPtr& connection )
{
    FUNC_IN
    if( !connection.isNull() )
    {
        connect( connection->becomeReady(CONNECTION_FEATURES),
                 SIGNAL(finished(Tp::PendingOperation *)),
                 this,
                 SLOT( onConnectionReady(Tp::PendingOperation *)) );
    }

    Tp::AccountPtr account( qobject_cast<Tp::Account *>(sender()) );
    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }

    int row = mAccounts.indexOf( account );
    if( row >= 0 )
    {
        QModelIndex first = mParent->index( row, 0 );
        QModelIndex last = mParent->index( row, AccountListModel::ColumnCount - 1 );
        emit mParent->dataChanged( first, last );
    }
    FUNC_OUT
}

void
AccountListModelPrivate::onAccountCurrentPresenceChanged( const Tp::Presence& presence )
{
    FUNC_IN
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(sender()) );
    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }

    int row = mAccounts.indexOf( account );
    if( row >= 0 )
    {
        QModelIndex first = mParent->index( row, 0 );
        QModelIndex last = mParent->index( row, AccountListModel::ColumnCount - 1 );
        emit mParent->dataChanged( first, last );
        emit mParent->presenceStateChanged( row, presence.status() );
    }
    FUNC_OUT
}

void
AccountListModelPrivate::onAccountOnlinenessChanged( bool online )
{
    FUNC_IN
    if( online )
    {
        if( !mOneAccountOnline )
        {
            mOneAccountOnline = true;
            emit mParent->oneAccountOnlineChanged( mOneAccountOnline );
        }
    } else
    {
        for( int i = 0; i < mAccounts.count(); ++i )
        {
            if( mAccounts.at(i)->isOnline() &&
                !mOneAccountOnline )
            {
                online = mOneAccountOnline = true;
                emit mParent->oneAccountOnlineChanged( mOneAccountOnline );
                break;
            }
        }

        if( !online
            && mOneAccountOnline )
        {
            mOneAccountOnline = false;
            emit mParent->oneAccountOnlineChanged( mOneAccountOnline );
        }
    }
    FUNC_OUT
}

void
AccountListModelPrivate::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "error occured while making an account ready";
        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(),
                                    NotificationTypeWarning );
        if( --mInitializeCounter == 0
            && !mOneAccountOnline )
        {
            emit mParent->oneAccountOnlineChanged( mOneAccountOnline );
        }
        FUNC_OUT
        return;
    }

    Tp::PendingReady *pr = qobject_cast<Tp::PendingReady *>(operation);
    Tp::AccountPtr account = Tp::AccountPtr::staticCast( pr->object() );

    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }

    mAccountServiceMap.insert( account->objectPath(), serviceNameForAccount(account) );
    int row = mAccounts.indexOf( account );
    if( row >= 0 )
    {
        Tp::ConnectionPtr connection = account->connection();
        if( !connection.isNull() )
        {
            // if connection already exists we have to make it ready (activate some features)
            connect( connection->becomeReady(CONNECTION_FEATURES),
                     SIGNAL(finished(Tp::PendingOperation *)),
                     this,
                     SLOT(onConnectionReady(Tp::PendingOperation *)) );
        }

        QModelIndex first = mParent->index( row, 0 );
        QModelIndex last = mParent->index( row, AccountListModel::ColumnCount - 1 );
        emit mParent->dataChanged( first, last );
    }

    if( mAutoConnect
        && !account->isOnline() )
    {
        account->setRequestedPresence( account->automaticPresence() );
    }

    if( account->isOnline() && !mOneAccountOnline )
    {
        mOneAccountOnline = true;
        emit mParent->oneAccountOnlineChanged( mOneAccountOnline );
    } else if( --mInitializeCounter == 0
               && !mOneAccountOnline )
    {
        emit mParent->oneAccountOnlineChanged( mOneAccountOnline );
    }
    FUNC_OUT
}

void
AccountListModelPrivate::onAccountRemoved()
{
    FUNC_IN
    // get sending account object
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(sender()) );
    // return if signal was not emitted by account object
    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }
    // get dbus object path from account
    QString path = account->objectPath();

    int row = rowForPath( path );

    // everything below this line should be moved to removeRows()
    if( row >= 0 )
    {
        mParent->removeRow( row );
        mParent->beginRemoveRows( QModelIndex(), row, row );
    }
    else
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "account not found ... resetting the model";
        if( mAccounts.isEmpty() )
        {
            mParent->reset();
        } else
        {
            QModelIndex first = mParent->index( 0, 0 );
            QModelIndex last = mParent->index( mAccounts.count() - 1, AccountListModel::ColumnCount - 1 );
            emit mParent->dataChanged( first, last );
        }
    }
    FUNC_OUT
}

void
AccountListModelPrivate::onAccountServiceChanged()
{
    FUNC_IN
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(sender()) );
    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }

    mAccountServiceMap.insert( account->objectPath(), serviceNameForAccount(account) );
    FUNC_OUT
}

void
AccountListModelPrivate::onAccountChanged()
{
    FUNC_IN
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(sender()) );
    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }

    int row = mAccounts.indexOf( account );
    if(row >= 0)
    {
        QModelIndex first = mParent->index( row, 0 );
        QModelIndex last = mParent->index( row, AccountListModel::ColumnCount - 1 );
        emit mParent->dataChanged( first, last );
    }
    else
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "account not found ... resetting the model";
        if( mAccounts.isEmpty() )
        {
            mParent->reset();
        } else
        {
            QModelIndex first = mParent->index(0, 0);
            QModelIndex last = mParent->index( mAccounts.size() - 1, AccountListModel::ColumnCount - 1 );
            emit mParent->dataChanged( first, last );
        }
    }
    FUNC_OUT
}

void
AccountListModelPrivate::onPendingReadyFinished( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(),
                                    NotificationTypeWarning );
    }
    FUNC_OUT
}

void
AccountListModelPrivate::onConnectionReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "connection cannot become ready";
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(),
                                    NotificationTypeWarning );
        FUNC_OUT
        return;
    }

    // find corresponding account
    Tp::PendingReady *pr = qobject_cast<Tp::PendingReady *>( operation );
    Tp::ConnectionPtr connection = Tp::ConnectionPtr::staticCast(
                                                            pr->object() );
    if( connection.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "unknown connection";
        FUNC_OUT
        return;
    }

    for( int i = 0; i < mAccounts.size(); ++i )
    {
        if( mAccounts.at(i)->connection() == connection )
        {
            QModelIndex first = mParent->index( i, 0 );
            QModelIndex last = mParent->index( i, AccountListModel::ColumnCount - 1 );
            emit mParent->dataChanged( first, last );
        }
    }
    FUNC_OUT
}


/* *****************************************************************************
 * AccountListModel
 * ****************************************************************************/

void
AccountListModel::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames;
    rolenames.insert( Qt::DisplayRole,             "displayName" );
    rolenames.insert( NicknameRole,                "nickName" );
    rolenames.insert( AccountIdRole,               "accountId" );
    rolenames.insert( AccountUidRole,              "accountUid" );
    rolenames.insert( PresenceStateRole,           "presenceState" );
    rolenames.insert( PresenceStateMessageRole,    "presenceStateMassage" );
    rolenames.insert( AvailablePresenceStatesRole, "availablePresenceStates" );
    rolenames.insert( ServiceNameRole,             "serviceName" );
    rolenames.insert( ProtocolNameRole,            "protocolName" );
    rolenames.insert( AccountObjectPathRole,       "accountObjectPath" );
    setRoleNames( rolenames );
    FUNC_OUT
}

AccountListModel::AccountListModel( QObject *parent )
    : QAbstractItemModel( parent )
{
    FUNC_IN
    Peregrine::initialize();
    d = new AccountListModelPrivate( this );
    initRoleNames();
    FUNC_OUT
}

AccountListModel::~AccountListModel()
{
    FUNC_IN
    FUNC_OUT
}

int
AccountListModel::accountCountForService( const QString &serviceName ) const
{
    FUNC_IN
    int count = 0;
    for( int i = 0; i < d->mAccounts.count(); ++i )
    {
        Tp::AccountPtr account = d->mAccounts.at(i);
        switch( account->currentPresence().type() )
        {
        case Tp::ConnectionPresenceTypeAvailable:
        case Tp::ConnectionPresenceTypeAway:
        case Tp::ConnectionPresenceTypeBusy:
        case Tp::ConnectionPresenceTypeExtendedAway:
        case Tp::ConnectionPresenceTypeHidden:
            // now check service name
            if( d->mAccountServiceMap.value(account->objectPath()) == serviceName )
            {
                ++count;
            }
            break;
        case Tp::ConnectionPresenceTypeError:
        case Tp::ConnectionPresenceTypeOffline:
        case Tp::ConnectionPresenceTypeUnknown:
        case Tp::ConnectionPresenceTypeUnset:
        case Tp::_ConnectionPresenceTypePadding:
            break;
        }
    }
    FUNC_OUT
    return count;
}

QString
AccountListModel::accountPathAtRow( int index )
{
    FUNC_IN
    if( index >= 0
        && index < d->mAccounts.count() )
    {
        FUNC_OUT
        return d->mAccounts.at( index )->objectPath();
    }
    FUNC_OUT
    return QString();
}

QStringList
AccountListModel::accountsForService( const QString &serviceName ) const
{
    FUNC_IN
    FUNC_OUT
    return d->mAccountServiceMap.keys( serviceName );
}

bool
AccountListModel::autoConnect() const
{
    FUNC_IN
    FUNC_OUT
    return d->mAutoConnect;
}

int
AccountListModel::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    Q_UNUSED( parent );
    FUNC_OUT
    return ColumnCount;
}

QVariant
AccountListModel::data( const QModelIndex &index, int role ) const
{
    FUNC_IN
    if( !index.isValid()
        || !d->initialized() )
    {
        FUNC_OUT
        return QVariant();
    }

    if( index.row() < 0
        || index.row() >= d->mAccounts.count() )
    {
        FUNC_OUT
        return QVariant();
    }

    if( index.column() < 0
        || index.column() >= ColumnCount )
    {
        FUNC_OUT
        return QVariant();
    }

    Tp::AccountPtr account = d->mAccounts.at( index.row() );

    if( index.column() == ColumnAccount )
    {
        switch( role )
        {
        case Qt::DisplayRole:
            FUNC_OUT
            return QVariant( account->displayName() );
        case Qt::DecorationRole:
            {
                Tp::Avatar avatar = account->avatar();
                QPixmap avatarPM;
                avatarPM.loadFromData( avatar.avatarData,
                                       avatar.MIMEType.toStdString().c_str() );
                FUNC_OUT
                return avatarPM;
            }
        case Qt::CheckStateRole:
            FUNC_OUT
            return account->isEnabled() ? Qt::Checked : Qt::Unchecked;
        case NicknameRole:
            FUNC_OUT
            return account->nickname();
        case AccountIdRole:
            FUNC_OUT
            return QVariant( account->parameters().value("account")
                                                  .toString() );
        case AccountUidRole:
            FUNC_OUT
            return account->uniqueIdentifier();
        case PresenceStateRole:
            {
                int type = account->currentPresence().type();
                if( type >= PresenceStateCount || type < 0 )
                {
                    type = PresenceStateUnknown;
                }

                FUNC_OUT
                return PRESENCE_STATE_NAMES.at( type );
            }
        case AvailablePresenceStatesRole:
            FUNC_OUT
            return presencesStatesForAccount( account );
        case ServiceNameRole:
            FUNC_OUT
            return d->mAccountServiceMap.value( account->objectPath() );
        case AccountObjectPathRole:
            FUNC_OUT
            return account->objectPath();
        }
    }
    else
    {
        if( index.column() == ColumnPresence )
        {
            switch( role )
            {
            case Qt::DisplayRole:
                FUNC_OUT
                return account->currentPresence().status();
            case PresenceStateRole:
                FUNC_OUT
                return account->currentPresence().type();
            case PresenceStateMessageRole:
                FUNC_OUT
                return account->currentPresence().statusMessage();
            case AvailablePresenceStatesRole:
                FUNC_OUT
                return presencesStatesForAccount( account );
            }
        }

        else
        {
            if( index.column() == ColumnService )
            {
                switch( role )
                {
                case Qt::DisplayRole:
                    FUNC_OUT
                    return QVariant();
                case Qt::DecorationRole:
                    FUNC_OUT
                    return account->iconName();
                case ServiceNameRole:
                    FUNC_OUT
                    return account->serviceName();
                case ProtocolNameRole:
                    FUNC_OUT
                    return account->protocolName();
                }
            }
        }
    }
    FUNC_OUT
    return QVariant();
}

QVariant
AccountListModel::data(int row, int role) const
{
    FUNC_IN
    QModelIndex index = this->index( row, ColumnAccount );
    FUNC_OUT
    return data( index, role );
}

Qt::ItemFlags
AccountListModel::flags( const QModelIndex &index ) const
{
    FUNC_IN
    if( !index.isValid()
        || !d->initialized() )
    {
        FUNC_OUT
        return Qt::NoItemFlags;
    }

    if( index.column() == ColumnAccount )
    {
        FUNC_OUT
        return QAbstractItemModel::flags( index )
                | Qt::ItemIsSelectable
                | Qt::ItemIsUserCheckable
                | Qt::ItemIsEditable;
    }

    if( index.column() == ColumnPresence )
    {
        FUNC_OUT
        return  QAbstractItemModel::flags( index )
                | Qt::ItemIsEditable;
    }

    FUNC_OUT
    return QAbstractItemModel::flags( index );
}

QVariant
AccountListModel::headerData( int section,
                              Qt::Orientation orientation,
                              int role ) const
{
    FUNC_IN
    if ( role != Qt::DisplayRole ) {
        FUNC_OUT
        return QVariant();
    }

    if( orientation == Qt::Horizontal )
    {
        switch( section )
        {
        case ColumnAccount:
            FUNC_OUT
            return tr( "Account" );
        case ColumnPresence:
            FUNC_OUT
            return tr( "Presence State" );
        case ColumnService:
            FUNC_OUT
            return tr( "Service" );
        }
    }
    FUNC_OUT
    return QVariant();
}

QModelIndex
AccountListModel::index(int row, int column, const QModelIndex &parent) const
{
    FUNC_IN
    if( parent.isValid()
        || column < 0
        || column >= ColumnCount
        || row < 0
        || row >= d->mAccounts.count() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    FUNC_OUT
    return createIndex(row, column, d->mAccounts.at(row).data() );
}

bool
AccountListModel::oneAccountOnline() const
{
    FUNC_IN
    FUNC_OUT
    return d->mOneAccountOnline;
}

QModelIndex AccountListModel::parent(const QModelIndex &child) const
{
    FUNC_IN
    Q_UNUSED( child );
    FUNC_OUT
    return QModelIndex();
}

bool
AccountListModel::removeRows( int row,
                              int count,
                              const QModelIndex &parent )
{
    FUNC_IN
    if( parent.isValid()
        || !d->initialized() )
    {
        FUNC_OUT
        return false;
    }

    int last = row + count - 1;
    if( count < 0
        || row < 0
        || last >= d->mAccounts.count() )
    {
        FUNC_OUT
        return false;
    }

    beginRemoveRows( QModelIndex(), row, last );
    for( int i = last; i >= row; --i )
    {
        Tp::AccountPtr account = d->mAccounts.at(i);

        if( account.data() )
        {
            d->disconnectAccount( account );
            account->remove();
            // do not wait for answer
            // AccountManager will send a signal when account is removed
        }

        d->mAccounts.removeAt( row );
    }
    endRemoveRows();

    FUNC_OUT
    return true;
}

int
AccountListModel::rowCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return d->mAccounts.count();
}

void
AccountListModel::setAutoConnect( bool autoconnect )
{
    FUNC_IN
    if( d->mAutoConnect != autoconnect )
    {
        d->mAutoConnect = autoconnect;
        emit autoConnectChanged( autoconnect );
    }

    // autoconnect all accounts that are not online
    if( autoconnect )
    {
        foreach( Tp::AccountPtr account, d->mAccounts )
        {
            if( account->isReady(AccountListModelPrivate::ACCOUNT_FEATURES)
                && !account->isOnline() )
            {
                account->setRequestedPresence( account->automaticPresence() );
            }
        }
    }
    FUNC_OUT
}

bool
AccountListModel::setData( const QModelIndex &index,
                           const QVariant &value,
                           int role)
{
    FUNC_IN
    if( !index.isValid()
        || !d->initialized() )
    {
        FUNC_OUT
        return false;
    }

    if( !(role == Qt::EditRole
          || role == Qt::CheckStateRole
          || role == PresenceStateRole) )
    {
        FUNC_OUT
        return false;
    }

    Tp::AccountPtr account = d->mAccounts.at( index.row() );
    if( account.isNull()
        || !account->isReady() )
    {
        FUNC_OUT
        return false;
    }

    if( index.column() == ColumnAccount )
    {
        switch( role )
        {
        case Qt::EditRole:
        case PresenceStateRole:
            {
                // find corresponding integer
                Tp::Presence presence = account->currentPresence();
                QString newpresence = value.toString();
                int i = PRESENCE_STATE_NAMES.indexOf( newpresence );
                if( i < 0)
                {
                    FUNC_OUT
                    return false;
                }
                presence = PRESENCE_STATES.at(i);

                account->setRequestedPresence( presence );
                // do not wait for answer
                FUNC_OUT
                return true;
            }
        case Qt::CheckStateRole:
            account->setEnabled( value.toBool() );
            // do not wait for answer
            FUNC_OUT
            return true;
        }
    } else if( index.column() == ColumnPresence )
    {
        Tp::Presence presence = account->currentPresence();
        if( account->isChangingPresence() )
        {
            presence = account->requestedPresence();
        }

        switch( role )
        {
        case Qt::DisplayRole:
            if( presence.type() < 1
                || presence.type() > 6 )
            {
                FUNC_OUT
                        return false;
            }

            presence.setStatus( presence.type(), value.toString(), presence.statusMessage() );
            account->setRequestedPresence( presence );

            // do not wait for answer
            FUNC_OUT
            return true;
        case PresenceStateRole:
            {
                int type = value.toInt();
                if( type < 1
                    || type > 6 )
                {
                    FUNC_OUT
                    return false;
                }

                presence.setStatus( (Tp::ConnectionPresenceType)type, PRESENCE_STATES.at( type ).status(), presence.statusMessage() );
                account->setRequestedPresence( presence );

                FUNC_OUT
                return true;
            }
        case PresenceStateMessageRole:
            if( presence.type() < 1
                || presence.type() > 6 )
            {
                FUNC_OUT
                return false;
            }

            presence.setStatus( presence.type(), presence.status(), value.toString() );
            account->setRequestedPresence( presence );

            FUNC_OUT
            return true;
        }
    }

    FUNC_OUT
    return false;
}

int
AccountListModel::rowForAccountId( const QString &accountId ) const
{
    FUNC_IN
    for( int i = 0; i < d->mAccounts.count(); ++i )
    {
        if( d->mAccounts.at(i)->objectPath() == accountId )
        {
            FUNC_OUT
            return i;
        }
    }
    FUNC_OUT
    return -1;
}

QStringList
AccountListModel::serviceList() const
{
    FUNC_IN
    // get list of service names
    QStringList services = d->mAccountServiceMap.values();
    // remove duplicates
    services.removeDuplicates();
    // remove empty service names
    services.removeAll( QString() );
    // sort list
    services.sort();
    FUNC_OUT
    return services;
}

bool
AccountListModel::setData( int row,
                           const QString &rolename,
                           const QVariant &value)
{
    FUNC_IN
    QModelIndex index = this->index( row, 0 );
    int role = roleNames().key( rolename.toAscii(), PresenceStateRole );
    FUNC_OUT
    return setData( index, value, role );
}

