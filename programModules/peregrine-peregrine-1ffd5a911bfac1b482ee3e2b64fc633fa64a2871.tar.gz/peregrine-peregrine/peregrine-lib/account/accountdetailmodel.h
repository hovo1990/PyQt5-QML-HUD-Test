/*
 * accountdetailmodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef ACCOUNTDETAILMODEL_H
#define ACCOUNTDETAILMODEL_H

#include "../peregrinetypes.h"

#include <QAbstractItemModel>
#include <QModelIndex>
#include <QPointer>
#include <QString>
#include <QStringList>
#include <QVariant>

namespace Peregrine
{

class AccountDetailModelPrivate;

class AccountDetailModel
    : public QAbstractItemModel
{
    Q_OBJECT

    friend class AccountDetailModelPrivate;

    QPointer<AccountDetailModelPrivate> d;

    /** Maps values of type \em Properties to property names */
    QMap<int, QString> mPropertyNames;

    void initPropertyNames();
    void initRoleNames();

public:
    Q_ENUMS( Columns );
    Q_ENUMS( Properties );
    Q_ENUMS( Roles );

    /**
     * Defines from which account the model should get its data.
     */
    Q_PROPERTY( QString accountPath READ accountPath WRITE setAccountPath );

    /**
     *  Description of the columns.
     */
    enum Columns
    {
        ColumnValue,
        ColumnCount
    };
    /**
     * Properties of the account.
     */
    enum Properties
    {
        // read-write properties
        PropertyAutomaticPresence,
        PropertyRequestedPresence,
        PropertyConnectAutomatically,
        PropertyDisplayName,
        PropertyEnabled,
        PropertyIcon,
        PropertyNickname,
        PropertyCount
    };
    /**
     *  Description of the roles.
     */
    enum Roles
    {
        SecretRole = Qt::UserRole + 1,
        RequiredRole,
        RequiredForRegistrationRole,
        DataTypeRole,
        SectionRole,
        HeaderDataRole,
        RoleCount
    };

    /**
     *  Constructs an AccountDetailModel with the given parent.
     */
    explicit AccountDetailModel( QObject *parent = 0 );
    /**
     *  Constructs an AccountDetailModel with the given parent and
     *  initializes the model with the given connectionManager and
     *  protocol.
     */
    explicit AccountDetailModel( const QString &connectionManager,
                                 const QString &protocol,
                                 QObject *parent = 0 );
    /**
     *  Constructs an AccountDetailModel with the given parent and
     *  initializes the model o use the account described by
     *  accountObjectPath.
     */
    explicit AccountDetailModel( const QString &accountObjectPath,
                                 QObject *parent = 0 );

    /**
     *  get the currently set account path
     */
    QString accountPath();

    /**
     *  See documentation of QAbstractItemModel
     *  @see Qt::QAbstractTableModel::columnCount()
     */
    int columnCount( const QModelIndex &parent = QModelIndex() ) const;

    /**
     *  if model is in creation mode this function returns the name
     *  of connection manager and the protocol
     *  @return the returned QStringList contains two elements.
     *  the first one is the name of the connection manager the
     *  second the name of the protocol
     */
    Q_INVOKABLE QStringList connectionManagerAndProtocol() const;

    /**
     * See documentation of QAbstractItemModel
     * @see Qt::QAbstractTableModel::data()
     */
    QVariant data( const QModelIndex &index,
                   int role = Qt::DisplayRole ) const;
    /**
     * Returns the type of the data.
     * @param index QModelIndex of the requested parameter.
     */
    virtual QVariant::Type dataType( const QModelIndex index ) const;

   /**
    * See documentation of QAbstractItemModel
    * @see Qt::QAbstractTableModel::flags()
    */
    Qt::ItemFlags flags( const QModelIndex &index ) const;

   /**
    * See documentation of QAbstractItemModel
    * @see Qt::QAbstractTableModel::headerData()
    */
    QVariant headerData ( int section,
                          Qt::Orientation orientation,
                          int role = Qt::DisplayRole ) const;

    /**
     * @see Qt::QAbstractItemModel::index()
     */
    QModelIndex index( int row, int column,
                       const QModelIndex &parent = QModelIndex()) const;
    /**
     * returns true if model is in account creation mode
     * account creation mode is active when no account path but the
     * connection manager and protocol is set
     * @return true if in account creation mode
     * \sa setAccountPath() setConnectionManagerAndProtocol()
     */
    bool isAccountCreationMode();
    /**
     * Return whether model was modified. If the model was modified
     * slotSubmit() should be called to store the changes.
     * @return true if modified data is not submited yet
     */
    bool isModified() const;
    /**
     * Inherited from TableModelInterface.
     */
    bool isRequired( QModelIndex index );
    /**
     * Convenience function to get a parameter.
     * @param parameterName Name of the requested parameter.
     */
    Q_INVOKABLE QVariant parameter( const QString &parameterName ) const;
    /**
     * Convenience function to get a parameter.
     * @param index Index of the requested parameter.
     */
    Q_INVOKABLE QVariant parameter( int index ) const;
    /**
     * Returns the type of the parameter.
     * @param parameterName Name of the requested parameter.
     */
    virtual
    QVariant::Type parameterType( const QString &parameterName ) const;
    /**
     * Returns the type of the parameter.
     * @param parameterIndex Index of the requested parameter.
     */
    virtual QVariant::Type parameterType( int parameterIndex ) const;
    /**
     * @see Qt::QAbstractItemModel::parent()
     */
    QModelIndex parent(const QModelIndex &child) const;
    /**
     * Convenience function to get a property.
     * @param propertyName Name of the requested property.
     */
    Q_INVOKABLE QVariant property( const QString &propertyName ) const;
    /**
     * Convenience function to get a property.
     * @param prop The requested property.
     */
    Q_INVOKABLE QVariant property( Properties prop ) const;
    /**
     * Returns the type of the property.
     * @param parameterName Name of the requested property.
     */
    virtual
    QVariant::Type propertyType( const QString &propertyName ) const;
    /**
     * Returns the type of the property.
     * @param property Index of the requested property.
     */
    virtual QVariant::Type propertyType( Properties property ) const;
    /**
     * See documentation of QAbstractItemModel
     * @see Qt::QAbstractTableModel::rowCount()
     */
    int rowCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * set the account path of an account to be displayed / edited
     * @param path the dbus object path of the account
     */
    void setAccountPath( QString path );
    /**
     * set a connection manager and protocol to put model into account
     * creation mode
     * @param cmp This QStringList must contain two elements. The first
     * one has to be the connection manager and the second the protocol
     * to be used
     */
    Q_INVOKABLE void setConnectionManagerAndProtocol( QStringList cmp );
    /**
     * See documentation of QAbstractItemModel
     * @see Qt::QAbstractTableModel::setData()
     */
    bool setData( const QModelIndex &index,
                  const QVariant &value,
                  int role = Qt::EditRole );
    /**
     * Convenience function to set a parameter.
     * @param parameterName Name of the parameter to be set.
     * @param value Value the parameter should be set to.
     */
    Q_INVOKABLE bool setParameter( const QString &parameterName,
                                   const QVariant &value );
    /**
     * Convenience function to set a parameter.
     * @param parameterIndex Index of the parameter to be set.
     * @param value Value the parameter should be set to.
     */
    Q_INVOKABLE bool setParameter( int parameterIndex,
                                   const QVariant &value );
    /**
     * convenience function to set properties
     * @param propertyName defines the property to be set
     * @param value value to be set for property
     */
    Q_INVOKABLE bool setProperty( const QString &propertyName,
                                  const QVariant &value );
    /**
     * convenience function to set properties
     * @param property defines the property to be set
     * @param value value to be set for property
     */
    Q_INVOKABLE bool setProperty( Properties property,
                                  const QVariant &value );

public slots:
    /**
     * A call to this slot removes the currently loaded account
     * if this model is in account creation mode this will just reset
     * the model
     */
    Q_INVOKABLE virtual void remove();
    /**
     * Discard all changes that have been made to the model.
     * @deprecated use slot revert instead
     */
    Q_INVOKABLE virtual void resetValues();
    /**
     * Discard all changes that have been made to the model.
     * @see Qt::QAbstractItemModel::revert()
     */
    Q_INVOKABLE void revert();
    /**
     * Write changed data to the account or create a new account when in
     * account creation mode.
     * @see Qt::QAbstractItemModel::submit()
     */
    Q_INVOKABLE bool submit();

signals:
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( QString message, NotificationTypes type );
    /**
     * This signal is emitted when the current account is removed.
     */
    void signalAccountRemoved();

    /**
     * emitted when Model is initialized and ready to use
     */
    void initialized();

};

}

#endif // ACCOUNTDETAILMODEL_H
