/*
 * accountlistmodel_p.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef ACCOUNTLISTMODEL_P_H
#define ACCOUNTLISTMODEL_P_H

#include <QMap>
#include <QObject>
#include <QPointer>
#include <QString>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/AccountManager>
#include <TelepathyQt4/Feature>
#include <TelepathyQt4/Features>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/SharedPtr>

namespace Peregrine
{

class AccountListModel;

class AccountListModelPrivate
    : public QObject
{
    Q_OBJECT
    friend class AccountListModel;

    static const Tp::Features ACCOUNT_FEATURES;
    static const Tp::Features CONNECTION_FEATURES;

    // data
    QPointer<AccountListModel> mParent;

    Tp::AccountManagerPtr mAccountManager;
    QList<Tp::AccountPtr> mAccounts;
    QMap<QString, QString> mAccountServiceMap;
    bool mAutoConnect;
    int mInitializeCounter;

    bool mOneAccountOnline;

    // functions
    explicit AccountListModelPrivate( AccountListModel *parent );

    bool connectAccount( const Tp::AccountPtr &account );
    bool connectAccountManager( const Tp::AccountManagerPtr &accountManager );
    bool disconnectAccount( const Tp::AccountPtr &account );
    bool disconnectAccountManager( const Tp::AccountManagerPtr &accountManager );

    bool initialized() const;

    int rowForPath( const QString &path );

private slots:
    /**
     * onAccountManagerReady is called after finished was emitted by accountManager.
     */
    void onAccountManagerReady( Tp::PendingOperation *operation );
    /**
     * accountCreated is called after accountCreated was emitted by the
     * accountManager.
     */
    void onAccountManagerNewAccount(const Tp::AccountPtr &account);

    /**
     * this slot is called whenever a Tp::Account changes its connection,
     * create a new connection or lost its connection
     */
    void onAccountConnectionChanged( const Tp::ConnectionPtr &connection );
    /**
     * accountCurrentPresenceChanged is called whenever the current presence of
     * an account changes.
     */
    void onAccountCurrentPresenceChanged( const Tp::Presence &presence );
    /**
     * invoked whenever account goes online / offline
     */
    void onAccountOnlinenessChanged( bool online );
    /**
     * accountReady is called when ever a account becomes ready.
     */
    void onAccountReady( Tp::PendingOperation *operation );
    /**
     * accountRemoved is called after removed was emitted by the account.
     */
    void onAccountRemoved();
    /**
     * this slot gets connected to all signals of an account that might
     * indicate a service name change
     */
    void onAccountServiceChanged();

    /**
     * accountChanged is called when ever a account changes.
     *
     * this function looks up the row corresponding to the account that changed
     * and signals it to the view
     */
    void onAccountChanged();

    /**
     * this slot is called whenever a pending operation finished
     *
     * many functions called on an account object returning a pending ready object
     * we connect these object to this slot to send error/warning messages to the
     * UI
     */
    void onPendingReadyFinished( Tp::PendingOperation *operation );

    /**
     * onConnectionReady is called when ever a connection becomes ready
     */
    void onConnectionReady( Tp::PendingOperation *operation );

};

}

#endif // ACCOUNTLISTMODEL_P_H
