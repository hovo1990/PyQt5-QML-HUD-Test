/*
 * accountdetailmodel.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "accountdetailmodel.h"
#include "accountdetailmodel_p.h"

#include "../peregrineDebugHelper.h"
#include "../peregrineinitializer.h"
#include "../presencestates.h"

#include <TelepathyQt4/PendingAccount>
#include <TelepathyQt4/PendingReady>

using namespace Peregrine;

/* *****************************************************************************
 * AccountDetailModelPrivate
 * ****************************************************************************/

const Tp::Features
AccountDetailModelPrivate::ACCOUNT_FEATURES = ( Tp::Features()
                                                << Tp::Account::FeatureCore
                                                << Tp::Account::FeatureAvatar
                                                << Tp::Account::FeatureProtocolInfo);
const Tp::Features
AccountDetailModelPrivate::ACCOUNT_MANAGER_FEATURES = ( Tp::Features()
                                                        << Tp::AccountManager::FeatureCore);
const Tp::Features
AccountDetailModelPrivate::CONNECTION_MANAGER_FEATURES = ( Tp::Features()
                                                           << Tp::ConnectionManager::FeatureCore);

AccountDetailModelPrivate::AccountDetailModelPrivate( AccountDetailModel *parent )
    : QObject( parent ),
    mParent( parent ),
    mAccountCreationMode( false )
{
    FUNC_IN
    if( mParent.isNull() )
    {
        deleteLater();
        FUNC_OUT
        return;
    }

    mAccountManager = Tp::AccountManager::create();
    connect( mAccountManager->becomeReady(ACCOUNT_MANAGER_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onAccountManagerReady(Tp::PendingOperation *)) );
    FUNC_OUT
}

bool
AccountDetailModelPrivate::connectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( account.data(), SIGNAL(displayNameChanged(QString)),                   this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(iconNameChanged(QString)),                      this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(nicknameChanged(QString)),                      this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(normalizedNameChanged(QString)),                this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(validityChanged(bool)),                         this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(stateChanged(bool)),                            this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(connectsAutomaticallyPropertyChanged(bool)),    this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(firstOnline()),                                 this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(parametersChanged(QVariantMap)),                this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(automaticPresenceChanged(Tp::Presence)),        this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(currentPresenceChanged(Tp::Presence)),          this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(requestedPresenceChanged(Tp::Presence)),        this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(avatarChanged(Tp::Avatar)),                     this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(connectionStatusChanged(Tp::ConnectionStatus)), this, SLOT(slotModelUpdated()) );
    result &= connect( account.data(), SIGNAL(removed()),                                     this, SLOT(onAccountRemoved()), Qt::DirectConnection );

    result &= connect( account.data(), SIGNAL(connectionChanged(Tp::ConnectionPtr)),          this, SLOT(onConnectionChanged(Tp::ConnectionPtr)) );

    onConnectionChanged( account->connection() );

    FUNC_OUT
    return result;
}

bool
AccountDetailModelPrivate::disconnectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.data() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( account.data(), 0, this, 0 );
}

void
AccountDetailModelPrivate::loadProtocolInfo( const QString &protocol )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    if( mConnectionManager.isNull() )
    {
        FUNC_OUT
        return;
    }

    Tp::ProtocolInfoList pil = mConnectionManager->protocols();
    Tp::ProtocolInfo pi;
    foreach( const Tp::ProtocolInfo& i, pil )
    {
        if( i.name() == protocol )
        {
            pi = i;
            break;
        }
    }

    if( !pi.isValid() )
    {
        FUNC_OUT
        return;
    }

    if( mParamList.count() > 0 )
    {
        mParent->beginRemoveRows( QModelIndex(),
                                  AccountDetailModel::PropertyCount,
                                  AccountDetailModel::PropertyCount + mParamList.count() - 1 );
        mParamList.clear();
        mParent->endRemoveRows();
    }

    Tp::ProtocolParameterList list = pi.parameters();

    mParent->beginInsertRows( QModelIndex(),
                              AccountDetailModel::PropertyCount,
                              AccountDetailModel::PropertyCount + list.size() - 1 );
    mParamList = list;
    mParent->endInsertRows();

    FUNC_OUT
}

void
AccountDetailModelPrivate::onAccountChanged()
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    QModelIndex topLeft = mParent->index( 0, 0 );
    QModelIndex bottomRight = mParent->index( mParent->rowCount() - 1, AccountDetailModel::ColumnCount - 1 );
    if( topLeft.isValid() && bottomRight.isValid() )
    {
        emit mParent->dataChanged( topLeft, bottomRight );
    }
    FUNC_OUT
}

void
AccountDetailModelPrivate::onAccountManagerReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();

        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(), NotificationTypeError );

        FUNC_OUT
        return;
    }

    if( !mAccountObjectPath.isEmpty() )
    {
        // get account and make it ready
        mAccount = mAccountManager->accountForPath( mAccountObjectPath );
        connectAccount( mAccount );
        connect( mAccount->becomeReady(ACCOUNT_FEATURES),
                 SIGNAL(finished( Tp::PendingOperation *)),
                 this,
                 SLOT(onAccountReady(Tp::PendingOperation *)) );
    }

    // when in "account creation mode" we need AccountManager
    // and ConnectionManager to be ready
    if( mAccountCreationMode
        && mConnectionManager->isReady(CONNECTION_MANAGER_FEATURES) )
    {
        // emit initialized signal if ConnectionManager is already ready
        emit mParent->initialized();
    }
    FUNC_OUT
}

void
AccountDetailModelPrivate::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    if( operation->isError() ) {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();

        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(), NotificationTypeError );

        m_newParameters.clear();
        m_newProperties.clear();
        m_unsetParameters.clear();
        FUNC_OUT
        return;
    }

    mProtocolName = mAccount->protocolName();
    mConnectionManagerName = mAccount->cmName();

    if( mParamList.count() > 0 )
    {
        mParent->beginRemoveRows( QModelIndex(),
                                  AccountDetailModel::PropertyCount,
                                  AccountDetailModel::PropertyCount + mParamList.count() - 1 );
        mParamList.clear();
        mParent->endRemoveRows();
    }

    QModelIndex topLeft = mParent->index( 0, 0 );
    QModelIndex bottomRight = mParent->index( mParent->rowCount() - 1, AccountDetailModel::ColumnCount - 1 );
    emit mParent->dataChanged( topLeft, bottomRight );

    Tp::ProtocolParameterList list = mAccount->protocolInfo().parameters();

    mParent->beginInsertRows( QModelIndex(),
                              AccountDetailModel::PropertyCount,
                              AccountDetailModel::PropertyCount + list.count() - 1 );
    mParamList = list;
    mParent->endInsertRows();

    // when not in "account creation mode" we can be pretty sure that
    // AccountManager is ready
    emit mParent->initialized();
    FUNC_OUT
}

void
AccountDetailModelPrivate::onAccountRemoved()
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    mParent->beginResetModel();

    if( !mAccount.isNull() )
    {
        disconnectAccount( mAccount );
    }

    // resetting AccountDetailModel
    mAccountObjectPath = QString();
    m_newProperties.clear();
    m_newParameters.clear();
    m_unsetParameters.clear();
    mAccount = Tp::AccountPtr( 0 );
    mConnectionManager = Tp::ConnectionManagerPtr( 0 );
    mConnectionManagerName = QString();
    mProtocolName = QString();
    mAccountCreationMode = false;
    mParamList.clear();

    mParent->endResetModel();
    FUNC_OUT
}

void
AccountDetailModelPrivate::onConnectionManagerReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << ": "
                   << operation->errorMessage();

        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(), NotificationTypeError );

        FUNC_OUT
        return;
    }

    loadProtocolInfo( mProtocolName );
    onAccountChanged();

    // when in "account creation mode" we need AccountManager
    // and ConnectionManager to be ready
    if( mAccountCreationMode
        && mAccountManager->isReady(ACCOUNT_MANAGER_FEATURES) )
    {
        // emit initialized signal if AccountManager is already ready
        emit mParent->initialized();
    }
    FUNC_OUT
}

void
AccountDetailModelPrivate::onPendingAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    mParent->beginResetModel();

    if( !mAccount.isNull() )
    {
        disconnectAccount( mAccount );
    }

    // resetting AccountDetailModel
    mAccountObjectPath = QString();
    m_newProperties.clear();
    m_newParameters.clear();
    m_unsetParameters.clear();
    mAccount = Tp::AccountPtr( 0 );
    mConnectionManager = Tp::ConnectionManagerPtr( 0 );
    mConnectionManagerName = QString();
    mProtocolName = QString();
    mAccountCreationMode = false;
    mParamList.clear();

    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();

        mParent->endResetModel();
        FUNC_OUT
        return;
    }

    Tp::PendingAccount *pa = qobject_cast<Tp::PendingAccount *>( operation );
    if( !pa )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "operation was not a PendingAccount!";

        mParent->endResetModel();
        FUNC_OUT
        return;
    }
    mAccount = pa->account();
    if( mAccount.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "operation has finished with errors";

        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(), NotificationTypeError );

        mParent->endResetModel();
        FUNC_OUT
        return;
    }

    mAccountObjectPath = mAccount->objectPath();

    Q_ASSERT( !mAccount.isNull() );
    connectAccount( mAccount );
    connect( mAccount->becomeReady(ACCOUNT_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onAccountReady(Tp::PendingOperation *)) );

    mParent->endResetModel();

    FUNC_OUT
}

void
AccountDetailModelPrivate::onConnectionChanged( const Tp::ConnectionPtr &connection )
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    if( !connection.isNull() )
    {

        if( !connection->isReady(Tp::Connection::FeatureSimplePresence) )
        {
            connect( connection->becomeReady(Tp::Connection::FeatureSimplePresence),
                     SIGNAL(finished(Tp::PendingOperation *)),
                     this,
                     SLOT(onConnectionReady(Tp::PendingOperation *)) );
        }
    }
    else
    {
        qWarning() << __PRETTY_FUNCTION__ << "connection not available";
    }

    onAccountChanged();
    FUNC_OUT
}

void
AccountDetailModelPrivate::onConnectionReady(Tp::PendingOperation *operation)
{
    FUNC_IN
    Q_ASSERT( !mParent.isNull() );

    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "connection cannot become ready";

        emit mParent->notification( operation->errorName() + ": " + operation->errorMessage(), NotificationTypeWarning );

        FUNC_OUT
        return;
    }

    onAccountChanged();
    FUNC_OUT
}


/* *****************************************************************************
 * AccountDetailModel
 * ****************************************************************************/

void
AccountDetailModel::initPropertyNames()
{
    FUNC_IN
    mPropertyNames.insert( PropertyAutomaticPresence,        "AutomaticPresence"     );
    mPropertyNames.insert( PropertyRequestedPresence,        "RequestedPresence"     );
    mPropertyNames.insert( PropertyConnectAutomatically,     "ConnectAutomatically"  );
    mPropertyNames.insert( PropertyDisplayName,              "DisplayName"           );
    mPropertyNames.insert( PropertyEnabled,                  "Enabled"               );
    mPropertyNames.insert( PropertyIcon,                     "Icon"                  );
    mPropertyNames.insert( PropertyNickname,                 "Nickname"              );
    FUNC_OUT
}

void
AccountDetailModel::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames;
    rolenames.insert( Qt::DisplayRole,             "value" );
    rolenames.insert( SecretRole,                  "secret" );
    rolenames.insert( RequiredRole,                "required" );
    rolenames.insert( RequiredForRegistrationRole, "requiredForRegistration" );
    rolenames.insert( DataTypeRole,                "dataType" );
    rolenames.insert( SectionRole,                 "section" );
    rolenames.insert( HeaderDataRole,              "headerData" );
    setRoleNames(rolenames);
    FUNC_OUT
}

AccountDetailModel::AccountDetailModel( QObject *parent )
    : QAbstractItemModel( parent )
{
    FUNC_IN
    Peregrine::initialize();

    d = new AccountDetailModelPrivate( this );

    initPropertyNames();
    initRoleNames();
    FUNC_OUT
}

AccountDetailModel::AccountDetailModel( const QString &connectionManager,
                                        const QString &protocol,
                                        QObject *parent )
    : QAbstractItemModel( parent )
{
    FUNC_IN
    Peregrine::initialize();

    d = new AccountDetailModelPrivate( this );
    setConnectionManagerAndProtocol( QStringList() << connectionManager << protocol );

    initPropertyNames();
    initRoleNames();

    FUNC_OUT
}

AccountDetailModel::AccountDetailModel( const QString &accountObjectPath,
                                        QObject *parent )
    : QAbstractItemModel( parent )
{
    FUNC_IN
    Peregrine::initialize();

    d = new AccountDetailModelPrivate( this );
    setAccountPath( accountObjectPath );

    initPropertyNames();
    initRoleNames();
    FUNC_OUT
}

QString
AccountDetailModel::accountPath()
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    FUNC_OUT
    return d->mAccountObjectPath;
}

int
AccountDetailModel::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return ColumnCount;
}

QStringList
AccountDetailModel::connectionManagerAndProtocol() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    FUNC_OUT
    return QStringList() << d->mConnectionManagerName << d->mProtocolName;
}

QVariant
AccountDetailModel::data( const QModelIndex &index, int role ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !d->mAccountCreationMode
        && d->mAccount.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "need account object when not in account creation mode";
        FUNC_OUT
        return QVariant();
    }

    if( d->mAccount.data()
        && !d->mAccount->isReady(AccountDetailModelPrivate::ACCOUNT_FEATURES) )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "Tp::Account not ready yet";
        FUNC_OUT
        return QVariant();
    }

    if( !index.isValid()
        || index.column() < 0
        || index.column() >= ColumnCount
        || index.row() < 0
        || index.row() >= PropertyCount + d->mParamList.count() )
    {
        FUNC_OUT
        return QVariant();
    }

    if( index.row() < PropertyCount )
    {
        // handle properties
        switch( role )
        {
            case Qt::DisplayRole:
            case Qt::EditRole:
                FUNC_OUT
                return this->property(
                           static_cast<Properties>( index.row() ) );
            case SecretRole:
            case RequiredRole:
            case RequiredForRegistrationRole:
                FUNC_OUT
                return false;
            case DataTypeRole:
                switch( this->propertyType(
                            static_cast<Properties>( index.row() ) ) )
                {
                    case QVariant::String:
                        FUNC_OUT
                        return "string";
                    case QVariant::Bool:
                        FUNC_OUT
                        return "bool";
                    default:
                        qWarning() << __PRETTY_FUNCTION__
                                   << "Property is another type:"
                                   << this->propertyType(
                                      static_cast<Properties>( index.row() ) );
                        FUNC_OUT
                        return QVariant();
                }
                FUNC_OUT
                return QVariant();
            case SectionRole:
                FUNC_OUT
                return QString( "properties" );
            case HeaderDataRole:
                FUNC_OUT
                return headerData( index.row(), Qt::Vertical );
            default:
                FUNC_OUT
                return QVariant();
        }
    } else if( index.row() < (PropertyCount + d->mParamList.size()) )
    {
        switch( role )
        {
        case Qt::DisplayRole:
        case Qt::EditRole:
            FUNC_OUT
            return parameter( index.row() - PropertyCount );
        case SecretRole:
            FUNC_OUT
            return d->mParamList.at( index.row() - PropertyCount )
                    .isSecret();
        case RequiredRole:
            FUNC_OUT
            return d->mParamList.at( index.row() - PropertyCount )
                    .isRequired();
        case RequiredForRegistrationRole:
            FUNC_OUT
            return d->mParamList.at( index.row() - PropertyCount )
                    .isRequiredForRegistration();
        case DataTypeRole:
            switch( d->mParamList.at(index.row() - PropertyCount).type() )
            {
            case QVariant::Bool:
                FUNC_OUT
                return "bool";
            case QVariant::Int:
                FUNC_OUT
                return "string";
            case QVariant::String:
                FUNC_OUT
                return "string";
            case QVariant::StringList:
                FUNC_OUT
                return "list";
            case QVariant::UInt:
                FUNC_OUT
                return "string";
            default:
                qWarning() << __PRETTY_FUNCTION__
                           << "Parameter is another type:"
                           << d->mParamList.at
                                   (index.row() - PropertyCount).type();
                FUNC_OUT
                return QVariant();
            }
            FUNC_OUT
            return QVariant();
        case SectionRole:
            FUNC_OUT
            return QString( "parameter" );
        case HeaderDataRole:
            FUNC_OUT
            return headerData( index.row(), Qt::Vertical );
        default:
            FUNC_OUT
            return QVariant();
        } //switch
    } //if

    FUNC_OUT
    return QVariant();
}

QVariant::Type
AccountDetailModel::dataType( const QModelIndex index ) const
{
    FUNC_IN
    if( !index.isValid() )
    {
        FUNC_OUT
        return QVariant::Invalid;
    }

    if( index.row() < PropertyCount )
    {
        FUNC_OUT
        return propertyType( static_cast<Properties>( index.row() ) );
    }
    else
    {
        FUNC_OUT
        return parameterType( static_cast<Properties>(
                                                 index.row() - PropertyCount) );
    }
    FUNC_OUT
}

Qt::ItemFlags
AccountDetailModel::flags( const QModelIndex &index ) const
{
    FUNC_IN
    if( !index.isValid() )
    {
        FUNC_OUT
        return Qt::NoItemFlags;
    }

    if( index.column() == ColumnValue )
    {
        FUNC_OUT
        return QAbstractItemModel::flags( index ) | Qt::ItemIsEditable;
    }

    FUNC_OUT
    return QAbstractItemModel::flags( index );
}

QVariant
AccountDetailModel::headerData ( int section,
                                Qt::Orientation orientation,
                                int role ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( role == Qt::DisplayRole )
    {
        switch( orientation )
        {
        case Qt::Horizontal:
            if( section < ColumnCount )
            {
                FUNC_OUT
                return tr( "Data" );
            }
            FUNC_OUT
            return QVariant();
        case Qt::Vertical:
            if( section < PropertyCount )
            {
                FUNC_OUT
                return mPropertyNames.value( section, QString(tr("unknown")) );
            }
            else if( section < (PropertyCount + d->mParamList.count()) )
            {
                FUNC_OUT
                return d->mParamList.at( section - PropertyCount ).name();
            }
        }
    }

    FUNC_OUT
    return QAbstractItemModel::headerData( section, orientation, role );
}

QModelIndex
AccountDetailModel::index( int row,
                           int column,
                           const QModelIndex &parent ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( parent.isValid() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    if( column < 0
        || column >= ColumnCount
        || row < 0
        || row > rowCount() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    FUNC_OUT
    return createIndex( row, column, d.data() );
}

bool
AccountDetailModel::isAccountCreationMode()
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );
    FUNC_OUT
    return d->mAccountCreationMode;
}

bool
AccountDetailModel::isModified() const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( d->mAccountCreationMode )
    {
        if( (!d->mConnectionManagerName.isNull()
            || !d->mProtocolName.isNull()
            || d->m_newProperties.count() > 0
            || d->m_newParameters.count() > 0 ) )
            {
            FUNC_OUT
            return true;
        }
        else
        {
            FUNC_OUT
            return false;
        }
    }

    if( !d->mAccount.data()
        || !d->mAccount->isReady(AccountDetailModelPrivate::ACCOUNT_FEATURES) )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "Not ready or no Tp::Account object present.";
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return ( !d->m_newProperties.isEmpty()
             || !d->m_newParameters.isEmpty() );
}

bool
AccountDetailModel::isRequired( QModelIndex index )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( index.row() < PropertyCount )
    {
        FUNC_OUT
        return false;
    }
    else
    {
        int i = index.row() - PropertyCount;
        if( i < d->mParamList.count() )
        {
            FUNC_OUT
            return d->mParamList.at(i).type();
        }
    }
    FUNC_OUT
    return false;
}

QVariant
AccountDetailModel::parameter( const QString &parameterName ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( d->m_unsetParameters.contains( parameterName ) ) {
        // user has already unset this parameter
        FUNC_OUT
        return QVariant();
    }

    if( !d->mAccount.data()
        || d->m_newParameters.contains(parameterName) )
    {
        FUNC_OUT
        return d->m_newParameters.value( parameterName, QVariant() );
    }
    else
    {
        if( !d->mAccount->isReady(AccountDetailModelPrivate::ACCOUNT_FEATURES) )
        {
            FUNC_OUT
            return QVariant();
        }

        FUNC_OUT
        return d->mAccount->parameters().value( parameterName );
    }
    FUNC_OUT
}

QVariant
AccountDetailModel::parameter( int index ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( index < 0
        || index >= d->mParamList.count() ) {
        FUNC_OUT
        return QVariant();
    }

    FUNC_OUT
    return parameter( d->mParamList.at(index).name() );
}

QVariant::Type
AccountDetailModel::parameterType( const QString &parameterName ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    foreach( const Tp::ProtocolParameter &param, d->mParamList )
    {
        if( param.name() == parameterName )
        {
            FUNC_OUT
            return param.type();
        }
    }

    FUNC_OUT
    return QVariant::Invalid;
}

QVariant::Type
AccountDetailModel::parameterType( int parameterIndex ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( parameterIndex < 0
        || parameterIndex >= d->mParamList.size() )
    {
        FUNC_OUT
        return QVariant::Invalid;
    }

    FUNC_OUT
    return d->mParamList.at( parameterIndex ).type();
}

QVariant
AccountDetailModel::property( const QString &propertyName ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    QVariant rvalue = property( static_cast<Properties>(
                                        mPropertyNames.key(propertyName, -1)) );
    FUNC_OUT
    return rvalue;
}

QModelIndex
AccountDetailModel::parent( const QModelIndex &child ) const
{
    FUNC_IN
    Q_UNUSED( child );
    FUNC_OUT
    return QModelIndex();
}

QVariant
AccountDetailModel::property( Properties property ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( d->mAccount.data()
        && !d->mAccount->isReady(AccountDetailModelPrivate::ACCOUNT_FEATURES) )
    {
        FUNC_OUT
        return QVariant();
    }

    switch( property )
    {
    case PropertyAutomaticPresence:
        if( d->mAccount.isNull()
           || d->m_newProperties.contains(PropertyAutomaticPresence) )
        {
            FUNC_OUT
            return d->m_newProperties.value( PropertyAutomaticPresence,
                                             PRESENCE_UNSET.status() );
        }
        FUNC_OUT
        return PRESENCE_STATE_NAMES.at( d->mAccount->automaticPresence().type() );
    case PropertyRequestedPresence:
        if( d->mAccount.isNull()
            || d->m_newProperties.contains(PropertyRequestedPresence) )
        {
            FUNC_OUT
            return d->m_newProperties.value( PropertyRequestedPresence,
                                             PRESENCE_UNSET.status() );
        }
        FUNC_OUT
        return PRESENCE_STATE_NAMES.at( d->mAccount->requestedPresence().type() );
    case PropertyConnectAutomatically:
        if( d->mAccount.isNull()
            || d->m_newProperties.contains(PropertyConnectAutomatically) )
        {
            FUNC_OUT
            return d->m_newProperties.value( PropertyConnectAutomatically, false );
        }
        FUNC_OUT
        return d->mAccount->connectsAutomatically();
    case PropertyDisplayName:
        if( d->mAccount.isNull()
        || d->m_newProperties.contains( PropertyDisplayName ) )
        {
            FUNC_OUT
            return d->m_newProperties.value( PropertyDisplayName, QString() );
        }
        FUNC_OUT
        return d->mAccount->displayName();
    case PropertyEnabled:
        if( d->mAccount.isNull()
            || d->m_newProperties.contains( PropertyEnabled ) )
        {
            FUNC_OUT
            return d->m_newProperties.value( PropertyEnabled, false );
        }
        FUNC_OUT
        return d->mAccount->isEnabled();
    case PropertyIcon:
        if( d->mAccount.isNull()
            || d->m_newProperties.contains( PropertyIcon ) )
        {
            FUNC_OUT
            return d->m_newProperties.value( PropertyIcon, QString() );
        }
        FUNC_OUT
        return d->mAccount->iconName();
    case PropertyNickname:
        if( d->mAccount.isNull()
            || d->m_newProperties.contains( PropertyNickname ) )
        {
            FUNC_OUT
            return d->m_newProperties.value( PropertyNickname, QString() );
        }
        FUNC_OUT
        return d->mAccount->nickname();

    case PropertyCount:
        FUNC_OUT
        return QVariant();
    }

    FUNC_OUT
    return QVariant();
}

QVariant::Type
AccountDetailModel::propertyType( const QString &propertyName ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    int index = mPropertyNames.key( propertyName, -1 );
    if( index < 0 )
    {
        FUNC_OUT
        return QVariant::Invalid;
    }

    FUNC_OUT
    return propertyType( static_cast<Properties>( index ) );
}

QVariant::Type
AccountDetailModel::propertyType( Properties property ) const
{
    FUNC_IN
    switch(property)
    {
    case PropertyAutomaticPresence:
    case PropertyRequestedPresence:
    case PropertyDisplayName:
    case PropertyIcon:
    case PropertyNickname:
        FUNC_OUT
        return QVariant::String;
    case PropertyConnectAutomatically:
    case PropertyEnabled:
        FUNC_OUT
        return QVariant::Bool;

    case PropertyCount:
        FUNC_OUT
        return QVariant::Invalid;
    }

    FUNC_OUT
    return QVariant::Invalid;
}

int
AccountDetailModel::rowCount( const QModelIndex &parent ) const
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return PropertyCount + d->mParamList.count();
}

void
AccountDetailModel::setAccountPath( QString path )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    beginResetModel();

    if( !d->mAccount.isNull() )
    {
        d->disconnectAccount( d->mAccount );
    }

    // resetting AccountDetailModel
    d->mAccountObjectPath = QString();
    d->m_newProperties.clear();
    d->m_newParameters.clear();
    d->m_unsetParameters.clear();
    d->mAccount = Tp::AccountPtr( 0 );
    d->mConnectionManager = Tp::ConnectionManagerPtr( 0 );
    d->mConnectionManagerName = "";
    d->mProtocolName = "";
    d->mAccountCreationMode = false;
    d->mParamList.clear();

    d->mAccountObjectPath = path;

    d->mAccount = d->mAccountManager->accountForPath( d->mAccountObjectPath );
    Q_ASSERT( !d->mAccount.isNull() );
    d->connectAccount( d->mAccount );
    connect( d->mAccount->becomeReady(AccountDetailModelPrivate::ACCOUNT_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             d,
             SLOT(onAccountReady(Tp::PendingOperation *)) );

    endResetModel();
    FUNC_OUT
}

void
AccountDetailModel::setConnectionManagerAndProtocol( QStringList cmp )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    beginResetModel();

    if( !d->mAccount.isNull() )
    {
        d->disconnectAccount( d->mAccount );
    }

    // resetting AccountDetailModel
    d->mAccountObjectPath = QString();
    d->m_newProperties.clear();
    d->m_newParameters.clear();
    d->m_unsetParameters.clear();
    d->mAccount = Tp::AccountPtr( 0 );
    d->mConnectionManager = Tp::ConnectionManagerPtr( 0 );
    d->mConnectionManagerName = "";
    d->mProtocolName = "";
    d->mAccountCreationMode = false;
    d->mParamList.clear();

    d->mConnectionManagerName = cmp.at(0);
    d->mProtocolName = cmp.at(1);
    d->mAccountCreationMode = true;

    d->mConnectionManager = Tp::ConnectionManager::create( d->mConnectionManagerName );
    connect( d->mConnectionManager->becomeReady(AccountDetailModelPrivate::CONNECTION_MANAGER_FEATURES),
             SIGNAL(finished(Tp::PendingOperation *)),
             d,
             SLOT(onConnectionManagerReady(Tp::PendingOperation *)) );

    endResetModel();
    FUNC_OUT
}

bool
AccountDetailModel::setData(const QModelIndex &index,
                            const QVariant &value,
                            int role)
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( !index.isValid()
        || role != Qt::EditRole
        || index.column() >= ColumnCount )
    {
        FUNC_OUT
        return false;
    }

    bool result = false;
    if( (index.row() >= 0)
        && (index.row() < PropertyCount) )
    {
        result = setProperty( static_cast<Properties>( index.row()), value );
    }
    else if( (index.row() >= PropertyCount)
             && (index.row() < (d->mAccount->parameters()
                                        .count() + PropertyCount)) )
    {
        result = setParameter( index.row() - PropertyCount, value );
    }
    else
    {
        FUNC_OUT
        return false;
    }

    if( result )
    {
        emit dataChanged( index, index );
    }
    FUNC_OUT
    return result;
}

bool
AccountDetailModel::setParameter( const QString &parameterName,
                                  const QVariant &value )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    int parameterIndex = -1;

    for( int i = 0; i < d->mParamList.size(); ++i )
    {
        if( d->mParamList.at(i).name() == parameterName )
        {
            parameterIndex = i;
            break;
        }
    }
    if( parameterIndex < 0 )
    {
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return setParameter( parameterIndex, value );
}

bool
AccountDetailModel::setParameter( int parameterIndex,
                                  const QVariant &value )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    QString parameterName = d->mParamList.at( parameterIndex ).name();
    if( parameterName.isEmpty() )
    {
        FUNC_OUT
        return false;
    }

    if( value == QVariant() )
    {
        // unset value
        d->m_newParameters.remove( parameterName );
        if( !d->m_unsetParameters.contains(parameterName) )
        {
            d->m_unsetParameters.insert( d->m_unsetParameters.size(), parameterName );
        }
        emit dataChanged( index(PropertyCount + parameterIndex, ColumnValue),
                          index(PropertyCount + parameterIndex, ColumnCount) );
        FUNC_OUT
        return true;
    } else
    {
        // set value we have to convert the value!
        QVariant::Type type = d->mParamList.at( parameterIndex ).type();
        if( value.canConvert( type ) )
        {
            QVariant copy_value = value;
            copy_value.convert( type );
            d->m_newParameters.insert( d->mParamList.at( parameterIndex ).name(),
                                       copy_value );

            if( d->m_unsetParameters.contains( parameterName ) )
            {
                d->m_unsetParameters.removeAll( parameterName );
            }
            emit dataChanged( index(PropertyCount + parameterIndex, ColumnValue),
                              index(PropertyCount + parameterIndex, ColumnCount) );
            FUNC_OUT
            return true;
        }
        FUNC_OUT
        return false;
    }
    FUNC_OUT
}

bool
AccountDetailModel::setProperty( const QString &propertyName,
                                 const QVariant &value )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    int property = mPropertyNames.key( propertyName, -1 );
    if( property < 0 )
    {
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return setProperty( static_cast<Properties>(property), value );
}

bool
AccountDetailModel::setProperty( Properties property,
                                 const QVariant &value )
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    switch( property )
    {
    case PropertyAutomaticPresence:
    case PropertyRequestedPresence:
        if( value.canConvert( QVariant::String ) )
        {
            QVariant copy_value = value;
            copy_value.convert( QVariant::String );
            d->m_newProperties.insert( property, copy_value );
            emit dataChanged( index(property, ColumnValue),
                              index(property, ColumnCount) );
            FUNC_OUT
            return true;
        }
        FUNC_OUT
        return false;
    case PropertyConnectAutomatically:
    case PropertyEnabled:
        if( value.canConvert( QVariant::Bool ) )
        {
            QVariant copy_value = value;
            copy_value.convert( QVariant::Bool );
            d->m_newProperties.insert( property, copy_value );
            emit dataChanged( index(property, ColumnValue),
                              index(property, ColumnCount) );
            FUNC_OUT
            return true;
        }
        FUNC_OUT
        return false;
    case PropertyDisplayName:
    case PropertyIcon:
    case PropertyNickname:
        if( value.canConvert( QVariant::String ) )
        {
            QVariant copy_value = value;
            copy_value.convert( QVariant::String );
            d->m_newProperties.insert( property, copy_value );
            emit dataChanged( index(property, ColumnValue),
                              index(property, ColumnCount) );
            FUNC_OUT
            return true;
        }
        FUNC_OUT
        return false;

    case PropertyCount:
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return false;
}

void
AccountDetailModel::remove()
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    beginResetModel();

    if( !d->mAccount.isNull() )
    {
        d->disconnectAccount( d->mAccount );
        d->mAccount->remove();
    }

    // resetting AccountDetailModel
    d->mAccountObjectPath = QString();
    d->m_newProperties.clear();
    d->m_newParameters.clear();
    d->m_unsetParameters.clear();
    d->mAccount = Tp::AccountPtr( 0 );
    d->mConnectionManager = Tp::ConnectionManagerPtr( 0 );
    d->mConnectionManagerName = "";
    d->mProtocolName = "";
    d->mAccountCreationMode = false;
    d->mParamList.clear();

    endResetModel();
    FUNC_OUT
}

void
AccountDetailModel::resetValues()
{
    FUNC_IN
    revert();
    FUNC_OUT
}

void
AccountDetailModel::revert()
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    d->m_newParameters.clear();
    d->m_newProperties.clear();
    d->m_unsetParameters.clear();

    QModelIndex topLeft = index( 0, 0 );
    QModelIndex bottomRight = index( rowCount(), ColumnCount );
    emit dataChanged( topLeft, bottomRight );
    FUNC_OUT
}

bool
AccountDetailModel::submit()
{
    FUNC_IN
    Q_ASSERT( !d.isNull() );

    if( d->mAccountCreationMode )
    {
        if( !d->mAccountManager->isReady(AccountDetailModelPrivate::ACCOUNT_MANAGER_FEATURES) )
        {
            qWarning() << __PRETTY_FUNCTION__
                       << "AccountManager not ready!";
            FUNC_OUT
            return false;
        }

        // check if all required parameters are given
        if( d->mConnectionManagerName.isEmpty()
            || d->mProtocolName.isEmpty() )
        {
            FUNC_OUT
            return false;
        }

        foreach( const Tp::ProtocolParameter& param, d->mParamList )
        {
            if( param.isRequired() )
            {
                if( !d->m_newParameters.contains( param.name() ) )
                {
                    // TODO: create a error message
                    qWarning() << __PRETTY_FUNCTION__
                               << "Parameter "
                               << param.name()
                               << " required";
                    FUNC_OUT
                    return false;
                }
            }
        }

        QString displayName = d->m_newProperties.value( PropertyDisplayName )
                                                                    .toString();
        if( displayName.isNull() )
        {
            displayName = d->m_newParameters.value( "account" ).toString();
        }

        QVariantMap propertyMap;
        foreach( int i, d->m_newProperties.keys() )
        {
            if( i == PropertyDisplayName )
            {
                continue;
            }
            propertyMap.insert( "org.freedesktop.Telepathy.Account." +
                                mPropertyNames.value(i, ""),
                                d->m_newProperties.value(i) );
        }
        propertyMap.remove( "org.freedesktop.Telepathy.Account." );

        Tp::PendingAccount *pa = d->mAccountManager->createAccount( d->mConnectionManagerName,
                                                                    d->mProtocolName,
                                                                    displayName,
                                                                    d->m_newParameters,
                                                                    propertyMap);
        connect( pa,
                 SIGNAL(finished(Tp::PendingOperation *)),
                 d,
                 SLOT(onPendingAccountReady(Tp::PendingOperation *)) );

        FUNC_OUT
        return true;
    }

    if( !d->mAccount.data()
        || !d->mAccount->isValidAccount() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "no or not valid account set";
        FUNC_OUT
        return false;
    }

    if( !d->mAccount->isReady(AccountDetailModelPrivate::ACCOUNT_FEATURES) )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "account not ready yet";
        FUNC_OUT
        return false;
    }

    if( !isModified() )
    {
        // nothing to do
        FUNC_OUT
        return true;
    }

    // disconnect to do not get update notifications
    d->disconnectAccount( d->mAccount );

//    mAccount->setProperties( m_newProperties );
    //there is no setter for account properties
    //so we have to do it manually
    foreach( int property, d->m_newProperties.keys() )
    {
        switch( property )
        {
            case PropertyAutomaticPresence:
                if( d->m_newProperties.value(property)
                        .canConvert<Tp::SimplePresence>() )
                {
                    int i = PRESENCE_STATE_NAMES.indexOf(
                             d->m_newProperties.value(property)
                                            .value<QString>() );

                    if( i > PresenceStateUnset
                        || i < PresenceStateUnknown )
                    {
                        d->mAccount->setAutomaticPresence( PRESENCE_STATES.at(i) );
                    }
                }
                break;
            case PropertyRequestedPresence:
                if( d->m_newProperties.value( property )
                                   .canConvert<Tp::SimplePresence>() )
                {
                    int i = PRESENCE_STATE_NAMES.indexOf( d->m_newProperties
                                                         .value(property)
                                                         .value<QString>() );
                    if( i > PresenceStateUnset || i < PresenceStateUnknown )
                    {
                        d->mAccount->setRequestedPresence( PRESENCE_STATES.at(i) );
                    }
                }
                break;
            case PropertyConnectAutomatically:
                d->mAccount->setConnectsAutomatically( d->m_newProperties
                                                    .value(property)
                                                    .toBool() );
                break;
            case PropertyDisplayName:
                d->mAccount->setDisplayName( d->m_newProperties
                                          .value(property)
                                          .toString() );
                break;
            case PropertyEnabled:
                d->mAccount->setEnabled( d->m_newProperties
                                      .value(property)
                                      .toBool() );
                break;
            case PropertyIcon:
                d->mAccount->setIconName( d->m_newProperties
                                       .value(property)
                                       .toString() );
                break;
            case PropertyNickname:
                d->mAccount->setNickname( d->m_newProperties
                                       .value(property)
                                       .toString() );
                break;
        }
    }

    d->mAccount->updateParameters( d->m_newParameters, d->m_unsetParameters );

    // reconnect signals
    d->connectAccount( d->mAccount );

    d->m_newParameters.clear();
    d->m_newProperties.clear();
    d->m_unsetParameters.clear();

    QModelIndex topLeft = index( 0, 0 );
    QModelIndex bottomRight = index( rowCount(), ColumnCount );
    emit dataChanged( topLeft, bottomRight );

    FUNC_OUT
    return true;
}

