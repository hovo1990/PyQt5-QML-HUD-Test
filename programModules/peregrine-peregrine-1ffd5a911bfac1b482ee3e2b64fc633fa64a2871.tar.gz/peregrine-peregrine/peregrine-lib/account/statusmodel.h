/*
 * statusmodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef STATUSMODEL_H
#define STATUSMODEL_H

#include "../peregrinetypes.h"

#include <QAbstractItemModel>
#include <QModelIndex>
#include <QPointer>
#include <QString>
#include <QStringList>

namespace Peregrine
{

class StatusModelPrivate;

class StatusModel : public QAbstractItemModel
{
    Q_OBJECT

    friend class StatusModelPrivate;

    QPointer<StatusModelPrivate> d;

    void initRoleNames();

public:
    Q_ENUMS( ColumnTypes );
    Q_ENUMS( NotificationTypes );
    Q_PROPERTY( QString globalPresence READ globalPresence WRITE setGlobalPresence NOTIFY globalPresenceChanged );

    /**
     * Column types.
     * Description of the columns and its meaning.
     */
    enum ColumnTypes
    {
        ColumnPresenceStates,
        ColumnCount
    };

    explicit StatusModel( QObject *parent = 0 );
    ~StatusModel();

    /**
     * @see Qt::QAbstractItemModel::columnCount()
     */
    int columnCount( const QModelIndex &parent = QModelIndex() ) const;

    /**
     * @see Qt::QAbstractItemModel::data()
     */
    QVariant data( const QModelIndex &index,
                   int role = Qt::DisplayRole ) const;

    /**
     * returns the current global Presence
     */
    QString globalPresence() const;

    /**
     * @see Qt::QAbstractItemModel::index()
     */
    QModelIndex index( int row,
                       int column,
                       const QModelIndex &parent = QModelIndex() ) const;

    /**
     * Return true, if at least one account as status
     * "ConnectionStateConnected"
     */
    Q_INVOKABLE bool oneAccountOnline() const;

    /**
     * @see Qt::QAbstractItemModel::parent()
     */
    QModelIndex parent( const QModelIndex &child ) const;

    /**
     * @see Qt::QAbstractItemModel::rowCount()
     */
    int rowCount( const QModelIndex &parent = QModelIndex() ) const;

    /**
     * Set the current presence.
     * @param accountPath The dbus object path of an account to set the
     * presence for
     * @param presence The new presence to change to.
     * @param message The message that should be displayed to the contacts
     */
    Q_INVOKABLE bool setCurrentPresence( const QString& accountPath,
                                         const QString& presence,
                                         const QString& message = QString() );

    /**
     * Set the current presence for all connections with global status.
     * @param presence The new presence to change to.
     * @param message The message that should be displayed to the contacts
     */
    Q_INVOKABLE void setCurrentPresenceGlobal( const QString &presence,
                                               const QString &message = QString() );

    /**
     * Set the current presence for all connections to \em presence.
     * @param presence The new presence state to change to.
     */
    void setGlobalPresence( const QString &presence );

signals:
    /**
     * This signal notifies about changes of global presence
     */
    void globalPresenceChanged( const QString& presence );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( QString message, NotificationTypes type );

public slots:

};

}

#endif // STATUSMODEL_H
