#!/bin/sh
#
# new_test.sh
#
# Copyright (C) 2011 basysKom GmbH
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#
# This script generates a skeleton for a new test case
# USAGE: ./new_test.sh NameOfTestCase

if [ "x$1x" = "xx" ] || [ "x$1x" = "x--helpx" ]; then
  echo "USAGE: $0 NameOfTestCase"
  exit
fi

# FIXME: add some basic sanity checks

mkdir test$1
cp template/test.pro test$1/test$1.pro
cp template/test.cpp test$1/test.cpp
cp template/test.h test$1/test.h

# add a line to a general .pro file so all test cases get build automatically
echo "SUBDIRS += test$1" >> tests.pro

# re-create the peregrine-tests.xml to include all tests
./scripts/create_peregrine_xml.sh
