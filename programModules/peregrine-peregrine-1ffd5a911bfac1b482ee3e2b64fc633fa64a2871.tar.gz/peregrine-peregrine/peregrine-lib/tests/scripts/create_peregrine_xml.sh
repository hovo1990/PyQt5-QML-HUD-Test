#!/bin/sh
#
# create_peregrine_xml.sh
#
# Copyright (C) 2011 basysKom GmbH
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#
# Helper script to (re)create a peregrine-tests.xml file for testrunner-lite
# This checks for all existing testXXX directories and adds a testcase for each
# (has to be executed in the main "tests" subdirectory)
# Note: testframe (the library) is automatically skipped

cat ./template/peregrine_tests_header.xml > peregrine-tests.xml

for i in test*; do
  if [ -d $i -a ${i#test} != frame ]; then
    TESTNAME=${i#test}
    echo "Adding testcase: $TESTNAME"
    cat ./template/peregrine_tests_single.xml | sed s/%TESTNAME%/$TESTNAME/g >>peregrine-tests.xml
  fi
done

cat ./template/peregrine_tests_footer.xml >>peregrine-tests.xml
