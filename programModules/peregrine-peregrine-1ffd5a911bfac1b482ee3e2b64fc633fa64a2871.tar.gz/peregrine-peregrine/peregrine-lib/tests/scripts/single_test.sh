#!/bin/sh
#
# single_test.sh
#
# Copyright (C) 2011 basysKom GmbH
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#

DAEMONS="mission-control-5 telepathy-gabble"

function shutdown_daemon(){
for daemon in ${@}; do
	echo "Shutting down ${daemon}"
	killall -u ${USER} ${daemon}
	if [ -f "/tmp/${daemon}.log" ]; then
		echo
		echo "-----------------------------------------------------------------"
		echo "Dump and remove temporary /tmp/${daemon}.log"
		cat /tmp/${daemon}.log
		rm /tmp/${daemon}.log
	fi
done
}

function start_daemon(){
local PATH="$PATH:/usr/libexec/"
local export MC_DEBUG=all GABBLE_PERSIST=1 GABBLE_DEBUG=all
for daemon in ${@}; do
	echo "Starting ${daemon}"
	${daemon} > /tmp/${daemon}.log 2>&1 &
done
sleep 1
}


# clear out starter address to prevent telepathy from connecting to the wrong bus
DBUS_STARTER_ADDRESS=

# make sure there is no other telepathy stuff running for this user
shutdown_daemon ${DAEMONS}

# configure with provided config files FIXME
rm -rf ~/.mission-control

# start daemons in a controlled manner
echo Setting up telepathy...
start_daemon ${DAEMONS}

# run the test
echo Starting test...
/usr/lib/peregrine-lib-tests/$1 >/tmp/$1.log 2>/tmp/$1-error.log
TESTRETURN=$?
cat /tmp/$1-error.log >> /tmp/$1.log
cat /tmp/$1-error.log >&2

echo ...test finished

# write condensed result to stdout
echo Results:
grep "\(FAIL\|SUCCESS\)" /tmp/$1.log

# shutdown telepathy stuff again
shutdown_daemon ${DAEMONS}

exit $TESTRETURN
