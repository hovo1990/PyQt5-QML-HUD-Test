/*
* main.cpp
*
* Copyright (C) 2011 basysKom GmbH
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "logger.h"
#include "mctool.h"

#include <QtCore/QCoreApplication>
#include <QtCore/QTimer>

#include <glib-object.h>
#include <gst/gst.h>

#include <TelepathyQt4/Types>
#include <TelepathyQt4/Debug>

// this has to be implemented in the testcase!
extern QObject* createTest();

/**
    General initialization of Telepathy.
    We also intialize GStreamer always here, in case the test case
    might need it.
    Warning and debug is set to MAX to provide as much output as possible
    in the main log file.
*/
void init()
{
    g_type_init();

    gst_init( NULL, NULL );

    Tp::registerTypes();
    Tp::enableDebug( true );
    Tp::enableWarnings( true );
}

/**
    This can be used for de-initialization, currently just empty and
    only added for symmetry reasons.
*/
void deinit()
{
  
}

/**
    Main function.
    This one initializes everything, creates the test case, connects
    all standard signals and runs an event loop, running the test.
    Afterwards cleanup is handled.
*/
int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);

    init();

    QObject* test = createTest();

    QObject::connect(test, SIGNAL(testCompleted()), test, SLOT(check()));
    QObject::connect(test, SIGNAL(checkCompleted()), &app, SLOT(quit()));
    QObject::connect(test, SIGNAL(checkFailed()), &app, SLOT(quit()));

    QMetaObject::invokeMethod(test, "prepare");

    QTimer::singleShot(0, test, SLOT(run()));
    app.exec();

    QMetaObject::invokeMethod(test, "cleanup");

    deinit();

    return Logger::instance()->result();
}
