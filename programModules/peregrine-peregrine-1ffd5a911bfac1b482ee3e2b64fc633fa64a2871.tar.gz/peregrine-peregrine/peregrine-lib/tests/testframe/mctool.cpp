/*
* mctool.cpp
*
* Copyright (C) 2011 basysKom GmbH
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "mctool.h"
#include "logger.h"

#include <QtCore/QDebug>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QProcess>
#include <QtCore/QEventLoop>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/AccountManager>
#include <TelepathyQt4/Connection>
#include <TelepathyQt4/Contact>
#include <TelepathyQt4/ContactManager>
#include <TelepathyQt4/SharedPtr>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/PendingReady>

/**
    Wrapper for "mc-tool list".
    @return a list of all available accounts' objectpaths
*/
QStringList MCTool::accounts() const
{
    QProcess mctool;
    mctool.start("mc-tool", QStringList() << "list");
    if (!mctool.waitForStarted())
        return QStringList();

    mctool.closeWriteChannel();

    if (!mctool.waitForFinished())
        return QStringList();

    QByteArray result = mctool.readAll();
    QStringList accounts = QString::fromAscii(result.data()).split("\n", QString::SkipEmptyParts);
    return accounts;
}


/**
    Wrapper for "mc-tool show".
    @todo: make a clean split between properties and parameters.

    @param  accountPath     object path of the account to query

    @return a hashlist of all parameters and properties with their value.
*/
QHash<QString, QString> MCTool::accountData( const QString accountPath ) const
{
    QHash<QString, QString> params;

    QProcess mctool;
    mctool.start("mc-tool", QStringList() << "show" << accountPath);
    if (!mctool.waitForStarted())
        return params;

    mctool.closeWriteChannel();

    if (!mctool.waitForFinished())
        return params;

    QStringList lines = QString::fromAscii(mctool.readAll().data()).split("\n", QString::SkipEmptyParts);
    foreach( QString line, lines ) {
        QStringList parts = line.split(":", QString::SkipEmptyParts );
        if (parts.size() == 2) {
            params[ parts[0].trimmed().toLower() ] = parts[1].trimmed();
        } else {
            parts = line.split(" ", QString::SkipEmptyParts );
            if (parts.size() == 4) {
                params[ parts[1].trimmed().toLower() ] = parts[3].trimmed();
            }
        }
    }

    return params;
}

QString MCTool::add( const QString cm, const QString proto, const QString id, const QString passwd, const QString server ) const
{
    // extract server from id
    QString rserver = server;
    if( rserver.isEmpty() && proto == "jabber" )
    {
        QStringList list = id.split("@", QString::SkipEmptyParts);
        if (list.size() < 2)
            return QString();
        rserver = list.at(1);
    }

    // create list of arguments
    QStringList args;
    args << "add" << cm + "/" + proto << id << "string:account=" + id << "string:password=" + passwd;
    if (!rserver.isEmpty())
        args << "string:server=" + rserver;

    // call mc-tool
    QProcess mctool;
    mctool.start("mc-tool", args);
    if (!mctool.waitForStarted())
    {
        qWarning() << __PRETTY_FUNCTION__ << "!mctool.waitForStarted()";
        return QString();
    }

    mctool.closeWriteChannel();

    if (!mctool.waitForFinished())
    {
        qWarning() << __PRETTY_FUNCTION__ << "!mctool.waitForFinished()";
        return QString();
    }

    // read result
    QStringList lines = QString::fromAscii(mctool.readAll().data()).split("\n", QString::SkipEmptyParts);
    if( lines.size() > 0 )
    {
        return lines.at(0);
    }
    return QString();
}

void MCTool::enable( const QString accountName, bool enable ) const
{
    QProcess mctool;
    QString command = "enable";
    if (!enable)
        command = "disable";
    mctool.start("mc-tool", QStringList() << command << accountName);

    if (!mctool.waitForStarted())
        return;

    mctool.closeWriteChannel();

    if (!mctool.waitForFinished())
        return;
}

void MCTool::remove( const QString accountName ) const
{
    QProcess mctool;
    mctool.start("mc-tool", QStringList() << "remove" << accountName);
    if (!mctool.waitForStarted())
        return;

    mctool.closeWriteChannel();

    if (!mctool.waitForFinished())
        return;
}

void MCTool::request( const QString accountName, const QString presenceState, const QString message ) const
{
    QStringList args;
    args << "request" << accountName << presenceState;
    if( !message.isEmpty() )
        args << message;

    QProcess mctool;
    mctool.start("mc-tool", args);
    if (!mctool.waitForStarted())
        return;

    mctool.closeWriteChannel();

    if (!mctool.waitForFinished())
        return;
}

bool MCTool::removeContacts( const QString accountName ) const
{
    QString accountPath = "/org/freedesktop/Telepathy/Account/" + accountName;
    QEventLoop loop;

    // get account manager
    Tp::AccountManagerPtr am = Tp::AccountManager::create();

    connect( am->becomeReady(),
             SIGNAL(finished(Tp::PendingOperation*)),
             &loop,
             SLOT(quit()) );
    loop.exec();
    if( !am->isReady() )
    {
        qWarning() << __PRETTY_FUNCTION__ << ("unable to make AccountManager ready");
        return false;
    }

    // get account
    Tp::AccountPtr a = am->accountForPath( accountPath );
    if( a.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << ("Account not known to AccountManager");
        return false;
    }

    connect( a->becomeReady(),
             SIGNAL(finished(Tp::PendingOperation*)),
             &loop,
             SLOT(quit()) );
    loop.exec();
    if( !a->isReady() )
    {
        qWarning() << __PRETTY_FUNCTION__ << ("unable to make Account ready");
        return false;
    }

    // try to bring account online
    if( a->currentPresence().type() < 2 || a->currentPresence().type() > 6 )
    {
        Tp::PendingOperation *operation = a->setRequestedPresence( Tp::Presence::available() );
        connect( operation,
                 SIGNAL(finished(Tp::PendingOperation*)),
                 &loop,
                 SLOT(quit()) );
        loop.exec();
    }

    // check connection status
    Tp::ConnectionPtr c = a->connection();
    if( c.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << ("no Connection returned by Account");
        return false;
    }
    switch( c->status() )
    {
    case Tp::ConnectionStatusConnected:
        break;
    case Tp::ConnectionStatusConnecting:
        // wait for connection to connect
        connect( c.data(),
                 SIGNAL(statusChanged(Tp::ConnectionStatus)),
                 &loop,
                 SLOT(quit()) );
        loop.exec();
        if( c->status() != Tp::ConnectionStatusConnected )
        {
            qWarning() << __PRETTY_FUNCTION__ << ("Connection not able to connect");
            return false;
        }
        break;
    case Tp::ConnectionStatusDisconnected:
    case Tp::_ConnectionStatusPadding:
        return false;
    }

    // activate some features
    {
        Tp::PendingOperation *operation = c->becomeReady(Tp::Features() << Tp::Connection::FeatureRoster << Tp::Connection::FeatureRosterGroups << Tp::Connection::FeatureSimplePresence);
        connect( operation,
                 SIGNAL(finished(Tp::PendingOperation*)),
                 this,
                 SLOT(onPendingOperationFinished(Tp::PendingOperation*)) );
        connect( operation,
                 SIGNAL(finished(Tp::PendingOperation*)),
                 &loop,
                 SLOT(quit()) );
        loop.exec();
    }
    if( !c->isReady() )
    {
        qWarning() << __PRETTY_FUNCTION__ << ("unable to make Connection ready");
        return false;
    }

    // get contact manager
    Tp::ContactManagerPtr cm = c->contactManager();
    if( cm.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << ("no ContactManager returned by Connection");
        return false;
    }
    if( cm->state() == Tp::_ContactListStatePadding )
    {
        connect( cm.data(),
                 SIGNAL(stateChanged(Tp::ContactListState)),
                 &loop,
                 SLOT(quit()) );
        loop.exec();
        disconnect( cm.data(), 0, &loop, 0 );
    }
    if( cm->state() == Tp::ContactListStateWaiting )
    {
        connect( cm.data(),
                 SIGNAL(stateChanged(Tp::ContactListState)),
                 &loop,
                 SLOT(quit()) );
        loop.exec();
        disconnect( cm.data(), 0, &loop, 0 );
    }
    if( cm->state() != Tp::ContactListStateSuccess ){
        qWarning() << __PRETTY_FUNCTION__ << ("unable to get contact list");
        return false;
    }

    // get contacts
    Tp::Contacts cs = cm->allKnownContacts();
    // remove all contacts
    {
        Tp::PendingOperation *operation = cm->removeContacts(cs.toList());
        connect( operation,
                 SIGNAL(finished(Tp::PendingOperation*)),
                 &loop,
                 SLOT(quit()) );
        loop.exec();
    }

    cs.clear();
    // check if all contacts were removed
    cs = cm->allKnownContacts();
    if( cs.count() > 0 )
    {
        qWarning() << __PRETTY_FUNCTION__ << ("not all Contacts were removed from Account");
        return false;
    }
    return true;
}

void MCTool::onPendingOperationFinished( Tp::PendingOperation *operation )
{
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "Operation finished w/ errors:";
        qWarning() << __PRETTY_FUNCTION__ << operation->errorName() + ": " + operation->errorMessage();
    }
    qWarning() << __PRETTY_FUNCTION__ << "Operation finished w/o errors";
}
