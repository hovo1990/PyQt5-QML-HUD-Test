/*
* mctool.h
*
* Copyright (C) 2011 basysKom GmbH
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef TESTFRAME_MCTOOL_H
#define TESTFRAME_MCTOOL_H

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QHash>

/**
    Simple wrapper around the mc-tool (command line client for Telepathy's MissionControl).
    This class can be used to query information about accounts.
*/

namespace Tp
{
    class PendingOperation;
}

class MCTool : public QObject
{
    Q_OBJECT

  public:
    QStringList accounts() const;
    QHash<QString, QString> accountData( const QString accountPath ) const;

    /**
     * add an account to MissionControl
     * @return returns the account name
     */
    QString add( const QString cm, const QString proto, const QString id, const QString passwd, const QString server = QString() ) const;
    inline QHash<QString, QString> show( const QString accountName ) const
    {
        return accountData( accountName );
    }
    /**
     * enable or disable an account
     * @param accountName account name as returned by @see accounts() and @see add()
     * @param enable if true the named account becomes enabled
     * @return currently nothing (FIXME: we should return a bool or something)
     * @sa disable()
     */
    void enable( const QString accountName, bool enable = true ) const;
    /**
     * enable or disable an account
     * @param accountName account name as returned by @see accounts() and @see add()
     * @param disable if true the named account becomes disabled
     * @return currently nothing (FIXME: we should return a bool or something)
     * @sa enable()
     */
    inline void disable( const QString accountName, bool disable = true ) const { enable(accountName, !disable); }
    /**
     * remove an account from MissionControl
     * @param accountName account name as returned by @see accounts() and @see addAccount()
     * @return currently nothing (FIXME: we should return a bool or something)
     */
    void remove( const QString accountName ) const;
    /**
     * request a presence state for account
     * @param accountName account name as returned by @see accounts() and @see addAccount()
     * @return currently nothing (FIXME: we should return a bool or something)
     */
    void request( const QString accountName, const QString presenceState, const QString message = QString() ) const;

    /**
     * remove all contacts from an accounts roaster
     * the account has to be online to remove contacts
     * @param accountName account name as returned by @see accounts() and @see add()
     * @return true if all accounts were removed
     */
    bool removeContacts( const QString accountName ) const;

private slots:
    void onPendingOperationFinished( Tp::PendingOperation *operation );
};

#endif // TESTFRAME_MCTOOL_H
