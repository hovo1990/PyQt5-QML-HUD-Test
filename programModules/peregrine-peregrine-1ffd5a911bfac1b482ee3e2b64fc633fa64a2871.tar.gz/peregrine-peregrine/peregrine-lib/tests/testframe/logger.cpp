/*
* logger.cpp
*
* Copyright (C) 2011 basysKom GmbH
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "logger.h"

#include <QtCore/QDebug>

Logger* Logger::sInstance = 0;

/**
    Get the instance of this singleton. If it does not exist, create it on the fly.

    @return pointer to Logger instance
*/
Logger* Logger::instance()
{
    if (!sInstance) {
      sInstance = new Logger;
    }
    
    Q_ASSERT(sInstance);
    
    return sInstance;
}

/**
    This gives a UNIX compatible return value for the application.

    @return 0 if nothing failed, -1 if at least one thing was logged as failed
*/
int Logger::result()
{
    return mSomethingFailed ? -1 : 0;
}

/**
    Standard logging, at the moment just a qDebug with a LOG prefix.

    @param  msg     text to log
*/
void Logger::log( const char* msg )
{
    qDebug() << "[LOG]:" << msg;
}
void Logger::log( const QString msg )
{
    qDebug() << "[LOG]:" << msg;
}


/**
    Success logging, at the moment just a qDebug with a SUCCESS prefix.

    @param  msg     text to log
*/
void Logger::success( const char* msg )
{
    qDebug() << "[SUCCESS]:" << msg;
}
void Logger::success( const QString msg )
{
    qDebug() << "[SUCCESS]:" << msg;
}


/**
    Failure logging, at the moment just a qDebug with a FAIL prefix.
    In addition the fail state is set internally, @see result()

    @param  msg     text to log
*/
void Logger::fail( const char* msg )
{
    qDebug() << "[FAIL]:" << msg;
    mSomethingFailed = true;
}
void Logger::fail( const QString msg )
{
    qDebug() << "[FAIL]:" << msg;
    mSomethingFailed = true;
}
