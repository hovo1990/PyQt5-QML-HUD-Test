/*
* logger.h
*
* Copyright (C) 2011 basysKom GmbH
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef TESTFRAME_LOGGER_H
#define TESTFRAME_LOGGER_H

class QString;

/**
    Basic logging class.
    For normal usage, just use the provided macros LOG, FAIL, SUCCESS to do basic logging (LOG)
    or log test results (SUCCESS, FAIL). This ensures that a recognizable string is always put
    into the log file and can be used later on to collect results.
    One speciality is that as soon as the fail() method is used to log something this is
    remembered and result() will return -1 from then on.

    This class is a singleton which can be accessed from anywhere, thread safety is not ensured
    in any meaningful way.
*/
class Logger
{
  public:
    static Logger* instance();
    int result();
    void log( const char* msg );
    void log( const QString msg );
    void fail( const char* msg );
    void fail( const QString msg );
    void success( const char* msg );
    void success( const QString msg );

  private:
    Logger() : mSomethingFailed(false) {}
    static Logger* sInstance;

    bool mSomethingFailed;
};

// FIXME: add filename, line number and stuff, maybe just return qDebug stream object
#define LOG     Logger::instance()->log
#define FAIL    Logger::instance()->fail
#define SUCCESS Logger::instance()->success

#endif // TESTFRAME_LOGGER_H
