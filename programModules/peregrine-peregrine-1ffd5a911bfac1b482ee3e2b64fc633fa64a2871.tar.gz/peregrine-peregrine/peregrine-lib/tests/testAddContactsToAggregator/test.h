/*
 * test.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef TESTCASE_TEST_H
#define TESTCASE_TEST_H

#include <QtCore/QObject>
#include <QSemaphore>
#include <QStringList>

class QModelIndex;

namespace Peregrine
{
    class ContactListAggregatorModel;
}

class MCTool;

class Test : public QObject
{
    Q_OBJECT

 signals:

    void testCompleted();
    void checkCompleted();
    void checkFailed();
    void exitEventLoop();

 public slots:

    void prepare();
    void run();
    void check();
    void cleanup();

private slots:
    void onRowsInserted( const QModelIndex &parent, int start, int end );
    void onRowsRemoved( const QModelIndex &parent, int start, int end );
    void onDataChanged( const QModelIndex &topLeft, const QModelIndex &bottomRight );
    void onModelReset();

private:

    MCTool *mMcTool;
    QString mAccountName;
    QString mAccountPath;
    Peregrine::ContactListAggregatorModel *mContacts;

    QSemaphore mResetSemaphore;
    QSemaphore mSemaphore;
    QStringList mCreatedContactIds;

    int mInitialRowCount;

    // following values are read from config file
    // account details needed to create an account
    typedef struct
    {
        QString id;
        QString password;
        QString server;

        QString cm;
        QString protocol;

        QString name;
        QString path;
    } Account;
    typedef struct
    {
        QString id;
        QString account;
    } Contact;

    // list of accounts that should be used
    QList<Account> mAccounts;
    // list of contact ids that should be created
    QList<Contact> mContactIds;
};

#endif // TESTCASE_TEST_H
