/*
 * test.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "test.h"
#include "testframe.h"
#include "modeltest.h"
#include "contact/contactlistaggregatormodel.h"
#include <QTest>
#include <QEventLoop>
#include <QTimer>
#include <QSettings>

/**
    Return a new instance of the test class.
*/
QObject* createTest()
{
    return new Test;
}

/**
    Implement necessary additional preparation here. Should not be needed
    in most cases.
*/
void Test::prepare()
{
    QSettings settings(CONFIG_FILE, QSettings::IniFormat, this);
    settings.beginGroup( "AddContactsToAggregator" );
    {
        int size = settings.beginReadArray( "account" );
        for( int i = 0; i < size; ++i )
        {
            Account account;
            settings.setArrayIndex(i);
            account.id = settings.value("id").toString();
            account.password = settings.value("password").toString();
            account.server = settings.value("server").toString();
            account.cm = settings.value("cm").toString();
            account.protocol = settings.value("protocol").toString();
            account.name = "";
            account.path = "";
            mAccounts.append( account );
        }
        settings.endArray();
    }
    {
        int size = settings.beginReadArray( "contact" );
        for( int i = 0; i < size; ++i )
        {
            settings.setArrayIndex(i);
            Contact contact;
            contact.id = settings.value("id").toString();
            contact.account = settings.value("account").toString();
            mContactIds.append( contact );
        }
        settings.endArray();
    }
    settings.endGroup();

    // create local event loop
    // this is needed because the global event loop is not running at this point
    QEventLoop loop( this );
    connect( this, SIGNAL(exitEventLoop()),
             &loop, SLOT(quit()) );

    // create instance of MC-Tool wrapper class
    mMcTool = new MCTool();

    // remove old accounts
    {
        QStringList accounts = mMcTool->accounts();
        foreach( QString account, accounts )
        {
            mMcTool->remove(account);
        }
    }

    // make sure that mResetSemaphore has no available resources
    if( int available = mResetSemaphore.available() )
    {
        LOG("mResetSemaphore contains available resources: " + QString::number(available));
        mResetSemaphore.acquire( available );
    }

    for( int i = 0; i < mAccounts.count(); ++i )
    {
        // create new account
        LOG("creating new account " +  mAccounts[i].id);
        mAccounts[i].name = mMcTool->add( mAccounts[i].cm, mAccounts[i].protocol, mAccounts[i].id, mAccounts[i].password, mAccounts[i].server );
        LOG("account name: " + mAccounts[i].name);
        if( mAccounts[i].name.isEmpty() )
        {
            FAIL("unable to create account");
            // remove account from list
            mAccounts.removeAt(i--);
            continue;
        }
        // enable newly created account
        mMcTool->enable( mAccounts[i].name );
        // bring newly created account online
        mMcTool->request( mAccounts[i].name, "available", "online for testing" );
        // wait for a sec
        QTest::qWait( 1000 );
        LOG(QString("removing contacts for account " + mAccounts[i].id + ": ") + (mMcTool->removeContacts(mAccounts[i].name)?"true":"false") );

        // reconstruct a D-Bus object path from account name
        mAccounts[i].path = "/org/freedesktop/Telepathy/Account/" + mAccounts[i].name;
    }

    // create ContactListModel
    mContacts = new Peregrine::ContactListAggregatorModel( QStringList(), this );

    // create ModelTest and connect to ContactListModel
    new ModelTest(mContacts, this);

    // connect to signals
    connect( mContacts, SIGNAL(rowsInserted(QModelIndex, int, int)),
             this, SLOT(onRowsInserted(QModelIndex, int, int)) );
    connect( mContacts, SIGNAL(rowsRemoved(QModelIndex, int, int)),
             this, SLOT(onRowsRemoved(QModelIndex, int, int)) );
    connect( mContacts, SIGNAL(dataChanged(QModelIndex, QModelIndex)),
             this, SLOT(onDataChanged(QModelIndex, QModelIndex)) );
    connect( mContacts, SIGNAL(modelReset()),
             this, SLOT(onModelReset()) );

    // set mInitialRowCount to -1 so that onRowsInserted never emit exitEventLoop()
    mInitialRowCount = -1;

    // wait for modelReset signal or max. 10 seconds
    QTimer::singleShot( 10000, &loop, SLOT(quit()) );
    loop.exec();
    QApplication::processEvents();

    if( mResetSemaphore.tryAcquire(mAccounts.count()) )
    {
        LOG("got the mResetSemaphore");
    } else
    {
        // is that realy a fail?
        FAIL("got timeout");
    }

    mInitialRowCount = mContacts->rowCount();
    LOG("initial count of rows (contacts): " + QString::number(mInitialRowCount));
    for( int i = 0; i < mContacts->rowCount(); ++i )
    {
        QModelIndex index = mContacts->index( i, Peregrine::ContactListAggregatorModel::ColumnContact );
        LOG(" - " + QString::number(i) + ": " + index.data().toString() );
    }

    // make sure that mSemaphore has no available resources
    if( int available = mSemaphore.available() )
    {
        mSemaphore.acquire( available );
    }
}

/**
    Do all the stuff you want to test.
    If everything is done, emit the testFinished() signal which
    is automatically connected to the check() method.
*/
void Test::run()
{
    // create local event loop
    // this is needed because the global event loop is executing this function
    QEventLoop loop( this );
    connect( this, SIGNAL(exitEventLoop()),
             &loop, SLOT(quit()) );

    // insert some contact ids
    if( mContactIds.isEmpty() )
    {
        FAIL(QString("no contact ids configured in ") + CONFIG_FILE);
        return;
    } else
    {
        for( int i = 0; i < mContactIds.count(); ++i )
        {
            Account account;
            foreach( account, mAccounts )
            {
                if( account.id == mContactIds[i].account )
                {
                    break;
                } else
                { // invalidate account
                    account.name = account.path = "";
                }
            }

            if( mContacts->createContact(account.path, mContactIds[i].id) )
            {
                mCreatedContactIds.append( account.path + "::" + mContactIds[i].id );
            } else
            {
                FAIL("failed to create contact: " + mContactIds[i].id);
            }
            QTest::qWait(1000);
        }
    }

    // set count to number of confirmed contacts
    int contactIdCount = mCreatedContactIds.size();

    // wait for all contacts are created (max. 1sec/contact)
    QTimer::singleShot( contactIdCount * 1000, &loop, SLOT(quit()) );
    loop.exec();
    QApplication::processEvents();

    if( mSemaphore.tryAcquire(contactIdCount) )
    {
        if( mSemaphore.available() > 0 )
        {
            LOG("more contacts got created than ContactListModel::createContact() confirmed");
        }
    } else
    {
        LOG("no or not all contacts created in time. got " + QString::number(mSemaphore.available()) + " replies");
    }
    emit testCompleted();
}

/**
    Check the results of your test.
    Log accordingly.
*/
void Test::check()
{
    if( mCreatedContactIds.size() <= 0 )
    {
        // no contacts got created!! - log that
        FAIL( "no contacts got created" );
    } else
    {
        // check rowCount
        int rowCount = mContacts->rowCount();
        if( (rowCount - mInitialRowCount) == mCreatedContactIds.size() )
        {
            SUCCESS("count of rows is as expacted: " + QString::number(rowCount));
        } else
        {
            FAIL("unexpacted count of rows. is: " + QString::number(rowCount) + " expacted: " + QString::number(mCreatedContactIds.size() + mInitialRowCount));
        }

        // check content using ContactListModelIndex::indexForContactId()
        foreach( QString contactId, mCreatedContactIds )
        {
            QModelIndex index = mContacts->indexForContactId(contactId);
            if( !index.isValid() )
            {
                FAIL("unable to get index for contact ID: " + contactId);
                continue;
            }

            QString storedContactId = index.data(Peregrine::ContactListAggregatorModel::ContactIdRole).toString();
            if( storedContactId == contactId )
            {
                SUCCESS("returned index for contact " + contactId + " is correct");
            } else
            {
                FAIL("returned index for contact " + contactId + " is incorrect and corresponds to " + storedContactId);
            }
        }

        // double check content
        for( int i = 0; i < mContacts->rowCount(); ++i )
        {
            QModelIndex index = mContacts->index(i, Peregrine::ContactListAggregatorModel::ColumnContact );
            QString contactId = index.data(Peregrine::ContactListAggregatorModel::ContactIdRole).toString();
            QString subscription = index.data(Peregrine::ContactListAggregatorModel::SubscriptionRole).toString();
            QString publication = index.data(Peregrine::ContactListAggregatorModel::PublicationRole).toString();
            bool blocked = index.data(Peregrine::ContactListAggregatorModel::SubscriptionRole).toBool();

            if( subscription == "no" && publication == "no" && !blocked )
            {
                FAIL("contact ID " + contactId + " should NOT be in list. sub: '" + subscription + "' pub: '" + publication + "' blocked: '" + (blocked?"true":"false") + "'");
            } else
            {
                SUCCESS("contact ID " + contactId + " should be in list. sub: '" + subscription + "' pub: '" + publication + "' blocked: '" + (blocked?"true":"false") + "'");
            }

            if( 1 == mCreatedContactIds.removeAll(contactId) )
            {
                SUCCESS("contact ID " + contactId + " was stored in model");
            }
        }
        foreach( QString contactId, mCreatedContactIds )
        {
            FAIL("model is missing contact: " + contactId);
        }
    }

    emit checkCompleted();
}

/**
    Implement necessary additional cleanup here. Should not be needed
    in most cases.
*/
void Test::cleanup()
{
    delete mMcTool;
    mMcTool = 0;
}

void Test::onRowsInserted( const QModelIndex &parent, int start, int end )
{
    Q_UNUSED( parent );

    int count = end - start + 1;
    LOG(QString::number(count) + " row(s) inserted into model");
    mSemaphore.release( count );

    // if this was the last inserted contact emit signal exitEventLoop
    if( mSemaphore.available() == mInitialRowCount )
    {
        emit exitEventLoop();
    }
}

void Test::onRowsRemoved( const QModelIndex &parent, int start, int end )
{
    Q_UNUSED( parent );

    int count = end - start + 1;
    LOG(QString::number(count) + " row(s) removed from model");
}

void Test::onDataChanged( const QModelIndex &topLeft, const QModelIndex &bottomRight )
{
    if( topLeft.isValid() && bottomRight.isValid() )
    {
        int count = bottomRight.row() - topLeft.row() + 1;
        LOG(QString::number(count) + " row(s) changed in model");
    } else
    {
        if( !topLeft.isValid() )
            FAIL("topLeft index in dataChanged signal is invalid");
        if( !bottomRight.isValid() )
            FAIL("bottomRight index in dataChanged signal is invalid");
    }
}

void Test::onModelReset()
{
    LOG("model should now be filled with data");
    mResetSemaphore.release( 1 );
    if( mResetSemaphore.available() == mAccounts.count() )
        emit exitEventLoop();
}
