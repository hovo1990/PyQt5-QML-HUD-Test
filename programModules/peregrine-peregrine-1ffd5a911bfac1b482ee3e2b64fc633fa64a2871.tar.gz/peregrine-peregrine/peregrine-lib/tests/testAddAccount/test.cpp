/*
* test.cpp
*
* Copyright (C) 2011 basysKom GmbH
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "test.h"
#include "testframe.h"

#include <account/accountdetailmodel.h>

#include <QCoreApplication>
#include <QDebug>
#include <QSettings>

QObject* createTest()
{
    return new Test;
}

/**
    Implement necessary additional preparation here. Should not be needed
    in most cases.
*/
void Test::prepare()
{
    QSettings settings(CONFIG_FILE, QSettings::IniFormat, this);
    settings.beginGroup( "AddAccount" );
    {
        int size = settings.beginReadArray( "account" );
        if( size <= 0 )
        {
            mAccount.id = "this.is.a.fakeaccount@googlemail.com";
            mAccount.password = "";
            mAccount.server = "";
            mAccount.port = 5432;
            mAccount.cm = "gabble";
            mAccount.protocol = "jabber";
        } else
        {
            settings.setArrayIndex(0);
            mAccount.id = settings.value("id").toString();
            mAccount.password = settings.value("password").toString();
            mAccount.server = settings.value("server").toString();
            mAccount.port = settings.value("port").toUInt();
            mAccount.cm = settings.value("cm").toString();
            mAccount.protocol = settings.value("protocol").toString();
        }
        settings.endArray();
    }
    settings.endGroup();
}

/**
    Do all the stuff you want to test.
    If everything is done, emit the testFinished() signal which
    is automatically connected to the check() method.
*/
void Test::run()
{
    // use AccountDetailModel to add a new account
    m_model = new Peregrine::AccountDetailModel( mAccount.cm, mAccount.protocol );
    QObject::connect(m_model, SIGNAL(initialized()), this, SLOT(createAccount()));
}

void Test::createAccount()
{
    Q_ASSERT(m_model);

    m_model->setParameter( "account", mAccount.id );
    if( mAccount.port > 0 )
        m_model->setParameter( "port", mAccount.port );
    if( !mAccount.password.isEmpty() )
        m_model->setParameter( "password", mAccount.password );
    if( !mAccount.server.isEmpty() )
        m_model->setParameter( "server", mAccount.server );

    m_model->submit();

    emit testCompleted();
}

/**
    Check the results of your test.
    Log accordingly.
*/
void Test::check()
{
    MCTool mctool;

    QString accountPath;
    QHash<QString, QString> accountParams;
    foreach( QString a, mctool.accounts() ) {
        accountParams = mctool.accountData(a);
        if (accountParams.value("account") == mAccount.id ) {
            qDebug() << __PRETTY_FUNCTION__ << "account parameter" << accountParams;
            accountPath = a;
            break;
        }
    }

    if (accountPath.isEmpty()) {
        FAIL("Account not created in telepathy");
        emit checkFailed();
        return;
    }

    if (accountParams["account"] != mAccount.id) {
        FAIL("Account has wrong account in telepathy");
        emit checkFailed();
        return;
    }

    if (accountParams["server"] != mAccount.server) {
        FAIL("Account has wrong server in telepathy");
        emit checkFailed();
        return;
    }

    if (accountParams["port"].toUInt() != mAccount.port) {
        FAIL("Account has wrong port in telepathy");
        emit checkFailed();
        return;
    }

    // not realy needed. peregrine tries to create enabled accounts
    // so this test will fail if mc-tool is too slow while requesting
    // account data
    if (accountParams["enabled"] != "disabled") {
        FAIL("Account has wrong enabled state in telepathy");
        emit checkFailed();
        return;
    }

    SUCCESS("Adding account");

    emit checkCompleted();
}

/**
    Implement necessary additional cleanup here. Should not be needed
    in most cases.
*/
void Test::cleanup()
{
}
