/*
* @TODO: add desired license information
*/

#include "test.h"
#include "testframe.h"

/**
    Return a new instance of the test class.
*/
QObject* createTest()
{
    return new Test;
}

/**
    Implement necessary additional preparation here. Should not be needed
    in most cases.
*/
void Test::prepare()
{
}

/**
    Do all the stuff you want to test.
    If everything is done, emit the testFinished() signal which
    is automatically connected to the check() method.
*/
void Test::run()
{
    emit testCompleted();
}

/**
    Check the results of your test.
    Log accordingly.
*/
void Test::check()
{
    emit checkCompleted();
}

/**
    Implement necessary additional cleanup here. Should not be needed
    in most cases.
*/
void Test::cleanup()
{
}
