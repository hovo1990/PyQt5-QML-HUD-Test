/*
* @TODO: add desired license information
*/

#ifndef TESTCASE_TEST_H
#define TESTCASE_TEST_H

#include <QtCore/QObject>

class Test : public QObject
{
    Q_OBJECT

 signals:

    void testCompleted();
    void checkCompleted();
    void checkFailed();

 public slots:
    
    void prepare();
    void run();
    void check();
    void cleanup();
};

#endif // TESTCASE_TEST_H
