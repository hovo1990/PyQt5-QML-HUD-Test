#!/bin/bash

accountName=

# check if ring ConnectionManager is installed
if [ ! -f "/usr/share/dbus-1/services/org.freedesktop.Telepathy.ConnectionManager.ring.service" ]
then
  exit
fi

# check if ring account exists
accountName=$( /usr/bin/mc-tool list | grep -e '^ring/tel.*' )

# if not create a new account
if [ -z "${accountName}" ]
then
  accountName=$( /usr/bin/mc-tool add ring/tel Ring )
fi

# check if account is enabled (for each)
for acc in ${accountName}
do
  # check if enabled
  enabled=$( /usr/bin/mc-tool show "${acc}" | grep -oe 'Enabled:.*' | awk '{ print $2 }' )

  if [ "${enabled}" = "disabled" ]
  then
    # enable account
    /usr/bin/mc-tool enable "${acc}"
  fi
done
