/*
 * contactlistmodel_p.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CONTACTLISTMODEL_P_H
#define CONTACTLISTMODEL_P_H

#include <QObject>
#include <QPointer>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/AccountManager>
#include <TelepathyQt4/AvatarData>
#include <TelepathyQt4/Connection>
#include <TelepathyQt4/Contact>
#include <TelepathyQt4/ContactManager>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/SharedPtr>
#include <TelepathyQt4/Types>

namespace Peregrine
{

class ContactListModel;

class ContactListModelPrivate
    : public QObject
{
    Q_OBJECT
    friend class ContactListModel;

    // data
    QPointer<ContactListModel> mParent;

    QMap<Tp::ConnectionPresenceType, QString> m_presenceTypeToIconName;
    uint presenceIdentifier;
    Tp::ConnectionPresenceType presenceType;

    QString presenceStatus;
    QString presenceStatusMessage;

    QList<Tp::ContactPtr> mPendingContacts;

    QString mAccountId;
    QString mAccountPath;
    QString mAccountService;

    Tp::AccountPtr mAccount;
    Tp::AccountManagerPtr mAccountManager;
    Tp::ConnectionPtr mConnection;
    Tp::ContactManagerPtr mContactManager;

    QList<Tp::ContactPtr> mContactList;
    QList<Tp::ContactPtr> mUnsubscribedContactList;

    static const Tp::Features ACCOUNT_FEATURES;
    static const Tp::Features ACCOUNT_MANAGER_FEATURES;
    static const Tp::Features CONNECTION_FEATURES;
    static const Tp::Features CONTACT_FEATURES;

    // functions
    explicit ContactListModelPrivate( ContactListModel *parent );

    bool addToSubscribedList( const Tp::ContactPtr &contact, bool emitSignals = true );
    bool addToUnsubscribedList( const Tp::ContactPtr &contact, bool emitSignals = true );
    void clearAccountData();
    void clearContactData();
    void getAllKnownContacts();
    void setAccountPath( const QString &accountPath );

    bool connectAccount( Tp::AccountPtr account );
    bool disconnectAccount( Tp::AccountPtr account );
    bool connectAccountManager( Tp::AccountManagerPtr accountManager );
    bool disconnectAccountManager( Tp::AccountManagerPtr accountManager );
    bool connectConnection( Tp::ConnectionPtr connection );
    bool disconnectConnection( Tp::ConnectionPtr connection );
    /**
     * connect signals of a Tp::Contact object to this->onContactChanged()
     * \sa onContactChanged()
     */
    bool connectContact( Tp::ContactPtr contact );
    bool disconnectContact( Tp::ContactPtr contact );
    bool connectContactManager( Tp::ContactManagerPtr contactManager );
    bool disconnectContactManager( Tp::ContactManagerPtr contactManager );

private slots:
    void onAccountManagerReady( Tp::PendingOperation *operation );

    void onAccountConnectionChanged( const Tp::ConnectionPtr &connection );
    void onAccountReady( Tp::PendingOperation *operation );
    void onAccountRemoved();

    void onChannelRequestFailed(const QString &errorName, const QString &errorMessage);
    void onContactManagerContactsUpgraded( Tp::PendingOperation* operation );
    void onContactManagerContactsRemoved( Tp::PendingOperation* operation );
    void onContactManagerPresencePublicationRequested( const Tp::Contacts &contacts );
    void onContactManagerAllKnownContactsChanged( const Tp::Contacts &contactsAdded, const Tp::Contacts &contactsRemoved, const Tp::Channel::GroupMemberChangeDetails &details );
    void onContactManagerStateChanged(Tp::ContactListState state);
    void onPendingChannelRequestChannelRequestCreated( Tp::ChannelRequestPtr channelRequest );

    /**
     * this slot is called when a contact was retrieved from ContactManager
     * retreiving contacts from ContactManager happens when a user adds a
     * not known contact to the contact list
     */
    void onPendingContactsFinished( Tp::PendingOperation *operation );

    /**
     * onContactChanged slot is called when a known Tp::Contact emits one of following signals:
     * aliasChanged, avatarTokenChanged, simplePresenceChanged, capabilitiesChanged,
     * subscriptionStateChanged, publishStateChanged, addedToGroup, removedFromGroup
     */
    void onContactChanged();
    void onContactSubscriptionStateChanged(Tp::Contact::PresenceState state);
    void onContactPublishStateChanged(Tp::Contact::PresenceState state);


    /**
     * onConnectionReady slot is called when the Tp::Connection becomes ready
     */
    void onConnectionReady( Tp::PendingOperation* operation );
    void onConnectionStatusChanged( Tp::ConnectionStatus status );

//    void onAvatarRetrieved(uint contact, const QString &token, const QByteArray &avatar, const QString &type);

public:
    ~ContactListModelPrivate();

};

}

#endif // CONTACTLISTMODEL_P_H
