/*
 * metacontactlistmodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef METACONTACTLISTMODEL_H
#define METACONTACTLISTMODEL_H

#include <QAbstractItemModel>
#include <QList>
#include <QModelIndex>
#include <QPair>
#include <QPointer>
#include <QSet>
#include <QMultiMap>
#include <QString>
#include <QStringList>
#include <QVariant>

namespace Peregrine
{

class ContactListAggregatorModel;
class MetaContact;
class MetaContactStorage;

class MetaContactListModel : public QAbstractItemModel
{
    Q_OBJECT
    Q_ENUMS( Columns )
    Q_ENUMS( Roles )

    // list of MetaContact objects
    QList< QPair< QString, QPointer<MetaContact> > > mMetaContacts;

    // list of local stored ContactIds
    // this is needed to keep track of all used ContactIds
    QSet<QString> mContactIds;
    QMultiMap< QString, QPointer<MetaContact> > mUsedContactIds;

    QPointer<ContactListAggregatorModel> mContactListModel;

    /**
     * check and move row if needed to keep list of MetaContacts
     * in order
     */
    int adjustIndexOf( int row );
    /**
     * create a display name for a MetaContact
     */
    QString createDisplayName( MetaContact *metaContact ) const;
    /**
     * (re)create the list of MetaContacts. therefor the list of
     * MetaContactIds read by MetaContactStorage is used
     */
    void createMetaContacts();
    /**
     * using the to sets mContactIds and mUsedContactIds to find
     * unused contact ids and create MetaContact for these
     */
    void createMetaContactsForUnusedContactIds();
    /**
     * (re)create a set that contains all contact ids listed
     * in mContactListModel (ContactListAggregatorModel)
     */
    void createSetOfAllContactIds();
    /**
     * (re)create a set that contains all contacts that are
     * handled by MetaContacts
     */
    void createSetOfUsedContactIds();
    /**
     * split display name into `name' and `surname'
     */
    QPair<QString, QString> extractFromDisplayName( const QString &displayName ) const;
    /**
     * initialize role names. that is needed to access data from QML
     */
    void initRoleNames();
    /**
     * insert a MetaContact into the list of MetaContacts
     * at right position so that the list is still ordered
     * correctly
     */
    int insertMetaContact( MetaContact *metaContact );
    /**
     * this is a simple function to find the row for a MetaContact pointer
     * that is stored inside a QModelIndex (as a void pointer).
     */
    int rowForPointer( void *metaContact ) const;

    bool connectContactListModel( QAbstractItemModel *model );
    bool disconnectContactListModel( QAbstractItemModel *model );
    bool connectMetaContact( MetaContact *metaContact );
    bool disconnectMetaContact( MetaContact *metaContact );
    bool connectMetaContactStorage( MetaContactStorage *metaContactStorage );
    bool disconnectMetaContactStorage( MetaContactStorage *metaContactStorage );

private slots:
    void onContactListModelDataChanged( const QModelIndex &topLeft, const QModelIndex &bottomRight );
    void onContactListModelModelReset();
    void onContactListModelRowsAboutToBeRemoved( const QModelIndex &parent, int start, int end );
    void onContactListModelRowsInserted( const QModelIndex &parent, int start, int end );

    void onMetaContactAboutToBeDeleted();
    void onMetaContactCapabilitiesChanged( const QStringList &capabilities );
    void onMetaContactDataChanged( const QModelIndex &topLeft, const QModelIndex &bottomRight );
    void onMetaContactDeleted();
    void onMetaContactModelReset();
    void onMetaContactPresencePublicationChanged();
    void onMetaContactPresenceStateChanged( const QString &presenceState );
    void onMetaContactRowsAboutToBeInserted( const QModelIndex &parent, int start, int end );
    void onMetaContactRowsAboutToBeRemoved( const QModelIndex &parent, int start, int end );
    void onMetaContactRowsInserted( const QModelIndex &parent, int start, int end );
    void onMetaContactRowsRemoved( const QModelIndex &parent, int start, int end );

    void onMetaContactAvatarUriChanged( const QString &avatarUri );
    void onMetaContactNameChanged( const QString &name );
    void onMetaContactSurnameChanged( const QString &surname );

    void onMetaContactStorageMetaContactCreated( const QString &metaContactId );

public:
    Q_ENUMS( NotificationTypes );

    /**
     * enum for convenient access to the columns
     */
    enum Columns
    {
        ColumnContact,
        ColumnCount
    };
    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };
    /**
     * enum for convenient access to the roles
     */
    enum Roles
    {
        NameRole = Qt::UserRole + 1,
        SurnameRole,
        ContactIdRole,
        PresenceStateRole,
        PublicationRole,
        AvatarUriRole,
        CapabilityListRole,
        SortRole,
        RoleCount
    };

    explicit MetaContactListModel( QObject *parent = 0 );

    /**
     * returns the instance of ContactListAggregatorModel that is used
     * as data source for this (meta-)contact list
     * @return returns the source model (ContactListAggregatorModel) as QObject*
     * It is not best practice to return the model as QObject* but it is needed
     * to be able to handle the returned model in QML!
     */
    Q_INVOKABLE QObject *contactListModel() const;

    /**
     * creates a new contact and adds it to an existing MetaContact. If no
     * metaContactId is specified a new MetaContact is greated.
     * @param accountId accountObjectPath of account the new contact should be added to
     * @param contactId the contactId the user has entered (NOT in a format returned by any of Peregrines functions)
     * @param metaContactId ID of a MetaContact that new contact should be added to. if string is empty a new MetaContact is created
     * @return ID of MetaContact the new contact is added to
     */
    Q_INVOKABLE QString createContact( const QString &accountId,
                                       const QString &contactId,
                                       const QString &metaContactId = QString(),
                                       bool force = false );

    /**
     * create a new contact and meta-contact if \em nickname does not already exist.
     * the nickname is used as name for the newly created meta-contact
     * @param accountPath account path of account to use for creating the new contact
     * @param contactId contact id of contact that should be added to list
     * @param nickname name of contact. the model tries to split this name to get a name and a surname
     * @return true if creation was successful
     */
    Q_INVOKABLE QString createNamedContact( const QString &accountPath,
                                         const QString &contactId,
                                         const QString &nickname);

    /**
     * remove a meta-contact.
     * @param metaContactId ID of meta-contact that should be removed
     * @return true if remove was successful
     */
    Q_INVOKABLE bool removeContact( const QString &metaContactId );

    /**
     * remove a contact from meta-contact.
     * @param contactId contact id of contact that should be removed from meta-contact
     * @return true if remove was successful
     */
    Q_INVOKABLE bool removeIdFromContact( const QString &metaContactId, const QString &contactId);

    /**
     * remove all contacts of account
     * @param accountPath
     * @return true if all contacts are deleted successfully
     */
    Q_INVOKABLE bool removeContacts( const QString &accountPath );

    /**
     * @see Qt::QAbstractItemModel::columnCount()
     */
    Q_INVOKABLE int columnCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractItemModel::data()
     */
    Q_INVOKABLE QVariant data( const QModelIndex &index, int role = Qt::DisplayRole ) const;
    /**
     * @see Qt::QAbstractItemModel::flags()
     */
    Qt::ItemFlags flags( const QModelIndex &index ) const;
    /**
     * @see Qt::QAbstractItemModel::index()
     */
    QModelIndex index( int row, int column, const QModelIndex &parent = QModelIndex() ) const;
    /**
     * Merge a list of meta contacts into destination meta contact
     */
    Q_INVOKABLE bool mergeMetaContactsInto( const QString &destinationMetaContactId, const QStringList &metaContactIds );
    /**
     * returns the metaContactId of MetaContact that contains a given contactId
     */
    Q_INVOKABLE QString metaContactIdForContactId( const QString &contactId ) const;
    /**
     * @see Qt::QAbstractItemModel::parent()
     */
    QModelIndex parent( const QModelIndex &child ) const;
    /**
     * @see Qt::QAbstractItemModel::removeRow()
     */
    Q_INVOKABLE bool removeRow( int row, const QModelIndex &parent = QModelIndex() );
    /**
     * @see Qt::QAbstractItemModel::removeRows()
     */
    Q_INVOKABLE bool removeRows(int row, int count, const QModelIndex &parent = QModelIndex() );
    /**
     * @see Qt::QAbstractItemModel::rowCount()
     */
    Q_INVOKABLE int rowCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * convenience function to set data. mostly used in QML
     * \sa setData()
     */
    Q_INVOKABLE virtual bool setData( int row, const QVariant &value, const QString &rolename );
    /**
     * @see Qt::QAbstractItemModel::setData()
     */
    Q_INVOKABLE bool setData( const QModelIndex &index, const QVariant &value, int role = Qt::DisplayRole );
    /**
     * removes a (sub-)contact from a meta-contact and creates a new meta-contact
     * that contains the named (sub-)contact
     */
    Q_INVOKABLE bool unlink( const QString &contactId );

signals:
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );

public slots:

};

}

#endif // METACONTACTLISTMODEL_H
