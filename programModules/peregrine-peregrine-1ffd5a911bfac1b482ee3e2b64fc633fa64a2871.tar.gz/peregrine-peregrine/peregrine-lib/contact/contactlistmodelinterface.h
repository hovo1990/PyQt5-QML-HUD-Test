/*
 * contactlistmodelinterface.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CONTACTLISTMODELINTERFACE_H
#define CONTACTLISTMODELINTERFACE_H

#include <QAbstractItemModel>
#include <QObject>
#include <QPair>
#include <QString>
#include <QStringList>

namespace Peregrine
{

class ContactListModelInterface
{
public:
    static const QString SEPARATOR;
    /**
     * flags to indicate capabilities of a contact
     * flags can be combined using binary 'or' operation
     */
    enum Capabilities
    {
        CapabilityNone = 0x0,
        CapabilityTextChat = 0x1,
        CapabilityMediaCall = 0x2,
        CapabilityAudioCall = 0x4,
        CapabilityVideoCall = 0x8,
        CapabilityUpgradeCall = 0x10,
        CapabilityFileTransfer = 0x20
    };

    /**
     * enum for convenient access to the columns
     */
    enum Columns
    {
        ColumnContact,
        ColumnState,
        ColumnAuthorisation,
        ColumnGroup,
        ColumnCount
    };
    /**
     * enum for convenient access to the roles
     */
    enum Roles
    {
        ContactIdRole = Qt::UserRole + 1,
        PresenceStateRole,
        PresenceStateMessageRole,
        CapabilitiesRole,
        SubscriptionRole,
        PublicationRole,
        BlockedRole,
        RemovedRole,
        ServiceNameRole,
        AccountIdRole,
        ContactAliasRole,
        ReadableContactIdRole,
        RoleCount
    };

    static inline QString createContactId( const QString &accountId,
                                           const QString &contactId )
    {
        if( accountId.isEmpty() || contactId.isEmpty() )
        {
            return QString();
        }
        return accountId + SEPARATOR + contactId;
    }

    static inline QString extractAccountId( const QString &contactId )
    {
        if( contactId.isEmpty() )
        {
            return QString();
        }

        QStringList parts = contactId.split( QString(SEPARATOR) );
        if( parts.count() != 2 )
        {
            return QString();
        }
        return parts.at( 0 );
    }

    static inline QString extractContactId( const QString &contactId )
    {
        if( contactId.isEmpty() )
        {
            return QString();
        }

        QStringList parts = contactId.split( QString(SEPARATOR) );
        if( parts.count() != 2 )
        {
            return QString();
        }
        return parts.at( 1 );
    }

    static inline QPair<QString, QString> splitContactId( const QString &contactId )
    {
        if( contactId.isEmpty() )
        {
            return QPair<QString, QString>();
        }

        QStringList parts = contactId.split( QString(SEPARATOR) );
        if( parts.count() != 2 )
        {
            return QPair<QString, QString>();
        }
        return QPair<QString, QString>( parts.at(0), parts.at(1) );
    }
};

}

#endif // CONTACTLISTMODELINTERFACE_H
