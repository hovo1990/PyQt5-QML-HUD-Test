/*
 * metacontactwatcher.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef METACONTACTWATCHER_H
#define METACONTACTWATCHER_H

#include <QObject>
#include <QPointer>
#include <QString>

namespace Peregrine
{

class MetaContactWatcherPrivate;

class MetaContactWatcher
        : public QObject
{
    Q_OBJECT
    friend class MetaContactWatcherPrivate;

    QPointer<MetaContactWatcherPrivate> d;


public:
    Q_ENUMS( NotificationTypes );

    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };

    explicit MetaContactWatcher( QObject *parent = 0 );

signals:
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );

};

}

#endif // METACONTACTWATCHER_H
