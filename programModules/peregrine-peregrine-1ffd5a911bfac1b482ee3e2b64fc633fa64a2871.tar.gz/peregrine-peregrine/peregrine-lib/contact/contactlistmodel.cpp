/*
 * contactlistmodel.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "contactlistmodel_p.h"
#include "contactlistmodel.h"
#include "../peregrineDebugHelper.h"
#include "../peregrineinitializer.h"
#include "../channel/clienthandler_p.h"

#include <TelepathyQt4/ChannelRequest>
#include <TelepathyQt4/ContactCapabilities>
#include <TelepathyQt4/PendingChannelRequest>
#include <TelepathyQt4/PendingContacts>
#include <TelepathyQt4/PendingReady>
#include <TelepathyQt4/Types>

using namespace Peregrine;

/* *****************************************************************************
 * ContactListModelPrivate
 * ****************************************************************************/

const
Tp::Features ContactListModelPrivate::ACCOUNT_FEATURES = ( Tp::Features()
                                                           << Tp::Account::FeatureCore
                                                           << Tp::Account::FeatureAvatar
                                                           << Tp::Account::FeatureCapabilities
                                                           << Tp::Account::FeatureProtocolInfo );
const
Tp::Features ContactListModelPrivate::ACCOUNT_MANAGER_FEATURES = ( Tp::Features()
                                                                   << Tp::AccountManager::FeatureCore );
const
Tp::Features ContactListModelPrivate::CONNECTION_FEATURES = ( Tp::Features()
                                                              << Tp::Connection::FeatureCore
                                                              << Tp::Connection::FeatureRoster
                                                              << Tp::Connection::FeatureRosterGroups );
const
Tp::Features ContactListModelPrivate::CONTACT_FEATURES = ( Tp::Features()
                                                           << Tp::Contact::FeatureAlias
                                                           << Tp::Contact::FeatureAvatarToken
                                                           << Tp::Contact::FeatureCapabilities
                                                           << Tp::Contact::FeatureSimplePresence );

ContactListModelPrivate::ContactListModelPrivate( ContactListModel *parent )
    : QObject( parent ),
    mParent( parent )
{
    FUNC_IN
    if( mParent.isNull() )
    {
        deleteLater();
        FUNC_OUT
        return;
    }

    mAccountManager = Tp::AccountManager::create();
    connectAccountManager( mAccountManager );
    connect( mAccountManager->becomeReady(ACCOUNT_MANAGER_FEATURES),
             SIGNAL(finished(Tp::PendingOperation*)),
             this,
             SLOT(onAccountManagerReady(Tp::PendingOperation*)) );
    FUNC_OUT
}


bool
ContactListModelPrivate::addToSubscribedList( const Tp::ContactPtr &contact,
                                              bool emitSignals )
{
    FUNC_IN
    if( contact.isNull() )
    {
        FUNC_OUT
        return false;
    }

    if( mContactList.contains(contact) )
    { // contact is already in list
        FUNC_OUT
        return true;
    }

    // remove from list of unsubscribed contacts
    mUnsubscribedContactList.removeAll( contact );

    for( int i = 0; i <= mContactList.count(); ++i )
    { // find index to insert contact
        if( i == mContactList.count() )
        { // append
            if( emitSignals )
            {
                mParent->beginInsertRows( QModelIndex(), i, i );
            }
            mContactList.append( contact );
            if( emitSignals )
            {
                mParent->endInsertRows();
            }
            FUNC_OUT
            return true;
        }
        if( mContactList.at(i)->id() >= contact->id() )
        { // insert at `i'
            if( emitSignals )
            {
                mParent->beginInsertRows( QModelIndex(), i, i );
            }
            mContactList.insert( i, contact );
            if( emitSignals )
            {
                mParent->endInsertRows();
            }
            FUNC_OUT
            return true;
        }
    }
    FUNC_OUT
    return false;
}
bool
ContactListModelPrivate::addToUnsubscribedList( const Tp::ContactPtr &contact,
                                                bool emitSignals )
{
    FUNC_IN
    if( contact.isNull() )
    {
        FUNC_OUT
        return false;
    }

    if( mUnsubscribedContactList.contains(contact) )
    { // contact is already in list
        FUNC_OUT
        return true;
    }

    int i = mContactList.indexOf( contact );
    if( i > 0 )
    { // remove contact from list of subscribed contacts
        if( emitSignals )
        {
            mParent->beginRemoveRows( QModelIndex(), i, i );
        }
        mContactList.removeAt( i );
        if( emitSignals )
        {
            mParent->endRemoveRows();
            emit mParent->contactDeleted( ContactListModelInterface::createContactId(mAccount->objectPath(), contact->id()) );
        }
    }

    mUnsubscribedContactList.append( contact );
    FUNC_OUT
    return true;
}

void ContactListModelPrivate::clearAccountData()
{
    FUNC_IN
    clearContactData();

    disconnectContactManager( mContactManager );
    mContactManager.reset();
    disconnectConnection( mConnection );
    mConnection.reset();
    disconnectAccount( mAccount );
    mAccount.reset();

    mAccountId.clear();
    mAccountPath.clear();
    FUNC_OUT
}
void ContactListModelPrivate::clearContactData()
{
    FUNC_IN

    foreach( Tp::ContactPtr contact, mPendingContacts )
    {
        disconnectContact( contact );
    }
    mPendingContacts.clear();

    foreach( Tp::ContactPtr contact, mContactList )
    {
        disconnectContact( contact );
    }
    mContactList.clear();

    foreach( Tp::ContactPtr contact, mUnsubscribedContactList )
    {
        disconnectContact( contact );
    }
    mUnsubscribedContactList.clear();

    FUNC_OUT
}

void
ContactListModelPrivate::getAllKnownContacts()
{
    FUNC_IN
    if( mConnection.isNull()
        || !mConnection->isReady(CONNECTION_FEATURES) )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "connection not ready (or connected) yet";
        FUNC_OUT
        return;
    }

    if ( mContactManager.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "cannot get contact manager from connection";
        FUNC_OUT
        return;
    }

    mParent->beginResetModel();

    mContactList.clear();
    mUnsubscribedContactList.clear();
    Tp::Contacts contacts = mContactManager->allKnownContacts();

    foreach(Tp::ContactPtr contact, contacts)
    {
        if( contact->subscriptionState() != Tp::Contact::PresenceStateNo || contact->publishState() != Tp::Contact::PresenceStateNo || contact->isBlocked() )
        {
            addToSubscribedList( contact, false );
        } else
        {
            addToUnsubscribedList( contact, false );
        }

        connectContact( contact );
    }

    connect( mContactManager->upgradeContacts(mContactList, CONTACT_FEATURES), SIGNAL(finished(Tp::PendingOperation *)),
             this, SLOT(onContactManagerContactsUpgraded(Tp::PendingOperation *)) );

    mParent->endResetModel();
    FUNC_OUT
}

void ContactListModelPrivate::setAccountPath( const QString &accountPath )
{
    FUNC_IN
    if( accountPath == mAccountPath )
    {
        return;
    }

    clearAccountData();
    mAccountPath = accountPath;

    if( mAccountManager->isReady(ACCOUNT_MANAGER_FEATURES) )
    {
        mAccount = mAccountManager->accountForPath( mAccountPath );

        if( mAccount.isNull() )
        {
            qWarning() << __PRETTY_FUNCTION__
                       << "account could not be resolved `" + mAccountPath + "'";
            emit mParent->notification( "Account not found!", "Cannot resolve account `" + mAccountPath + "'", ContactListModel::NotificationTypeError );
        } else
        {
            connectAccount( mAccount );
            connect( mAccount->becomeReady(ACCOUNT_FEATURES), SIGNAL(finished(Tp::PendingOperation *)),
                     this, SLOT(onAccountReady(Tp::PendingOperation *)) );
        }
    }
    FUNC_OUT
}

bool
ContactListModelPrivate::connectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( account.data(), SIGNAL(removed()),
                       this, SLOT(onAccountRemoved()) );
    result &= connect(account.data(), SIGNAL(connectionChanged(Tp::ConnectionPtr)),
                      this, SLOT(onAccountConnectionChanged(Tp::ConnectionPtr)));

    FUNC_OUT
    return result;
}
bool
ContactListModelPrivate::disconnectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( account.data(), 0, this, 0 );
}

bool
ContactListModelPrivate::connectAccountManager( Tp::AccountManagerPtr accountManager )
{
    FUNC_IN
    if( accountManager.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
//    result &= connect( accountManager.data(), SIGNAL(newAccount(Tp::AccountPtr)),
//                       this, SLOT() );
    FUNC_OUT
    return result;
}
bool
ContactListModelPrivate::disconnectAccountManager( Tp::AccountManagerPtr accountManager )
{
    FUNC_IN
    if( accountManager.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( accountManager.data(), 0, this, 0 );
}

bool
ContactListModelPrivate::connectConnection( Tp::ConnectionPtr connection )
{
    FUNC_IN
    if( connection.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( connection.data(), SIGNAL(statusChanged(Tp::ConnectionStatus)),
                       this, SLOT(onConnectionStatusChanged(Tp::ConnectionStatus)) );

    FUNC_OUT
    return result;
}
bool
ContactListModelPrivate::disconnectConnection( Tp::ConnectionPtr connection )
{
    FUNC_IN
    if( connection.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( connection.data(), 0, this, 0 );
}

bool
ContactListModelPrivate::connectContact( Tp::ContactPtr contact )
{
    FUNC_IN
    if( contact.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( contact.data(), SIGNAL(aliasChanged(QString)),
                       this, SLOT(onContactChanged()) );
    result &= connect( contact.data(), SIGNAL(avatarDataChanged(Tp::AvatarData)),
                       this, SLOT(onContactChanged()) );
    result &= connect( contact.data(), SIGNAL(presenceChanged(Tp::Presence)),
                       this, SLOT(onContactChanged()) );
    result &= connect( contact.data(), SIGNAL(capabilitiesChanged(Tp::ContactCapabilities)),
                       this, SLOT(onContactChanged()) );
    result &= connect( contact.data(), SIGNAL(locationUpdated(Tp::LocationInfo)),
                       this, SLOT(onContactChanged()) );
    result &= connect( contact.data(), SIGNAL(infoFieldsChanged(Tp::Contact::InfoFields)),
                       this, SLOT(onContactChanged()) );
    result &= connect( contact.data(), SIGNAL(subscriptionStateChanged(Tp::Contact::PresenceState)),
                       this, SLOT(onContactChanged()) );
    result &= connect( contact.data(), SIGNAL(publishStateChanged(Tp::Contact::PresenceState,QString)),
                       this, SLOT(onContactChanged()) );
    result &= connect( contact.data(), SIGNAL(blockStatusChanged(bool)),
                       this, SLOT(onContactChanged()) );

    result &= connect( contact.data(), SIGNAL(subscriptionStateChanged(Tp::Contact::PresenceState)),
                       this, SLOT(onContactSubscriptionStateChanged(Tp::Contact::PresenceState)) );
    result &= connect( contact.data(), SIGNAL(publishStateChanged(Tp::Contact::PresenceState,QString)),
                       this, SLOT(onContactPublishStateChanged(Tp::Contact::PresenceState)) );

    FUNC_OUT
    return result;
}
bool
ContactListModelPrivate::disconnectContact( Tp::ContactPtr contact )
{
    FUNC_IN
    if( contact.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( contact.data(), 0, this, 0 );
}

bool
ContactListModelPrivate::connectContactManager( Tp::ContactManagerPtr contactManager )
{
    FUNC_IN
    if( contactManager.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( contactManager.data(),
                       SIGNAL(stateChanged(Tp::ContactListState)),
                       this,
                       SLOT(onContactManagerStateChanged(Tp::ContactListState)) );
    result &= connect( contactManager.data(),
                       SIGNAL(presencePublicationRequested(Tp::Contacts)),
                       this,
                       SLOT(onContactManagerPresencePublicationRequested(Tp::Contacts)) );
    result &= connect( contactManager.data(),
                       SIGNAL(allKnownContactsChanged(Tp::Contacts, Tp::Contacts, Tp::Channel::GroupMemberChangeDetails)),
                       this,
                       SLOT(onContactManagerAllKnownContactsChanged(Tp::Contacts,Tp::Contacts,Tp::Channel::GroupMemberChangeDetails)) );

    FUNC_OUT
    return result;
}
bool
ContactListModelPrivate::disconnectContactManager( Tp::ContactManagerPtr contactManager )
{
    FUNC_IN
    if( contactManager.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( contactManager.data(), 0, this, 0 );
}

// slots connected to account manager
void
ContactListModelPrivate::onAccountManagerReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();
        FUNC_OUT
        return;
    }

    if( !mAccountPath.isEmpty()
        && mAccount.isNull() )
    {
        mAccount = mAccountManager->accountForPath( mAccountPath );

        if( mAccount.isNull() )
        {
            qWarning() << __PRETTY_FUNCTION__
                       << "account could not be resolved `" + mAccountPath + "'";
            emit mParent->notification( "Account not found", "Cannot resolve account `" + mAccountPath + "'", ContactListModel::NotificationTypeError );
        } else
        {
            connectAccount( mAccount );
            connect( mAccount->becomeReady(ACCOUNT_FEATURES), SIGNAL(finished(Tp::PendingOperation *)),
                     this, SLOT(onAccountReady(Tp::PendingOperation *)) );
        }
    }
    FUNC_OUT
}

// slots connected to account
void
ContactListModelPrivate::onAccountConnectionChanged( const Tp::ConnectionPtr &connection )
{
    FUNC_IN
    if( mConnection == connection )
    {
        FUNC_OUT
        return;
    }

    disconnectConnection( mConnection );
    mConnection = connection;

    if( connection.isNull() )
    {
        // remove content from model
        foreach( Tp::ContactPtr contact, mPendingContacts )
        {
            disconnectContact( contact );
        }
        mPendingContacts.clear();

        if( mContactList.count() > 0 )
        {
            mParent->beginRemoveRows( QModelIndex(), 0, mContactList.count() - 1 );
            foreach( Tp::ContactPtr contact, mContactList )
            {
                disconnectContact( contact );
            }
            mParent->endRemoveRows();
        }
        mContactList.clear();
        foreach( Tp::ContactPtr contact, mUnsubscribedContactList )
        {
            disconnectContact( contact );
        }
        mUnsubscribedContactList.clear();
    } else
    {
        mConnection = mAccount->connection();

        connectConnection( mConnection );
        connect( mConnection->becomeReady(CONNECTION_FEATURES), SIGNAL(finished(Tp::PendingOperation *)),
                 this, SLOT(onConnectionReady(Tp::PendingOperation *)) );
    }
    FUNC_OUT
}

void
ContactListModelPrivate::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName()
                   << operation->errorMessage();
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), ContactListModel::NotificationTypeError );
        FUNC_OUT
        return;
    }

    mConnection = mAccount->connection();
    if( !mConnection.isNull() )
    {
        connectConnection( mConnection );

        connect( mConnection->becomeReady(CONNECTION_FEATURES), SIGNAL(finished(Tp::PendingOperation *)),
                 this, SLOT(onConnectionReady(Tp::PendingOperation *)) );
    }

    // set local service variable
    mAccountService = mAccount->serviceName();
    QString iconName = mAccount->iconName();
    if( mAccountService.isEmpty() )
    {
        mAccountService = iconName;
        if( mAccountService.startsWith("im-") )
        {
            mAccountService.remove( 0, 3 );
        }
    }

    if( mAccountService == "xmpp" )
    {
        mAccountService = "jabber";
    }

    if( mAccountService == "jabber" )
    {
        if( iconName.endsWith( "google-talk") )
        {
            mAccountService = "google-talk";
        } else if( iconName.endsWith("facebook") )
        {
            mAccountService = "facebook";
        } else
        {
            if( mAccount->parameters().contains("server") )
            {
                QString server = mAccount->parameters().value("server").toString();
                if( server == "talk.google.com" )
                {
                    mAccountService = "google-talk";
                } else if( server.endsWith("facebook.com") )
                {
                    mAccountService = "facebook";
                }
            }
        }
    }
    FUNC_OUT
}

void
ContactListModelPrivate::onAccountRemoved()
{
    FUNC_IN
    foreach( Tp::ContactPtr contact, mPendingContacts )
    {
        disconnectContact( contact );
    }
    mPendingContacts.clear();
    if( mContactList.count() > 0 )
    {
        mParent->beginRemoveRows( QModelIndex(), 0, mContactList.count() - 1 );
        foreach( Tp::ContactPtr contact, mContactList )
        {
            disconnectContact( contact );
        }
        mParent->endRemoveRows();
    }
    mContactList.clear();
    foreach( Tp::ContactPtr contact, mUnsubscribedContactList )
    {
        disconnectContact( contact );
    }
    mUnsubscribedContactList.clear();

    disconnectContactManager( mContactManager );
    disconnectConnection( mConnection );
    disconnectAccount( mAccount );
    FUNC_OUT
}

void
ContactListModelPrivate::onChannelRequestFailed( const QString &errorName, const QString &errorMessage )
{
    FUNC_IN
    emit mParent->notification( errorName.split(".").last(), errorMessage, ContactListModel::NotificationTypeError );
    FUNC_OUT
}

// slots connected to contact manager
void
ContactListModelPrivate::onContactManagerPresencePublicationRequested( const Tp::Contacts &contacts )
{
    FUNC_IN
    // TODO upgrade newly added contacts
    foreach(Tp::ContactPtr contact, contacts)
    {

//        // check if contact is already in list
//        if( !mContactList.contains(contact) )
//        {
//            // put contact into list
//            addToSubscribedList( contact );
//        }

        // emit signal
        emit mParent->presencePublicationRequested( contact->id() );
    }

    // emit signal
    FUNC_OUT
}
void
ContactListModelPrivate::onContactManagerAllKnownContactsChanged( const Tp::Contacts &contactsAdded,
                                                                  const Tp::Contacts &contactsRemoved,
                                                                  const Tp::Channel::GroupMemberChangeDetails &details)
{
    FUNC_IN
    Q_UNUSED( details );

    QStringList contactIds;
    foreach( Tp::ContactPtr contact, contactsRemoved )
    {
        // get row
        int row = mContactList.indexOf( contact );

        // remove from internal lists
        if( row >= 0 )
        {
            mParent->beginRemoveRows( QModelIndex(), row, row );
            mContactList.removeAll( contact );
            mParent->endRemoveRows();
        } else
        {
            mUnsubscribedContactList.removeAll( contact );
        }

        // disconnect contact
        disconnectContact( contact );
    }

    foreach( Tp::ContactPtr contact, contactsAdded )
    {
        // add contact to internal list
        if( contact->subscriptionState() != Tp::Contact::PresenceStateNo
            || contact->publishState() != Tp::Contact::PresenceStateNo
            || contact->isBlocked() )
        {
            addToSubscribedList( contact );
        } else
        {
            addToUnsubscribedList( contact );
        }

        // first disconnect to not connect twice
        disconnectContact( contact );

        // connect contact
        connectContact( contact );
    }

    if( contactsAdded.count() > 0 )
    {
        // upgrade contact
        connect( mContactManager->upgradeContacts(contactsAdded.toList(), CONTACT_FEATURES),
                 SIGNAL(finished(Tp::PendingOperation *)),
                 this,
                 SLOT(onContactManagerContactsUpgraded(Tp::PendingOperation *)) );
    }
    FUNC_OUT
}
void
ContactListModelPrivate::onContactManagerStateChanged( Tp::ContactListState state )
{
    FUNC_IN
    Q_UNUSED( state );
    FUNC_OUT
}

void
ContactListModelPrivate::onContactManagerContactsRemoved( Tp::PendingOperation *operation )
{
    FUNC_IN
    Q_UNUSED( operation );
    if( operation->isError() )
    {
        emit mParent->notification( operation->errorName().split(".").last(), operation->errorMessage(), ContactListModel::NotificationTypeError );
    }
    FUNC_OUT
}

void
ContactListModelPrivate::onContactManagerContactsUpgraded( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();
        FUNC_OUT
        return;
    }

    Tp::PendingContacts *pc = qobject_cast<Tp::PendingContacts *>(operation);
    QList<Tp::ContactPtr> contacts = pc->contacts();

    foreach( Tp::ContactPtr contact, contacts )
    { // if avatar is not known force to load data
        if( !contact->isAvatarTokenKnown() )
        {
            contact->requestAvatarData();
        }

        int row = mContactList.indexOf( contact );
        if( row >= 0 )
        {
            QModelIndex topLeft = mParent->index( row, 0 );
            QModelIndex bottomRight = mParent->index( row, ContactListModel::ColumnCount - 1 );
            emit mParent->dataChanged( topLeft, bottomRight );
        }
    }
    FUNC_OUT
}

void
ContactListModelPrivate::onPendingChannelRequestChannelRequestCreated( Tp::ChannelRequestPtr channelRequest )
{
    FUNC_IN
    connect( channelRequest.data(),
             SIGNAL(failed(QString, QString)),
             this,
             SLOT(onChannelRequestFailed(QString, QString)),
             Qt::DirectConnection );
    FUNC_OUT
}

void
ContactListModelPrivate::onPendingContactsFinished( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                << operation->errorName() + ": "
                   + operation->errorMessage();
        FUNC_OUT
        return;
    }

    Tp::PendingContacts *pc = qobject_cast<Tp::PendingContacts *>( operation );
    QList<Tp::ContactPtr> contacts = pc->contacts();

    foreach( Tp::ContactPtr contact, contacts )
    {
        if( contact.isNull() )
        {
            continue;
        }

        // as long as this function is only called when a contact is created (added to the contact list)
        // we can set presence publication/subscription here
        if( contact->isBlocked() )
        {
            contact->block( false );
        }
        if( contact->publishState() == Tp::Contact::PresenceStateNo )
        {
            contact->authorizePresencePublication();
        }
        if( contact->subscriptionState() == Tp::Contact::PresenceStateNo )
        {
            contact->requestPresenceSubscription();
        }
        addToSubscribedList( contact );
        // first disconnect to not connect twice
        disconnectContact( contact );
        // connect contact
        connectContact( contact );
    }
    FUNC_OUT
}

// slots connected to contacts
void
ContactListModelPrivate::onContactChanged()
{
    FUNC_IN
    Tp::ContactPtr contact( qobject_cast<Tp::Contact *>(sender()) );

    if( contact.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "cannot resolve sending contact";
        FUNC_OUT
        return;
    }

    if( contact->subscriptionState() != Tp::Contact::PresenceStateNo
        || contact->publishState() != Tp::Contact::PresenceStateNo
        || contact->isBlocked() )
    {
        int row = mContactList.indexOf( contact );
        if( row >= 0 )
        {
            QModelIndex topLeft = mParent->index( row, 0 );
            QModelIndex bottomRight = mParent->index( row, ContactListModel::ColumnCount - 1 );
            emit mParent->dataChanged( topLeft, bottomRight );
        } else
        {
            // move contact to mContactList
            addToSubscribedList( contact );
        }
    } else
    {
        // move contact to mUnsubscribedContactList
        addToUnsubscribedList( contact );
    }
    FUNC_OUT
}
void
ContactListModelPrivate::onContactPublishStateChanged( Tp::Contact::PresenceState state )
{
    FUNC_IN
    Tp::ContactPtr contact( qobject_cast<Tp::Contact *>(sender()) );

    if( contact.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "signal from unknown contact";
        FUNC_OUT
        return;
    }

    switch( state )
    {
    case Tp::Contact::PresenceStateNo:
        break;
    case Tp::Contact::PresenceStateAsk:
        emit mParent->presencePublicationRequested( contact->id() );
        break;
    case Tp::Contact::PresenceStateYes:
        break;
    }
    FUNC_OUT
}
void
ContactListModelPrivate::onContactSubscriptionStateChanged( Tp::Contact::PresenceState state )
{
    FUNC_IN
    Tp::ContactPtr contact( qobject_cast<Tp::Contact *>(sender()) );

    if( contact.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "signal from unknown contact";
        FUNC_OUT
        return;
    }

    switch( state )
    {
    case Tp::Contact::PresenceStateNo:
        break;
    case Tp::Contact::PresenceStateAsk:
        break;
    case Tp::Contact::PresenceStateYes:
        break;
    }
    FUNC_OUT
}

// slots connected to connection
void
ContactListModelPrivate::onConnectionReady( Tp::PendingOperation* operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << operation->errorName() + ": " + operation->errorMessage();
        FUNC_OUT
        return;
    }

    Tp::PendingReady *pr = qobject_cast<Tp::PendingReady *>(operation);
    Tp::ConnectionPtr connection = Tp::ConnectionPtr::staticCast(pr->object());

    Q_ASSERT( connection == mConnection );

    disconnectContactManager( mContactManager );
    mContactManager = connection->contactManager();
    connectContactManager( mContactManager );

    if( connection->status() == Tp::ConnectionStatusConnected )
    {
        getAllKnownContacts();
    }
    FUNC_OUT
}

void
ContactListModelPrivate::onConnectionStatusChanged( Tp::ConnectionStatus status )
{
    FUNC_IN
    if( status == Tp::ConnectionStatusConnected )
    {
        disconnectContactManager( mContactManager );
        // get contact manager
        mContactManager = mConnection->contactManager();
        connectContactManager( mContactManager );
        // get list of contacts
        getAllKnownContacts();
    }
    FUNC_OUT
}

ContactListModelPrivate::~ContactListModelPrivate()
{
    FUNC_IN
    mParent = 0;
    mPendingContacts.clear();
    mAccount.reset();
    mAccountManager.reset();
    mConnection.reset();
    mContactManager.reset();

    mContactList.clear();
    mUnsubscribedContactList.clear();
    FUNC_OUT
}


/* *****************************************************************************
 * ContactListModel
 * ****************************************************************************/

void
ContactListModel::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames;
    rolenames.insert( Qt::DisplayRole,          "displayName");
    rolenames.insert( ContactIdRole,            "contactId" );
    rolenames.insert( PresenceStateRole,        "presenceState");
    rolenames.insert( PresenceStateMessageRole, "presenceStateMessage");
    rolenames.insert( CapabilitiesRole,         "capabilities");
    rolenames.insert( SubscriptionRole,         "subscription");
    rolenames.insert( PublicationRole,          "publication");
    rolenames.insert( BlockedRole,              "blocked");
    rolenames.insert( RemovedRole,              "removed");
    rolenames.insert( ServiceNameRole,          "serviceName" );
    rolenames.insert( AccountIdRole,            "accountId" );
    rolenames.insert( ContactAliasRole,         "contactAlias" );
    rolenames.insert( ReadableContactIdRole,    "readableContactId" );
    setRoleNames( rolenames );
    FUNC_OUT
}

ContactListModel::ContactListModel( const QString &accountPath,
                                    QObject *parent )
    : QAbstractItemModel( parent )
{
    FUNC_IN

    Peregrine::initialize();
    d = new ContactListModelPrivate( this );
    d->setAccountPath( accountPath );
    initRoleNames();

    FUNC_OUT
}

ContactListModel::~ContactListModel()
{
    FUNC_IN
    delete d;
    FUNC_OUT
}

int
ContactListModel::rowCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( d->mConnection.isNull() )
    {
        FUNC_OUT
        return 0;
    }
    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return d->mContactList.count();
}

int
ContactListModel::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return ColumnCount;
}

QVariant
ContactListModel::data( const QModelIndex &index,
                        int role ) const
{
    FUNC_IN
    if( !index.isValid()
        || index.parent().isValid() )
    {
        FUNC_OUT
        return QVariant();
    }

    int row = index.row();
    int column = index.column();

    if( row < 0 || row >= rowCount() )
    {
        FUNC_OUT
        return QVariant();
    }
    if( column < 0 || column >= ColumnCount )
    {
        FUNC_OUT
        return QVariant();
    }

    Tp::ContactPtr contact = d->mContactList.at( row );

    if( column == ColumnContact )
    {
        switch( role )
        {
        case Qt::DisplayRole:
            FUNC_OUT
            return contact->id();
        case Qt::DecorationRole:
            {
                if( !contact->isAvatarTokenKnown() )
                {
                    d->mContactManager->requestContactAvatar( contact.data() );
                    FUNC_OUT
                    return QString();
                }
                FUNC_OUT
                return contact->avatarData().fileName;
            }
        case ContactIdRole:
            FUNC_OUT
            return createContactId( accountPath(), contact->id() );
        case PresenceStateRole:
            FUNC_OUT
            return contact->presence().status();
        case PresenceStateMessageRole:
            FUNC_OUT
            return contact->presence().statusMessage();
        case CapabilitiesRole:
            {
                Tp::ContactCapabilities caps = contact->capabilities();
                int capflags = CapabilityNone;

                if( caps.isSpecificToContact() )
                {
                    caps.textChats() && (capflags |= CapabilityTextChat);
                    caps.streamedMediaCalls() && (capflags |= CapabilityMediaCall);
                    caps.streamedMediaAudioCalls() && (capflags |= CapabilityAudioCall);
                    caps.streamedMediaVideoCalls() && (capflags |= CapabilityVideoCall);
                    caps.upgradingStreamedMediaCalls() && (capflags |= CapabilityUpgradeCall);
                    caps.fileTransfers() && (capflags |= CapabilityFileTransfer);
                }
                else
                {
                    caps.textChats() && (capflags |= CapabilityTextChat);
                    caps.streamedMediaCalls() && (capflags |= CapabilityMediaCall);
                    caps.streamedMediaAudioCalls() && (capflags |= CapabilityAudioCall);
                    caps.streamedMediaVideoCalls() && (capflags |= CapabilityVideoCall);
                    caps.upgradingStreamedMediaCalls() && (capflags |= CapabilityUpgradeCall);
                    caps.fileTransfers() && (capflags |= CapabilityFileTransfer);
                }

                FUNC_OUT
                return capflags;
            }
        case SubscriptionRole:
            {
                Tp::Contact::PresenceState state = contact->subscriptionState();
                if( state == Tp::Contact::PresenceStateNo )
                {
                    FUNC_OUT
                    return QString( "no" );
                } else if( state == Tp::Contact::PresenceStateAsk )
                {
                    FUNC_OUT
                    return QString( "ask" );
                } else if( state == Tp::Contact::PresenceStateYes )
                {
                    FUNC_OUT
                    return QString( "yes" );
                } else
                { // should never happen
                    qWarning() << __PRETTY_FUNCTION__ << "Telepathy Qt4 returned a value that is out of range: " + QString::number(state);
                    FUNC_OUT
                    return QString();
                }
            }
        case PublicationRole:
            {
                Tp::Contact::PresenceState state = contact->publishState();
                if( state == Tp::Contact::PresenceStateNo )
                {
                    FUNC_OUT
                    return QString( "no" );
                } else if( state == Tp::Contact::PresenceStateAsk )
                {
                    FUNC_OUT
                    return QString( "ask" );
                } else if( state == Tp::Contact::PresenceStateYes )
                {
                    FUNC_OUT
                    return QString( "yes" );
                } else
                { // should never happen
                    qWarning() << __PRETTY_FUNCTION__ << "Telepathy Qt4 returned a value that is out of range: " + QString::number(state);
                    FUNC_OUT
                    return QString();
                }
            }
        case BlockedRole:
            FUNC_OUT
            return contact->isBlocked();
        case ServiceNameRole:
            FUNC_OUT
            return d->mAccountService;
        case AccountIdRole:
            FUNC_OUT
            return d->mAccountPath;
        case ContactAliasRole:
            FUNC_OUT
            return contact->alias();
        case ReadableContactIdRole:
            FUNC_OUT
            return contact->id();
        case RoleCount:
            FUNC_OUT
            return QVariant();
        }
    } else if( column == ColumnState )
    {
        switch( role )
        {
        case Qt::DisplayRole:
            FUNC_OUT
            return contact->presence().status();
        case Qt::DecorationRole:
            // TODO
            FUNC_OUT
            return QVariant();
        case PresenceStateRole:
            FUNC_OUT
            return contact->presence().type();
        case PresenceStateMessageRole:
            FUNC_OUT
            return contact->presence().statusMessage();
        case ContactIdRole:
        case CapabilitiesRole:
        case SubscriptionRole:
        case PublicationRole:
        case BlockedRole:
        case ServiceNameRole:
        case AccountIdRole:
        case ReadableContactIdRole:
        case RoleCount:
            FUNC_OUT
            return QVariant();
        }
    } else if( column == ColumnAuthorisation )
    {
        switch( role )
        {
        case SubscriptionRole:
            {
                Tp::Contact::PresenceState state = contact->subscriptionState();
                if( state == Tp::Contact::PresenceStateNo )
                {
                    FUNC_OUT
                    return QString( "no" );
                } else if( state == Tp::Contact::PresenceStateAsk )
                {
                    FUNC_OUT
                    return QString( "ask" );
                } else if( state == Tp::Contact::PresenceStateYes )
                {
                    FUNC_OUT
                    return QString( "yes" );
                } else
                { // should never happen
                    FUNC_OUT
                    return QString();
                }
            }
        case PublicationRole:
            {
                Tp::Contact::PresenceState state = contact->publishState();
                if( state == Tp::Contact::PresenceStateNo )
                {
                    FUNC_OUT
                    return QString( "no" );
                } else if( state == Tp::Contact::PresenceStateAsk )
                {
                    FUNC_OUT
                    return QString( "ask" );
                } else if( state == Tp::Contact::PresenceStateYes )
                {
                    FUNC_OUT
                    return QString( "yes" );
                } else
                { // should never happen
                    FUNC_OUT
                    return QString();
                }
            }
        case BlockedRole:
            FUNC_OUT
            return contact->isBlocked();
        case Qt::DisplayRole:
        case Qt::DecorationRole:
        case ContactIdRole:
        case PresenceStateRole:
        case PresenceStateMessageRole:
        case CapabilitiesRole:
        case ServiceNameRole:
        case AccountIdRole:
        case ReadableContactIdRole:
        case RoleCount:
            FUNC_OUT
            return QVariant();
        }
    } else if( column == ColumnGroup )
    {
        switch( role )
        {
        case Qt::DisplayRole:
            FUNC_OUT
            return contact->groups();
        case Qt::DecorationRole:
        case ContactIdRole:
        case PresenceStateRole:
        case PresenceStateMessageRole:
        case CapabilitiesRole:
        case SubscriptionRole:
        case PublicationRole:
        case BlockedRole:
        case ServiceNameRole:
        case AccountIdRole:
        case ReadableContactIdRole:
        case RoleCount:
            FUNC_OUT
            return QVariant();
        }
    }
    FUNC_OUT
    return QVariant();
}

QVariant ContactListModel::headerData( int section, Qt::Orientation orientation, int role ) const
{
    FUNC_IN
    if( (role != Qt::DisplayRole) )
    {
        FUNC_OUT
        return QVariant();
    }

    if( orientation == Qt::Horizontal ) {
        switch( section )
        {
        case ColumnContact:
            FUNC_OUT
            return QString( "Contact" );
        case ColumnState:
            FUNC_OUT
            return QString( "Presence State" );
        case ColumnAuthorisation:
            FUNC_OUT
            return QString( "Authorization State" );
        case ColumnGroup:
            FUNC_OUT
            return QString( "Groups" );
        }
    }
    FUNC_OUT
    return QString();
}

QModelIndex ContactListModel::index( int row,
                                     int column,
                                     const QModelIndex &parent ) const
{
    if( parent.isValid()
        || row < 0 || row >= d->mContactList.count()
        || column < 0 || column >= ColumnCount )
    {
        return QModelIndex();
    }

    return createIndex( row, column, d->mContactList.at(row).data() );
}

QModelIndex ContactListModel::parent( const QModelIndex &child ) const
{
    Q_UNUSED( child );
    return QModelIndex();
}

Qt::ItemFlags ContactListModel::flags( const QModelIndex &index ) const
{
    FUNC_IN
    if( !index.isValid() )
    {
        FUNC_OUT
        return Qt::NoItemFlags;
    }

    FUNC_OUT
    return QAbstractItemModel::flags( index );
}

bool ContactListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    FUNC_IN

    if( !index.isValid() || index.parent().isValid() )
    {
        FUNC_OUT
        return false;
    }

    int row = index.row();
    int column = index.column();

    if( row < 0 || row >= rowCount() )
    {
        FUNC_OUT
        return false;
    }

    Tp::ContactPtr contact = d->mContactList.at(row);

    if( column == ColumnContact )
    {
        switch( role )
        {
        case SubscriptionRole:
            {
                QString subscription = value.toString();
                if( subscription == "yes" )
                {
                    contact->requestPresenceSubscription();
                } else if( subscription == "no" )
                {
                    contact->removePresenceSubscription();
                    if( contact->publishState() == Tp::Contact::PresenceStateNo
                        && !contact->isBlocked() )
                    {
                        d->mContactManager->removeContacts( QList<Tp::ContactPtr>() << contact );
                        d->addToUnsubscribedList( contact );
                    }
                }
            }
            return true;
        case PublicationRole:
            {
                QString publication = value.toString();
                if( publication == "yes" )
                {
                    contact->authorizePresencePublication();
                } else if( publication == "no" )
                {
                    contact->removePresencePublication();
                    if( contact->subscriptionState() == Tp::Contact::PresenceStateNo
                        && !contact->isBlocked() )
                    {
                        d->mContactManager->removeContacts( QList<Tp::ContactPtr>() << contact );
                        d->addToUnsubscribedList( contact );
                    }
                }
            }
            return true;
        case BlockedRole:
            {
                bool blocked = value.toBool();
                if( blocked )
                {
                    contact->removePresencePublication();
                    contact->block( true );
                } else
                {
                    contact->requestPresenceSubscription();
                    contact->authorizePresencePublication();
                    contact->block( false );
                    if( contact->subscriptionState() == Tp::Contact::PresenceStateNo
                        && contact->publishState() == Tp::Contact::PresenceStateNo )
                    {
                        d->mContactManager->removeContacts( QList<Tp::ContactPtr>() << contact );
                        d->addToUnsubscribedList( contact );
                    }
                }
            }
            return true;
        }
    } else if( column == ColumnAuthorisation )
    {
        switch( role )
        {
        case SubscriptionRole:
            {
                QString subscription = value.toString();
                if( subscription == "yes" )
                {
                    contact->requestPresenceSubscription();
                } else if( subscription == "no" )
                {
                    contact->removePresenceSubscription();
                    if( contact->publishState() == Tp::Contact::PresenceStateNo
                        && !contact->isBlocked() )
                    {
                        d->mContactManager->removeContacts( QList<Tp::ContactPtr>() << contact );
                        d->addToUnsubscribedList( contact );
                    }
                }
            }
            return true;
        case PublicationRole:
            {
                QString publication = value.toString();
                if( publication == "yes" )
                {
                    contact->authorizePresencePublication();
                } else if( publication == "no" )
                {
                    contact->removePresencePublication();
                    if( contact->subscriptionState() == Tp::Contact::PresenceStateNo
                        && !contact->isBlocked() )
                    {
                        d->mContactManager->removeContacts( QList<Tp::ContactPtr>() << contact );
                        d->addToUnsubscribedList( contact );
                    }
                }
            }
            return true;
        case BlockedRole:
            {
                bool blocked = value.toBool();
                if( blocked )
                {
                    contact->removePresencePublication();
                    contact->block( true );
                } else
                {
                    contact->requestPresenceSubscription();
                    contact->authorizePresencePublication();
                    contact->block( false );
                    if( contact->subscriptionState() == Tp::Contact::PresenceStateNo
                        && contact->publishState() == Tp::Contact::PresenceStateNo )
                    {
                        d->mContactManager->removeContacts( QList<Tp::ContactPtr>() << contact );
                        d->addToUnsubscribedList( contact );
                    }
                }
            }
            return true;
        }
    }
    FUNC_OUT
    return false;
}

bool
ContactListModel::startTextChat( int row )
{
    FUNC_IN
    if( d->mAccount.isNull()
        || !d->mAccount->capabilities().textChats() )
    {
        emit notification( "Text chat not supported", "Account not capable to hanlde selected channel type", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }
    if( row < 0
        || row >= d->mContactList.count() )
    {
        emit notification( "Invalid index", "Contact index out of range", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    Tp::ContactPtr contact = d->mContactList.at( row );
    if( !contact->capabilities().textChats() )
    {
        emit notification( "Text chat not supported", "Contact not capable to handle selected channel type", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    QString clientName = ClientHandlerPrivate::clientName();
    if( !clientName.isEmpty() )
    {
        clientName = TP_QT4_IFACE_CLIENT + "." + clientName;
    }
    Tp::PendingChannelRequest *request = d->mAccount->ensureTextChat( contact,
                                                                      QDateTime::currentDateTime(),
                                                                      clientName );

    connect( request,
             SIGNAL(channelRequestCreated(Tp::ChannelRequestPtr)),
             d.data(),
             SLOT(onPendingChannelRequestChannelRequestCreated(Tp::ChannelRequestPtr)),
             Qt::DirectConnection);

    FUNC_OUT
    return true;
}

bool
ContactListModel::startVoIPCall( int row )
{
    FUNC_IN
    if( d->mAccount.isNull()
        || !d->mAccount->capabilities().streamedMediaVideoCalls() )
    {
        emit notification( "Video call not supported", "Account not capable to hanlde selected channel type", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }
    if( row < 0
        || row >= d->mContactList.count() )
    {
        emit notification( "Invalid index", "Contact index out of range", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    Tp::ContactPtr contact = d->mContactList.at( row );
    if( !contact->capabilities().streamedMediaAudioCalls() )
    {
        emit notification( "VoIP call not supported", "Contact not capable to handle selected channel type", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    QString clientName = ClientHandlerPrivate::clientName();
    if( !clientName.isEmpty() )
    {
        clientName = TP_QT4_IFACE_CLIENT + "." + clientName;
    }
    Tp::PendingChannelRequest *request = d->mAccount->ensureStreamedMediaAudioCall( contact,
                                                                                    QDateTime::currentDateTime(),
                                                                                    clientName );

    connect( request,
             SIGNAL(channelRequestCreated(Tp::ChannelRequestPtr)),
             d.data(),
             SLOT(onPendingChannelRequestChannelRequestCreated(Tp::ChannelRequestPtr)) );

    FUNC_OUT
    return true;
}

bool
ContactListModel::startVideoCall( int row )
{
    FUNC_IN
    if( d->mAccount.isNull()
        || !d->mAccount->capabilities().streamedMediaAudioCalls() )
    {
        emit notification( "VoIP call not supported", "Account not capable to hanlde selected channel type", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }
    if( row < 0
        || row >= d->mContactList.count() )
    {
        emit notification( "Invalid index", "Contact index out of range", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    Tp::ContactPtr contact = d->mContactList.at( row );
    if( !contact->capabilities().streamedMediaAudioCalls() )
    {
        emit notification( "VoIP call not supported", "Contact not capable to handle selected channel type", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    if( !contact->capabilities().streamedMediaVideoCalls() )
    {
        emit notification( "Video call not supported", "Contact not capable to handle selected channel type", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    QString clientName = ClientHandlerPrivate::clientName();
    if( !clientName.isEmpty() )
    {
        clientName = TP_QT4_IFACE_CLIENT + "." + clientName;
    }
    Tp::PendingChannelRequest *request = d->mAccount->ensureStreamedMediaVideoCall( contact, true,
                                                                                    QDateTime::currentDateTime(),
                                                                                    clientName );

    connect( request,
             SIGNAL(channelRequestCreated(Tp::ChannelRequestPtr)),
             d.data(),
             SLOT(onPendingChannelRequestChannelRequestCreated(Tp::ChannelRequestPtr)) );

    FUNC_OUT
    return true;
}

bool ContactListModel::removeRow( int row, const QModelIndex &parent )
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return false;
    }
    if( row < 0
        || row >= rowCount() )
    {
        FUNC_OUT
        return false;
    }

    Tp::ContactPtr contact = d->mContactList.at(row);

    beginRemoveRows( QModelIndex(), row, row );

    if( !contact.isNull() )
    {
        d->disconnectContact( contact );
        connect( d->mContactManager->removeContacts( QList<Tp::ContactPtr>() << contact ),
                 SIGNAL(finished(Tp::PendingOperation *)),
                 d,
                 SLOT(onContactManagerContactsRemoved(Tp::PendingOperation *)) );
    } else
    {
        qWarning() << __PRETTY_FUNCTION__ << "contact is null!!!";
    }

    d->addToUnsubscribedList( contact, false );

    endRemoveRows();

    FUNC_OUT
    return true;
}

QModelIndex ContactListModel::indexForContactId( const QString &contactId ) const
{
    FUNC_IN
    int row = rowForContactId( contactId );
    if( row >= 0 )
    {
        FUNC_OUT
        return index( row, 0 );
    }

    FUNC_OUT
    return QModelIndex();
}

int ContactListModel::rowForContactId( const QString &contactId ) const
{
    FUNC_IN
    QString cid = contactId;

    QPair<QString, QString> pair = splitContactId( contactId );
    if( !pair.first.isEmpty() )
    {
        if( pair.first != d->mAccountPath )
        {
            return -1;
        }
        cid = pair.second;
    }

    for( int row = 0; row < d->mContactList.count(); ++row )
    {
        if( d->mContactList.at(row)->id() == cid )
        {
            FUNC_OUT
            return row;
        }
    }

    FUNC_OUT
    return -1;
}

QString ContactListModel::accountId() const
{
    FUNC_IN
    if( d->mAccount.isNull() )
    {
        FUNC_OUT
        return QString();
    }
    FUNC_OUT
    return d->mAccount->normalizedName();
}

QString ContactListModel::accountPath() const
{
    FUNC_IN
    FUNC_OUT
    return d->mAccountPath;
}

bool ContactListModel::createContact( const QString &contactId )
{
    FUNC_IN
    // check id validity
    if( contactId.isEmpty() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "No contact ID set!";
        emit notification( "No contact ID set", "Cannot create contact without contact ID", NotificationTypeError );
        FUNC_OUT
        return false;
    }
    // check online state
    if( d->mConnection.isNull() || (d->mConnection->status() != Tp::ConnectionStatusConnected) )
    {
        qWarning() << __PRETTY_FUNCTION__ << "Account is not connected!";
        emit notification( "Account not connected!", "Cannot create contact if account is not online", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }
    if( d->mContactManager.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "Contact manager not available!";
        emit notification( "Unsupported feature", "Contact manager not available!", NotificationTypeError );
        FUNC_OUT
        return false;
    }

    // check if it is a global unique or local unique id
    QPair<QString, QString> pair = splitContactId( contactId );
    QString cId = contactId;
    if( !pair.first.isEmpty() )
    {
        if( pair.first != d->mAccountPath )
        {
            return false;
        }
        cId = pair.second;
    }

    if( rowForContactId(contactId) >= 0 )
    { // TODO realy return true?
        // if already exist request presence subscription
        emit notification( "Cannot create duplicates", "Contact `" + contactId + "'already exists", NotificationTypeNotice );
        FUNC_OUT
        return true;
    }

    Tp::PendingContacts *pContacts = d->mContactManager->contactsForIdentifiers(QStringList() << cId, ContactListModelPrivate::CONTACT_FEATURES);
    connect( pContacts,
             SIGNAL(finished(Tp::PendingOperation *)),
             d,
             SLOT(onPendingContactsFinished(Tp::PendingOperation *)),
             Qt::DirectConnection );

    FUNC_OUT
    return true;
}

void ContactListModel::setAccountPath( const QString &accountPath )
{
    d->setAccountPath( accountPath );
}
