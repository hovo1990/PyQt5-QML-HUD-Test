/*
 * contactlistaggregatormodel.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "contactlistaggregatormodel.h"
#include "contactlistaggregatormodel_p.h"

#include "contactlistmodel.h"
#include "../peregrineDebugHelper.h"
#include "../peregrineinitializer.h"

#include <TelepathyQt4/PendingReady>

using namespace Peregrine;

/* *****************************************************************************
 * ContactListAggregatorModelPrivate
 * ****************************************************************************/

const Tp::Features ContactListAggregatorModelPrivate::ACCOUNT_MANAGER_FEATURES = ( Tp::Features() << Tp::AccountManager::FeatureCore );


ContactListAggregatorModelPrivate::ContactListAggregatorModelPrivate( ContactListAggregatorModel *parent )
    : QObject( parent ),
    mParent( parent )
{
    FUNC_IN
    if( mParent.isNull() )
    {
        deleteLater();
        FUNC_OUT
        return;
    }

    mAccountManager = Tp::AccountManager::create();
    connectAccountManager( mAccountManager );
    connect( mAccountManager->becomeReady(ACCOUNT_MANAGER_FEATURES),
             SIGNAL(finished(Tp::PendingOperation*)),
             this,
             SLOT(onAccountManagerReady(Tp::PendingOperation*)) );
    FUNC_OUT
}

void ContactListAggregatorModelPrivate::clear()
{
    FUNC_IN

    // remove old stuff
    disconnectAccountSet( mAccountSet );
    mAccountSet.reset();

    foreach( QString accountId, mAccountIds )
    {
        QAbstractItemModel *model = mContactLists.value( accountId );
        if( model )
        {
            disconnectModel( model );
            delete model;
        }
        Tp::AccountPtr account = mAccounts.value( accountId );
        if( !account.isNull() )
        {
            disconnectAccount( account );
        }
    }

    mContactLists.clear();
    mAccounts.clear();
    mAccountIds.clear();

    FUNC_OUT
}

bool
ContactListAggregatorModelPrivate::connectAccountManager( Tp::AccountManagerPtr accountManager )
{
    FUNC_IN
    if( accountManager.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

//    result &= connect( accountManager.data(), SIGNAL(newAccount(Tp::AccountPtr)),
//                       this, SLOT(onAccountManagerNewAccount(Tp::AccountPtr)) );

    FUNC_OUT
    return result;
}
bool
ContactListAggregatorModelPrivate::disconnectAccountManager( Tp::AccountManagerPtr accountManager )
{
    FUNC_IN
    if( accountManager.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( accountManager.data(), 0, this, 0 );
}

bool
ContactListAggregatorModelPrivate::connectAccountSet( Tp::AccountSetPtr accountSet )
{
    FUNC_IN
    if( accountSet.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( accountSet.data(),
                       SIGNAL(accountAdded(Tp::AccountPtr)),
                       this,
                       SLOT(onAccountSetAccountAdded(Tp::AccountPtr)) );
    result &= connect( accountSet.data(),
                       SIGNAL(accountRemoved(Tp::AccountPtr)),
                       this,
                       SLOT(onAccountSetAccountRemoved(Tp::AccountPtr)),
                       Qt::DirectConnection );

    FUNC_OUT
    return result;
}
bool
ContactListAggregatorModelPrivate::disconnectAccountSet( Tp::AccountSetPtr accountSet )
{
    FUNC_IN
    if( accountSet.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( accountSet.data(), 0, this, 0 );
}

bool
ContactListAggregatorModelPrivate::connectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( account.data(),
                       SIGNAL(removed()),
                       this,
                       SLOT(onAccountRemoved()),
                       Qt::DirectConnection );

    FUNC_OUT
    return result;
}
bool
ContactListAggregatorModelPrivate::disconnectAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( account.data(), 0, this, 0 );
}

bool
ContactListAggregatorModelPrivate::connectModel( QAbstractItemModel *contactList )
{
    FUNC_IN
    if( !contactList )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( contactList,
                       SIGNAL(modelReset()),
                       mParent,
                       SLOT(onModelReset()) );
    result &= connect( contactList,
                       SIGNAL(modelAboutToBeReset()),
                       mParent,
                       SLOT(onModelAboutToBeReset()) );
    result &= connect( contactList,
                       SIGNAL(dataChanged(QModelIndex, QModelIndex)),
                       mParent,
                       SLOT(onDataChanged(QModelIndex, QModelIndex)) );
    result &= connect( contactList,
                       SIGNAL(rowsAboutToBeInserted(QModelIndex, int, int)),
                       mParent,
                       SLOT(onRowsAboutToBeInserted(QModelIndex,int,int)) );
    result &= connect( contactList,
                       SIGNAL(rowsInserted(QModelIndex, int, int)),
                       mParent,
                       SLOT(onRowsInserted(QModelIndex, int, int)) );
    result &= connect( contactList,
                       SIGNAL(rowsRemoved(QModelIndex, int, int)),
                       mParent,
                       SLOT(onRowsRemoved(QModelIndex, int, int)) );
    result &= connect( contactList,
                       SIGNAL(rowsAboutToBeRemoved(QModelIndex, int, int)),
                       mParent,
                       SLOT(onRowsAboutToBeRemoved(QModelIndex, int, int)) );

    result &= connect( contactList,
                       SIGNAL(contactDeleted(QString)),
                       mParent,
                       SIGNAL(contactDeleted(QString)) );
    result &= connect( contactList,
                       SIGNAL(presencePublicationRequested(QString)),
                       mParent,
                       SIGNAL(presencePublicationRequested(QString)) );
    result &= connect( contactList,
                       SIGNAL(notification(QString, QString, NotificationTypes)),
                       mParent,
                       SIGNAL(notification(QString, QString, NotificationTypes)) );

    FUNC_OUT
    return result;
}
bool
ContactListAggregatorModelPrivate::disconnectModel( QAbstractItemModel *contactList )
{
    FUNC_IN
    if( !contactList )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( contactList, 0, this, 0 );
}

void
ContactListAggregatorModelPrivate::onAccountManagerReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__ << operation->errorName() + ": " + operation->errorMessage();
        FUNC_OUT
        return;
    }

    mParent->beginResetModel();

    // store list of accountIds if model is in auto-controlled mode
    QStringList accountIds = mAccountSet.isNull() ? mAccountIds : QStringList();
    // remove old stuff
    clear();
    mAccountIds = accountIds;

    if( mAccountIds.isEmpty() )
    {
        mAccountSet = mAccountManager->validAccounts();
        connectAccountSet( mAccountSet );

        foreach( Tp::AccountPtr account, mAccountSet->accounts() )
        {
            // whitelist all jabber, skype accounts
            QString protocolName = account->protocolName();
            if( protocolName != "jabber"
                && protocolName != "skype" )
            {
                continue;
            }

            QString path = account->objectPath();
            mAccountIds.append( path );

            ContactListModel *model = new ContactListModel( path );
            connectModel( model );
            mContactLists.insert( path, model );

            account->becomeReady( Tp::Account::FeatureCore );
            mAccounts.insert( path, account );
        }
    } else
    {
        QList<Tp::AccountPtr> accounts = mAccountManager->accountsForPaths( mAccountIds );

        foreach( Tp::AccountPtr account, accounts)
        {
            QString path = account->objectPath();
            mAccountIds.append( path );

            ContactListModel *model = new ContactListModel( path );
            connectModel( model );
            mContactLists.insert( path, model );

            account->becomeReady( Tp::Account::FeatureCore );
            connectAccount( account );
            mAccounts.insert( path, account );
        }
    }

    mParent->endResetModel();
    FUNC_OUT
}

void
ContactListAggregatorModelPrivate::onAccountSetAccountAdded( const Tp::AccountPtr &account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }

    // whitelist all jabber, skype accounts
    QString protocolName = account->protocolName();
    if( protocolName != "jabber"
        && protocolName != "skype" )
    {
        FUNC_OUT
        return;
    }

    QString path = account->objectPath();

    if( mContactLists.contains(path) )
    {
        FUNC_OUT
        return;
    }

    mAccountIds.append( path );

    ContactListModel *model = new ContactListModel( path );

    int rows = model->rowCount();
    if( rows > 0 )
    {
        int row = mParent->rowCount();
        mParent->beginInsertRows( QModelIndex(), row, (row + rows - 1) );
    }

    connectModel( model );
    mContactLists.insert( path, model );

    account->becomeReady( Tp::Account::FeatureCore );
    mAccounts.insert( path, account );

    if( rows > 0 )
    {
        mParent->endInsertRows();
    }
    FUNC_OUT
}
void
ContactListAggregatorModelPrivate::onAccountSetAccountRemoved( const Tp::AccountPtr &account )
{
    FUNC_IN
    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }

    QString path = account->objectPath();

    if( !mContactLists.contains(path) )
    {
        FUNC_OUT
        return;
    }

    mAccountIds.removeAll( path );

    QAbstractItemModel *model = mContactLists.value( path );

    int rows = 0;
    if( model )
    {
        rows = model->rowCount();
        if( rows > 0 )
        {
            int row = 0;
            for( int i = 0; i < mAccountIds.indexOf(path); ++i )
            {
                row += mContactLists.value( mAccountIds.at(i) )->rowCount();
            }

            mParent->beginRemoveRows( QModelIndex(), row, (rows + row - 1) );
        }

        disconnectModel( model );
        delete model;
    }

    mContactLists.remove( path );

    disconnectAccount( mAccounts.value(path) );
    mAccounts.remove( path );

    if( rows > 0 )
    {
        mParent->endInsertRows();
    }
    FUNC_OUT
}

void
ContactListAggregatorModelPrivate::onAccountRemoved()
{
    FUNC_IN
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(sender()) );

    if( account.isNull() )
    {
        FUNC_OUT
        return;
    }

    QString path = account->objectPath();
    mAccountIds.removeAll( path );

    QAbstractItemModel *model = mContactLists.value( path );

    int rows = 0;
    if( model )
    {
        rows = model->rowCount();
        if( rows > 0 )
        {
            int row = 0;
            for( int i = 0; i < mAccountIds.indexOf(path); ++i )
            {
                row += mContactLists.value( mAccountIds.at(i) )->rowCount();
            }

            mParent->beginRemoveRows( QModelIndex(), row, (rows + row - 1) );
        }

        disconnectModel( model );
        delete model;
    }

    mContactLists.remove( path );

    disconnectAccount( mAccounts.value(path) );
    mAccounts.remove( path );

    if( rows > 0 )
    {
        mParent->endInsertRows();
    }
    FUNC_OUT
}

ContactListAggregatorModelPrivate::~ContactListAggregatorModelPrivate()
{
    FUNC_IN
    mParent = 0;
    mAccountIds.clear();

    foreach( QAbstractItemModel *model, mContactLists.values() )
    {
        delete model;
    }
    mContactLists.clear();
    mAccounts.clear();

    mAccountManager.reset();
    mAccountSet.reset();;
    FUNC_OUT
}

/* *****************************************************************************
 * ContactListAggregatorModel
 * ****************************************************************************/

void
ContactListAggregatorModel::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames;
    rolenames.insert( Qt::DisplayRole,          "displayName");
    rolenames.insert( ContactIdRole,            "contactId" );
    rolenames.insert( PresenceStateRole,        "presenceState");
    rolenames.insert( PresenceStateMessageRole, "presenceStateMessage");
    rolenames.insert( CapabilitiesRole,         "capabilities");
    rolenames.insert( SubscriptionRole,         "subscription");
    rolenames.insert( PublicationRole,          "publication");
    rolenames.insert( BlockedRole,              "blocked");
    rolenames.insert( RemovedRole,              "removed");
    rolenames.insert( ServiceNameRole,          "serviceName" );
    rolenames.insert( AccountIdRole,            "accountId" );
    rolenames.insert( ContactAliasRole,         "contactAlias" );
    rolenames.insert( ReadableContactIdRole,    "readableContactId" );
    setRoleNames( rolenames );
    FUNC_OUT
}

int
ContactListAggregatorModel::mapFromSource( const QAbstractItemModel *model,
                                           int row ) const
{
    FUNC_IN
    if( row < 0
        || model == 0 )
    {
        FUNC_OUT
        return -1;
    }

    int rows = 0;
    for( int i = 0; i < d->mAccountIds.count(); ++i )
    {
        QAbstractItemModel *currentModel = d->mContactLists.value( d->mAccountIds.at(i) );
        if( !currentModel )
        {
            continue;
        }
        if( currentModel != model )
        {
            rows += currentModel->rowCount();
            continue;
        }

        // model found
        FUNC_OUT
        return rows + row;
    }
    // model not found
    FUNC_OUT
    return -1;
}

// slots connected to ContactListModel
void
ContactListAggregatorModel::onDataChanged( const QModelIndex &topLeft,
                                           const QModelIndex &bottomRight )
{
    FUNC_IN
    if( !topLeft.isValid()
        || !bottomRight.isValid() )
    {
        FUNC_OUT
        return;
    }

    if( topLeft.parent() != bottomRight.parent() )
    {
        qWarning() << __PRETTY_FUNCTION__
                   << "topLeft and bottomRight indexes have different parents";
        FUNC_OUT
        return;
    }

    QModelIndex proxy_index_first = mapFromSource( topLeft );
    QModelIndex proxy_index_last = mapFromSource( bottomRight );

    if( proxy_index_first.isValid()
        && proxy_index_last.isValid() )
    {
        emit dataChanged( proxy_index_first, proxy_index_last );
    }
    FUNC_OUT
}

void
ContactListAggregatorModel::onRowsAboutToBeInserted( const QModelIndex &parent,
                                                     int start,
                                                     int end )
{
    FUNC_IN
    const ContactListModel *source_model = qobject_cast<const ContactListModel *>( sender() );
    if( !source_model )
    {
        FUNC_OUT
        return;
    }
    if( parent.isValid() )
    {
        QModelIndex newParent = mapFromSource( parent );
        beginInsertRows( newParent, start, end );
        FUNC_OUT
        return;
    }

    int newStart = mapFromSource( source_model, start );
    int newEnd = mapFromSource( source_model, end );
    beginInsertRows( QModelIndex(), newStart, newEnd );
    FUNC_OUT
}
void
ContactListAggregatorModel::onRowsInserted( const QModelIndex &parent,
                                            int start,
                                            int end )
{
    FUNC_IN
    Q_UNUSED( parent );
    Q_UNUSED( start );
    Q_UNUSED( end );
    endInsertRows();
    FUNC_OUT
}
void
ContactListAggregatorModel::onRowsAboutToBeRemoved( const QModelIndex &parent,
                                                    int start,
                                                    int end )
{
    FUNC_IN
    const ContactListModel *source_model = qobject_cast<const ContactListModel *>( sender() );
    if( !source_model )
    {
        FUNC_OUT
        return;
    }
    if( parent.isValid() )
    {
        QModelIndex newParent = mapFromSource( parent );
        beginRemoveRows( newParent, start, end );
        FUNC_OUT
        return;
    }

    int newStart = mapFromSource( source_model, start );
    int newEnd = mapFromSource( source_model, end );
    beginRemoveRows( QModelIndex(), newStart, newEnd );
    FUNC_OUT
}
void
ContactListAggregatorModel::onRowsRemoved( const QModelIndex &parent,
                                           int start,
                                           int end )
{
    FUNC_IN
    Q_UNUSED( parent );
    Q_UNUSED( start );
    Q_UNUSED( end );
    endRemoveRows();
    FUNC_OUT
}
void
ContactListAggregatorModel::onRowsAboutToBeMoved( const QModelIndex &parent,
                                                  int start,
                                                  int end,
                                                  const QModelIndex &destination,
                                                  int row )
{
    FUNC_IN
    const ContactListModel *source_model = qobject_cast<const ContactListModel *>( sender() );
    if( !source_model )
    {
        FUNC_OUT
        return;
    }

    QModelIndex newParent = parent;
    int newStart = start;
    int newEnd = end;
    QModelIndex newDestination = destination;
    int newRow = row;
    if( parent.isValid() )
    {
        newParent = mapFromSource( parent );
    } else
    {
        newStart = mapFromSource( source_model, start );
        newEnd = mapFromSource( source_model, end );
    }
    if( destination.isValid() )
    {
        newDestination = mapFromSource( destination );
    } else
    {
        newRow = mapFromSource( source_model, row );
    }

    beginMoveRows( newParent, newStart, newEnd, newDestination, newRow );
    FUNC_OUT
}
void
ContactListAggregatorModel::onRowsMoved( const QModelIndex &parent,
                                         int start,
                                         int end,
                                         const QModelIndex &destination,
                                         int row )
{
    FUNC_IN
    Q_UNUSED( parent );
    Q_UNUSED( start );
    Q_UNUSED( end );
    Q_UNUSED( destination );
    Q_UNUSED( row );
    endMoveRows();
    FUNC_OUT
}
void
ContactListAggregatorModel::onModelAboutToBeReset()
{
    FUNC_IN
    beginResetModel();
    FUNC_OUT
}
void
ContactListAggregatorModel::onModelReset()
{
    FUNC_IN
    endResetModel();
    FUNC_OUT
}

ContactListAggregatorModel::ContactListAggregatorModel( const QStringList &accountIds,
                                                        QObject *parent )
    : QAbstractItemModel( parent )
{
    FUNC_IN

    // initialize peregrine
    Peregrine::initialize();

    // initialize role names
    initRoleNames();

    // create and initialize private object
    d = new ContactListAggregatorModelPrivate( this );
    d->clear();
    d->mAccountIds = accountIds;

    FUNC_OUT
}

ContactListAggregatorModel::~ContactListAggregatorModel()
{
    FUNC_IN
    delete d;
    FUNC_OUT
}

QModelIndex
ContactListAggregatorModel::mapFromSource( const QModelIndex &sourceIndex ) const
{
    FUNC_IN
    if ( !sourceIndex.isValid()
        || sourceIndex.parent().isValid() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    int row = mapFromSource( sourceIndex.model(), sourceIndex.row() );

    FUNC_OUT
    return index( row, sourceIndex.column() );
}

QModelIndex
ContactListAggregatorModel::mapToSource( const QModelIndex & proxyIndex ) const
{
    FUNC_IN
    if( !proxyIndex.isValid()
        || proxyIndex.parent().isValid() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    int row_count = 0;
    for( int i = 0; i < d->mAccountIds.size(); ++i )
    {
        QAbstractItemModel *model = d->mContactLists.value( d->mAccountIds.at(i) );
        if( !model )
        {
            continue;
        }

        if( proxyIndex.row() < row_count + model->rowCount())
        {
            FUNC_OUT
            return model->index( proxyIndex.row() - row_count, proxyIndex.column() );
        }
        row_count += model->rowCount();
    }

    FUNC_OUT
    return QModelIndex();
}

int
ContactListAggregatorModel::rowCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( d->mAccountIds.isEmpty() )
    {
        FUNC_OUT
        return 0;
    }

    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    int row_count = 0;

    foreach( const QAbstractItemModel *contact_model, d->mContactLists )
    {
        row_count += contact_model->rowCount();
    }

    FUNC_OUT
    return row_count;
}

int
ContactListAggregatorModel::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }

    FUNC_OUT
    return ColumnCount;
}

QVariant
ContactListAggregatorModel::data( const QModelIndex &index,
                                  int role ) const
{
    FUNC_IN
    if( !index.isValid()
        || index.parent().isValid() )
    {
        FUNC_OUT
        return QVariant();
    }

    QModelIndex source_index = mapToSource( index );
    if( source_index.isValid() )
    {
        FUNC_OUT
        return source_index.data( role );
    }

    FUNC_OUT
    return QVariant();
}

QVariant
ContactListAggregatorModel::headerData( int section,
                                        Qt::Orientation orientation,
                                        int role ) const
{
    FUNC_IN
    if( (role != Qt::DisplayRole) )
    {
        FUNC_OUT
        return QVariant();
    }

    if( orientation == Qt::Horizontal ) {
        switch( section )
        {
        case ColumnContact:
            FUNC_OUT
            return QString( "Contact" );
        case ColumnState:
            FUNC_OUT
            return QString( "Presence State" );
        case ColumnAuthorisation:
            FUNC_OUT
            return QString( "Authorization State" );
        case ColumnGroup:
            FUNC_OUT
            return QString( "Groups" );
        }
    }
    FUNC_OUT
    return QString();
}

QModelIndex ContactListAggregatorModel::index(int row, int column, const QModelIndex &parent) const
{
    FUNC_IN
    if( parent.isValid()
        || column < 0
        || column >= ColumnCount
        || row < 0
        || row >= rowCount() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    FUNC_OUT
    return createIndex( row, column );
}

QModelIndex ContactListAggregatorModel::parent( const QModelIndex &child ) const
{
    FUNC_IN
    Q_UNUSED( child );
    FUNC_OUT
    return QModelIndex();
}

Qt::ItemFlags
ContactListAggregatorModel::flags( const QModelIndex &index ) const
{
    FUNC_IN
    if( !index.isValid()
        || index.parent().isValid() )
    {
        FUNC_OUT
        return Qt::NoItemFlags;
    }

    QModelIndex source_index = mapToSource( index );
    if( source_index.isValid() )
    {
        FUNC_OUT
        return source_index.flags();
    }

    FUNC_OUT
    return Qt::NoItemFlags;
}

bool
ContactListAggregatorModel::setData( const QModelIndex &index,
                                     const QVariant &value,
                                     int role )
{
    FUNC_IN
    if( !index.isValid()
        || index.parent().isValid() )
    {
        FUNC_OUT
        return false;
    }

    QModelIndex source_index = mapToSource( index );
    QAbstractItemModel *model = const_cast<QAbstractItemModel *>( source_index.model() );
    if( source_index.isValid() && model )
    {
        FUNC_OUT
        return model->setData( source_index, value, role );
    }

    FUNC_OUT
    return false;
}

bool
ContactListAggregatorModel::startTextChat( int row )
{
    FUNC_IN
    QModelIndex index = this->index( row, 0 );
    QModelIndex source_index = mapToSource( index );

    if( !source_index.isValid() )
    {
        FUNC_OUT
        return false;
    }

    ContactListModel *cl = qobject_cast<ContactListModel *>( const_cast<QAbstractItemModel *>(source_index.model()) );
    if( !cl )
    {
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return cl->startTextChat( source_index.row() );
}

bool
ContactListAggregatorModel::startVoIPCall( int row )
{
    FUNC_IN
    QModelIndex index = this->index( row, 0 );
    QModelIndex source_index = mapToSource( index );

    if( !source_index.isValid() )
    {
        FUNC_OUT
        return false;
    }

    ContactListModel *cl = qobject_cast<ContactListModel *>( const_cast<QAbstractItemModel *>(source_index.model()) );
    if( !cl )
    {
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return cl->startVoIPCall( source_index.row() );
}

bool
ContactListAggregatorModel::startVideoCall( int row )
{
    FUNC_IN
    QModelIndex index = this->index( row, 0 );
    QModelIndex source_index = mapToSource( index );

    if( !source_index.isValid() )
    {
        FUNC_OUT
        return false;
    }

    ContactListModel *cl = qobject_cast<ContactListModel *>( const_cast<QAbstractItemModel *>(source_index.model()) );
    if( !cl )
    {
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return cl->startVideoCall( source_index.row() );
}

bool
ContactListAggregatorModel::removeRow( int row,
                                       const QModelIndex &parent )
{
    FUNC_IN

    if( parent.isValid()
        || row < 0
        || row >= rowCount() )
    {
        FUNC_OUT
        return false;
    }

    QModelIndex index = this->index( row, 0 );
    QModelIndex source_index = mapToSource( index );

    if( source_index.isValid() )
    {
        //QAbstractItemModel *model = const_cast<QAbstractItemModel *>( source_index.model() );
        ContactListModel *model = const_cast<ContactListModel *>( qobject_cast<const ContactListModel *>(source_index.model()) );

        FUNC_OUT
        return model->removeRow( source_index.row() );
    }

    FUNC_OUT
    return false;
}

bool
ContactListAggregatorModel::removeRows( int row,
                                        int count,
                                        const QModelIndex &parent )
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    for( int i = (row + count - 1); i >= row; --i )
    {
        result &= removeRow( i );
    }

    FUNC_OUT
    return result;
}

QModelIndex
ContactListAggregatorModel::indexForContactId( const QString &contactId ) const
{
    FUNC_IN
    QString accountId = extractAccountId( contactId );
    ContactListModel *model = qobject_cast<ContactListModel *>( d->mContactLists.value(accountId, NULL) );
    if( !model )
    {
        FUNC_OUT
        return QModelIndex();
    }

    QModelIndex index = model->indexForContactId( contactId );
    FUNC_OUT
    return mapFromSource( index );
}

int
ContactListAggregatorModel::rowForContactId( const QString &contactId ) const
{
    FUNC_IN
    QModelIndex index = indexForContactId( contactId );
    if( index.isValid() )
    {
        FUNC_OUT
        return index.row();
    }

    FUNC_OUT
    return -1;
}

bool
ContactListAggregatorModel::createContact( const QString &accountId, const QString &contactId )
{
    FUNC_IN
    if( accountId.isEmpty()
        || contactId.isEmpty() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "Account ID and contact ID must be set!";
        emit notification( "No account ID or contact ID set", "To create a contact the account ID and contact ID must be set!", NotificationTypeError );
        FUNC_OUT
        return false;
    }

    ContactListModel *model = qobject_cast<ContactListModel *>( d->mContactLists.value(accountId, NULL) );
    if( model != 0 )
    {
        FUNC_OUT
        return model->createContact( contactId );
    }

    qWarning() << __PRETTY_FUNCTION__ << "Account ID invalid!";
    emit notification( "Invalid account ID", "Account with ID `" + accountId + "' could not be found!", NotificationTypeError );

    FUNC_OUT
    return false;
}

QStringList ContactListAggregatorModel::accountIds() const
{
    FUNC_IN
    FUNC_OUT
    return d->mAccountIds;
}

void ContactListAggregatorModel::setAccountIds( const QStringList &accountIds )
{
    FUNC_IN
    beginResetModel();

    d->clear();
    d->mAccountIds = accountIds;

    if( d->mAccountIds.isEmpty() )
    {
        d->mAccountSet = d->mAccountManager->validAccounts();
        d->connectAccountSet( d->mAccountSet );

        foreach( Tp::AccountPtr account, d->mAccountSet->accounts() )
        {
            QString path = account->objectPath();
            d->mAccountIds.append( path );

            ContactListModel *model = new ContactListModel( path );
            d->connectModel( model );
            d->mContactLists.insert( path, model );

            account->becomeReady( Tp::Account::FeatureCore );
            d->mAccounts.insert( path, account );
        }
    } else
    {
        QList<Tp::AccountPtr> accounts = d->mAccountManager->accountsForPaths( d->mAccountIds );

        foreach( Tp::AccountPtr account, accounts)
        {
            QString path = account->objectPath();
            d->mAccountIds.append( path );

            ContactListModel *model = new ContactListModel( path );
            d->connectModel( model );
            d->mContactLists.insert( path, model );

            account->becomeReady( Tp::Account::FeatureCore );
            d->connectAccount( account );
            d->mAccounts.insert( path, account );
        }
    }

    endResetModel();
    FUNC_OUT
}
