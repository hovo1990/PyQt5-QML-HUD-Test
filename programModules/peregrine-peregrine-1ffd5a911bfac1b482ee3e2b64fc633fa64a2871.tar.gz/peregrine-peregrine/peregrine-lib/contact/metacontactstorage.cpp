/*
 * metacontactstorage.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "metacontactstorage.h"
#include "../peregrineDebugHelper.h"

#include <QPointer>
#include <QSettings>
#include <QString>
#include <QStringList>

using namespace Peregrine;

MetaContactStorage::MetaContactStorage( QObject *parent ) :
    QObject( parent ),
    mSettings( "peregrine", "MetaContacts" )
{
    FUNC_IN
    mMetaContactIds = mSettings.childGroups();
    FUNC_OUT
}

MetaContactStorage::~MetaContactStorage()
{
    FUNC_IN
    sync();
    FUNC_OUT
}

MetaContactStorage *
MetaContactStorage::instance()
{
    FUNC_IN
    static QPointer<MetaContactStorage> instance;
    if( instance.isNull() )
    {
        instance = new MetaContactStorage();
    }

    FUNC_OUT
    return instance;
}

QStringList
MetaContactStorage::metaContactIds() const
{
    FUNC_IN
    FUNC_OUT
    return mMetaContactIds;
}

QString
MetaContactStorage::createMetaContact( const QString &name,
                                       const QString &surname,
                                       const QStringList &contactIds )
{
    QString metaContactId = createMetaContactId();

    mMetaContactIds.append( metaContactId );

    mSettings.beginGroup( metaContactId );

    mSettings.setValue( "name", name );
    mSettings.setValue( "surname", surname );

    mSettings.beginWriteArray("details", contactIds.size() );
    for( int i = 0; i < contactIds.count(); ++i )
    {
        mSettings.setArrayIndex( i );
        mSettings.setValue("id", contactIds.at(i) );
    }
    mSettings.endArray();

    mSettings.endGroup();

    emit metaContactCreated( metaContactId );

    return metaContactId;
}

QString
MetaContactStorage::createMetaContactId()
{
    FUNC_IN
    int id = mMetaContactIds.size();
    QString metaContactId;
    do
    {
        metaContactId = QString( "MetaContact%1" ).arg( id++ );
    } while( mMetaContactIds.contains(metaContactId) );

    FUNC_OUT
    return metaContactId;
}

void
MetaContactStorage::removeMetaContactId( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return;
    }

    mMetaContactIds.removeAll( metaContactId );
    mSettings.remove( metaContactId );

    emit metaContactDeleted( metaContactId );

    FUNC_OUT
}

bool
MetaContactStorage::containsMetaContactId( const QString &metaContactId )
{
    FUNC_IN
    FUNC_OUT
    return ( !metaContactId.isEmpty()
             && mMetaContactIds.contains(metaContactId) );
}

bool
MetaContactStorage::autoNamed( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return false;
    }

    mSettings.beginGroup( metaContactId );
    bool isAutomaticName = mSettings.value( "autonamed" ).toBool();
    mSettings.endGroup();

    FUNC_OUT
    return isAutomaticName;
}

QString
MetaContactStorage::nameForMetaContactId( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return QString();
    }

    mSettings.beginGroup( metaContactId );
    QString name = mSettings.value( "name" ).toString();
    mSettings.endGroup();

    FUNC_OUT
    return name;
}

QString
MetaContactStorage::presencePublication( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return QString();
    }

    mSettings.beginGroup( metaContactId );
    QString state = mSettings.value( "presencepublication" ).toString();
    mSettings.endGroup();

    FUNC_OUT
    return state;
}

QString
MetaContactStorage::surnameForMetaContactId( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return QString();
    }

    mSettings.beginGroup( metaContactId );
    QString surname = mSettings.value( "surname" ).toString();
    mSettings.endGroup();

    FUNC_OUT
    return surname;
}

QStringList
MetaContactStorage::contactIdsForMetaContactId( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return QStringList();
    }

    QStringList contactIds;
    mSettings.beginGroup( metaContactId );
    int size = mSettings.beginReadArray( "details" );
    for( int i = 0; i < size; ++i )
    {
        mSettings.setArrayIndex( i );
        contactIds.append( mSettings.value("id").toString() );
    }
    mSettings.endArray();
    mSettings.endGroup();

    FUNC_OUT
    return contactIds;
}

void
MetaContactStorage::setAutoNamed( const QString &metaContactId,
                                  bool isAutomaticName )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return;
    }

    mSettings.beginGroup( metaContactId );
    if( isAutomaticName )
    {
        mSettings.setValue(  "autonamed", isAutomaticName );
    } else
    {
        mSettings.remove( "autonamed" );
    }
    mSettings.endGroup();

    emit metaContactChanged( metaContactId );

    FUNC_OUT
}

void
MetaContactStorage::setNameForMetaContactId( const QString &metaContactId,
                                             const QString &name )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return;
    }

    mSettings.beginGroup( metaContactId );
    mSettings.setValue( "name", name );
    mSettings.endGroup();

    emit metaContactChanged( metaContactId );

    FUNC_OUT
}

void
MetaContactStorage::setPresencePublication( const QString &metaContactId,
                                            const QString &state )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return;
    }

    mSettings.beginGroup( metaContactId );
    mSettings.setValue( "presencepublication", state );
    mSettings.endGroup();

    emit metaContactChanged( metaContactId );

    FUNC_OUT
}

void
MetaContactStorage::setSurnameForMetaContactId( const QString &metaContactId,
                                                const QString &surname )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return;
    }

    mSettings.beginGroup( metaContactId );
    mSettings.setValue( "surname", surname );
    mSettings.endGroup();

    emit metaContactChanged( metaContactId );

    FUNC_OUT
}

void
MetaContactStorage::setContactIdsForMetaContactId( const QString &metaContactId,
                                                   const QStringList &contactIds )
{
    FUNC_IN
    if( metaContactId.isEmpty()
        || !mMetaContactIds.contains(metaContactId) )
    {
        FUNC_OUT
        return;
    }

    mSettings.beginGroup( metaContactId );
    mSettings.remove( "details" );
    mSettings.beginWriteArray( "details" );
    for( int i = 0; i < contactIds.count(); ++i )
    {
        mSettings.setArrayIndex( i );
        mSettings.setValue( "id", contactIds.at(i) );
    }
    mSettings.endArray();
    mSettings.endGroup();

    emit metaContactChanged( metaContactId );

    FUNC_OUT
}

void MetaContactStorage::sync()
{
    FUNC_IN
    mSettings.sync();
    FUNC_OUT
}
