/*
 * metacontact.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef METACONTACT_H
#define METACONTACT_H

#include "contactlistmodelinterface.h"

#include <QAbstractItemModel>
#include <QModelIndex>
#include <QPointer>
#include <QSortFilterProxyModel>
#include <QString>
#include <QStringList>
#include <QVariant>

namespace Peregrine
{

class ContactListAggregatorModel;

class MetaContact
    : public QAbstractItemModel
    , public ContactListModelInterface
{
    Q_OBJECT

public:
    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };

    enum PresencePublication
    {
        PresencePublicationAnswerRequired,
        PresencePublicationWaitingForContact,
        PresencePublicationPublished,
        PresencePublicationUnpublished,
        PresencePublicationUnknown
    };

private:

    static const QString PRESENCE_PUBLICATION_ACCEPTED;
    static const QString PRESENCE_PUBLICATION_REJECTED;
    static const QString PRESENCE_PUBLICATION_REQUESTED;

    bool mAutoNamed;
    QStringList mContactDetails;
    QString mMetaContactId;
    QString mName;
    QString mSurname;
    QString mAvatarUri;
    int mPresence;
    QString mPresencePublication;
    PresencePublication mPresencePublicationState;
    int mCapabilities;

    QPointer<ContactListAggregatorModel> mContactListModel;
    QPointer<QSortFilterProxyModel> mProxyModel;

    bool connectMetaContactStorage();
    bool connectProxyModel( QSortFilterProxyModel *model );
    QStringList createCapabilitiesList( int capabilities ) const;
    void createMetaContactName();
    QString createServiceNameFromContactId( const QString &contactId ) const;
    bool disconnectMetaContactStorage();
    bool disconnectProxyModel( QSortFilterProxyModel *model );
    QModelIndex indexForContactId( const QString &contactId, int column = 0 ) const;
    void initRoleNames();
    void recreateFilter();

private slots:
    void onContactListModelContactDeleted( const QString &contactId );
    void onDataChanged( const QModelIndex &topLeft, const QModelIndex &bottomRight );
    void onMetaContactStorageMetaContactChanged( const QString &metaContactId );
    void onMetaContactStorageMetaContactDeleted( const QString &metaContactId );
    void onModelReset();
    void onRowsInserted( const QModelIndex &parent, int first, int last );
    void onRowsRemoved( const QModelIndex &parent, int first, int last );
    void updateCapabilities();
    void updatePresence();
    void updatePresencePublication();

public:
    Q_ENUMS( Columns );
    Q_ENUMS( NotificationTypes );
    Q_ENUMS( PresencePublication );
    Q_PROPERTY( QString avatarUri READ avatarUri WRITE setAvatarUri NOTIFY avatarUriChanged );
    Q_PROPERTY( QStringList capabilities READ capabilities NOTIFY capabilitiesChanged );
    Q_PROPERTY( QObject * contactListModel READ contactListModel WRITE setContactListModel );
    Q_PROPERTY( QString displayName READ displayName WRITE setDisplayName NOTIFY displayNameChanged );
    Q_PROPERTY( QString metaContactId READ metaContactId WRITE setMetaContactId );
    Q_PROPERTY( QString name READ name WRITE setName NOTIFY nameChanged );
    Q_PROPERTY( PresencePublication presencePublication READ presencePublication WRITE setPresencePublication NOTIFY presencePublicationChanged );
    Q_PROPERTY( QString presenceState READ presenceState NOTIFY presenceStateChanged );
    Q_PROPERTY( QString surname READ surname WRITE setSurname NOTIFY surnameChanged );

    explicit MetaContact( const QString metaContactId = QString(),
                          ContactListAggregatorModel *model = 0,
                          QObject *parent = 0 );
    ~MetaContact();

    QAbstractItemModel *contactListModel() const;
    QString metaContactId() const;
    Q_INVOKABLE void setContactListModel( QAbstractItemModel *model );
    /**
     * for some reason it is not possible to handle a QAbstractItemModel* in
     * QML. This overloaded function should only be used by QML code!
     */
    Q_INVOKABLE void setContactListModel( QObject *model );
    void setMetaContactId( const QString &metaContactId );

    Q_INVOKABLE void acceptContact();
    QString avatarUri() const;
    QStringList capabilities() const;
    QStringList contactIds() const;
    Q_INVOKABLE int countContactIdsSupportingCapability( const QString &capability ) const;
    void deleteMetaContact();
    QString displayName() const;
    bool importAndDelete( const QString &metaContactId );
    QString name() const;
    PresencePublication presencePublication() const;
    QString presenceState() const;
    Q_INVOKABLE void rejectContact();
    Q_INVOKABLE int rowForContactId( const QString &contactId ) const;
    QString surname() const;
    void setAvatarUri( const QString &uri );
    void setContactIds( const QStringList &contactIds );
    void setDisplayName( const QString &displayName );
    void setName( const QString &name );
    void setPresencePublication( PresencePublication publication );
    void setSurname( const QString &surname );

    void addContactId( const QString &contactId );
    void removeContactId( const QString &contactId );
    bool containsContactId( const QString &contactId ) const;

    int columnCount( const QModelIndex &parent = QModelIndex() ) const;
    QVariant data( const QModelIndex &index, int role = Qt::DisplayRole ) const;
    QModelIndex index( int row, int column, const QModelIndex &parent = QModelIndex() ) const;
    QModelIndex parent( const QModelIndex &child ) const;
    bool removeRow( int row, const QModelIndex &parent = QModelIndex() );
    bool removeRows(int row, int count, const QModelIndex &parent = QModelIndex() );
    int rowCount( const QModelIndex &parent = QModelIndex() ) const;

    static const QString CAPABILITY_FILE;
    static const QString CAPABILITY_TEXT;
    static const QString CAPABILITY_VIDEO;
    static const QString CAPABILITY_VOIP;
signals:
    void aboutToBeDeleted();
    void avatarUriChanged( const QString &name );
    void capabilitiesChanged( const QStringList &capabilities = QStringList() );
    void deleted();
    void displayNameChanged( const QString &name );
    void nameChanged( const QString &name );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );
    void presencePublicationChanged( MetaContact::PresencePublication publication );
    void presenceStateChanged( const QString &presenceState );
    void surnameChanged( const QString &surname );

public slots:
    void revert();
    QString startTextChat( const QString &contactId = "" );
    QString startVoIPCall( const QString &contactId = "" );
    QString startVideoCall( const QString &contactId = "" );
    bool submit();

};

QDataStream &operator<<( QDataStream &stream, const MetaContact &metaContact );

}

#endif // METACONTACT_H
