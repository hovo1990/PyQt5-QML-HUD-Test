/*
 * contactlistaggregatormodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CONTACTLISTAGGREGATORMODEL_H
#define CONTACTLISTAGGREGATORMODEL_H

#include "contactlistmodelinterface.h"

#include <QAbstractItemModel>
#include <QPointer>

namespace Peregrine
{

class ContactListAggregatorModelPrivate;

class ContactListAggregatorModel
    : public QAbstractItemModel // public QAbstractProxyModel
    , public ContactListModelInterface
{
    Q_OBJECT
    friend class ContactListAggregatorModelPrivate;

    QPointer<ContactListAggregatorModelPrivate> d;

    void initRoleNames();
    int mapFromSource( const QAbstractItemModel *model, int row ) const;

private slots:
    void onDataChanged( const QModelIndex &topLeft, const QModelIndex &bottomRight );
    void onRowsAboutToBeInserted( const QModelIndex &parent, int start, int end );
    void onRowsInserted( const QModelIndex &parent, int start, int end );
    void onRowsAboutToBeRemoved( const QModelIndex &parent, int start, int end );
    void onRowsRemoved( const QModelIndex &parent, int start, int end );
    void onRowsAboutToBeMoved( const QModelIndex &sourceParent, int sourceStart, int sourceEnd, const QModelIndex &destinationParent, int destinationRow );
    void onRowsMoved( const QModelIndex &parent, int start, int end, const QModelIndex &destination, int row );
    void onModelAboutToBeReset();
    void onModelReset();

public:
    Q_ENUMS( NotificationTypes );
    Q_PROPERTY( QStringList accountIds READ accountIds WRITE setAccountIds );

    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };

    explicit ContactListAggregatorModel( const QStringList &accountIds = QStringList(), QObject *parent = 0 );
    ~ContactListAggregatorModel();

    /**
     * this function maps an index a source model to an index for this model
     * @param sourceIndex index created by a source model to be mapped
     * @return QModelIndex created by this model pointing to the same element or an invalid index if mapping failed
     */
    QModelIndex mapFromSource( const QModelIndex &sourceIndex ) const;
    /**
     * this function maps an index created by this model to an index for the source model
     * @param proxyIndex index created by this model to be mapped
     * @return QModelIndex created by source model pointing to source element or an invalid index if mapping failed
     */
    QModelIndex mapToSource( const QModelIndex &proxyIndex ) const;

    /**
     * @see Qt::QAbstractTableModel::rowCount()
     */
    int rowCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractTableModel::columnCount()
     */
    int columnCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractTableModel::data()
     */
    QVariant data( const QModelIndex &index, int role = Qt::DisplayRole ) const;
    /**
     * @see Qt::QAbstractTableModel::headerData()
     */
    QVariant headerData( int section, Qt::Orientation orientation, int role ) const;
    /**
     * @see Qt::QAbstractTableModel::index()
     */
    QModelIndex index( int row, int column, const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractTableModel::parent()
     */
    QModelIndex parent( const QModelIndex &child ) const;
    /**
     * @see Qt::QAbstractTableModel::flags()
     */
    Qt::ItemFlags flags( const QModelIndex &index ) const;
    /**
     * @see Qt::QAbstractTableModel::setData()
     */
    bool setData( const QModelIndex &index, const QVariant &value, int role=Qt::EditRole );
    /**
     * start a text chat with contact at row `row'
     * @param row row of contact the TextChannel should be created to
     * @return true if contact has needed capability and request is created successfully
     */
    Q_INVOKABLE bool startTextChat( int row );
    /**
     * start a voip call with contact at row `row'
     * @param row row of contact the StreamedMediaChannel should be created to
     * @return true if contact has needed capability and request is created successfully
     */
    Q_INVOKABLE bool startVoIPCall( int row );
    /**
     * start a video call with contact at row `row'
     * @param row row of contact the StreamedMediaChannel should be created to
     * @return true if contact has needed capability and request is created successfully
     */
    Q_INVOKABLE bool startVideoCall( int row );
    /**
     * @see Qt::QAbstractTableModel::remove()
     */
    bool removeRow( int row, const QModelIndex &parent = QModelIndex() );
    /**
     * @see Qt::QAbstractTableModel::removeRows()
     */
    bool removeRows ( int row, int count, const QModelIndex & parent = QModelIndex() );

    /**
     * this function will search the data for given contact id and will return a QModelIndex pointing to that data
     * @param ContactId contact id of contact you are looking for in following format: <account path>::<contact id>
     * @return QModelIndex pointing to the searched contact or an invalid index if not found
     */
    QModelIndex indexForContactId( const QString &contactId ) const;
    //        Tp::ContactPtr contactForContactId( const QString &contactId ) const;
    //        Tp::ContactPtr contactAtRow( int row ) const;

    //        int rowForContact( Tp::ContactPtr contact ) const;
    /**
     * convenience function to get the row for known contact id
     * @param ContactId contact id of contact you are looking for in following format: <account path>::<contact id>
     * @return the row for the contact or -1 if not found
     */
    int rowForContactId( const QString &contactId ) const;

    //        ContactListModel *contactListModelForConnection( Tp::ConnectionPtr connection );

    /**
     * create a new contact
     * @param accountPath account path of account to use for creating the new contact
     * @param contactId contact id of contact that should be added to list
     * @return true if creation was successful
     */
    Q_INVOKABLE bool createContact( const QString &accountId, const QString &contactId );

    QStringList accountIds() const;
    void setAccountIds( const QStringList &accountIds );

signals:
    void contactDeleted( const QString &contactId );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );
    /**
     * convenience signal
     * @see presencePublicationRequested( const Tp::Contacts &contacts )
     */
    void presencePublicationRequested( const QString &contactId );

public slots:

};

}

#endif // CONTACTLISTAGGREGATORMODEL_H
