/*
 * contactlistaggregatormodel_p.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CONTACTLISTAGGREGATORMODEL_P_H
#define CONTACTLISTAGGREGATORMODEL_P_H

#include <QAbstractItemModel>
#include <QHash>
#include <QList>
#include <QObject>
#include <QPointer>
#include <QString>
#include <QStringList>

#include <TelepathyQt4/AccountManager>
#include <TelepathyQt4/AccountSet>
#include <TelepathyQt4/PendingOperation>
#include <TelepathyQt4/SharedPtr>

namespace Peregrine
{

class ContactListAggregatorModel;

class ContactListAggregatorModelPrivate
    : public QObject
{
    Q_OBJECT
    friend class ContactListAggregatorModel;
    // data
    QPointer<ContactListAggregatorModel> mParent;
    QStringList mAccountIds;
    QHash< QString, QPointer<QAbstractItemModel> > mContactLists;
    QHash< QString, Tp::AccountPtr > mAccounts;

    Tp::AccountManagerPtr mAccountManager;
    Tp::AccountSetPtr mAccountSet;

    static const Tp::Features ACCOUNT_MANAGER_FEATURES;

    explicit ContactListAggregatorModelPrivate( ContactListAggregatorModel *parent );

    void clear();

    bool connectAccountManager( Tp::AccountManagerPtr accountManager );
    bool disconnectAccountManager( Tp::AccountManagerPtr accountManager );

    bool connectAccountSet( Tp::AccountSetPtr accountSet );
    bool disconnectAccountSet( Tp::AccountSetPtr accountSet );

    bool connectAccount( Tp::AccountPtr account );
    bool disconnectAccount( Tp::AccountPtr account );

    bool connectModel( QAbstractItemModel *contactList );
    bool disconnectModel( QAbstractItemModel *contactList );

private slots:
    void onAccountManagerReady( Tp::PendingOperation *operation );

    void onAccountRemoved();

    void onAccountSetAccountAdded( const Tp::AccountPtr &account );
    void onAccountSetAccountRemoved( const Tp::AccountPtr &account );

public:
    ~ContactListAggregatorModelPrivate();
};

}

#endif // CONTACTLISTAGGREGATORMODEL_P_H
