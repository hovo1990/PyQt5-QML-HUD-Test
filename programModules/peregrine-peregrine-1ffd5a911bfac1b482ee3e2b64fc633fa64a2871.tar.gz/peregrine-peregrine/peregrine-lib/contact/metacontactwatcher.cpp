/*
 * metacontactwatcher.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "metacontactwatcher.h"
#include "metacontactwatcher_p.h"

#include "contactlistmodelinterface.h"
#include "metacontactstorage.h"
#include "../peregrineDebugHelper.h"

#include <QPair>
#include <QStringList>

#include <TelepathyQt4/PendingReady>

using namespace Peregrine;

MetaContactWatcherPrivate::MetaContactWatcherPrivate( QObject *parent )
    : QObject( parent )
{
    FUNC_IN
    mAccountManager = Tp::AccountManager::create();
    connect( mAccountManager->becomeReady(),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onAccountManagerReady(Tp::PendingOperation*)) );
    FUNC_OUT
}

void
MetaContactWatcherPrivate::onAccountManagerNewAccount( const Tp::AccountPtr &account )
{
    FUNC_IN
    mAccounts.append( account );
    connect( account.data(),
             SIGNAL(removed()),
             this,
             SLOT(onAccountRemoved()) );
    connect( account->becomeReady(),
             SIGNAL(finished(Tp::PendingOperation *)),
             this,
             SLOT(onAccountReady(Tp::PendingOperation *)) );
    FUNC_OUT
}

void
MetaContactWatcherPrivate::onAccountManagerReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        qWarning() << __PRETTY_FUNCTION__ << operation->errorName().split(".").last() + ": " + operation->errorMessage();
        emit notification( operation->errorName().split(".").last(), operation->errorMessage(), NotificationTypeError );
    }

    mAccounts = mAccountManager->allAccounts();
    QList<QString> accountIds;
    for( int i = 0; i < mAccounts.count(); ++i )
    {
        Tp::AccountPtr account = mAccounts.at( i );
        accountIds.append( account->objectPath() );
        connect( account.data(),
                 SIGNAL(removed()),
                 this,
                 SLOT(onAccountRemoved()) );
        connect( account->becomeReady(),
                 SIGNAL(finished(Tp::PendingOperation *)),
                 this,
                 SLOT(onAccountReady(Tp::PendingOperation *)) );
    }

    // initial check of contacts
    MetaContactStorage *mcs = MetaContactStorage::instance();
    QStringList metaContactIds = mcs->metaContactIds();
    for( int i = 0; i < metaContactIds.count(); ++i )
    {
        bool contactChanged = false;
        QStringList contactIds = mcs->contactIdsForMetaContactId( metaContactIds.at(i) );
        for( int j = 0; j < contactIds.count(); ++j )
        {
            QPair<QString, QString> idPair = ContactListModelInterface::splitContactId( contactIds.at(j) );
            if( !accountIds.contains(idPair.first) )
            {
                contactIds.removeAt( j-- );
                contactChanged = true;
            }
        }

        // write changes to MetaContactStorage
        if( contactChanged )
        {
            QString displayName = mcs->nameForMetaContactId( metaContactIds.at(i) );
            if( contactIds.count() <= 0 )
            {
                // remove MetaContact
                mcs->removeMetaContactId( metaContactIds.at(i) );
                emit notification( "Contact deleted!", "Contact " + displayName + " was removed from contact list because all conted contact IDs got removed!", NotificationTypeNotice );
            } else
            {
                // set new list of contactIds
                mcs->setContactIdsForMetaContactId( metaContactIds.at(i), contactIds );
                emit notification( "Contact IDs deleted!", "Contact " + displayName + " was modified because the corresponding account was removed!", NotificationTypeNotice );
            }
        }
    }
    mcs->sync();
    FUNC_OUT
}

void
MetaContactWatcherPrivate::onAccountReady( Tp::PendingOperation *operation )
{
    FUNC_IN
    if( operation->isError() )
    {
        emit notification( operation->errorName().split(".").last(), operation->errorMessage(), NotificationTypeError );
    }
    FUNC_OUT
}

void
MetaContactWatcherPrivate::onAccountRemoved()
{
    FUNC_IN
    Tp::AccountPtr account( qobject_cast<Tp::Account *>(sender()) );
    if( account.isNull() )
    {
        emit notification( "Unknown sender!", "Signal `removed' was not sent by a Tp::Account object!", NotificationTypeDebug );
        FUNC_OUT
        return;
    }

    disconnect( account.data(), 0, this, 0 );

    QString accountId = account->objectPath();

    // find account to remove from list
    for( int i = 0; i < mAccounts.count(); ++i )
    {
        if( accountId == mAccounts.at(i)->objectPath() )
        {
            mAccounts.removeAt( i );
            break;
        }
    }

    // remove contacts
    MetaContactStorage *mcs = MetaContactStorage::instance();
    QStringList metaContactIds = mcs->metaContactIds();
    for( int i = 0; i < metaContactIds.count(); ++i )
    {
        bool contactChanged = false;
        QStringList contactIds = mcs->contactIdsForMetaContactId( metaContactIds.at(i) );
        for( int j = 0; j < contactIds.count(); ++j )
        {
            QPair<QString, QString> idPair = ContactListModelInterface::splitContactId( contactIds.at(j) );
            if( accountId == idPair.first )
            {
                contactIds.removeAt( j-- );
                contactChanged = true;
            }
        }

        // write changes to MetaContactStorage
        if( contactChanged )
        {
            QString displayName = mcs->nameForMetaContactId( metaContactIds.at(i) );
            if( contactIds.count() <= 0 )
            {
                // remove MetaContact
                mcs->removeMetaContactId( metaContactIds.at(i) );
                emit notification( "Contact deleted!", "Contact " + displayName + " was removed from contact list because all conted contact IDs got removed!", NotificationTypeNotice );
            } else
            {
                // set new list of contactIds
                mcs->setContactIdsForMetaContactId( metaContactIds.at(i), contactIds );
                emit notification( "Contact IDs deleted!", "Contact " + displayName + " was modified because the corresponding account was removed!", NotificationTypeNotice );
            }
        }
    }
    mcs->sync();
    FUNC_OUT
}

MetaContactWatcherPrivate*
MetaContactWatcherPrivate::instance()
{
    FUNC_IN
    static MetaContactWatcherPrivate *instancePointer = 0;
    if( instancePointer == 0 )
    {
        instancePointer = new MetaContactWatcherPrivate();
    }

    return instancePointer;
    FUNC_OUT
}

MetaContactWatcher::MetaContactWatcher( QObject *parent )
    : QObject( parent )
{
    FUNC_IN
    d = MetaContactWatcherPrivate::instance();
    connect( d.data(),
             SIGNAL(notification(QString,QString,NotificationTypes)),
             this,
             SIGNAL(notification(QString,QString,NotificationTypes)) );
    FUNC_OUT
}
