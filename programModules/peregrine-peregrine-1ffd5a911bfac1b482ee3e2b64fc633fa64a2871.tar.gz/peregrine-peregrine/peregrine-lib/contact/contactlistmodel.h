/*
 * contactlistmodel.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CONTACTLISTMODEL_H
#define CONTACTLISTMODEL_H

#include "contactlistmodelinterface.h"

#include <QAbstractItemModel>
#include <QModelIndex>
#include <QPointer>
#include <QString>
#include <QVariant>

namespace Peregrine
{
class ContactListModelPrivate;

class ContactListModel
    : public QAbstractItemModel
    , public ContactListModelInterface
{
    Q_OBJECT
    friend class Peregrine::ContactListModelPrivate;

    QPointer<ContactListModelPrivate> d;

    void initRoleNames();

public:
    Q_ENUMS( NotificationTypes );
    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };

    Q_PROPERTY( QString accountPath READ accountPath WRITE setAccountPath )

    explicit ContactListModel( const QString &accountPath, QObject *parent = 0 );
    ~ContactListModel();

    /**
     * @see Qt::QAbstractTableModel::rowCount()
     */
    Q_INVOKABLE int rowCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractTableModel::columnCount()
     */
    Q_INVOKABLE int columnCount( const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractTableModel::data()
     */
    Q_INVOKABLE QVariant data( const QModelIndex &index, int role = Qt::DisplayRole ) const;
    /**
     * @see Qt::QAbstractTableModel::headerData()
     */
    Q_INVOKABLE QVariant headerData( int section, Qt::Orientation orientation, int role ) const;
    /**
     * @see Qt::QAbstractTableModel::index()
     */
    Q_INVOKABLE QModelIndex index( int row, int column,
                                           const QModelIndex &parent = QModelIndex() ) const;
    /**
     * @see Qt::QAbstractTableModel::parent()
     */
    Q_INVOKABLE QModelIndex parent( const QModelIndex &child ) const;
    /**
     * @see Qt::QAbstractTableModel::flags()
     */
    Q_INVOKABLE Qt::ItemFlags flags( const QModelIndex &index ) const;
    /**
     * @see Qt::QAbstractTableModel::setData()
     */
    Q_INVOKABLE bool setData( const QModelIndex &index, const QVariant &value, int role=Qt::EditRole );
    /**
     * start a text chat with contact at row `row'
     * @param row row of contact the TextChannel should be created to
     * @return true if contact has needed capability and request is created successfully
     */
    Q_INVOKABLE bool startTextChat( int row );
    /**
     * start a voip call with contact at row `row'
     * @param row row of contact the StreamedMediaChannel should be created to
     * @return true if contact has needed capability and request is created successfully
     */
    Q_INVOKABLE bool startVoIPCall( int row );
    /**
     * @see Qt::QAbstractTableModel::removeRows()
     */
    Q_INVOKABLE bool startVideoCall( int row );
    /**
     * @see Qt::QAbstractTableModel::removeRows()
     */
    Q_INVOKABLE bool removeRow( int row, const QModelIndex &parent = QModelIndex() );

    /**
     * convenience function to get a QModelIndex for known contact id
     * @param contactId the contact id you are looking for
     * @return the QModelIndex pointing to the contact or an invalid QModelIndex
     */
    Q_INVOKABLE QModelIndex indexForContactId( const QString &contactId ) const;

    /**
     * convenience function to get the row for known contact id
     * @param contactId the contact id you are looking for
     * @return the row for the contact or -1 if not found
     */
    Q_INVOKABLE int rowForContactId( const QString &contactId ) const;

    /**
     * the account id of account this contact list is retrieved from
     * @return this is the username of the account
     */
    Q_INVOKABLE QString accountId() const;
    /**
     * the account path of account this contact list is retrieved from
     * @return the dbus object path of the account
     */
    QString accountPath() const;

    /**
     * add new contact with given contact id
     * adding contacts is just setting the presence subscription state to yes
     * this function is asynchronous and returns true if request was successful
     * @return true if successful
     */
    Q_INVOKABLE bool createContact( const QString &contactId );

    void setAccountPath( const QString &accountPath );

signals:
    /**
     * emitted whenever a contact gets deleted. this is needed to discriminate between
     * a deleted contact and going offline w/ an account (that also results in rowsRemoved signals)
     */
    void contactDeleted( const QString &contactId );
    /**
     * emitted when model is initialized
     */
    void initialized();
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );
    /**
     * This signal is emitted when signal presencePublicationRequested is received from ContactManager. it is a reemitted signal
     * @param contactId The contact who requested to see the presence state.
     */
    void presencePublicationRequested( const QString &contactId );
};

}

#endif // CONTACTLISTMODEL_H
