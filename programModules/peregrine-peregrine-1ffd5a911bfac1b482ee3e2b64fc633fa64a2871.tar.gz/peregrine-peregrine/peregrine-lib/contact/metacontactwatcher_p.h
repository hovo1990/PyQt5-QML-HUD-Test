/*
 * metacontactwatcher_p.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef METACONTACTWATCHER_P_H
#define METACONTACTWATCHER_P_H

#include <QList>
#include <QObject>
#include <QString>

#include <TelepathyQt4/Account>
#include <TelepathyQt4/AccountManager>
#include <TelepathyQt4/SharedPtr>
#include <TelepathyQt4/PendingOperation>

namespace Peregrine
{

class MetaContactWatcherPrivate
        : public QObject
{
    Q_OBJECT
    explicit MetaContactWatcherPrivate( QObject *parent = 0 );

    Tp::AccountManagerPtr mAccountManager;
    QList<Tp::AccountPtr> mAccounts;

private slots:
    void onAccountManagerNewAccount( const Tp::AccountPtr &account );
    void onAccountManagerReady( Tp::PendingOperation *operation );
    void onAccountReady( Tp::PendingOperation *operation );
    void onAccountRemoved();

public:
    Q_ENUMS( NotificationTypes );

    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };

    static MetaContactWatcherPrivate* instance();

signals:
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );

};

}

#endif // METACONTACTWATCHER_P_H
