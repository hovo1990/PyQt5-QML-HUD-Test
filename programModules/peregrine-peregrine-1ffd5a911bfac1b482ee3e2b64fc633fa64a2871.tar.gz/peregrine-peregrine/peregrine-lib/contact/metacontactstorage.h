/*
 * metacontactstorage.h
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef METACONTACTSTORAGE_H
#define METACONTACTSTORAGE_H

#include <QObject>

#include <QPointer>
#include <QSettings>
#include <QString>
#include <QStringList>

namespace Peregrine
{

class MetaContactStorage : public QObject
{
    Q_OBJECT

    QSettings mSettings;

    QStringList mMetaContactIds;

    explicit MetaContactStorage( QObject *parent = 0 );
    void getMetaContactIds();

public:
    Q_ENUMS( NotificationTypes );
    /**
     * enum to mark notification type
     */
    enum NotificationTypes
    {
        NotificationTypeNotice,
        NotificationTypeWarning,
        NotificationTypeError,
        NotificationTypeDebug
    };

    static MetaContactStorage *instance();
    ~MetaContactStorage();

    QStringList metaContactIds() const;

    QString createMetaContact( const QString &name,
                               const QString &surname,
                               const QStringList &contactIds = QStringList() );
    QString createMetaContactId();
    void removeMetaContactId( const QString &metaContactId );
    bool containsMetaContactId( const QString &metaContactId );

    bool autoNamed( const QString &metaContactId );
    QString nameForMetaContactId( const QString &metaContactId );
    QString presencePublication( const QString &metaContactId );
    QString surnameForMetaContactId( const QString &metaContactId );
    QStringList contactIdsForMetaContactId( const QString &metaContactId );
    void setAutoNamed( const QString &metaContactId,
                       bool isAutomaticName );
    void setNameForMetaContactId( const QString &metaContactId,
                                  const QString &name );
    void setPresencePublication( const QString &metaContactId,
                                 const QString &state );
    void setSurnameForMetaContactId( const QString &metaContactId,
                                     const QString &surname );
    void setContactIdsForMetaContactId( const QString &metaContactId,
                                        const QStringList &contactIds );

signals:
    void metaContactChanged( const QString &metaContactId );
    void metaContactCreated( const QString &metaContactId );
    void metaContactDeleted( const QString &metaContactId );
    /**
     * This signal is meant to notify UIs about errors, warnings, and so on
     */
    void notification( const QString &title, const QString &message, NotificationTypes type );

public slots:
    void sync();

};

}

#endif // METACONTACTSTORAGE_H
