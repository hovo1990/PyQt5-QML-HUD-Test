/*
 * metacontactlistmodel.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "metacontactlistmodel.h"

#include "contactlistaggregatormodel.h"
#include "metacontact.h"
#include "metacontactstorage.h"
#include "../peregrineDebugHelper.h"
#include "../presencestates.h"

#include <QAbstractItemModel>
#include <QList>
#include <QModelIndex>
#include <QPair>
#include <QPointer>
#include <QString>
#include <QStringList>
#include <QVariant>

using namespace Peregrine;

/* ***
 * private
 * **/
int MetaContactListModel::adjustIndexOf( int row )
{
    FUNC_IN
    if( row < 0
        || row >= mMetaContacts.count() )
    {
        FUNC_OUT
        return row;
    }

    QString name = mMetaContacts.at( row ).first;
    int movedToRow = row;

    if( row == 0
        || name.localeAwareCompare(mMetaContacts.at(row - 1).first) > 0 )
    { // look for new position downwards
        for( int i = row + 1; i <= mMetaContacts.count(); ++i )
        {
            if( i == mMetaContacts.count()
                || name.localeAwareCompare(mMetaContacts.at(i).first) <= 0 )
            {
                if( i == row || (row + 1) == i )
                {
                    movedToRow = row;
                    break;
                }

                // move MetaContact from row `row' down to row `i'
                beginMoveRows( QModelIndex(), row, row, QModelIndex(), i );
                // move MetaContact pointer in list
                mMetaContacts.move( row, --i );
                endMoveRows();
                movedToRow = i;
                break;
            }
        }
    } else
    { // look for new position upwards
        for( int i = row - 1; i >= -1; --i )
        {
            if( i == -1
                || name.localeAwareCompare(mMetaContacts.at(i).first) > 0 )
            {
                i += 1; // increment i to insert after current element
                if( i == row || (row + 1) == i )
                {
                    movedToRow = row;
                    break;
                }

                // move MetaContact from row `row' up to row `i'
                beginMoveRows( QModelIndex(), row, row, QModelIndex(), i );
                // move MetaContact pointer in list
                mMetaContacts.move( row, i );
                endMoveRows();
                movedToRow = i;
                break;
            }
        }
    }

    FUNC_OUT
    return movedToRow;
}

QString
MetaContactListModel::createDisplayName( MetaContact *metaContact ) const
{
    FUNC_IN
    QString name = metaContact->name();
    QString surname = metaContact->surname();

    if( !name.isEmpty()
        && !surname.isEmpty() )
    {
        name.append(" ");
    }
    name.append( surname );

    FUNC_OUT
    return name;
}

void
MetaContactListModel::createMetaContacts()
{
    FUNC_IN
    MetaContactStorage *mcs = MetaContactStorage::instance();
    QStringList metaContactIds = mcs->metaContactIds();

    foreach( QString metaContactId, metaContactIds )
    {
        MetaContact *metaContact = new MetaContact( metaContactId,
                                                    mContactListModel,
                                                    this );

        insertMetaContact( metaContact );
    }
    FUNC_OUT
}

void
MetaContactListModel::createMetaContactsForUnusedContactIds()
{
    FUNC_IN
    QSet<QString> unused = mContactIds;
    unused.subtract( mUsedContactIds.keys().toSet() );


    // create MetaContacts for unused contact ids
    MetaContactStorage *mcs = MetaContactStorage::instance();
    disconnectMetaContactStorage( mcs );
    foreach( QString contactId, unused )
    {
        MetaContact *metaContact = new MetaContact( QString(),
                                                    mContactListModel,
                                                    this );
        metaContact->addContactId( contactId );
        insertMetaContact( metaContact );
        metaContact->submit();
    }
    connectMetaContactStorage( mcs );
    FUNC_OUT
}

void
MetaContactListModel::createSetOfAllContactIds()
{
    FUNC_IN
    mContactIds.clear();

    for( int i = 0; i < mContactListModel->rowCount(); ++i )
    {
        QModelIndex index = mContactListModel->index( i, MetaContact::ColumnContact );
        mContactIds.insert( index.data(MetaContact::ContactIdRole).toString() );
    }

    FUNC_OUT
}

void
MetaContactListModel::createSetOfUsedContactIds()
{
    FUNC_IN
    mUsedContactIds.clear();

    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        QStringList contactIds = mMetaContacts.at(i).second->contactIds();
        for( int j = 0; j < contactIds.count(); ++j )
        {
            mUsedContactIds.insert( contactIds.at(j), mMetaContacts.at(i).second );
        }
    }

    FUNC_OUT
}

QPair<QString, QString>
MetaContactListModel::extractFromDisplayName( const QString &displayName ) const
{
    FUNC_IN
    QPair<QString, QString> rvalue;

    if( displayName.isEmpty() )
    {
        FUNC_OUT
        return rvalue;
    }

    QStringList parts = displayName.split( " ", QString::SkipEmptyParts );

    if( parts.count() <= 0 )
    {
        FUNC_OUT
        return rvalue;
    }

    rvalue.first = parts.takeAt( 0 );
    while( parts.count() )
    {
        if( !rvalue.second.isEmpty() )
        {
            rvalue.second.append( " " );
        }
        rvalue.second.append( parts.takeAt(0) );
    }

    FUNC_OUT
    return rvalue;
}

void MetaContactListModel::initRoleNames()
{
    QHash<int, QByteArray> rolenames;
    rolenames.insert( Qt::DisplayRole,    "displayName" );
    rolenames.insert( Qt::DecorationRole, "avatar" );
    rolenames.insert( NameRole,           "name" );
    rolenames.insert( SurnameRole,        "surname" );
    rolenames.insert( ContactIdRole,      "contactId" );
    rolenames.insert( PresenceStateRole,  "presenceState" );
    rolenames.insert( PublicationRole,    "publication" );
    rolenames.insert( AvatarUriRole,      "avatarUri" );
    rolenames.insert( CapabilityListRole, "capabilityList" );
    rolenames.insert( SortRole,           "sort" );
    setRoleNames( rolenames );
}

int
MetaContactListModel::insertMetaContact( MetaContact *metaContact )
{
    FUNC_IN
    QString displayName = createDisplayName( metaContact );
    QPair< QString, QPointer<MetaContact> > mcEntry( displayName, metaContact );

    disconnectMetaContact( metaContact );
    connectMetaContact( metaContact );

    QStringList contactIds = metaContact->contactIds();
    for( int i = 0; i < contactIds.count(); ++i )
    {
        mUsedContactIds.insert( contactIds.at(i), metaContact );
    }

    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( displayName.localeAwareCompare(mMetaContacts.at(i).first) <= 0 )
        { // name is less than or equal to mcName
            beginInsertRows( QModelIndex(), i, i );
            mMetaContacts.insert( i, mcEntry );
            endInsertRows();

            FUNC_OUT
            return i;
        }
    }

    int i = mMetaContacts.count();
    beginInsertRows( QModelIndex(), i, i );
    mMetaContacts.insert( i, mcEntry );
    endInsertRows();

    FUNC_OUT
    return i;
}

int
MetaContactListModel::rowForPointer( void *metaContact ) const
{
    FUNC_IN
    if( !metaContact )
    {
        FUNC_OUT
        return -1;
    }

    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( mMetaContacts.at(i).second == metaContact )
        {
            FUNC_OUT
            return i;
        }
    }

    FUNC_OUT
    return -1;
}

bool
MetaContactListModel::connectContactListModel( QAbstractItemModel *model )
{
    FUNC_IN
    if( !model )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( model,
                       SIGNAL(dataChanged(QModelIndex,QModelIndex)),
                       this,
                       SLOT(onContactListModelDataChanged(QModelIndex,QModelIndex)) );
    result &= connect( model,
                       SIGNAL(modelReset()),
                       this,
                       SLOT(onContactListModelModelReset()) );
    result &= connect( model,
                       SIGNAL(rowsAboutToBeRemoved(QModelIndex,int,int)),
                       this,
                       SLOT(onContactListModelRowsAboutToBeRemoved(QModelIndex,int,int)) );
    result &= connect( model,
                       SIGNAL(rowsInserted(QModelIndex,int,int)),
                       this,
                       SLOT(onContactListModelRowsInserted(QModelIndex,int,int)) );
    result &= connect( model,
                       SIGNAL(notification(QString, QString, NotificationTypes)),
                       this,
                       SIGNAL(notification(QString, QString, NotificationTypes)) );

    FUNC_OUT
    return result;
}

bool
MetaContactListModel::disconnectContactListModel( QAbstractItemModel *model )
{
    FUNC_IN
    if( !model )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( model, 0, this, 0 );
}

bool
MetaContactListModel::connectMetaContact( MetaContact *metaContact )
{
    FUNC_IN
    if( !metaContact )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( metaContact,
                       SIGNAL(aboutToBeDeleted()),
                       this,
                       SLOT(onMetaContactAboutToBeDeleted()) );
    result &= connect( metaContact,
                       SIGNAL(dataChanged(QModelIndex,QModelIndex)),
                       this,
                       SLOT(onMetaContactDataChanged(QModelIndex,QModelIndex)) );
    result &= connect( metaContact,
                       SIGNAL(deleted()),
                       this,
                       SLOT(onMetaContactDeleted()) );
    result &= connect( metaContact,
                       SIGNAL(modelReset()),
                       this,
                       SLOT(onMetaContactModelReset()) );
    result &= connect( metaContact,
                       SIGNAL(rowsAboutToBeRemoved(QModelIndex,int,int)),
                       this,
                       SLOT(onMetaContactRowsAboutToBeRemoved(QModelIndex,int,int)) );
    result &= connect( metaContact,
                       SIGNAL(rowsInserted(QModelIndex,int,int)),
                       this,
                       SLOT(onMetaContactRowsInserted(QModelIndex,int,int)) );
    result &= connect( metaContact,
                       SIGNAL(rowsRemoved(QModelIndex,int,int)),
                       this,
                       SLOT(onMetaContactRowsRemoved(QModelIndex,int,int)) );

    result &= connect( metaContact,
                       SIGNAL(avatarUriChanged(QString)),
                       this,
                       SLOT(onMetaContactAvatarUriChanged(QString)) );
    result &= connect( metaContact,
                       SIGNAL(capabilitiesChanged(QStringList)),
                       this,
                       SLOT(onMetaContactCapabilitiesChanged(QStringList)) );
    result &= connect( metaContact,
                       SIGNAL(nameChanged(QString)),
                       this,
                       SLOT(onMetaContactNameChanged(QString)) );
    result &= connect( metaContact,
                       SIGNAL(presencePublicationChanged(MetaContact::PresencePublication)),
                       this,
                       SLOT(onMetaContactPresencePublicationChanged()) );
    result &= connect( metaContact,
                       SIGNAL(presenceStateChanged(QString)),
                       this,
                       SLOT(onMetaContactPresenceStateChanged(QString)) );
    result &= connect( metaContact,
                       SIGNAL(surnameChanged(QString)),
                       this,
                       SLOT(onMetaContactSurnameChanged(QString)) );
    result &= connect( metaContact,
                       SIGNAL(notification(QString, QString, NotificationTypes)),
                       this,
                       SIGNAL(notification(QString, QString, NotificationTypes)) );

    FUNC_OUT
    return result;
}

bool
MetaContactListModel::disconnectMetaContact( MetaContact *metaContact )
{
    FUNC_IN
    if( !metaContact )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( metaContact, 0, this, 0 );
}

bool
MetaContactListModel::connectMetaContactStorage( MetaContactStorage *metaContactStorage )
{
    FUNC_IN
    if( !metaContactStorage )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;
    result &= connect( metaContactStorage,
                       SIGNAL(metaContactCreated(QString)),
                       this,
                       SLOT(onMetaContactStorageMetaContactCreated(QString)) );
    result &= connect( metaContactStorage,
                       SIGNAL(notification(QString,QString,NotificationTypes)),
                       this,
                       SIGNAL(notification(QString,QString,NotificationTypes)) );
    FUNC_OUT
    return result;
}

bool
MetaContactListModel::disconnectMetaContactStorage( MetaContactStorage *metaContactStorage )
{
    FUNC_IN
    if( !metaContactStorage )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( metaContactStorage, 0, this, 0 );
}


/* ***
 * private slots
 * **/

void
MetaContactListModel::onContactListModelDataChanged( const QModelIndex &topLeft,
                                                     const QModelIndex &bottomRight )
{
    FUNC_IN
    Q_UNUSED( topLeft );
    Q_UNUSED( bottomRight );
    // there should be nothing to do
    FUNC_OUT
}

void
MetaContactListModel::onContactListModelModelReset()
{
    FUNC_IN
    createSetOfAllContactIds();
    // create MetaContacts for unused contact ids
    createMetaContactsForUnusedContactIds();
    FUNC_OUT
}

void
MetaContactListModel::onContactListModelRowsAboutToBeRemoved( const QModelIndex &parent,
                                                              int start,
                                                              int end )
{
    FUNC_IN
    if( parent.isValid() )
    { // we are only interested in contact ids
      // and these are stored in top level indexes
        FUNC_OUT
        return;
    }

    for( int i = start; i <= end; ++i )
    {
        // remove contact ids from set
        QModelIndex index = mContactListModel->index( i, MetaContact::ColumnContact );
        mContactIds.remove( index.data(MetaContact::ContactIdRole).toString() );
    }
    FUNC_OUT
}

void
MetaContactListModel::onContactListModelRowsInserted( const QModelIndex &parent,
                                                      int start,
                                                      int end )
{
    FUNC_IN
    if( parent.isValid() )
    { // we are only interested in contact ids
      // and these are stored in top level indexes
        FUNC_OUT
        return;
    }

    for( int i = start; i <= end; ++i )
    {
        // remove contact ids from set
        QModelIndex index = mContactListModel->index( i, MetaContact::ColumnContact );
        mContactIds.insert( index.data(MetaContact::ContactIdRole).toString() );
    }

    // create MetaContacts for unused contact ids
    createMetaContactsForUnusedContactIds();
    FUNC_OUT
}

void
MetaContactListModel::onMetaContactAboutToBeDeleted()
{
    FUNC_IN
    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    if( !metaContact )
    { // should not happen
        // sender is not a MetaContact
        qWarning() << __PRETTY_FUNCTION__ << "MetaContact not known";
        emit notification( "Unknown signal sender", "Sender is not a MetaContact object", NotificationTypeDebug );
        FUNC_OUT
        return;
    }

    QStringList contactIds = metaContact->contactIds();
    for( int i = 0; i < contactIds.count(); ++i )
    {
        mUsedContactIds.remove( contactIds.at(i), metaContact );
    }
    FUNC_OUT
}

void
MetaContactListModel::onMetaContactCapabilitiesChanged( const QStringList &capabilities )
{
    FUNC_IN
    Q_UNUSED( capabilities );

    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    if( !metaContact )
    { // should not happen
        // sender is not a MetaContact
        FUNC_OUT
        return;
    }

    // find row for MetaContact
    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( mMetaContacts.at(i).second == metaContact )
        {
            // emit dataChanged signal
            QModelIndex index = this->index( i, ColumnContact );
            emit dataChanged( index, index );
            break;
        }
    }

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactDataChanged( const QModelIndex &topLeft,
                               const QModelIndex &bottomRight )
{
    FUNC_IN
    Q_UNUSED( topLeft );
    Q_UNUSED( bottomRight );

    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    if( !metaContact )
    { // should not happen
        // sender is not a MetaContact
        FUNC_OUT
        return;
    }

    // not the fastest way but we have to remove all contact Ids that
    // where linked to this meta contact ( because contact ids can change too )
    QStringList contactIds = mUsedContactIds.keys( metaContact );
    for( int i = 0; i < contactIds.count(); ++i )
    {
        mUsedContactIds.remove( contactIds.at(i), metaContact );
    }
    contactIds = metaContact->contactIds();
    for( int i = 0; i < contactIds.count(); ++i )
    {
        mUsedContactIds.insert( contactIds.at(i), metaContact );
    }

    // find row for MetaContact
    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( mMetaContacts.at(i).second == metaContact )
        {
            // emit dataChanged signal
            QModelIndex index = this->index( i, ColumnContact );
            emit dataChanged( index, index );

            FUNC_OUT
            return;
        }
    }

    // should not happen
    // sending MetaContact not in list
    FUNC_OUT
}

void
MetaContactListModel::onMetaContactDeleted()
{
    FUNC_IN
    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    if( !metaContact )
    { // should not happen
        // sender is not a MetaContact
        qWarning() << __PRETTY_FUNCTION__ << "MetaContact not known";
        emit notification( "Unknown signal sender", "Sender is not a MetaContact object", NotificationTypeDebug );
        FUNC_OUT
        return;
    }

    // find row for MetaContact
    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( mMetaContacts.at(i).second == metaContact )
        {
            beginRemoveRows( QModelIndex(), i, i );
            mMetaContacts.removeAt( i );
            delete metaContact;
            endRemoveRows();
            break;
        }
    }
    FUNC_OUT
}

void
MetaContactListModel::onMetaContactModelReset()
{
    FUNC_IN
    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    if( !metaContact )
    { // should not happen
        // sender is not a MetaContact
        FUNC_OUT
        return;
    }

    // not the fastest way but we have to remove all contact Ids that
    // where linked to this meta contact ( because contact ids can change too )
    QStringList contactIds = mUsedContactIds.keys( metaContact );
    for( int i = 0; i < contactIds.count(); ++i )
    {
        mUsedContactIds.remove( contactIds.at(i), metaContact );
    }
    contactIds = metaContact->contactIds();
    for( int i = 0; i < contactIds.count(); ++i )
    {
        mUsedContactIds.insert( contactIds.at(i), metaContact );
    }


    // find row for MetaContact
    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( mMetaContacts.at(i).second == metaContact )
        {
            // emit dataChanged signal
            QModelIndex index = this->index( i, ColumnContact );
            emit dataChanged( index, index );

            FUNC_OUT
            return;
        }
    }

    // should not happen
    // sending MetaContact not in list
    FUNC_OUT
}

void
MetaContactListModel::onMetaContactPresencePublicationChanged()
{
    FUNC_IN

    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    int row = rowForPointer( metaContact );
    if( row < 0 )
    { // should not happen
        // sender is not a MetaContact or not in list
        FUNC_OUT
        return;
    }

    // emit dataChanged signal
    QModelIndex index = this->index( row, ColumnContact );
    emit dataChanged( index, index );

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactPresenceStateChanged( const QString &presenceState )
{
    FUNC_IN
    Q_UNUSED( presenceState );

    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    int row = rowForPointer( metaContact );
    if( row >= 0 )
    {
        QModelIndex index = this->index( row, ColumnContact );
        emit dataChanged( index, index );
    }

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactRowsAboutToBeInserted( const QModelIndex &parent, int start, int end )
{
    FUNC_IN
    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );

    // get row
    int row = rowForPointer( metaContact );
    if( row < 0 )
    { // should not happen
        qWarning() << __PRETTY_FUNCTION__ << "sending MetaContact not in list";
        emit notification( "Unknown signal sender", "MetaContact not in list", NotificationTypeDebug );
        // sending MetaContact not in list
        FUNC_OUT
        return;
    }

    if( !parent.isValid() )
    {
        // create index
        QModelIndex parent = this->index( row, ColumnContact );
        // re-emit signal
        beginInsertRows( parent, start, end );
    }

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactRowsAboutToBeRemoved( const QModelIndex &parent,
                                   int start,
                                   int end )
{
    FUNC_IN
    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );

    // get row
    int row = rowForPointer( metaContact );
    if( row < 0 )
    { // should not happen
        qWarning() << __PRETTY_FUNCTION__ << "sending MetaContact not in list";
        emit notification( "Unknown signal sender", "MetaContact not in list", NotificationTypeDebug );
        // sending MetaContact not in list
        FUNC_OUT
        return;
    }

    if( !parent.isValid() )
    {
        // create index
        QModelIndex parent = this->index( row, ColumnContact );
        // re-emit signal
        beginRemoveRows( parent, start, end );
    }

    // emit dataChanged signal
    QModelIndex index = this->index( row, ColumnContact );
    emit dataChanged( index, index );

    if( parent.isValid() )
    { // we are only interested in contact id changes
        FUNC_OUT
        return;
    }

    // get contact ids
    for( int i = start; i <= end; ++i )
    {
        QModelIndex index = metaContact->index( i, MetaContact::ColumnContact );
        QString contactId = index.data( MetaContact::ContactIdRole ).toString();
        mUsedContactIds.remove( contactId, metaContact );
    }

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactRowsInserted( const QModelIndex &parent, int start, int end )
{
    FUNC_IN
    Q_UNUSED( parent );

    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    // get row
    int row = rowForPointer( metaContact );
    if( row < 0 )
    { // should not happen
        qWarning() << __PRETTY_FUNCTION__ << "sending MetaContact not in list";
        emit notification( "Unknown signal sender", "MetaContact not in list", NotificationTypeDebug );
        // sending MetaContact not in list
        FUNC_OUT
        return;
    }

    // get contact ids
    for( int i = start; i <= end; ++i )
    {
        QModelIndex index = metaContact->index( i, MetaContact::ColumnContact );
        QString contactId = index.data( MetaContact::ContactIdRole ).toString();
        // put them into mUsedContactIds set
        mUsedContactIds.insert( contactId, metaContact );
    }

    endInsertRows();

    // emit dataChanged signal
    QModelIndex index = this->index( row, ColumnContact );
    emit dataChanged( index, index );

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactRowsRemoved( const QModelIndex &parent, int start, int end )
{
    FUNC_IN
    Q_UNUSED( parent );
    Q_UNUSED( start );
    Q_UNUSED( end );

    endRemoveRows();

    // finished removing rows
    // create MetaContacts for unused contact ids
    // needed for unlinking contacts
    createMetaContactsForUnusedContactIds();

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactAvatarUriChanged( const QString &avatarUri )
{
    FUNC_IN
    Q_UNUSED( avatarUri );

    MetaContact *metaContact = qobject_cast<MetaContact *>( sender() );
    // get row
    int row = rowForPointer( metaContact );
    if( row < 0 )
    { // should not happen
        qWarning() << __PRETTY_FUNCTION__ << "sending MetaContact not in list";
        emit notification( "Unknown signal sender", "MetaContact not in list", NotificationTypeDebug );
        // sending MetaContact not in list
        FUNC_OUT
        return;
    }

    QModelIndex index = this->index( row, ColumnContact );
    emit dataChanged( index, index );

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactNameChanged( const QString &name )
{
    FUNC_IN
    Q_UNUSED( name );

    int row = rowForPointer( sender() );
    if( row >= 0 )
    {
        // update display name
        mMetaContacts[row].first = createDisplayName( mMetaContacts.at(row).second );
        // signalize change
        QModelIndex index = this->index( row, ColumnContact );
        emit dataChanged( index, index );
    }

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactSurnameChanged( const QString &surname )
{
    FUNC_IN
    Q_UNUSED( surname );

    int row = rowForPointer( sender() );
    if( row >= 0 )
    {
        // update display name
        mMetaContacts[row].first = createDisplayName( mMetaContacts.at(row).second );
        // signalize change
        QModelIndex index = this->index( row, ColumnContact );
        emit dataChanged( index, index );
    }

    FUNC_OUT
}

void
MetaContactListModel::onMetaContactStorageMetaContactCreated( const QString &metaContactId )
{
    FUNC_IN
    bool found = false;
    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( mMetaContacts.at(i).second->metaContactId() == metaContactId )
        {
            found = true;
            break;
        }
    }

    if( !found )
    { // create MetaContact object
        MetaContact *metaContact = new MetaContact( metaContactId,
                                                    mContactListModel,
                                                    this );
        insertMetaContact( metaContact );
    }
    FUNC_OUT
}

/* ***
 * public
 * **/

MetaContactListModel::MetaContactListModel( QObject *parent ) :
    QAbstractItemModel( parent )
{
    FUNC_IN
    // create instance of MetaContactStorage and connect to it
    MetaContactStorage *mcs = MetaContactStorage::instance();
    connectMetaContactStorage( mcs );

    // create ContactListAggregatorModel
    mContactListModel = new ContactListAggregatorModel( QStringList(), this );
    connectContactListModel( mContactListModel );

    // initialize role names
    initRoleNames();

    // get all ContactIds to keep track of unused ContactIds
    createSetOfAllContactIds();

    // initialize MetaContacts and fill internal list
    createMetaContacts();

    // get all used ContactIds to keep track of unused ContactIds
    createSetOfUsedContactIds();

    // create MetaContacts for unused contact ids
    createMetaContactsForUnusedContactIds();
    FUNC_OUT
}

QObject *
MetaContactListModel::contactListModel() const
{
    FUNC_IN
    FUNC_OUT
    return mContactListModel.data();
}

QString
MetaContactListModel::createContact( const QString &accountId,
                                     const QString &contactId,
                                     const QString &metaContactId,
                                     bool force )
{
    FUNC_IN
    Q_UNUSED( metaContactId );

    if( accountId.isEmpty() )
    {
        emit notification( "Creating contact failed!", "No account specified when creating contact", NotificationTypeError );
        FUNC_OUT
        return QString();
    } else if( contactId.isEmpty() )
    {
        emit notification( "Creating contact failed!", "No contact ID specified when creating contact", NotificationTypeError );
        FUNC_OUT
        return QString();
    }

    QString cid = accountId + ContactListModelInterface::SEPARATOR + contactId.toLower();
    if( mUsedContactIds.contains(cid)
        && !force )
    {
        emit notification( "Creating contact failed!", "Specified contact ID already exists", NotificationTypeWarning );
        FUNC_OUT
        return QString();
    }
    // get list of MetaContacts that already contain new contact ID
    // delete contact ID from other contacts after creating new contact
    QList< QPointer<MetaContact> > toBeChanged = mUsedContactIds.values( cid );

    MetaContact *metaContact = 0;
    MetaContactStorage *mcs = MetaContactStorage::instance();
    if( !metaContactId.isEmpty() )
    {
        if( mcs->containsMetaContactId(metaContactId) )
        {
            metaContact = new MetaContact( metaContactId, mContactListModel, this );

            if( metaContact->containsContactId(cid) )
            {
                // metaContact already contains contactId
                delete metaContact;
                FUNC_OUT
                return metaContactId;
            }
        }
    }
    if( metaContact == 0 )
    {
        // no metaContactId specified or metaContactId not found
        // create a new MetaContact
        metaContact = new MetaContact( QString(), mContactListModel, this );
    }
    metaContact->addContactId( cid );
    metaContact->submit();
    // the mUsedContactIds variable should now be updated

    QString mcid = metaContact->metaContactId();
    if( mcid.isEmpty() )
    {
        emit notification( "Creating contact failed!", "Error while writing contact data to storage", NotificationTypeError );
        metaContact->deleteMetaContact();
        delete metaContact;

        FUNC_OUT
        return QString();
    }

    // this must be done after the MetaContact has been updated
    // to avoid creation of other MetaContacts in other instance
    // of MetaContactListModel
    if( !mContactListModel->createContact(accountId, contactId.toLower())
        && toBeChanged.isEmpty() )
    {
        if( metaContact->rowCount() <= 1 )
        {
            metaContact->deleteMetaContact();
        } else
        {
            metaContact->removeContactId( cid );
            metaContact->submit();
        }

        mcid = QString();

        emit notification( "Creating contact failed!", "Unable to create contact in subsystem", NotificationTypeError );
    }
    for( int i = 0; i < toBeChanged.count(); ++i )
    {
        toBeChanged.at(i)->removeContactId( cid );
        toBeChanged.at(i)->submit();
    }

    delete metaContact;

    FUNC_OUT
    return mcid;
}

QString
MetaContactListModel::createNamedContact( const QString &accountId,
                                          const QString &contactId,
                                          const QString &displayName )
{
    FUNC_IN
    // create meta data
    QString mcid = createContact( accountId, contactId );
    if( !mcid.isEmpty() )
    {
        MetaContact *metaContact = new MetaContact( mcid, mContactListModel, this );
        metaContact->setDisplayName( displayName );
        metaContact->submit();
        delete metaContact;
    }

    FUNC_OUT
    return mcid;
}

bool
MetaContactListModel::removeContact( const QString &metaContactId )
{
    FUNC_IN
    int row = -1;
    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( mMetaContacts.at(i).second->metaContactId() == metaContactId )
        {
            row = i;
            break;
        }
    }
    if( row < 0 )
    {
        FUNC_OUT
        return false;
    }
    FUNC_OUT
    return removeRow( row );
}

bool
MetaContactListModel::removeIdFromContact( const QString &metaContactId, const QString &contactId )
{
    FUNC_IN
    QModelIndex index;
    int row = -1;
    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        if( mMetaContacts.at(i).second->metaContactId() == metaContactId )
        {
            index = this->index( i, ColumnContact );
            row = mMetaContacts.at(i).second->rowForContactId( contactId );
            break;
        }
    }
    if( !index.isValid() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "index not valid. MetaContact not found!";
        emit notification( "Cannot delete contact ID", "MetaContact not found!", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }
    if( row < 0 )
    {
        qWarning() << __PRETTY_FUNCTION__ << "row not valid. ContactId not part of MetaContact!";
        emit notification( "Cannot delete contact ID", "Contact ID not contained in MetaContact!", NotificationTypeWarning );
        FUNC_OUT
        return false;
    }

    FUNC_OUT
    return removeRows( row, 1, index );
}

bool
MetaContactListModel::removeContacts( const QString &accountPath )
{
    FUNC_IN
    QString expr = accountPath + ContactListAggregatorModel::SEPARATOR;
    bool deleted = true;

    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        MetaContact *metaContact = mMetaContacts.at(i).second;
        QStringList contactIds = metaContact->contactIds();
        foreach( QString contactId, contactIds )
        {
            if( contactId.startsWith(expr) )
            {
                // remove that contactId from contact list
                int row = mContactListModel->rowForContactId( contactId );
                if( row >= 0
                    && row < mContactListModel->rowCount() )
                {
                    deleted &= mContactListModel->removeRow( row );
                }

                // remove that contactId from meta-contact
                metaContact->removeContactId( contactId );
            }
        }

        if( metaContact->contactIds().count() <= 0 )
        {
            deleted &= removeRows( i--, 1 );
        }
    }

    createMetaContactsForUnusedContactIds();

    FUNC_OUT
    return deleted;
}

int
MetaContactListModel::columnCount(const QModelIndex &parent) const
{
    FUNC_IN
    if( !parent.isValid() )
    {
        FUNC_OUT
        return ColumnCount;
    }
    if( parent.parent().isValid() )
    { // currently there is no support for more than one level
        FUNC_OUT
        return 0;
    }

    int row = parent.row();
    FUNC_OUT
    return mMetaContacts.at(row).second->columnCount();
}

QVariant
MetaContactListModel::data( const QModelIndex &index, int role ) const
{
    FUNC_IN
    if( !index.isValid() )
    {
        FUNC_OUT
        return QVariant();
    }

    if( !index.parent().isValid() )
    {
        if( index.column() == ColumnContact )
        {
            MetaContact *metaContact = mMetaContacts.at( index.row() ).second;
            switch( role )
            {
            case Qt::DisplayRole:
                FUNC_OUT
                return mMetaContacts.at( index.row() ).first;
            case NameRole:
                FUNC_OUT
                return metaContact->name();
            case SurnameRole:
                FUNC_OUT
                return metaContact->surname();
            case ContactIdRole:
                FUNC_OUT
                return metaContact->metaContactId();
            case PresenceStateRole:
                FUNC_OUT
                return metaContact->presenceState();
            case PublicationRole:
                FUNC_OUT
                return metaContact->presencePublication();
            case AvatarUriRole:
                FUNC_OUT
                return metaContact->avatarUri();
            case CapabilityListRole:
                // the original model returns a ContactCapsModel
                // do we realy need to return this data here?
                FUNC_OUT
                return metaContact->capabilities();
            case SortRole:
                {
                    QString sortstring;
                    int i = 0;
                    if( metaContact->presencePublication() != MetaContact::PresencePublicationAnswerRequired )
                    {
                        i = PRESENCE_STATE_NAMES.indexOf( metaContact->presenceState() );
                        if( i < 0 )
                        {
                            i = PRESENCE_STATES_ORDER.indexOf(PresenceStateUnknown);
                        } else
                        {
                            i = PRESENCE_STATES_ORDER.indexOf( (PresenceStates)i );
                        }
                        i += 1;
                    }
                    sortstring = QString::number(i) + mMetaContacts.at( index.row() ).first;
                    FUNC_OUT
                    return sortstring;
                }
            }
        }
        FUNC_OUT
        return QVariant();
    } else if( !index.parent().parent().isValid() )
    {
        MetaContact *metaContact = mMetaContacts.at( index.parent().row() ).second;
        QModelIndex mcIndex = metaContact->index( index.row(), index.column() );

        FUNC_OUT
        return mcIndex.data( role );
    }

    FUNC_OUT
    return QVariant();
}

Qt::ItemFlags
MetaContactListModel::flags( const QModelIndex &index ) const
{
    if( !index.isValid() )
    {
        FUNC_OUT
        return QAbstractItemModel::flags( index );
    }

    if( !index.parent().isValid() )
    {
        FUNC_OUT
        return QAbstractItemModel::flags( index ) | Qt::ItemIsEditable;
    }

    int row = rowForPointer( index.parent().internalPointer() );
    if( row >= 0 )
    {
        MetaContact *metaContact = mMetaContacts.at(row).second;
        QModelIndex mcIndex = metaContact->index( index.row(), index.column() );
        FUNC_OUT
        return mcIndex.flags();
    }

    FUNC_OUT
    return QAbstractItemModel::flags( index );
}

QModelIndex
MetaContactListModel::index(int row, int column, const QModelIndex &parent) const
{
    FUNC_IN
    if( !parent.isValid() )
    {
        if( row >= 0
            && row < mMetaContacts.count()
            && column >= 0
            && column < ColumnCount )
        {
            FUNC_OUT
            return createIndex( row, column, mMetaContacts.at(row).second.data() );
        }
    } else if( !parent.parent().isValid() )
    {
        int parentRow = rowForPointer( parent.internalPointer() );
        if( parentRow >= 0 )
        {
            MetaContact *mc = mMetaContacts.at(parentRow).second;
            FUNC_OUT
            return mc->index( row, column );
        }
    }

    FUNC_OUT
    return QModelIndex();
}

bool
MetaContactListModel::mergeMetaContactsInto( const QString &destinationMetaContactId, const QStringList &metaContactIds )
{
    FUNC_IN
    if( destinationMetaContactId.isEmpty() )
    {
        FUNC_OUT
        return false;
    }

    MetaContactStorage *mcs = MetaContactStorage::instance();
    if( !mcs->containsMetaContactId(destinationMetaContactId) )
    {
        FUNC_OUT
        return false;
    }

    MetaContact *mc = new MetaContact( destinationMetaContactId );

    bool result = true;

    foreach( QString metaContactId, metaContactIds )
    {
        if( metaContactId != destinationMetaContactId )
        {
            result &= mc->importAndDelete( metaContactId );
        }
    }

    result &= mc->submit();

    delete mc;

    FUNC_OUT
    return result;
}

QString
MetaContactListModel::metaContactIdForContactId( const QString &contactId ) const
{
    for( int i = 0; i < mMetaContacts.count(); ++i )
    {
        MetaContact *metaContact = mMetaContacts.at(i).second;
        if( metaContact->containsContactId(contactId) )
        {
            return metaContact->metaContactId();
        }
    }
    return QString();
}

QModelIndex
MetaContactListModel::parent(const QModelIndex &child) const
{
    FUNC_IN
    if( !child.isValid() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    int row = rowForPointer( const_cast<void *>(static_cast<const void *>(child.model())) );
    if( row < 0 )
    {
        FUNC_OUT
        return QModelIndex();
    }

    FUNC_OUT
    return index( row, ColumnContact );
}

bool
MetaContactListModel::removeRow( int row, const QModelIndex &parent )
{
    FUNC_IN
    FUNC_OUT
    return removeRows( row, 1, parent );
}

bool
MetaContactListModel::removeRows( int row,
                                  int count,
                                  const QModelIndex &parent )
{
    FUNC_IN
    if( parent.isValid() )
    {
        int parentRow = parent.row();
        if( parentRow >= 0 )
        {
            MetaContact *metaContact = mMetaContacts.at(parentRow).second;
            // get contact ids
            for( int i = row; i < row + count; ++i )
            {
                QModelIndex index = metaContact->index( i, MetaContact::ColumnContact );
                QString contactId = index.data(MetaContact::ContactIdRole).toString();

                // remove contact id from mContactListModel
                int cRow = mContactListModel->rowForContactId( contactId );
                if( cRow > 0 )
                {
                    mContactListModel->removeRow( cRow );
                }
            }

            // remove row from MetaContact
            bool result = metaContact->removeRows( row, count );
            if( metaContact->rowCount() <= 0 )
            {
                FUNC_OUT
                return removeRow( parentRow );
            }
            metaContact->submit();
            FUNC_OUT
            return result;
        }

        // currently we do not support more than 2 levels
        FUNC_OUT
        return false;
    }

    int last = qMin( (int)(row + count - 1), (int)(mMetaContacts.count() - 1) );

    if( row < 0
        || row >= mMetaContacts.count()
        || last < row )
    {
        FUNC_OUT
        return false;
    }

    beginRemoveRows(parent, row, last);
    for( int i = last; i >= row; --i )
    {
        // get MetaContact
        MetaContact *metaContact = mMetaContacts.at( i ).second;
        disconnectMetaContact( metaContact );

        // get contact ids from MetaContact
        QStringList contactIds = metaContact->contactIds();

        // remove contact ids from mContactListModel
        foreach( QString contactId, contactIds )
        {
            int cRow = mContactListModel->rowForContactId( contactId );
            if( cRow >= 0)
            {
                mContactListModel->removeRow( cRow );
            }

            // remove contact ids from mUsedContactIds set
            // don't wait for reset signal to remove contact IDs
            // to save some time
            mUsedContactIds.remove( contactId, metaContact );
        }

        // remove MetaContact
        metaContact->deleteMetaContact();

        // delete MetaContact object
        metaContact->deleteLater();

        // remove Pointer from mMetaContacts
        mMetaContacts.removeAt( i );

    }
    endRemoveRows();

    FUNC_OUT
    return true;
}

int
MetaContactListModel::rowCount(const QModelIndex &parent) const
{
    FUNC_IN
    if( !parent.isValid() )
    {
        FUNC_OUT
        return mMetaContacts.count();
    } else if( !parent.parent().isValid() )
    {
        int row = rowForPointer( parent.internalPointer() );
        if( row >= 0 )
        {
            MetaContact *mc = mMetaContacts.at(row).second;
            FUNC_OUT
            return mc->rowCount();
        }
    }

    FUNC_OUT
    return 0; // currently there is no support for more than one level
}

bool
MetaContactListModel::setData( int row,
                               const QVariant &value,
                               const QString &rolename )
{
    FUNC_IN
    QModelIndex index = this->index( row, ColumnContact );
    int role = roleNames().key(rolename.toAscii(), Qt::DisplayRole);
    FUNC_OUT
    return setData(index, value, role);
}

bool
MetaContactListModel::setData( const QModelIndex &index,
                               const QVariant &value,
                               int role )
{
    FUNC_IN
    if( !index.isValid() )
    {
        FUNC_OUT
        return false;
    }

    if( index.parent().isValid() )
    {
        int row = rowForPointer( index.parent().internalPointer() );
        if( row < 0 )
        {
            FUNC_OUT
            return false;
        }

        MetaContact *metaContact = mMetaContacts.at(row).second;
        QModelIndex mcIndex = metaContact->index( index.row(), index.column() );

        FUNC_OUT
        return metaContact->setData( mcIndex, value, role );
    }

    int row = index.row();
    if( index.column() == ColumnContact )
    {
        MetaContact *metaContact = mMetaContacts.at( row ).second;
        switch( role )
        {
        case Qt::DisplayRole:
            {
                QPair<QString, QString> displayName = extractFromDisplayName( value.toString() );
                metaContact->setName( displayName.first );
                metaContact->setSurname( displayName.second );
            }
            mMetaContacts[row].first = createDisplayName( metaContact );
            adjustIndexOf( row );
            FUNC_OUT
                    return true;
        case NameRole:
            metaContact->setName( value.toString() );
            mMetaContacts[row].first = createDisplayName( metaContact );
            adjustIndexOf( row );
            FUNC_OUT
                    return true;
        case SurnameRole:
            metaContact->setSurname( value.toString() );
            mMetaContacts[row].first = createDisplayName( metaContact );
            adjustIndexOf( row );
            FUNC_OUT
                    return true;
        case AvatarUriRole:
            metaContact->setAvatarUri( value.toString() );
            FUNC_OUT
                    return true;

            // read only properties
        case ContactIdRole:
        case PresenceStateRole:
        case CapabilityListRole:
        default:
            FUNC_OUT
            return false;
        }
    }

    FUNC_OUT
    return false;
}

bool
MetaContactListModel::unlink( const QString &contactId )
{
    FUNC_IN
    QPair<QString, QString> contactIdPair = ContactListModelInterface::splitContactId( contactId );

    disconnect( mContactListModel.data(),
                SIGNAL(notification(QString,QString,NotificationTypes)),
                this,
                SIGNAL(notification(QString,QString,NotificationTypes)) );

    QString mcid = createContact( contactIdPair.first, contactIdPair.second, QString(), true );

    connect( mContactListModel,
             SIGNAL(notification(QString, QString, NotificationTypes)),
             this,
             SIGNAL(notification(QString, QString, NotificationTypes)) );

    FUNC_OUT
    return !mcid.isEmpty();
}
