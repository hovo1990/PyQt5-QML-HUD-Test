/*
 * metacontact.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "metacontact.h"
#include "metacontactstorage.h"
#include "contactlistaggregatormodel.h"
#include "../peregrineDebugHelper.h"
#include "../presencestates.h"
#include "../peregrineinitializer.h"

#include <QModelIndex>
#include <QPointer>
#include <QSortFilterProxyModel>
#include <QString>
#include <QStringList>
#include <QVariant>

using namespace Peregrine;

/* ***
 * public
 * **/

const QString MetaContact::CAPABILITY_FILE = QString( "file" );
const QString MetaContact::CAPABILITY_TEXT = QString( "text" );
const QString MetaContact::CAPABILITY_VIDEO = QString( "video" );
const QString MetaContact::CAPABILITY_VOIP = QString( "voip" );

const QString MetaContact::PRESENCE_PUBLICATION_ACCEPTED = QString( "accepted" );
const QString MetaContact::PRESENCE_PUBLICATION_REJECTED = QString( "rejected" );
const QString MetaContact::PRESENCE_PUBLICATION_REQUESTED = QString( "requested" );

MetaContact::MetaContact(const QString metaContactId,
                         ContactListAggregatorModel *model,
                         QObject *parent)
    : QAbstractItemModel( parent )
    , mAutoNamed( false )
{
    FUNC_IN

    // initialize peregrine
    Peregrine::initialize();

    mPresence = PresenceStateUnknown;

    // initialize storage
    MetaContactStorage::instance();
    connectMetaContactStorage();

    // initialize role names
    initRoleNames();

    // contact creation mode if metaContactId.isEmpty()
    setMetaContactId( metaContactId );
    // offline mode if !model
    setContactListModel( model );

    FUNC_OUT
}

MetaContact::~MetaContact()
{
    FUNC_IN
    disconnectMetaContactStorage();
    submit();
    FUNC_OUT
}

QAbstractItemModel *MetaContact::contactListModel() const
{
    FUNC_IN
    FUNC_OUT
    return mContactListModel.data();
}

QString MetaContact::metaContactId() const
{
    FUNC_IN
    FUNC_OUT
    return mMetaContactId;
}

void
MetaContact::setContactListModel( QAbstractItemModel *model )
{
    FUNC_IN
    ContactListAggregatorModel *contactModel = qobject_cast<ContactListAggregatorModel *>( model );
    if( mProxyModel.isNull() )
    {
        // create new QSortFilterProxyModel
        mProxyModel = new QSortFilterProxyModel( this );
        mProxyModel->setFilterKeyColumn( ColumnContact );
        mProxyModel->setFilterRole( ContactIdRole );
        // make sure that this proxy does not contain any data
        mProxyModel->setFilterRegExp( "^()$" );

        connectProxyModel( mProxyModel );
    }

    mContactListModel = contactModel;
    mProxyModel->setSourceModel( mContactListModel );

    recreateFilter();

    int columns = columnCount() - 1;
    int rows = rowCount() - 1;
    emit dataChanged( index(0, columns), index(rows, columns) );
    FUNC_OUT
}

void
MetaContact::setContactListModel( QObject *model )
{
    FUNC_IN
    QAbstractItemModel *abstractModel = qobject_cast<QAbstractItemModel *>( model );
    if( abstractModel )
    {
        setContactListModel( abstractModel );
    }
    FUNC_OUT
}

void
MetaContact::setMetaContactId( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId == mMetaContactId )
    {
        FUNC_OUT
        return;
    }

    beginResetModel();

    // clear object
    mAutoNamed = false;
    mAvatarUri.clear();
    mContactDetails.clear();
    mMetaContactId.clear();
    mName.clear();
    mPresence = PresenceStateUnknown;
    mPresencePublication.clear();
    mPresencePublicationState = PresencePublicationUnknown;
    mSurname.clear();

    // set new MetaContactId
    mMetaContactId = metaContactId;

    if( !mMetaContactId.isEmpty() )
    {
        // load data from local storage
        MetaContactStorage *mcs = MetaContactStorage::instance();
        if( mcs->containsMetaContactId(metaContactId) )
        {
            mAutoNamed = mcs->autoNamed( metaContactId );
            mName = mcs->nameForMetaContactId( metaContactId );
            mPresencePublication = mcs->presencePublication( metaContactId );
            mSurname = mcs->surnameForMetaContactId( metaContactId );
            mContactDetails = mcs->contactIdsForMetaContactId( metaContactId );
        }
    }

    // create filter
    recreateFilter();
    endResetModel();
    updateCapabilities();
    updatePresence();
    updatePresencePublication();

    emit avatarUriChanged( mAvatarUri );
    emit nameChanged( mName );
    emit surnameChanged( mSurname );
    emit displayNameChanged( displayName() );
    emit presenceStateChanged( PRESENCE_STATE_NAMES.at(mPresence) );

    FUNC_OUT
}

void
MetaContact::acceptContact()
{
    FUNC_IN
    for( int i = 0; i < mProxyModel->rowCount(); ++i )
    {
        QModelIndex index = mProxyModel->index( i, ColumnContact );
        if( index.data(PublicationRole).toString() != "yes" )
        {
            mProxyModel->setData( index, "yes", PublicationRole );
        }
        if( index.data(SubscriptionRole).toString() != "yes" )
        {
            mProxyModel->setData( index, "yes", SubscriptionRole );
        }
    }
    mPresencePublication = PRESENCE_PUBLICATION_ACCEPTED;
    if( mPresencePublicationState != PresencePublicationPublished )
    {
        mPresencePublicationState = PresencePublicationPublished;
        emit presencePublicationChanged( mPresencePublicationState );
    }
    if( !mMetaContactId.isEmpty() )
    {
        MetaContactStorage *mcs = MetaContactStorage::instance();
        mcs->setPresencePublication( mMetaContactId, mPresencePublication );
    }
    FUNC_OUT
}

QString
MetaContact::avatarUri() const
{
    FUNC_IN
    FUNC_OUT
    return mAvatarUri;
}

QStringList
MetaContact::capabilities() const
{
    FUNC_IN
    FUNC_OUT
    return createCapabilitiesList( mCapabilities );
}

QStringList
MetaContact::contactIds() const
{
    FUNC_IN
    FUNC_OUT
    return mContactDetails;
}

int
MetaContact::countContactIdsSupportingCapability( const QString &capability ) const
{
    FUNC_IN
    int count = 0;

    if( mProxyModel.isNull() )
    {
        return 0;
    }

    // create bitmap to identify capable contacts
    int cap = CapabilityNone;
    if( capability == CAPABILITY_TEXT )
    {
        cap = CapabilityTextChat;
    } else if( capability == CAPABILITY_VOIP )
    {
        cap = CapabilityAudioCall | CapabilityMediaCall;
    } else if( capability == CAPABILITY_VIDEO )
    {
        cap = CapabilityVideoCall | CapabilityMediaCall;
    } else if( capability == CAPABILITY_FILE )
    {
        cap = CapabilityFileTransfer;
    } else
    {
        // unknown capability
        FUNC_OUT
        return 0;
    }

    for( int i = 0; i < mProxyModel->rowCount(); ++i )
    {
        QModelIndex index = mProxyModel->index( i, ColumnContact );
        if( index.data(CapabilitiesRole).toInt() & cap )
        {
            ++count;
        }
    }

    FUNC_OUT
    return count;
}

void
MetaContact::deleteMetaContact()
{
    FUNC_IN
    emit aboutToBeDeleted();
    beginResetModel();
    // disconnect from signals to prevent loop
    disconnectMetaContactStorage();

    if( !mMetaContactId.isEmpty() )
    {
        MetaContactStorage *mcs = MetaContactStorage::instance();
        mcs->removeMetaContactId( mMetaContactId );
        mcs->sync();
    }

    // clear object
    mAvatarUri.clear();
    mContactDetails.clear();
    mMetaContactId.clear();
    mName.clear();
    mPresence = PresenceStateUnknown;
    mSurname.clear();

    connectMetaContactStorage();
    endResetModel();
    emit deleted();
    FUNC_OUT
}

QString
MetaContact::displayName() const
{
    FUNC_IN
    QString displayName = mName;

    if( !displayName.isEmpty()
        && !mSurname.isEmpty() )
    {
        displayName.append(" ");
    }
    displayName.append( mSurname );

    FUNC_OUT
    return displayName;
}

bool
MetaContact::importAndDelete( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId.isEmpty() )
    {
        FUNC_OUT
        return false;
    }

    MetaContactStorage *mcs = MetaContactStorage::instance();
    if( !mcs->containsMetaContactId(metaContactId) )
    {
        FUNC_OUT
        return false;
    }

    QStringList contactIds = mcs->contactIdsForMetaContactId( metaContactId );

    foreach( QString contactId, contactIds )
    {
        addContactId( contactId );
    }

    mcs->removeMetaContactId( metaContactId );

    FUNC_OUT
    return true;
}

QString
MetaContact::name() const
{
    FUNC_IN
    FUNC_OUT
    return mName;
}

MetaContact::PresencePublication
MetaContact::presencePublication() const
{
    FUNC_IN
    FUNC_OUT
    return mPresencePublicationState;
}

QString
MetaContact::presenceState() const
{
    FUNC_IN
    FUNC_OUT
    return PRESENCE_STATE_NAMES.at( mPresence );
}

void
MetaContact::rejectContact()
{
    FUNC_IN
    if( mProxyModel.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "no contactList! set a contact list using function setContactListModel()";
        emit notification( "Error", "Subsystem not available!", NotificationTypeError );
        return;
    }
    if( mContactListModel.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "no contactList! set a contact list using function setContactListModel()";
        emit notification( "Error", "Subsystem not available!", NotificationTypeError );
        return;
    }
    for( int i = mProxyModel->rowCount() - 1; i >= 0; --i )
    {
        QModelIndex index = mProxyModel->index( i, ColumnContact );
        if( index.data(PublicationRole).toString() != "yes" )
        {
            mProxyModel->setData( index, "no", PublicationRole );
            mProxyModel->setData( index, "no", SubscriptionRole );
            removeRow( i );
        } else if( mProxyModel->rowCount() == 1 )
        {
            qWarning() << __PRETTY_FUNCTION__ << "you cannot reject already accepted contacts";
            emit notification( "Cannot reject contact", "Unable to reject already accepted contacts. If you want to revoke your presence publication you can delete the contact.", NotificationTypeWarning );
            return;
        }
    }

    if( rowCount() <= 0 )
    {
        deleteMetaContact();
    } else
    {
        mPresencePublication = PRESENCE_PUBLICATION_ACCEPTED;
        if( mPresencePublicationState != PresencePublicationPublished )
        {
            mPresencePublicationState = PresencePublicationPublished;
            emit presencePublicationChanged( mPresencePublicationState );
        }
    }
    submit();
    FUNC_OUT
}

int MetaContact::rowForContactId( const QString &contactId ) const
{
    FUNC_IN
    FUNC_OUT
    return mContactDetails.indexOf( contactId );
}

QString
MetaContact::surname() const
{
    FUNC_IN
    FUNC_OUT
    return mSurname;
}

void
MetaContact::setAvatarUri(const QString &uri)
{
    if( uri == mAvatarUri )
    {
        FUNC_OUT
        return;
    }

    mAvatarUri = uri;
    emit avatarUriChanged( mAvatarUri );
    FUNC_OUT
}

void
MetaContact::setContactIds( const QStringList &contactIds )
{
    int last = -1;
    // remove contacts
    for( int i = mContactDetails.count() - 1; i >= -1; --i )
    {
        if( i == -1
            || contactIds.contains(mContactDetails.at(i)) )
        {
            if( last != -1 )
            {
                int first = i + 1;
                // remove things
                beginRemoveRows( QModelIndex(), first, last );
                for( int ii = last; ii >= first; --ii )
                {
                    mContactDetails.removeAt(ii);
                }
                endRemoveRows();
                last = -1;
            }
        } else
        {
            if( last == -1 )
            {
                last = i;
            }
        }
    }
    QStringList toBeAdded;
    // add contacts
    for( int i = 1; i < contactIds.count(); ++i )
    {
        if( !mContactDetails.contains(contactIds.at(i)) )
        {
            toBeAdded.append( contactIds.at(i) );
        }
    }
    if( !toBeAdded.isEmpty() )
    {
        beginInsertRows( QModelIndex(),
                         mContactDetails.count(),
                         mContactDetails.count() + toBeAdded.count() - 1 );
        mContactDetails.append( contactIds );
        endInsertRows();
    }

    // recreate proxy model filter
    recreateFilter();
    updateCapabilities();
    updatePresence();
    updatePresencePublication();
    FUNC_OUT
}

void
MetaContact::setDisplayName( const QString &displayName )
{
    FUNC_IN
    QString surname;

    if( displayName.isEmpty() )
    {
        setName( displayName );
        setSurname( displayName );
        FUNC_OUT
        return;
    }

    QStringList parts = displayName.split( " ", QString::SkipEmptyParts );

    if( parts.count() <= 0 )
    {
        setName( displayName );
        setSurname( displayName );
        FUNC_OUT
        return;
    }

    setName( parts.takeAt(0) );

    while( parts.count() )
    {
        if( !surname.isEmpty() )
        {
            surname.append( " " );
        }
        surname.append( parts.takeAt(0) );
    }

    setSurname( surname );

    FUNC_OUT
    return;
}

void
MetaContact::setName( const QString &name )
{
    FUNC_IN
    if( mName != name )
    {
        mAutoNamed = false;
        mName = name;
        emit nameChanged( mName );
        emit displayNameChanged( displayName() );
    }
    FUNC_OUT
}

void
MetaContact::setPresencePublication( PresencePublication presencePublication )
{
    FUNC_IN
    if( presencePublication == PresencePublicationPublished )
    {
        acceptContact();
        updatePresencePublication();
        FUNC_OUT
        return;
    } else if( presencePublication == PresencePublicationUnpublished )
    {
        rejectContact();
        updatePresencePublication();
        FUNC_OUT
        return;
    }
    FUNC_OUT
}

void
MetaContact::setSurname( const QString &surname )
{
    FUNC_IN
    if( mSurname != surname )
    {
        mAutoNamed = false;
        mSurname = surname;
        emit surnameChanged( mSurname );
        emit displayNameChanged( displayName() );
    }
    FUNC_OUT
}

void
MetaContact::addContactId( const QString &contactId )
{
    FUNC_IN
    if( !mContactDetails.contains(contactId) )
    {
        beginInsertRows( QModelIndex(),
                         mContactDetails.count(),
                         mContactDetails.count() );
        mContactDetails.append( contactId );
        recreateFilter();
        endInsertRows();
        updateCapabilities();
        updatePresence();
        updatePresencePublication();
    }
    FUNC_OUT
}

void
MetaContact::removeContactId( const QString &contactId )
{
    FUNC_IN
    int row = mContactDetails.indexOf( contactId );
    if( row >= 0 )
    {
        beginRemoveRows( QModelIndex(), row, row);
        mContactDetails.removeAt( row );
        recreateFilter();
        endRemoveRows();
        updateCapabilities();
        updatePresence();
        updatePresencePublication();
    }
    FUNC_OUT
}

bool
MetaContact::containsContactId( const QString &contactId ) const
{
    FUNC_IN
    FUNC_OUT
    return mContactDetails.contains( contactId );
}

int
MetaContact::columnCount( const QModelIndex &parent ) const
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }
    FUNC_OUT
    return ColumnCount;
}

QVariant
MetaContact::data(const QModelIndex &index, int role) const
{
    FUNC_IN
    if( !index.isValid() )
    {
        FUNC_OUT
        return QVariant();
    }

    int column = index.column();
    int row = index.row();

    // get related contact id
    QString contactId = mContactDetails.at( row );
    if( contactId.isEmpty() )
    {
        FUNC_OUT
        return QVariant();
    }

    // get row for proxy model
    QModelIndex proxyIndex = indexForContactId( contactId, column );
    if( proxyIndex.isValid() )
    {
        FUNC_OUT
        return proxyIndex.data( role );
    }

    // get data from local storage when contact is not in list
    // that happens when user is not online
    if( column == ColumnContact )
    {
        switch( role )
        {
        case Qt::DisplayRole:
            FUNC_OUT
            return extractContactId( contactId );
        case ContactIdRole:
            FUNC_OUT
            return contactId;
        case PresenceStateRole:
            FUNC_OUT
            return PRESENCE_STATE_NAMES.at( PresenceStateOffline );
        case CapabilitiesRole:
            FUNC_OUT
            return CapabilityNone;
        case ServiceNameRole:
            FUNC_OUT
            return createServiceNameFromContactId( contactId );
        case AccountIdRole:
            FUNC_OUT
            return ContactListModelInterface::extractAccountId( contactId );
        case ReadableContactIdRole:
            FUNC_OUT
            return ContactListModelInterface::extractContactId( contactId );
        }
    }

    FUNC_OUT
    return QVariant();
}

QModelIndex
MetaContact::index(int row, int column, const QModelIndex &parent) const
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return QModelIndex();
    }
    if( row < 0
        || row >= mContactDetails.count()
        || column < 0
        || column >= ColumnCount )
    {
        FUNC_OUT
        return QModelIndex();
    }

    FUNC_OUT
    return createIndex( row, column );
}

QModelIndex
MetaContact::parent(const QModelIndex &child) const
{
    FUNC_IN
    Q_UNUSED( child );
    FUNC_OUT
    return QModelIndex();
}

bool
MetaContact::removeRow( int row, const QModelIndex &parent )
{
    FUNC_IN
    FUNC_OUT
    return removeRows( row, 1, parent );
}

bool
MetaContact::removeRows( int row, int count, const QModelIndex &parent )
{
    FUNC_IN
    Q_UNUSED( parent );

    int last = qMin( row + count - 1, mContactDetails.count() - 1 );

    if( row < 0
        || row >= mContactDetails.count()
        || last < row )
    {
        return false;
    }
    beginRemoveRows( QModelIndex(), row, last );

    for( int i = last; i >= row; --i )
    {
        mContactDetails.removeAt(i);
    }
    recreateFilter();

    endRemoveRows();

    updateCapabilities();
    updatePresence();
    updatePresencePublication();

    FUNC_OUT
    return true;
}

int
MetaContact::rowCount(const QModelIndex &parent) const
{
    FUNC_IN
    if( parent.isValid() )
    {
        FUNC_OUT
        return 0;
    }
    FUNC_OUT
    return mContactDetails.count();
}

/* ***
 * public slots
 * **/

void
MetaContact::revert()
{
    FUNC_IN
    QString metaContactId = mMetaContactId;

    if( metaContactId.isEmpty() )
    {
        beginResetModel();
        mAvatarUri.clear();
        mAutoNamed = false;
        mContactDetails.clear();
        mMetaContactId.clear();
        mName.clear();
        mPresence = PresenceStateUnknown;
        mSurname.clear();

        recreateFilter();
        endResetModel();
    } else
    {
        mMetaContactId.clear();
        setMetaContactId( metaContactId );
    }
    FUNC_OUT
}

QString
MetaContact::startTextChat( const QString &contactId )
{
    FUNC_IN
    if( !(mCapabilities & CapabilityTextChat) )
    {
        FUNC_OUT
        return QString();
    }

    QModelIndex proxyIndex;
    if( contactId.isEmpty() )
    {
        if( mProxyModel.isNull() )
        {
            FUNC_OUT
            return QString();
        }
        for( int i = 0; i < mProxyModel->rowCount(); ++i )
        {
            proxyIndex = mProxyModel->index( i, ColumnContact );
            if( proxyIndex.data( CapabilitiesRole ).toInt() & CapabilityTextChat )
            {
                break;
            }
            proxyIndex = QModelIndex();
        }
    } else
    {
        proxyIndex = indexForContactId( contactId );
    }
    if( !proxyIndex.isValid() )
    {
        FUNC_OUT
        return QString();
    }

    QModelIndex sourceIndex = mProxyModel->mapToSource( proxyIndex );
    if( !sourceIndex.isValid() )
    {
        FUNC_OUT
        return QString();
    }

    int row = sourceIndex.row();

    if( mContactListModel->startTextChat(row) )
    {
        return sourceIndex.data( ContactIdRole ).toString();
    }
    FUNC_OUT
    return QString();
}

QString
MetaContact::startVideoCall( const QString &contactId )
{
    FUNC_IN
    if( !(mCapabilities & CapabilityAudioCall
        || mCapabilities & CapabilityVideoCall
        || mCapabilities & CapabilityMediaCall) )
    {
        FUNC_OUT
        return QString();
    }

    QModelIndex proxyIndex;
    if( contactId.isEmpty() )
    {
        if( mProxyModel.isNull() )
        {
            FUNC_OUT
            return QString();
        }
        for( int i = 0; i < mProxyModel->rowCount(); ++i )
        {
            proxyIndex = mProxyModel->index( i, ColumnContact );
            int capabilities = proxyIndex.data( CapabilitiesRole ).toInt();
            if( (capabilities & CapabilityAudioCall)
                || (capabilities & CapabilityVideoCall)
                || (capabilities & CapabilityMediaCall) )
            {
                break;
            }
            proxyIndex = QModelIndex();
        }
    } else
    {
        proxyIndex = indexForContactId( contactId );
    }
    if( !proxyIndex.isValid() )
    {
        FUNC_OUT
        return QString();
    }

    QModelIndex sourceIndex = mProxyModel->mapToSource( proxyIndex );
    if( !sourceIndex.isValid() )
    {
        FUNC_OUT
        return QString();
    }

    int row = sourceIndex.row();

    if( mContactListModel->startVideoCall(row) )
    {
        FUNC_OUT
        return sourceIndex.data( ContactIdRole ).toString();
    }
    FUNC_OUT
    return QString();
}

QString
MetaContact::startVoIPCall( const QString &contactId )
{
    FUNC_IN
    if( !(mCapabilities & CapabilityAudioCall
        || mCapabilities & CapabilityMediaCall) )
    {
        FUNC_OUT
        return QString();
    }

    QModelIndex proxyIndex;
    if( contactId.isEmpty() )
    {
        if( mProxyModel.isNull() )
        {
            FUNC_OUT
            return QString();
        }
        for( int i = 0; i < mProxyModel->rowCount(); ++i )
        {
            proxyIndex = mProxyModel->index( i, ColumnContact );
            int capabilities = proxyIndex.data( CapabilitiesRole ).toInt();
            if( (capabilities & CapabilityAudioCall)
                || (capabilities & CapabilityMediaCall) )
            {
                break;
            }
            proxyIndex = QModelIndex();
        }
    } else
    {
        proxyIndex = indexForContactId( contactId );
    }
    if( !proxyIndex.isValid() )
    {
        FUNC_OUT
        return QString();
    }

    QModelIndex sourceIndex = mProxyModel->mapToSource( proxyIndex );
    if( !sourceIndex.isValid() )
    {
        FUNC_OUT
        return QString();
    }

    int row = sourceIndex.row();

    if( mContactListModel->startVoIPCall(row) )
    {
        FUNC_OUT
        return sourceIndex.data( ContactIdRole ).toString();
    }
    FUNC_OUT
    return QString();
}

bool
MetaContact::submit()
{
    FUNC_IN
    if( mContactDetails.isEmpty()
        && mMetaContactId.isEmpty()
        && mName.isEmpty()
        && mSurname.isEmpty()
        && mAvatarUri.isEmpty() )
    {
        // there is no data to write to disk
        // got the MetaContact deleted?
        return false;
    }
    // write data to local storage
    MetaContactStorage *mcs = MetaContactStorage::instance();

    if( mMetaContactId.isEmpty()
        || !mcs->containsMetaContactId(mMetaContactId) )
    { // creation mode
        if( mName.isEmpty()
            && mSurname.isEmpty() )
        {
            createMetaContactName();
        }
        mMetaContactId = mcs->createMetaContact( mName,
                                                 mSurname,
                                                 mContactDetails );
        // mark as autogenerated name
        mcs->setAutoNamed( mMetaContactId, mAutoNamed );
        mcs->setPresencePublication( mMetaContactId, mPresencePublication );
    } else
    {
        disconnectMetaContactStorage();
        if( mName.isEmpty()
            && mSurname.isEmpty() )
        {
            createMetaContactName();
        }
        mcs->setAutoNamed( mMetaContactId, mAutoNamed );
        mcs->setNameForMetaContactId( mMetaContactId, mName );
        mcs->setPresencePublication( mMetaContactId, mPresencePublication );
        mcs->setSurnameForMetaContactId( mMetaContactId, mSurname );
        mcs->setContactIdsForMetaContactId( mMetaContactId, mContactDetails );
        connectMetaContactStorage();
    }
    mcs->sync();

    FUNC_OUT
    return true;
}

/* ***
 * private
 * **/

bool
MetaContact::connectMetaContactStorage()
{
    FUNC_IN
    MetaContactStorage *metaContactStorage = MetaContactStorage::instance();
    if( !metaContactStorage )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( metaContactStorage,
                       SIGNAL(metaContactChanged(QString)),
                       this,
                       SLOT(onMetaContactStorageMetaContactChanged(QString)) );
    result &= connect( metaContactStorage,
                       SIGNAL(metaContactDeleted(QString)),
                       this,
                       SLOT(onMetaContactStorageMetaContactDeleted(QString)) );

    FUNC_OUT
    return result;
}

bool
MetaContact::connectProxyModel( QSortFilterProxyModel *model )
{
    FUNC_IN
    if( !model )
    {
        FUNC_OUT
        return false;
    }

    bool result = true;

    result &= connect( model,
                       SIGNAL(dataChanged(QModelIndex,QModelIndex)),
                       this,
                       SLOT(onDataChanged(QModelIndex,QModelIndex)) );
    result &= connect( model,
                       SIGNAL(modelReset()),
                       this,
                       SLOT(onModelReset()) );
    result &= connect( model,
                       SIGNAL(rowsInserted(QModelIndex,int,int)),
                       this,
                       SLOT(onRowsInserted(QModelIndex,int,int)) );
    result &= connect( model,
                       SIGNAL(rowsRemoved(QModelIndex,int,int)),
                       this,
                       SLOT(onRowsRemoved(QModelIndex,int,int)) );

    FUNC_OUT
    return result;
}

QStringList MetaContact::createCapabilitiesList( int capabilities ) const
{
    FUNC_IN
    QStringList list;

    if( capabilities & CapabilityTextChat )
    {
        list.append( CAPABILITY_TEXT );
    }
    if( capabilities & CapabilityAudioCall
        || capabilities & CapabilityMediaCall )
    {
        list.append( CAPABILITY_VOIP );
    }
    if( capabilities & CapabilityVideoCall
        || capabilities & CapabilityMediaCall )
    {
        list.append( CAPABILITY_VIDEO );
    }
    if( capabilities & CapabilityFileTransfer )
    {
        list.append( CAPABILITY_FILE );
    }

    FUNC_OUT
    return list;
}

void
MetaContact::createMetaContactName()
{
    FUNC_IN
    QString name;
    for( int i = 0; i < rowCount(); ++i )
    {
        QModelIndex index = this->index( i, ColumnContact );
        QString displayName = index.data( ContactAliasRole ).toString();
        QString contactId = index.data( ReadableContactIdRole ).toString();
        if( i == 0 )
        {
            // use first displayName as fallback
            name = contactId;
        }

        if( !displayName.isEmpty()
            && displayName != contactId )
        {
            // displayName is no contact ID but an alias
            setDisplayName( displayName );
            FUNC_OUT
            return;
        }
    }

    // name is a contact ID
    if( !name.isEmpty() )
    {
        setName( name );
    }
    mAutoNamed = true;
    FUNC_OUT
}

QString
MetaContact::createServiceNameFromContactId( const QString &contactId ) const
{
    FUNC_IN
    QString service = "";

    QPair<QString, QString> parts = splitContactId( contactId );

    QString accountPath = parts.first;
    QStringList pathSegments = accountPath.split( QString("/"), QString::SkipEmptyParts );

    if( pathSegments.count() < 7 )
    {
        // not expacted format of accountPath
        FUNC_OUT
        return QString();
    }

    service = pathSegments.at( 5 );

    if( service == QString("jabber") )
    {
        QString accountName = pathSegments.at(6);
        QStringList nameSegments = accountName.split( QString("_40") );
        nameSegments = nameSegments.at(1).split( QString("_2e") );
        QString serverName = nameSegments.at(0);

        if( serverName == QString("googlemail") )
            service = "google-talk";
        else if( serverName == QString("gmail") )
            service = "google-talk";
        else if( serverName == QString("facebook") ) // does facebook realy use it's own addresses? or is it the users email address?
            service = "facebook";
    }

    FUNC_OUT
    return service;
}

bool
MetaContact::disconnectMetaContactStorage()
{
    FUNC_IN
    MetaContactStorage *metaContactStorage = MetaContactStorage::instance();
    if( !metaContactStorage )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( metaContactStorage, 0, this, 0 );
}

bool
MetaContact::disconnectProxyModel( QSortFilterProxyModel *model )
{
    FUNC_IN
    if( !model )
    {
        FUNC_OUT
        return true;
    }

    FUNC_OUT
    return disconnect( model, 0, this, 0 );
}

QModelIndex
MetaContact::indexForContactId(const QString &contactId, int column) const
{
    FUNC_IN
    if( mProxyModel.isNull() )
    {
        FUNC_OUT
        return QModelIndex();
    }

    for( int i = 0; i < mProxyModel->rowCount(); ++i )
    {
        QModelIndex index = mProxyModel->index( i,
                                                ColumnContact,
                                                QModelIndex() );
        if( index.isValid() )
        {
            QString cid = index.data( ContactIdRole ).toString();
            if( cid == contactId )
            {
                FUNC_OUT
                return mProxyModel->index( i, column, QModelIndex() );
            }
        }
    }

    FUNC_OUT
    return QModelIndex();
}

void
MetaContact::initRoleNames()
{
    FUNC_IN
    QHash<int, QByteArray> rolenames;
    rolenames.insert( Qt::DisplayRole,          "displayName");
    rolenames.insert( ContactIdRole,            "contactId" );
    rolenames.insert( PresenceStateRole,        "presenceState");
    rolenames.insert( PresenceStateMessageRole, "presenceStateMessage");
    rolenames.insert( CapabilitiesRole,         "capabilities");
    rolenames.insert( SubscriptionRole,         "subscription");
    rolenames.insert( PublicationRole,          "publication");
    rolenames.insert( BlockedRole,              "blocked");
    rolenames.insert( RemovedRole,              "removed");
    rolenames.insert( ServiceNameRole,          "serviceName" );
    rolenames.insert( AccountIdRole,            "accountId" );
    rolenames.insert( ContactAliasRole,         "contactAlias" );
    rolenames.insert( ReadableContactIdRole,    "readableContactId" );
    setRoleNames( rolenames );
    FUNC_OUT
}

void
MetaContact::recreateFilter()
{
    FUNC_IN
    if( mProxyModel.isNull() )
    {
        FUNC_OUT
        return;
    }

    QString filterRegExp = "";

    foreach (QString contact, mContactDetails)
    {
        QRegExp rx("\\|");
        int pos = 0;
        int match = 0;

        while( (pos = rx.indexIn(contact, pos + match)) != -1 ) {
            match = 1;
            contact.insert( pos, QString("\\") );
            pos += rx.matchedLength();
        }

        if( !filterRegExp.isEmpty() )
        {
            filterRegExp.append( "|" );
        }
        filterRegExp.append( contact );
    }
    filterRegExp.prepend( "^(" );
    filterRegExp.append( ")$" );

    mProxyModel->setFilterRegExp( filterRegExp );

    FUNC_OUT
}

/* ***
 * private slots
 * **/

void
MetaContact::onContactListModelContactDeleted( const QString &contactId )
{
    FUNC_IN
    int row = rowForContactId( contactId );
    if( row >= 0 )
    {
        removeRow( row );
    }
    FUNC_OUT
}

void
MetaContact::onDataChanged( const QModelIndex &topLeft, const QModelIndex &bottomRight )
{
    FUNC_IN
    Q_UNUSED( topLeft );
    Q_UNUSED( bottomRight );

    if( mAutoNamed )
    {
        // generate a useful name
        createMetaContactName();
        if( !mAutoNamed )
        {
            submit();
        }
    }

    updateCapabilities();
    updatePresence();
    updatePresencePublication();

    FUNC_OUT
}

void
MetaContact::onMetaContactStorageMetaContactChanged( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId != mMetaContactId )
    {
        FUNC_OUT
        return;
    }

    MetaContactStorage *mcs = MetaContactStorage::instance();

    QString name = mcs->nameForMetaContactId( mMetaContactId );
    QString surname = mcs->surnameForMetaContactId( mMetaContactId );
    QStringList contactIds = mcs->contactIdsForMetaContactId( mMetaContactId );
    mAutoNamed = mcs->autoNamed( mMetaContactId );
    mPresencePublication = mcs->presencePublication( mMetaContactId );
    if( mPresencePublication == PRESENCE_PUBLICATION_ACCEPTED )
    {
        mPresencePublicationState = PresencePublicationPublished;
    } else if( mPresencePublication == PRESENCE_PUBLICATION_REJECTED )
    {
        mPresencePublicationState = PresencePublicationUnpublished;
    } else
    {
        mPresencePublicationState = PresencePublicationAnswerRequired;
    }
    emit presenceStateChanged( presenceState() );
    emit presencePublicationChanged( mPresencePublicationState );

    if( name != mName )
    {
        // update name
        mName = name;
        emit nameChanged( mName );
        emit displayNameChanged( displayName() );
    }

    if( surname != mSurname )
    {
        // update surname
        mSurname = surname;
        emit surnameChanged( mSurname );
        emit displayNameChanged( displayName() );
    }

    // update avatar uri
    // TODO: currently not supported

    if( contactIds.count() == mContactDetails.count()
        && contactIds.count() > 0 )
    {
        // update list of contact IDs
        mContactDetails = contactIds;
        recreateFilter();
        updateCapabilities();
        // update presence
        updatePresence();
        updatePresencePublication();
        emit dataChanged( index(0, 0), index(contactIds.count() - 1, ColumnCount -1) );
    } else
    {
        beginResetModel();
        // update list of contact IDs
        mContactDetails = contactIds;
        recreateFilter();
        // update capabilities
        updateCapabilities();
        // update presence
        updatePresence();
        updatePresencePublication();
        endResetModel();
    }

    FUNC_OUT
}

void
MetaContact::onMetaContactStorageMetaContactDeleted( const QString &metaContactId )
{
    FUNC_IN
    if( metaContactId != mMetaContactId )
    {
        FUNC_OUT
        return;
    }

    emit aboutToBeDeleted();
    setMetaContactId( QString() );
    emit deleted();
    FUNC_OUT
}

void
MetaContact::onModelReset()
{
    FUNC_IN

    updateCapabilities();
    updatePresence();
    updatePresencePublication();

    FUNC_OUT
}

void
MetaContact::onRowsInserted( const QModelIndex &parent, int first, int last )
{
    FUNC_IN
    Q_UNUSED( parent );
    Q_UNUSED( first );
    Q_UNUSED( last );

    updateCapabilities();
    updatePresence();
    updatePresencePublication();

    FUNC_OUT
}

void
MetaContact::onRowsRemoved( const QModelIndex &parent, int first, int last )
{
    FUNC_IN
    Q_UNUSED( parent );
    Q_UNUSED( first );
    Q_UNUSED( last );

    updateCapabilities();
    updatePresence();
    updatePresencePublication();

    FUNC_OUT
}

void
MetaContact::updateCapabilities()
{
    FUNC_IN
    if( mProxyModel.isNull() )
    {
        if( mCapabilities != CapabilityNone )
        {
            mCapabilities = CapabilityNone;
            emit capabilitiesChanged();
        }
        FUNC_OUT
        return;
    }

    int capabilities = 0;
    for( int i = 0; i < mProxyModel->rowCount(); ++i )
    {
        QModelIndex index = mProxyModel->index( i, ColumnContact );
        capabilities |= index.data( CapabilitiesRole ).toInt();
    }

    if( capabilities != mCapabilities )
    {
        mCapabilities = capabilities;
        QStringList capList = createCapabilitiesList( mCapabilities );
        emit capabilitiesChanged( capList );
    }
    FUNC_OUT
}

void
MetaContact::updatePresence()
{
    FUNC_IN
    if( mProxyModel.isNull() )
    {
        if( mPresencePublicationState == PresencePublicationPublished )
        {
            if( mPresence != PresenceStateOffline )
            {
                mPresence = PresenceStateOffline;
                emit presenceStateChanged( PRESENCE_STATE_NAMES.at(PresenceStateOffline) );
            }
        } else if( mPresence != PresenceStateUnknown )
        {
            mPresence = PresenceStateUnknown;
            emit presenceStateChanged( PRESENCE_STATE_NAMES.at(PresenceStateUnknown) );
        }
        FUNC_OUT
        return;
    }

    if( mPresencePublicationState == PresencePublicationAnswerRequired )
    {
        if( mPresence != PresenceStateUnknown )
        {
            mPresence = PresenceStateUnknown;
            emit presenceStateChanged( PRESENCE_STATE_NAMES.at(PresenceStateUnknown) );
        }
        FUNC_OUT
        return;
    }

    QSet<int> states;
    for( int i = 0; i < mProxyModel->rowCount(); ++i )
    {
        QModelIndex index = mProxyModel->index( i, ColumnState );
        states.insert( index.data(PresenceStateRole).toInt() );
    }

    QList<int> sortedStates = sortPresenceStates( states.toList() );

    if( sortedStates.count() > 0 )
    {
        if( mPresence != sortedStates.first() )
        {
            mPresence = sortedStates.first();
            emit presenceStateChanged( PRESENCE_STATE_NAMES.at(mPresence) );
        }
    } else
    {
        if( mPresence != PresenceStateOffline )
        {
            mPresence = PresenceStateOffline;
            emit presenceStateChanged( PRESENCE_STATE_NAMES.at(PresenceStateOffline) );
        }
    }
    FUNC_OUT
}

void
MetaContact::updatePresencePublication()
{
    FUNC_IN
    if( mProxyModel.isNull() )
    {
        if( mPresencePublication == PRESENCE_PUBLICATION_ACCEPTED )
        {
            mPresencePublicationState = PresencePublicationPublished;
        } else if( mPresencePublication == PRESENCE_PUBLICATION_REJECTED )
        {
            mPresencePublicationState = PresencePublicationUnpublished;
        } else
        {
            mPresencePublicationState = PresencePublicationAnswerRequired;
        }

        emit presencePublicationChanged( mPresencePublicationState );
        FUNC_OUT
        return;
    }

    if( mPresencePublication == PRESENCE_PUBLICATION_ACCEPTED )
    {
        // accept all unaccepted
        for( int i = 0; i < mProxyModel->rowCount(); ++i )
        {
            QModelIndex index = mProxyModel->index( i, ColumnContact );
            if( index.data(PublicationRole).toString() != "yes" )
            {
                mProxyModel->setData( index, "yes", PublicationRole );
            }
            if( index.data(SubscriptionRole).toString() == "no" )
            {
                mProxyModel->setData( index, "yes", SubscriptionRole );
            }
        }
        FUNC_OUT
        return;
    } else if( mPresencePublication == PRESENCE_PUBLICATION_REJECTED )
    {
        // reject all unaccepted
        rejectContact();
        FUNC_OUT
        return;
    } else
    {
        // check for changes
        for( int i = 0; i < mProxyModel->rowCount(); ++i )
        {
            QModelIndex index = mProxyModel->index( i, ColumnContact );
            if( index.data(PublicationRole).toString() == "yes" )
            {
                // there is already an accepted contact
                acceptContact();
                FUNC_OUT
                return;
            }
        }
        if( mPresencePublicationState != PresencePublicationAnswerRequired )
        {
            mPresencePublicationState = PresencePublicationAnswerRequired;
            emit presencePublicationChanged( mPresencePublicationState );
        }

    }
    FUNC_OUT
}

QDataStream &
operator<<( QDataStream &stream, const MetaContact &metaContact )
{
    QStringList contactIds = metaContact.contactIds();
    QString output = "[" + metaContact.metaContactId() + "]" + "\n"
                     + "name=" + metaContact.name() + "\n"
                     + "surname=" + metaContact.surname() + "\n"
                     + "details\\size=" + QString::number(contactIds.count()) + "\n";
    for( int i = 0; i < contactIds.count(); ++i )
    {
        output += "details\\i\\id=" + contactIds.at(i) + "\n";
    }

    return stream << output;
}
