/*
 * sortfilterproxymodel.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <QString>

#include "sortfilterproxymodel.h"

using namespace Peregrine;

SortFilterProxyModel::SortFilterProxyModel( QObject *parent )
    : QSortFilterProxyModel( parent )
    , mInverseFiltering( false )
{
    Q_UNUSED( parent )
}

SortFilterProxyModel::~SortFilterProxyModel()
{}

void SortFilterProxyModel::setInverseFiltering( bool enabled )
{
    if( enabled != mInverseFiltering )
    {
        mInverseFiltering = enabled;
        emit inverseFilteringChanged( mInverseFiltering );
        invalidateFilter();
    }
}

void SortFilterProxyModel::setModel( QObject *model )
{
    setSourceModel( dynamic_cast<QAbstractItemModel*>( model ) );

    if( m_selectionModel )
        delete m_selectionModel;

    m_selectionModel = new QItemSelectionModel( dynamic_cast<QAbstractItemModel*>( model ) );

    connect( m_selectionModel, SIGNAL( selectionChanged( QItemSelection, QItemSelection ) ), this, SIGNAL( selectionChanged( QItemSelection, QItemSelection ) ) );
}

void SortFilterProxyModel::sort( int column, SortOrder order )
{
    QSortFilterProxyModel::sort( column, static_cast<Qt::SortOrder>(order) );
}

void SortFilterProxyModel::select( int row, bool multiSelection )
{
    if( m_selectionModel )
    {
        if( multiSelection )
            m_selectionModel->select( mapToSource( index( row, 0 ) ), QItemSelectionModel::Toggle | QItemSelectionModel::Rows );
        else
            m_selectionModel->select( mapToSource( index( row, 0 ) ), QItemSelectionModel::ClearAndSelect | QItemSelectionModel::Rows );
    }
}

bool SortFilterProxyModel::inverseFiltering() const
{
    return mInverseFiltering;
}

bool SortFilterProxyModel::isSelected( int row )
{
    if( m_selectionModel && row > -1 )
        return m_selectionModel->isSelected( mapToSource( index( row, 0 ) ) );
    else
        return false;
}

void SortFilterProxyModel::clearSelection()
{
    if( m_selectionModel )
        m_selectionModel->clearSelection();
}


QList<QVariant> SortFilterProxyModel::getSelection( int role )
{
    QList<QVariant> selectionList;

    QList<QModelIndex> selectedIndexes = m_selectionModel->selectedIndexes();

    for (int i = 0; i < selectedIndexes.size(); ++i)
    {
        selectionList.append( selectedIndexes.at( i ).data( role ) );
    }

    return selectionList;
}

bool SortFilterProxyModel::filterAcceptsColumn( int source_column, const QModelIndex &source_parent ) const
{
    bool result = QSortFilterProxyModel::filterAcceptsColumn( source_column, source_parent );
    if( mInverseFiltering )
    {
        return !result;
    }
    return QSortFilterProxyModel::filterAcceptsColumn( source_column, source_parent );
}

bool SortFilterProxyModel::filterAcceptsRow( int source_row, const QModelIndex &source_parent ) const
{
    if( mInverseFiltering )
    {
        return !QSortFilterProxyModel::filterAcceptsRow( source_row, source_parent );
    }
    return QSortFilterProxyModel::filterAcceptsRow( source_row, source_parent );
}
