/*
* presencestates.h
*
* Copyright (C) 2009-2011 basysKom GmbH
* Copyright (C) 2009-2011 Nokia Corporation
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef PRESENCESTATES_H
#define PRESENCESTATES_H

#include <TelepathyQt4/Types>
#include <TelepathyQt4/Account>

#include <QString>
#include <QStringList>
#include <QList>

namespace Peregrine
{

static const QStringList PRESENCE_STATE_NAMES = ( QStringList() << "unset" << "offline" << "available" << "away" << "xa" << "hidden"
                                                  << "busy" << "unknown" << "error" );

static const Tp::Presence PRESENCE_UNSET = Tp::Presence( Tp::ConnectionPresenceTypeUnset, "unset", "" );
static const Tp::Presence PRESENCE_OFFLINE = Tp::Presence::offline();
static const Tp::Presence PRESENCE_AVAILABLE = Tp::Presence::available();
static const Tp::Presence PRESENCE_AWAY = Tp::Presence::away();
//static const Tp::Presence PRESENCE_BRB = Tp::Presence::brb(); // we don't use it because it's the same type as away
static const Tp::Presence PRESENCE_XA = Tp::Presence::xa();
static const Tp::Presence PRESENCE_HIDDEN = Tp::Presence::hidden();
static const Tp::Presence PRESENCE_BUSY = Tp::Presence::busy();
static const Tp::Presence PRESENCE_UNKNOWN = Tp::Presence( Tp::ConnectionPresenceTypeUnknown, PRESENCE_STATE_NAMES.at(Tp::ConnectionPresenceTypeUnknown), "" );
static const Tp::Presence PRESENCE_ERROR = Tp::Presence( Tp::ConnectionPresenceTypeError, PRESENCE_STATE_NAMES.at(Tp::ConnectionPresenceTypeError), "" );

static const QList<Tp::Presence> PRESENCE_STATES = ( QList<Tp::Presence>() << PRESENCE_UNSET << PRESENCE_OFFLINE << PRESENCE_AVAILABLE
                                                     << PRESENCE_AWAY << /*PRESENCE_BRB <<*/ PRESENCE_XA << PRESENCE_HIDDEN << PRESENCE_BUSY
                                                     << PRESENCE_UNKNOWN << PRESENCE_ERROR );

static const QStringList OFFLINE_PRESENCE_STATES = ( QStringList() << PRESENCE_STATE_NAMES.at(1) << PRESENCE_STATE_NAMES.at(2) << PRESENCE_STATE_NAMES.at(3) );

enum PresenceStates
{
    PresenceStateUnset,
    PresenceStateOffline,
    PresenceStateAvailable,
    PresenceStateAway,
    PresenceStateXa,
    PresenceStateHidden,
    PresenceStateBusy,
    PresenceStateUnknown,
    PresenceStateError,
    PresenceStateCount
};

static const QList<PresenceStates> PRESENCE_STATES_ORDER = ( QList<PresenceStates>() << PresenceStateAvailable << PresenceStateAway << PresenceStateBusy << PresenceStateXa
                                                             << PresenceStateHidden << PresenceStateOffline << PresenceStateUnknown << PresenceStateError << PresenceStateUnset);

QStringList presencesStatesForAccount( Tp::AccountPtr account );
QStringList sortPresenceStates( const QStringList &presenceStateNames );
QList<int> sortPresenceStates( const QList<int> &presenceStates );
}

#endif // PRESENCESTATES_H
