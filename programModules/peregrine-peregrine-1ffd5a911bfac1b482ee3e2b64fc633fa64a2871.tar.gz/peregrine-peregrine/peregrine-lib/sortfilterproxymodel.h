/*
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 * Copyright (C) 2009-2011 Nokia Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef SORTFILTERPROXYMODEL_H
#define SORTFILTERPROXYMODEL_H

#include <QAbstractItemModel>
#include <QItemSelection>
#include <QItemSelectionModel>
#include <QList>
#include <QSortFilterProxyModel>
#include <QVariant>

#include "contact/metacontactlistmodel.h"

namespace Peregrine
{

class SortFilterProxyModel : public QSortFilterProxyModel
{
    Q_OBJECT

public:
    Q_ENUMS( SortOrder )
    Q_PROPERTY( bool inverseFiltering READ inverseFiltering WRITE setInverseFiltering NOTIFY inverseFilteringChanged )

    enum SortOrder {
        AscendingOrder = Qt::AscendingOrder,
        DescendingOrder = Qt::DescendingOrder
    };

    SortFilterProxyModel( QObject *parent = 0 );
    ~SortFilterProxyModel();

    Q_INVOKABLE void setInverseFiltering( bool enabled );
    Q_INVOKABLE void setModel( QObject *model );
    Q_INVOKABLE void sort( int column, SortOrder order = AscendingOrder  );
    Q_INVOKABLE void select( int row, bool multiSelection  = false );
    Q_INVOKABLE bool inverseFiltering() const;
    Q_INVOKABLE bool isSelected( int row );
    Q_INVOKABLE void clearSelection();
    Q_INVOKABLE QList<QVariant> getSelection( int role = Qt::DisplayRole );

private:
    Q_DISABLE_COPY( SortFilterProxyModel );

    bool mInverseFiltering;
    QItemSelectionModel* m_selectionModel;

protected:
    virtual bool filterAcceptsColumn( int source_column, const QModelIndex & source_parent ) const;
    virtual bool filterAcceptsRow( int source_row, const QModelIndex & source_parent ) const;

signals:
    void inverseFilteringChanged( bool enabled );
    void selectionChanged ( const QItemSelection & selected, const QItemSelection & deselected );

};

}

//Q_DECLARE_METATYPE( QAbstractItemModel * )

#endif // SORTFILTERPROXYMODEL_H
