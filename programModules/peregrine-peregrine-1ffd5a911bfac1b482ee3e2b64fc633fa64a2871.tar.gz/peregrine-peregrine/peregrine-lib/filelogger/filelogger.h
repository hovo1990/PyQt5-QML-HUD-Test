/*
* filelogger.h
*
* Copyright (C) 2009-2011 basysKom GmbH
* Copyright (C) 2009-2011 Nokia Corporation
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef FILELOGGER_H
#define FILELOGGER_H

#include <QObject>

class QFile;
class QTextStream;

class FileLogger : public QObject
{
    Q_OBJECT
    public:
        static inline FileLogger *instance();
        static inline void cleanUp();
        void write( QString file, int line, QString function, QString message);

    protected:
            FileLogger();
            ~FileLogger();

    private:
        static FileLogger *m_Instance;
        QFile* m_File;
        QTextStream* m_TextStream;
};

#define F_LOG(_MSG_) FileLogger::instance()->write( __FILE__,__LINE__,__FUNCTION__,_MSG_ );

#ifndef F_LOG
#define F_LOG(_MSG_);
#endif

#endif // FILELOGGER_H
