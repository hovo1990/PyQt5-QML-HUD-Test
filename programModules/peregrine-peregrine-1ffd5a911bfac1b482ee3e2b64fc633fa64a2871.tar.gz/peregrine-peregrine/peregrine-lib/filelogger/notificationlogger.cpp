/*
 * notificationlogger.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <QChar>
#include <QDateTime>
#include <QDir>
#include <QIODevice>

#include "notificationlogger.h"

using namespace Peregrine;

NotificationLogger::NotificationLogger(QObject *parent) :
    QObject(parent)
{
    QString notificationsFile = QDir::homePath();

    if( !notificationsFile.endsWith( QDir::separator() ) )
        notificationsFile.append(  QDir::separator() );

    notificationsFile.append( ".peregrine_notifications" );

    m_file = new QFile( notificationsFile );
    m_file->open( QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text );
}

NotificationLogger::~NotificationLogger()
{
    if( m_file->isOpen() )
    {
        m_file->flush();
        m_file->close();
    }
}

void NotificationLogger::write( QString title, QString message, NotificationTypes type )
{
    Q_ASSERT( m_file != NULL && m_file->isOpen() );

    QString line = QDateTime::currentDateTime().toString();

    switch( type )
    {
    case NotificationTypeError:
        line.append( " [ERROR] " );
        break;

    case NotificationTypeWarning:
        line.append( " [WARNING] " );
        break;

    case NotificationTypeNotice:
        line.append( " [NOTICE] " );
        break;

    case NotificationTypeDebug:
        line.append( " [DEBUG] " );
        break;

    default:
        line.append( " [NOTICE] " );
        break;
    }

    line.append( title );
    line.append( ": " );

    line.append( message );
    line.append( QChar( '\n' ) );

    m_file->write( line.toLatin1() );
    m_file->flush();
}
