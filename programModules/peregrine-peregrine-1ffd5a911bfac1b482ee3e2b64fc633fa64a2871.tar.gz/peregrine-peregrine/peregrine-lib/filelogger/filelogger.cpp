/*
* filelogger.cpp
*
* Copyright (C) 2009-2011 basysKom GmbH
* Copyright (C) 2009-2011 Nokia Corporation
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "filelogger.h"

#include <QCoreApplication>
#include <QFile>
#include <QDebug>
#include <QThread>
#include <QDateTime>
#include <QTextStream>




FileLogger *FileLogger::m_Instance = 0;

FileLogger::FileLogger()
    : QObject(),
    m_File( 0 ),
    m_TextStream( 0 )
{
    m_File = new QFile( "/tmp/" + QCoreApplication::instance()->applicationName() + ".log", this );

    if (m_File->open(QFile::WriteOnly | QFile::Truncate)) {

        m_TextStream = new QTextStream( m_File );
    } // if
}


FileLogger::~FileLogger()
{
    if ( m_TextStream ) {
        m_TextStream->flush();
        m_File->close();

        delete m_TextStream;
    } // if
}

FileLogger *FileLogger::instance()
{
    if( !m_Instance )
    {
        m_Instance = new FileLogger();
    }
    
    return m_Instance;
}

void FileLogger::cleanUp()
{
    delete m_Instance;
    m_Instance = 0;
}

void FileLogger::write( QString file, int line, QString function, QString message )
{
    if ( !m_TextStream ) {
        return;
    } // if

    QDateTime dateTime = QDateTime::currentDateTime();
    Qt::HANDLE threadId = QThread::currentThreadId();

    QString logMessage = QString("%1 (%2): T.%3:[%4] %5() : %6")
    .arg(file)
    .arg(line)
    .arg((quint32)threadId)
    .arg(dateTime.toString( "HH:mm:ss:zz" ))
    .arg(function)
    .arg(message);

    qDebug() << __FILE__ << logMessage;
    *m_TextStream << logMessage << "\n";
    m_TextStream->flush();
}
