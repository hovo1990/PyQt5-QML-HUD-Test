/*
 * peregrineservicenames.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "peregrineservicenames.h"
#include "peregrineDebugHelper.h"
#include "contact/contactlistmodelinterface.h"

#include <QDebug>

using namespace Peregrine;

QString
Peregrine::serviceNameForAccount( Tp::AccountPtr account )
{
    FUNC_IN
    if( account.isNull() )
    {
        qWarning() << __PRETTY_FUNCTION__ << "account object is NULL";
        FUNC_OUT
        return QString();
    }

    QString serviceName = account->serviceName();
    QString iconName = account->iconName();
    if( serviceName.isEmpty() )
    {
        if( iconName.isEmpty() )
        {
            FUNC_OUT
            return serviceNameForAccountId( account->objectPath() );
        }
        serviceName = iconName;

        if( serviceName.startsWith("im-") )
        {
            serviceName.remove( 0, 3 );
        }
    }

    if( serviceName == "xmpp" )
    {
        serviceName = "jabber";
    }

    if( serviceName == "jabber" )
    {
        if( iconName.endsWith( "google-talk") )
        {
            serviceName = "google-talk";
        } else if( iconName.endsWith("facebook") )
        {
            serviceName = "facebook";
        } else
        {
            if( account->parameters().contains("server") )
            {
                QString server = account->parameters().value("server").toString();
                if( server == "talk.google.com" )
                {
                    serviceName = "google-talk";
                } else if( server.endsWith("facebook.com") )
                {
                    serviceName = "facebook";
                }
            }
        }
    }

    FUNC_OUT
    return serviceName;
}

QString
Peregrine::serviceNameForAccountId( const QString &accountId )
{
    FUNC_IN
    QStringList pathSegments = accountId.split( QString("/"), QString::SkipEmptyParts );

    if( pathSegments.count() < 7 )
    {
        qWarning() << __PRETTY_FUNCTION__ << "unexpected format of account ID";
        // not expacted format of accountPath
        FUNC_OUT
        return QString();
    }

    QString serviceName = pathSegments.at( 5 );

    if( serviceName == QString("jabber") )
    {
        QString accountName = pathSegments.at(6);
        QStringList nameSegments = accountName.split( QString("_40") );
        nameSegments = nameSegments.at(1).split( QString("_2e") );
        QString serverName = nameSegments.at(0);

        if( serverName == QString("googlemail") )
            serviceName = "google-talk";
        else if( serverName == QString("gmail") )
            serviceName = "google-talk";
        else if( serverName == QString("facebook") ) // does facebook realy use it's own addresses? or is it the users email address?
            serviceName = "facebook";
    }

    FUNC_OUT
    return serviceName;
}

QString
Peregrine::serviceNameForContactId( const QString &contactId )
{
    FUNC_IN
    QString service = "";

    QPair<QString, QString> parts = ContactListModelInterface::splitContactId( contactId );

    QString accountId = parts.first;
    service = serviceNameForAccountId( accountId );

    FUNC_OUT
    return service;
}
