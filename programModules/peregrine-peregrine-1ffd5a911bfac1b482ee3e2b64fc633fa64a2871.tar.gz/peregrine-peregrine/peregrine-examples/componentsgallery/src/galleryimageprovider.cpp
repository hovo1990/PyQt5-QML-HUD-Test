/*
 * galleryimageprovider.cpp
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <QColor>
#include <QFile>
#include <QImageReader>
#include <QPixmap>
#include <QSize>
#include <QString>

#include "galleryimageprovider.h"

#ifndef QMLPATH
#define QMLPATH "/usr/local/share/peregrine/peregrinecomponentsgallery"
#endif

GalleryImageProvider::GalleryImageProvider() :
        QDeclarativeImageProvider( QDeclarativeImageProvider::Pixmap )
{}

GalleryImageProvider::~GalleryImageProvider()
{}

QPixmap GalleryImageProvider::requestPixmap( const QString &id, QSize *size, const QSize &requestedSize )
{
    QPixmap pixmap;

    QString imagePath = QMLPATH "/images/";

    if( QFile::exists( imagePath + id ) )
    {
        QImageReader imageReader( imagePath + id );

        if( requestedSize.isValid() )
            imageReader.setScaledSize( requestedSize );

        pixmap = QPixmap::fromImageReader( &imageReader );
    }

    if( !pixmap )
    {
        // No image found: return a red pixmap
        int width = requestedSize.width() > 0 ? requestedSize.width() : 50;
        int height = requestedSize.height() > 0 ? requestedSize.height() : 50;

        pixmap = QPixmap( width, height) ;

        pixmap.fill( QColor("red").rgba() );
    }

    if( size )
        *size = pixmap.size();

    return pixmap;
}
