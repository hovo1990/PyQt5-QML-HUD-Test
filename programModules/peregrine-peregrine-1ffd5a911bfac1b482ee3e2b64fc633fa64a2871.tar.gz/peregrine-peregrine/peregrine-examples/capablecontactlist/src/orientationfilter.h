/*
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef ORIENTATIONFILTER_H
#define ORIENTATIONFILTER_H

#include <QObject>
#include <QOrientationFilter>
#include <QOrientationReading>
#include <QOrientationSensor>
#include <QRect>



class OrientationFilter : public QObject, public QtMobility::QOrientationFilter
{
    Q_OBJECT

    Q_PROPERTY(int orientation READ orientation WRITE setOrientation NOTIFY orientationChanged )
    Q_PROPERTY(bool lock READ isLocked WRITE setLocked NOTIFY lockChanged)
    Q_PROPERTY(QVariant visibleArea READ visibleArea WRITE setVisibleArea NOTIFY visibleAreaChanged)

public:

    explicit OrientationFilter(QObject *parent = 0);

    int orientation() const;
    void setOrientation( int orientation, bool lock = false );

    bool isLocked() const;
    void setLocked( bool lock );

    QVariant visibleArea() const;
    void setVisibleArea( QVariant visibleArea );

    virtual bool filter(QtMobility::QOrientationReading *reading);

public slots:
    void onVisibleAreaChanged( const QRect& rect );

signals:
    void orientationChanged();
    void lockChanged();
    void visibleAreaChanged( QVariant visibleArea );

private:
    QtMobility::QOrientationSensor m_sensor;
    int m_orientation;
    bool m_lockOrientation;
    QVariant m_visibleArea;
};

#endif // ORIENTATIONFILTER_H
