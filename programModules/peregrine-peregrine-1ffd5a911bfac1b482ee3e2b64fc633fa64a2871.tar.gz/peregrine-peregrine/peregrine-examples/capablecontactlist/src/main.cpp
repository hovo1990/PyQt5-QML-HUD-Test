/*
 *
 * Copyright (C) 2009-2011 basysKom GmbH
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#include <QtGui/QApplication>
#include <QGLFormat>
#include <QDeclarativeContext>
#include <QDeclarativeEngine>
#include <QDeclarativeView>
#include <QProcessEnvironment>
#include <MComponentData>

#include "orientationfilter.h"

#ifndef QMLPATH
#define QMLPATH "/usr/local/share/peregrine/peregrinecapablecontactlist"
#endif

int main(int argc, char *argv[])
{
    // set default graphics system to raster for now
    QApplication::setGraphicsSystem( "raster" );
    QApplication app(argc, argv);

    MComponentData mcd( argc, argv );

    QDeclarativeView view;
    QDeclarativeEngine *engine = view.rootContext()->engine();

    engine->setProperty( "BRIDGESET", "common" );
    engine->setProperty( "UX", "common" );

    // connect to quit() signal
    QObject::connect( engine, SIGNAL(quit()), &app, SLOT(quit()) );

    // but use a QGLWidget viewport
    QGLFormat format = QGLFormat::defaultFormat();
    format.setSampleBuffers( false );

    // create QGLWidget and set as viewport
    QGLWidget *glWidget = new QGLWidget( format );
    glWidget->setAutoFillBackground( true );
    view.setViewport( glWidget );

    OrientationFilter of;
    of.setLocked( false );
    engine->rootContext()->setContextProperty("orientation", &of);
    engine->rootContext()->setContextProperty("qApp", &of);
    engine->rootContext()->setContextProperty("visibleArea", &of);

    // set base dir
    engine->setBaseUrl( QUrl::fromLocalFile(QMLPATH) );

    // set QML file to load as content
    view.setSource(QUrl::fromLocalFile( QMLPATH + QString("/main.qml")) );
    view.setResizeMode( QDeclarativeView::SizeRootObjectToView );

    // show application on screen
    view.showFullScreen();

    // start event loop
    return app.exec();
}
